# FOOTBALL EDGE — BATCH05A.3 RESULT
Date: 2026-10-07
Scope: LOCAL/OFFLINE ONLY. No deploy. No real API. No production/model coefficient change.

## Before (independent audit findings)
- Batch05A.2 manifest/model lock accepted, but observed suite result was 25 PASS / 1 FAIL.
- D1 integration ACK could use SQLite/CURRENT_TIMESTAMP (real wall clock) while prediction used fake clock, causing ACK_BEFORE_PREDICTION / ACK_BEFORE_CUTOFF.
- Owner acquire conflict existed, but mutation endpoints did not enforce owner lease/fence.
- Capture load was not pilot-isolated.

## After
1. One injected clock contract is used by observation generation, ACK validation readback time, local SQLite recorder, legacy A2 staging persistence test path, and A3 D1 bridge persistence. `Math.max(clock.now(), Date.now())` was removed; no ACK gate was relaxed.
2. A3 DB owner uses monotonic fencing token. Budget/session/capture/bundle writes require matching pilot+owner+fence+unexpired lease at DB write. Lease transfer increments fence. Release expires rather than deletes owner row, preserving monotonic fencing.
3. Budget rejects total_requests regression and stop_reason erasure.
4. Captures/locked bundles/OLD rows carry pilot_id + owner_fence in A3 staging schema. Reads/restart/export are pilot-scoped.
5. Restart validates locked observation content_fingerprint plus per-tick capture record_id/payload_hash/endpoint/fixture/cutoff source identity. Tamper => fail closed before provider request.
6. Full offline HTTP path exercised: Node orchestrator -> authenticated Worker handler -> SQLite/D1 adapter -> SERVER-shaped ACK/readback -> restart. This is local emulation, NOT remote SERVER ACK verification.
7. Prepared staging Worker entry, config, guarded remote CLI (run/stop/export) and remote plan. Run requires explicit FE_APPROVE_REMOTE_SMOKE=YES. Nothing remote was executed.

## Evidence / tests
- `evidence/BATCH05A3_REGRESSION_EVIDENCE.json`: clock, lease competition/fencing, pilot isolation, HTTP E2E, tamper/restart.
- `evidence/BATCH05A3_FULL_TESTS.log`: 27 test files PASS / 0 FAIL.
- Syntax: all JS/MJS under prediction_v2 and staging_kit PASS `node --check`.
- probability-engine SHA256 remains `194b0c5b9870dbdcb4e06b2a823e1b0afd81f6626fb98c44917172de87257b16`.
- Exact P2.0.5.2 OLD reference remains `a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844`.

## Environment
Node v22.16.0; built-in `node:sqlite` (experimental warning); local filesystem; injected fake clock; fake API-Football transport; in-process authenticated Worker Request/Response handler. Network real calls = 0. Deployments = 0.

## Remaining blockers
Remote Worker route, real Cloudflare D1 semantics, staging binding/hostname, remote auth/lease behavior, actual SERVER ACK across network, API-Football quota/status and real provider transport remain UNVERIFIED. Therefore this package does NOT claim remote smoke readiness and does NOT claim NEW > OLD.

## Production baseline
No standalone production frontend bytes were introduced. Frozen production frontend is reference-only hash `a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844` where used as the exact P2.0.5.2 baseline reference. Production was not modified.
