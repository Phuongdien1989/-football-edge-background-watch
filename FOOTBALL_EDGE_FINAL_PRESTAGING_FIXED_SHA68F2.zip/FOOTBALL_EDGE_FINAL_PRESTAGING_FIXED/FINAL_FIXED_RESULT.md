# FINAL PRESTAGING FIXED — independent completion

Scope: local/offline only. No deploy, provider network, production change or model coefficient change.

## Result
29/29 test programs PASS; 82 JS/MJS syntax checks PASS on Node v24.19.0.
The two previously reproduced blockers are closed in offline SQLite/D1 and HTTP emulation.

| Probe | Before | After |
|---|---|---|
| Change statistics payload_json, preserve payload_hash | Restart accepted; 5 more provider attempts | RESTART_STATE_FAILURE; 0 new attempts |
| Change discovery payload, preserve hash | Discovery bytes not independently checked | Restart fails before provider attempt |
| Change raw text/envelope, observation, paper or exact OLD payload | Stored columns trusted on parts of restore | Content validation fails before provider attempt |
| First write with false payload hash | No raw-byte recomputation in A3 bridge | Rejected; no capture row |
| Delay budget save 11/null; concurrent save 20/OPERATOR_STOP | State regressed to 11/null | CAS rejects delayed write; 20/OPERATOR_STOP retained |
| HTTP stop while active runner is between ticks, restart/export | Stop depended on taking/releasing runner lease | Authenticated monotonic stop; 5 total attempts; 0 on restart; full evidence retained |

## Changes
- `prediction_v2/capture-integrity.js`: canonical representation matching capture contract, SHA256 of exact raw text or canonical payload, parsed/raw agreement and identity checks.
- `staging_kit/batch05a3-staging-bridge.js`: durable capture envelope/hash, pre-write/readback validation, full bundle validation on restore, atomic budget CAS/revision and DB counter/stop predicates, sticky session stop, dedicated operator-stop mutation, full evidence bytes in export.
- `staging_kit/batch05a3-http-d1-bridge.js`: returns committed budget revision to Node client; authenticated stop route.
- `staging_kit/batch05a-smoke-orchestrator.mjs`: validates recovered raw and observation content, locks discovery source identity, obtains lease before state read, rejects missing budget, checks durable stop before tick and reports durable final budget.
- `prediction_v2/local-evidence-recorder.mjs`: preserves exact capture envelope/raw text and recomputes capture hash before local write.
- `staging_kit/batch05a-final-remote-cli.mjs`: stop uses server stop route without taking runner lease.
- Staging-only schema adds capture_json/capture_envelope_hash. Existing A3 evidence without these bytes is not silently repaired; restart fails closed.
- `prediction_v2/test-final-blockers-fixed.mjs`: first-write validation, six tamper probes, delayed SQL interleavings with/without operator stop, active HTTP stop/restart/full export and pilot isolation.

## Evidence
`evidence/FINAL_FIXED_PROBES.json`, `evidence/FINAL_FIXED_FULL_TESTS.log`, `evidence/FINAL_FIXED_TEST_SUMMARY.json`.
All HTTP provider inputs are synthetic. SERVER-shaped ACKs were exercised against SQLite/D1-compatible emulation, not remote Cloudflare D1.
Historical raw replay remains limited: 47 captures, 15-fixture universe, 0 populated stats and 0 market offers in that artifact. No new real data collected; no lift/calibration result.

## Locks
Probability engine: 194b0c5b9870dbdcb4e06b2a823e1b0afd81f6626fb98c44917172de87257b16 (unchanged byte-for-byte from input).
Exact runnable OLD fixture: b38b8f3d398db714b7c6a6e7c2e3de0a8cf9e317bb408942f4bcbe8e5a754714 (unchanged).
Frozen P2.0.5.2 frontend reference: a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844. Standalone frontend bytes are absent; this is a reference, not a verified production read or rollback file.

## Remote checkpoint
Code and offline tests complete within the requested scope. Remote deployment/runtime/ACK/quota remain unverified. Before remote execution, confirm dedicated staging Worker URL/name, dedicated D1 name/ID, bridge token and provider key through secret bindings, prior staging version (if any), and explicit approval for only 1 fixture/600 seconds/40 cumulative attempts. No larger pilot or production deployment authorized.
