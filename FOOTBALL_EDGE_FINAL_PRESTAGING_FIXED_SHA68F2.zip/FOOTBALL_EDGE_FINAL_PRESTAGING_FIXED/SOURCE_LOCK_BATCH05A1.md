# Batch05A.1 source lock
Parent artifact: FOOTBALL_EDGE_BATCH05A_OFFLINE_PREPILOT_2026-10-07.zip
Parent Batch05A was independently reported by user as manifest-matched with 24 tests PASS and unchanged probability engine.
This Batch05A.1 modifies only shadow/staging/local-prepilot code/tests/docs/evidence in this package.
Frozen production reference SHA256: a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844
Probability engine SHA256 (unchanged): 194b0c5b9870dbdcb4e06b2a823e1b0afd81f6626fb98c44917172de87257b16
No deploy and no real provider call performed.
