# BATCH04 SOURCE / EVIDENCE INVENTORY

## Locked inputs

- Batch03.1 ZIP SHA256: `f21a829fddfb691337546291806305a7102a02ba52468335183b3aee2a504fa4`
- Batch03.1 source-tree manifest SHA256: `fb171421af882a90af99c1d8ec86219969e4d7bbc6326311878c0e902f393a75`
- Batch03.1 lineage branch head: `8f8fb24d7c76c9cc8b0ab8d5c0b07af6b73e0026`
- Exact frozen P2.0.5.2 frontend SHA256: `a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844`

## Existing collector / persistence source read

### `v2-raw-capture`
- branch head: `a0273ca36d661d0d7ebe0fbf5a623282cec1792c`
- `schema.sql` blob: `2231904d8af6b253732122584a699f5da668996e`
- `worker.js` blob: `771ee5e5ffff78428b354c03def80b2e03a18f53`
- `export-real-raw.mjs` blob: `b4e1b37abca123fcc040ea7130c7e455fda87be3`

Existing raw schema already separates `request_started_at` and `received_at` and stores payload hashes. The worker knows endpoint-evidence kinds including `LIVE_ODDS` and `PRE_ODDS`; the stored real artifact available for Batch03/04 nevertheless contains no `/odds/live` requests.

### `v2-foundation`
- branch head: `fba2e609ef20c8ede7df6ef9f57f36513245d511`
- `v2/v2_ingest_core.js` blob: `283813e275835c424cf747811be3ed6542c54f07`
- `v2/v2_shadow_capture_core.js` blob: `b962208709414f903988945003f3830521e033a6`
- `v2/v2_persist_d1.js` blob: `1bce455743e9d10776a4a22af90bda353359b6b4`

These are reference sources only in Batch04. Production is untouched.

## Exact OLD source

Batch04 does not implement a similar/approximate OLD engine. The staging bridge calls the exact P2.0.5.2 runtime functions after the patcher verifies the whole HTML SHA256.

Selected exact function source hashes from P2.0.5.2 are stored in `prediction_v2/old-exact-function-manifest.json`, including:
- `watchEvaluate`
- `watchApplyState`
- `h1WatchEvaluate`
- `h1WatchApplyState`
- `hcEvaluate`
- `feMasterRankMeta` dependency is required by the runtime bridge.

## Evidence requirement table

| Data required | Planned source | Availability proof | Stored as | Current blocker / note |
|---|---|---|---|---|
| Independent live universe | `/fixtures?live=all` | response `received_at` | raw capture + fixture universe snapshot | Must not use OLD rank/TOP to select membership |
| Fixture state / score / clock | `/fixtures?live=all` / detail fixture | `received_at`, provider fields if present | full raw payload history | Missing minute/score = unmodelable, fixture stays denominator |
| Live statistics | `/fixtures/statistics?fixture=` | `received_at` | every snapshot, never overwrite | Existing real artifact is sparse; Batch04 distinguishes EMPTY_VALID/MISSING/FETCH_ERROR/STALE |
| Events | `/fixtures/events?fixture=` | `received_at`; event clock retained separately | every payload + event history | Late events may correct outcomes, never prediction |
| Live market | `/odds/live?fixture=` | `received_at` + provider `update` when present | raw bookmaker/bet/value rows | Existing real artifact has no market feed |
| Pre-market reference | `/odds?fixture=` | same | raw rows | optional context; not used as a hard gate |
| Lineups | `/fixtures/lineups?fixture=` | same | raw payload | refresh slower than live stats |
| Fixture player stats | `/fixtures/players?fixture=` | same | raw payload | optional if provider returns none |
| Injuries | `/injuries?fixture=` | same | raw payload | EMPTY_VALID must differ from missing/fetch error |
| Standings | `/standings?league=&season=` | same | raw context payload | slow context |
| Team season statistics | `/teams/statistics` | same | home/away role-labelled payloads | feeds existing B2 context features |
| Recent fixtures | `/fixtures?team=&last=8` | same | home/away role-labelled payloads | slow context |
| Season players | `/players?team=&season=` | same | home/away role-labelled payloads | pagination beyond page 1 is not yet implemented in staging collector core |
| OLD FT/H1 exact output | exact P2.0.5.2 runtime functions | same evaluation cutoff + baseline SHA | immutable OLD exact-output record | Requires staging page bridge; current historical raw artifact cannot reconstruct this |
| OLD HC exact output | exact P2.0.5.2 `hcEvaluate` | same cutoff + exact `preBaseline` | immutable OLD exact-output record | Full-universe exact HC remains conditional on exact preBaseline capture; not silently approximated |
| NEW feature packet | Batch04 capture adapter + existing B2/B3 code | only captured inputs `received_at <= cutoff` | immutable observation feature snapshot | Missing supported feature is declared in `capture_feature_support.unsupported` |
| Prediction snapshot | existing B3 model, unchanged | created at cutoff after feature build | locked prediction record | Must persist before outcome |
| Paper market snapshot | actual supported market rows only | market source provenance at cutoff | locked paper record | H1/FT/H2 period separation preserved |
| Persistence acknowledgement | local SQLite in Batch04 tests; staging D1 kit prepared | ACK returned only after commit + readback | ACK table / response | Local ACK is `LOCAL_DURABLE_TEST`, not SERVER. Staging server ACK is unverified until pilot |
| Outcome | later event/snapshot payloads | their own later `received_at` | append-only outcome revisions | cannot rewrite locked feature/prediction |
| Provider quota | `/status` + rate-limit headers during approved pilot | captured provider response | provider-status capture | **UNVERIFIED in Batch04**. Do not assume 75K is currently active |
