# Batch05A.3 remote plan — PREPARED, NOT EXECUTED

Status: LOCAL/OFFLINE ONLY. This document is not approval to deploy or call API-Football.

## Runtime boundary
Node owns provider collection/exact OLD VM. A staging-only Worker route owns authenticated persistence into a staging D1 binding. Production P2.0.5.2 is not a target.

## Required staging configuration
- Apply `staging_kit/batch05a3-staging-schema.sql` to a NEW/DEDICATED staging D1 database (schema contains additive A3 pilot/fence columns).
- Bind it as `BATCH05A3_STAGING_DB` only on the staging Worker.
- Secret `BATCH05A3_BRIDGE_TOKEN`; Node uses the same secret.
- Configure `batch05a3-staging-config.example.json` with the staging URL, a unique owner ID and pilot ID.
- Before any run, independently verify the hostname is staging and not the frozen production URL/version.

## Prepared commands (DO NOT RUN in this batch)
Deploy bridge after approval: `npx wrangler deploy staging_kit/batch05a3-staging-worker-entry.js --env staging` only after reviewing the staging-only diff and binding. No deploy was performed here.
Remote run after separate approval: `FE_APPROVE_REMOTE_SMOKE=YES BATCH05A3_BRIDGE_TOKEN=... APISPORTS_KEY=... node staging_kit/batch05a3-remote-cli.mjs run staging_kit/batch05a3-staging-config.json > evidence/REMOTE_SMOKE.json`
Operator stop: `BATCH05A3_BRIDGE_TOKEN=... node staging_kit/batch05a3-remote-cli.mjs stop staging_kit/batch05a3-staging-config.json`
Evidence export: `BATCH05A3_BRIDGE_TOKEN=... node staging_kit/batch05a3-remote-cli.mjs export staging_kit/batch05a3-staging-config.json > evidence/REMOTE_EXPORT.json`
Rollback: stop the pilot, export evidence, revoke bridge token, roll Worker staging deployment back to its prior staging version, and retain the dedicated D1 evidence database read-only. Production rollback is not involved because production must not be changed.

## Remaining remote blockers
No remote Worker/D1/API call has been executed. Therefore actual Cloudflare D1 semantics, deployed route/auth, SERVER ACK across the real network, API quota/status, and staging hostname safety are NOT VERIFIED. Do not label remote smoke ready until an independent review approves deployment and a staging preflight proves these items.
