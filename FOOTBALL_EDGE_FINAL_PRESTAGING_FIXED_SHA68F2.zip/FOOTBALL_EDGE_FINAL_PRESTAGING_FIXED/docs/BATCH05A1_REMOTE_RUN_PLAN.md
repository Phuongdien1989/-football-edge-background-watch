# Batch05A.1 remote staging smoke plan — PREPARED, NOT EXECUTED

## Runtime decision
The completed orchestrator is a **Node 22 separate smoke runner**. It uses `node:fs` for evidence export and the guarded `node:vm` P2.0.5.2 exact-runtime helper. It is **not claimed to be a Cloudflare Worker entrypoint**. The existing Cloudflare modules remain persistence/budget adapters only.

## Offline preflight now
```bash
node staging_kit/batch05a1-remote-preflight.mjs
```
This validates the target config and probability-engine hash. It makes zero provider calls and deploys nothing.

## Local regression / smoke
```bash
node prediction_v2/test-batch05a-smoke.mjs
node prediction_v2/test-batch05a1-regressions.mjs
```
The smoke uses injected fake transport and local SQLite durable ACK.

## Remote staging command sequence AFTER explicit approval
1. Re-verify production/model locks and staging account/target. Do not point any command at production.
2. Apply/check `staging_kit/batch04-staging-schema.sql` only against the dedicated staging D1 database.
3. Use `createD1BudgetStateStore(db,pilotId)` so the 40-attempt budget survives restart. Never use `MemoryBudgetStateStore` remotely.
4. Use `persistCaptureD1` for captures and `persistLockedPredictionStaging` for immutable bundles. Remote ACK must be `ack_origin=SERVER`, `server_verified=true`, and pass readback/fingerprint/timestamp validation.
5. The Node smoke runner must be wired to a **staging-only persistence bridge** that invokes those D1 adapters. This bridge is the remaining remote integration prerequisite; no direct D1 binding exists inside a standalone Node process today.
6. Only after that bridge is independently verified, run one smoke session with `max_fixtures=1`, `max_duration=600s`, `max_provider_requests=40`. Every `/status`, discovery and retry consumes the same durable budget.
7. Export evidence after every stop path. If pinned fixture disappears/ends, ACK/readback fails, quota guard fires, or persistence fails: stop immediately; do not substitute another fixture.

## Concrete staging deployment/preflight commands (DO NOT RUN in Batch05A.1)
These commands are for the future approved remote step and must use the staging configuration only:
```bash
node staging_kit/batch05a1-remote-preflight.mjs
npx wrangler deploy --env staging --dry-run
npx wrangler d1 execute <STAGING_D1_DATABASE_NAME> --env staging --file staging_kit/batch04-staging-schema.sql
```
The actual provider smoke command is intentionally **not enabled yet** because the standalone Node exact-OLD runtime has no verified D1 binding path. Enabling it before that adapter exists would violate the ACK/durable-budget requirements.

## Stop/export/rollback
- Stop reasons are durable budget/persistence/orchestrator reasons; no fixture substitution.
- Preserve capture rows, locked observations, ACK rows and exported JSON for audit.
- Roll back/remove only the staging-only version/bridge if created. Production P2.0.5.2 is not changed and therefore requires no production rollback.

## Claims explicitly NOT made
No staging deploy, no API-Football real call, no remote D1 verification, no pilot, no V2>OLD claim.
