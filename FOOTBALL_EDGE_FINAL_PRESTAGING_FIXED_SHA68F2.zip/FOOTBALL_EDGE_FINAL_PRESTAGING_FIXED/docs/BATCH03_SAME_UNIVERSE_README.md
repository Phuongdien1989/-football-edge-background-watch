# FOOTBALL EDGE — Batch 03 Same-Universe Replay

## Purpose

Batch 03 separates universe construction from OLD eligibility/ranking and creates two independent shadow rankings:

1. `football ranking`: prediction/confidence only, ranked only inside the same engine/period/horizon cohort.
2. `market opportunity ranking`: actual supported market offers only, using the existing B4 expected-return score.

No production code is deployed by this batch.

## Exact input

Batch 02.2 ZIP SHA256:

`3d96dc1bf230f04d19e35bed4d068c23cd1bdf19c4df015092cdd706ada28b42`

Batch 02.2 source manifest SHA256:

`f742599f65109fee2db2679584631801ba454be81b313d72b75a706ca128ca1c`

## Real raw replay artifact

The `replay_data/` folder is extracted from GitHub Actions artifact `11219420321` (`football-edge-v2-real-raw`).

Artifact SHA256:

`5aeda0cf600c19a5b25d63756d78a2ed248b96ea5901866b7e31c74cb0ea1f92`

It contains 47 raw requests, 83 fixture captures, 15 distinct fixtures, and 7 endpoint-evidence rows. It is a limited capture artifact, not proof of the complete live fixture universe.

## Run tests

```bash
node prediction_v2/test-b2.mjs
node prediction_v2/test-b3.mjs
node prediction_v2/test-b4.mjs
node prediction_v2/test-b5.mjs
node prediction_v2/test-b7-b9.mjs
node prediction_v2/test-batch02.mjs
node prediction_v2/test-batch021.mjs
node prediction_v2/test-batch022.mjs
node prediction_v2/test-batch022-integration.mjs
node prediction_v2/test-batch03.mjs
node prediction_v2/test-batch03-integration.mjs
node prediction_v2/test-batch03-real-raw.mjs replay_data

for f in prediction_v2/*.js prediction_v2/*.mjs worker_notify_v138_provider_quota75k.js; do
  node --check "$f"
done
```

## Run replays

Real raw artifact:

```bash
FE_RAW_DATASET_SHA256=5aeda0cf600c19a5b25d63756d78a2ed248b96ea5901866b7e31c74cb0ea1f92 \
node prediction_v2/replay-batch03-raw.mjs replay_data RAW_REPLAY_REPORT.json
```

Synthetic pipeline:

```bash
node prediction_v2/replay-batch03-synthetic.mjs SYNTHETIC_REPLAY_REPORT.json
```

## Important limitations

- The real raw artifact has no market feed.
- The real raw artifact has no nonempty statistics payloads at the selected cutoff and no team/player context source.
- Exact historical OLD watch/baseline state is not present, so strict OLD replay is unavailable for the real raw replay.
- No real persistence ACK is available; real raw evidence remains quarantined from strict metrics.
- Synthetic replay demonstrates pipeline behavior only and must not be used to claim predictive lift.
