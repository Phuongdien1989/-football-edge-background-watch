# BATCH05A — REMOTE STAGING SMOKE PLAN (NOT APPROVED / NOT RUN)

## Scope
Exactly one live fixture, maximum 10 minutes, maximum 40 provider HTTP attempts total. Production P2.0.5.2 is excluded. No model-weight or OLD-rule change.

## Required staging bindings (names only; no values/secrets)
- APISPORTS_KEY (secret)
- staging D1 binding used by Batch04.1 schema
- explicit staging service/environment identifier
- exact P2.0.5.2 runtime fixture/hash guard

## Preflight order
1. Verify release ZIP SHA256 and SOURCE_SHA256SUMS.
2. Verify production frozen frontend SHA256 remains a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844; do not target it.
3. Apply/verify Batch04.1 staging schema only on staging DB.
4. Start budget state with hard envelope: 1 fixture / 10 min / 40 attempts.
5. Make one explicitly approved provider /status call. It counts toward 40.
6. If daily/minute quota is unverified, reserve guard is hit, or effective provider cap is lower, reduce scope or STOP. Never buy/upgrade automatically.
7. Discover independent live universe. Deterministically choose lowest fixture_id; never OLD rank/watchlist.
8. Capture stats/events/odds-live through the shared budget controller. Every retry counts.
9. Exact OLD and NEW consume the same captured raw universe and evaluation cutoff; reject any source received after cutoff.
10. Persist capture + locked comparison bundle; require durable server write/readback ACK. Persistence failure => STOP.
11. Export evidence and stop. Do not continue to pilot or production.

## Stop conditions
TOTAL_REQUEST_CAP; DURATION_LIMIT; DAILY_RESERVE_GUARD; MINUTE_REMAINING_GUARD; REPEATED_HTTP_429; PERSISTENCE_FAILURE; missing/restarted budget state; unresolved in-flight requests; exact OLD SHA guard failure; unexpected production target; source after cutoff.

## Expected evidence
Provider request count, elapsed time, fixture selection policy, capture record IDs/hashes/received_at, exact OLD SHA/status, NEW modelable/status, football rank separately from market rank, market offers/NO_ENTRY state, durable staging ACK, stop reason, and confirmation production unchanged.

This document is a plan only. It does not authorize a remote call or deployment.
