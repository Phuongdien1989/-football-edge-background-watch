# Batch05A.2 remote staging plan — PREPARED, NOT EXECUTED

## Hard gates
- STAGING ONLY. Production P2.0.5.2 remains frozen.
- Explicit owner approval is required before any deploy or API-Football call.
- Max 1 pinned fixture, 600 seconds session elapsed, 40 provider attempts TOTAL across restart.
- Exact OLD remains guarded P2.0.5.2 Node VM; probability-engine coefficients are locked.
- A missing/corrupt session, owner conflict, ACK/readback mismatch, or persistence failure stops before further collection.

## Runtime architecture
Node smoke runner owns exact OLD VM and provider collection. It talks to a staging Worker bridge over authenticated HTTPS. The Worker bridge owns the D1 binding and persists capture payloads, budget state, smoke-session metadata, immutable bundles/readback, and a single-owner lease. The Node runner never receives a D1 credential. `SERVER` ACK is accepted only after the Worker D1 path performs durable readback.

## Staging integration files
- `staging_kit/batch05a2-staging-worker-entry.js` — staging Worker entrypoint wrapping the existing candidate Worker.
- `staging_kit/batch05a2-http-d1-bridge.js` — authenticated Worker handler + Node HTTP client.
- `staging_kit/batch05a2-staging-bridge.js` — D1 adapters, owner lease, budget/session/capture/bundle readback.
- `staging_kit/batch04-staging-schema.sql` — includes `b5_smoke_sessions` and `b5_smoke_session_owner` additions.
- `staging_kit/batch05a2-staging-config.example.json` — smoke limits/bindings.

## Commands to use ONLY after approval
The exact Cloudflare resource names/IDs must be filled from the existing staging account; never point these commands at production.

1. Verify target and model lock locally:
`node staging_kit/batch05a2-remote-preflight.mjs`

2. Apply schema to STAGING D1 only:
`npx wrangler d1 execute <STAGING_D1_NAME> --remote --file=staging_kit/batch04-staging-schema.sql`

3. Set bridge secret on STAGING Worker only:
`npx wrangler secret put BATCH05A2_BRIDGE_TOKEN --name <STAGING_WORKER_NAME>`

4. Deploy staging bridge entrypoint using a dedicated staging wrangler config whose `main` is `staging_kit/batch05a2-staging-worker-entry.js` and whose D1 binding is exactly `BATCH05A2_STAGING_DB`:
`npx wrangler deploy --config <STAGING_WRANGLER_TOML>`

5. Run Node smoke with a unique `pilot_id`, unique `owner_id`, bridge URL/token, and API key supplied only as runtime secrets. The runner configuration MUST retain 1 fixture / 600 s / 40 attempts and `ackMode=REMOTE`. Do not restart with a new pilot ID.

6. Stop: persist `stop_reason=OPERATOR_STOP` through the same durable budget/session path before terminating the runner. If the process is already gone, use a staging-only administrative invocation of the bridge/budget adapter to set the stop before any restart.

7. Export: read session state, budget, captures, locked observations/ACKs and runner report for the same pilot ID. Hash the export before review. No production evidence may be mixed into the bundle.

8. Rollback staging Worker:
`npx wrangler rollback --name <STAGING_WORKER_NAME>`
(or redeploy the exact previously recorded staging version ID). D1 evidence tables are retained for audit; rollback must not delete evidence.

## Required pre-run checks
Confirm staging URL/worker name, D1 database ID, bridge binding, previous staging version ID for rollback, API-Football remaining daily/minute quota, and that the bridge owner table has no active owner for the pilot ID. If any is unknown: DO NOT RUN.

## Current status
NOT DEPLOYED. NO REAL API CALLS. NO REMOTE D1 TEST. The bridge has only been exercised offline against SQLite through a D1-compatible adapter and through the HTTP Node→Worker→D1 routing layer.
