# FINAL FIXED — run / stop / export / rollback

All commands below run from the extracted package root. Offline tests may be run now. Remote mutation/provider commands require the next explicit staging approval.

## Offline
```
node prediction_v2/test-final-blockers-fixed.mjs
node prediction_v2/test-batch05a-final-package.mjs
```

## Configure before approval
Copy staging_kit/batch05a-final-staging-config.example.json to a private config, fill the dedicated staging bridge URL and unique pilot/owner IDs, retain 1 fixture / 600000ms / 40 attempts, and confirm the target only after checking it. Do not change pilot_id to reset limits after restart.
Copy staging_kit/wrangler.batch05a-final.example.toml to a private staging TOML. Fill the dedicated staging D1 ID. This package's ops script uses database_name football-edge-b05a-staging; if your approved staging database has another name, update that argument and TOML together before use.
Secrets come from environment/secret bindings; do not put their values in configs, command history, logs or ZIPs.

Offline configuration preflight:
```
CFG=/absolute/path/to/private-staging-config.json bash staging_kit/batch05a-final-ops.sh preflight
```

## After approval: deploy dedicated staging only
For a NEW, empty dedicated staging database, apply staging_kit/batch05a3-staging-schema.sql through db-init exactly once. It contains additive ALTER statements and must not be reapplied to a populated database. For a database already at A3, inspect its schema and apply only final-fixed-migration.sql once. Never synthesize missing legacy raw bytes or bypass failed capture validation.
```
FE_APPROVE_REMOTE_SMOKE=YES WRANGLER=/absolute/path/to/staging.toml bash staging_kit/batch05a-final-ops.sh db-init
npx wrangler secret put BATCH05A3_BRIDGE_TOKEN --config /absolute/path/to/staging.toml
FE_APPROVE_REMOTE_SMOKE=YES WRANGLER=/absolute/path/to/staging.toml bash staging_kit/batch05a-final-ops.sh deploy
```
The Worker contains no cron or provider collector. The Node runner owns provider requests and exact OLD runtime. Record the staging deployment version and existing prior version before any run.

## Run
With BATCH05A3_BRIDGE_TOKEN and APISPORTS_KEY already set securely in the Node environment:
```
FE_APPROVE_REMOTE_SMOKE=YES CFG=/absolute/path/to/private-staging-config.json bash staging_kit/batch05a-final-ops.sh run > evidence/REMOTE_SMOKE.json
```
Provider /status, discovery, detailed requests and retries all share the durable 40-attempt budget. Daily/minute quota is checked before enrichment; unknown quota, missing fixture, persistence/ACK errors and limit guards stop collection. Quota/status attempts consume the same cap.

## Stop active runner without competing for its lease
```
CFG=/absolute/path/to/private-staging-config.json bash staging_kit/batch05a-final-ops.sh stop
```
The authenticated server mutation sets a monotonic OPERATOR_STOP and advances budget revision. A delayed runner save cannot erase it. It prevents the next request; an already in-flight HTTP attempt may finish and its raw capture remains evidence. Restart does not clear the stop.

## Export
```
CFG=/absolute/path/to/private-staging-config.json bash staging_kit/batch05a-final-ops.sh export > evidence/REMOTE_EXPORT.json
sha256sum evidence/REMOTE_SMOKE.json evidence/REMOTE_EXPORT.json
```
Export includes validated raw text/payload envelopes, session/budget, full locked observations/paper records and exact OLD payloads. Corrupt rows cause validation failure instead of being labelled verified. Preserve the raw D1 database separately for forensic inspection if validation fails.

## Rollback staging only
```
STAGING_PREVIOUS_VERSION_ID=APPROVED_PREVIOUS_STAGING_VERSION WRANGLER=/absolute/path/to/staging.toml bash staging_kit/batch05a-final-ops.sh rollback
```
Use the exact recorded staging version, never a production version. For a brand-new staging service with no prior version, stop the runner and disable/remove the new staging service using the approved account workflow. Retain D1 evidence for audit. Production remains untouched.
