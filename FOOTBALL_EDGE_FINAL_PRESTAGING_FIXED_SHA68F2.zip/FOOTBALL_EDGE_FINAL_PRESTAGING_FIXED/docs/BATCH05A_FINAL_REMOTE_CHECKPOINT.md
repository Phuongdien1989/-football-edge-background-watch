# Remote staging checkpoint — commands prepared, NOT executed

## Fill configuration
Copy `staging_kit/batch05a-final-staging-config.example.json` to `staging_kit/batch05a-final-staging-config.json`, set the dedicated staging Worker URL, unique pilot/owner IDs, and set `staging_target_confirmed=true` only after checking the hostname is not production. Copy `staging_kit/wrangler.batch05a-final.example.toml` to a local staging config and fill the dedicated staging D1 ID.

## Commands
`CFG=staging_kit/batch05a-final-staging-config.json ./staging_kit/batch05a-final-ops.sh preflight`

After explicit approval only:
`FE_APPROVE_REMOTE_SMOKE=YES WRANGLER=staging_kit/wrangler.batch05a-final.toml ./staging_kit/batch05a-final-ops.sh db-init`
`npx wrangler secret put BATCH05A3_BRIDGE_TOKEN --config staging_kit/wrangler.batch05a-final.toml`
`FE_APPROVE_REMOTE_SMOKE=YES WRANGLER=staging_kit/wrangler.batch05a-final.toml ./staging_kit/batch05a-final-ops.sh deploy`
`FE_APPROVE_REMOTE_SMOKE=YES BATCH05A3_BRIDGE_TOKEN='<secret>' APISPORTS_KEY='<key>' CFG=staging_kit/batch05a-final-staging-config.json ./staging_kit/batch05a-final-ops.sh run > evidence/REMOTE_SMOKE.json`

Operator stop:
`BATCH05A3_BRIDGE_TOKEN='<secret>' CFG=staging_kit/batch05a-final-staging-config.json ./staging_kit/batch05a-final-ops.sh stop`

Evidence export:
`BATCH05A3_BRIDGE_TOKEN='<secret>' CFG=staging_kit/batch05a-final-staging-config.json ./staging_kit/batch05a-final-ops.sh export > evidence/REMOTE_EXPORT.json`

Rollback staging Worker:
`STAGING_PREVIOUS_VERSION_ID='<version-id>' WRANGLER=staging_kit/wrangler.batch05a-final.toml ./staging_kit/batch05a-final-ops.sh rollback`

After rollback retain the dedicated staging D1 evidence DB read-only until audit is complete; do not apply any of these commands to production.
