/* FOOTBALL EDGE — Prediction V2 / Batch 03
 * Builds a replay universe from raw fixture snapshots available at one evaluation cutoff.
 * IMPORTANT:
 * - Universe membership is derived from raw fixture captures only.
 * - OLD rank/watchlist/TOP is not consulted.
 * - "ALL LIVE" is never claimed unless the dataset itself proves it. This module reports
 *   RAW_CAPTURE_ARTIFACT_SCOPE for the exported artifact used in Batch 03.
 */
const finite=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim())?null:(Number.isFinite(Number(v))?Number(v):null);
const stable=v=>{
  if(v===null||typeof v!=='object')return JSON.stringify(v);
  if(Array.isArray(v))return '['+v.map(stable).join(',')+']';
  return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')+'}';
};
function fnv1a(str){let h=0x811c9dc5;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,0x01000193)}return (h>>>0).toString(16).padStart(8,'0')}
function timeMs(v){const t=Date.parse(v);return Number.isFinite(t)?t:null}
function toIso(v){const t=typeof v==='number'?v:timeMs(v);return Number.isFinite(t)?new Date(t).toISOString():null}
export function parseNdjson(text){
  return String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean).map((line,i)=>{
    try{return JSON.parse(line)}catch(e){throw new Error(`NDJSON parse error line ${i+1}: ${e?.message||e}`)}
  });
}
function latestByFixture(captures,cutoffMs){
  const map=new Map();
  for(const c of captures||[]){
    const id=Number(c?.fixture_id),rt=timeMs(c?.received_at);
    if(!Number.isFinite(id)||rt==null||rt>cutoffMs)continue;
    const prev=map.get(id),pt=timeMs(prev?.received_at);
    if(!prev||rt>pt||(rt===pt&&String(c?.capture_id||'')>String(prev?.capture_id||'')))map.set(id,c);
  }
  return map;
}
function evidenceAtCutoff(endpointEvidence,fixtureId,cutoffMs){
  return (endpointEvidence||[]).filter(e=>Number(e?.fixture_id)===Number(fixtureId)&&timeMs(e?.received_at)!=null&&timeMs(e.received_at)<=cutoffMs)
    .sort((a,b)=>(timeMs(a.received_at)||0)-(timeMs(b.received_at)||0));
}
function endpointPresence(rows,kind){
  const xs=(rows||[]).filter(x=>String(x?.evidence_kind||'').toUpperCase()===kind);
  const latest=xs.at(-1)||null;
  return {seen:xs.length>0,nonempty:xs.some(x=>(finite(x?.item_count)||0)>0||(finite(x?.non_null_value_count)||0)>0),latest};
}
function snapshotPresence(capture){
  return {
    events:Boolean(Number(capture?.has_events)||Number(capture?.event_count)>0),
    stats:Boolean(Number(capture?.has_stats)||Number(capture?.stats_team_count)>0||Number(capture?.stats_value_count)>0),
    lineups:Boolean(Number(capture?.has_lineups)),
    players:Boolean(Number(capture?.has_players))
  };
}
function sourceRef(kind,row){
  if(!row)return null;
  return {
    kind,
    source_id:row?.capture_id??row?.evidence_id??row?.request_id??null,
    request_id:row?.request_id??null,
    payload_hash:row?.fixture_payload_hash??row?.payload_hash??null,
    received_at:toIso(row?.received_at),
    provider_updated_at:null,
    provenance_status:row?.received_at?'STRICT_VALID':'UNKNOWN_PROVENANCE'
  };
}
export function buildRawSnapshotUniverse({
  fixtureCaptures=[],
  endpointEvidence=[],
  rawRequests=[],
  cutoff,
  datasetId='RAW_CAPTURE_DATASET',
  datasetHash=null,
  datasetSummary=null,
  scopeLabel='RAW_CAPTURE_ARTIFACT_SCOPE'
}={}){
  const cutoffMs=timeMs(cutoff);
  if(cutoffMs==null)throw new Error('valid cutoff required');
  const latest=latestByFixture(fixtureCaptures,cutoffMs),fixtureIds=[...latest.keys()].sort((a,b)=>a-b),fixtures=[];
  for(const id of fixtureIds){
    const c=latest.get(id),eps=evidenceAtCutoff(endpointEvidence,id,cutoffMs),events=endpointPresence(eps,'EVENTS'),stats=endpointPresence(eps,'STATISTICS'),
      snap=snapshotPresence(c),hasStats=snap.stats||stats.nonempty,hasEvents=snap.events||events.nonempty,
      reasons=[];
    if(!hasStats)reasons.push('NO_LIVE_STATS_AT_CUTOFF');
    if(!snap.lineups)reasons.push('NO_LINEUPS_AT_CUTOFF');
    if(!snap.players)reasons.push('NO_PLAYER_STATS_AT_CUTOFF');
    reasons.push('NO_TEAM_CONTEXT_IN_RAW_ARTIFACT');
    reasons.push('NO_MARKET_SOURCE_IN_RAW_ARTIFACT');
    const refs=[sourceRef('FIXTURE_CAPTURE',c),sourceRef('EVENTS_EVIDENCE',events.latest),sourceRef('STATISTICS_EVIDENCE',stats.latest)].filter(Boolean);
    fixtures.push({
      fixture_id:id,
      universe_cutoff:toIso(cutoffMs),
      capture_id:c?.capture_id??null,
      capture_received_at:toIso(c?.received_at),
      fixture_payload_hash:c?.fixture_payload_hash??null,
      request_id:c?.request_id??null,
      status_short:c?.status_short??c?.fixture_json?.fixture?.status?.short??null,
      match_clock:finite(c?.match_clock??c?.fixture_json?.fixture?.status?.elapsed),
      snapshot:c?.fixture_json??null,
      data_presence:{fixture:true,events:hasEvents,stats:hasStats,lineups:snap.lineups,players:snap.players,team_context:false,market:false},
      data_status:hasStats?'PARTIAL_RAW_STATS_NO_CONTEXT':'PARTIAL_RAW_NO_STATS_NO_CONTEXT',
      data_reasons:reasons,
      source_references:refs,
      endpoint_evidence:eps
    });
  }
  const withStats=fixtures.filter(x=>x.data_presence.stats).length,withEvents=fixtures.filter(x=>x.data_presence.events).length,
    withLineups=fixtures.filter(x=>x.data_presence.lineups).length,withPlayers=fixtures.filter(x=>x.data_presence.players).length,
    basis={dataset_id:datasetId,dataset_hash:datasetHash||null,cutoff:toIso(cutoffMs),fixture_ids:fixtureIds,
      capture_rows:(fixtureCaptures||[]).filter(x=>timeMs(x?.received_at)!=null&&timeMs(x.received_at)<=cutoffMs).length,
      endpoint_evidence_rows:(endpointEvidence||[]).filter(x=>timeMs(x?.received_at)!=null&&timeMs(x.received_at)<=cutoffMs).length};
  const universeId=`fe:universe:${fnv1a(stable(basis))}`;
  return {
    schema:'FE_PV2_RAW_UNIVERSE_V1',
    universe_id:universeId,
    cutoff:toIso(cutoffMs),
    scope:scopeLabel,
    scope_claim:'NOT_ALL_LIVE',
    availability_rule:'received_at <= cutoff',
    dataset:{dataset_id:datasetId,dataset_hash:datasetHash||null,summary:datasetSummary||null,
      raw_request_rows:(rawRequests||[]).filter(x=>timeMs(x?.received_at)!=null&&timeMs(x.received_at)<=cutoffMs).length,
      fixture_capture_rows:basis.capture_rows,endpoint_evidence_rows:basis.endpoint_evidence_rows},
    fixture_ids:fixtureIds,
    fixture_count:fixtureIds.length,
    completeness:{
      fixtures:fixtureIds.length,
      with_stats:withStats,
      without_stats:fixtureIds.length-withStats,
      with_events:withEvents,
      with_lineups:withLineups,
      with_players:withPlayers,
      with_team_context:0,
      with_market:0
    },
    fixtures
  };
}
export function assertUniverseMembershipIndependent(universe){
  if(!universe||!Array.isArray(universe.fixture_ids))return false;
  return universe.scope==='RAW_CAPTURE_ARTIFACT_SCOPE'&&universe.availability_rule==='received_at <= cutoff';
}
