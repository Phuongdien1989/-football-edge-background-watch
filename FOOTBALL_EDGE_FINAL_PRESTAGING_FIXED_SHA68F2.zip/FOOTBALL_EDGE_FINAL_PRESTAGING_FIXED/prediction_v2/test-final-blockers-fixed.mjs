import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {runBatch05aSmoke} from '../staging_kit/batch05a-smoke-orchestrator.mjs';
import {handleBatch05a3Bridge,createNodeHttpD1BridgeA3} from '../staging_kit/batch05a3-http-d1-bridge.js';
import {createD1StagingBridgeA3} from '../staging_kit/batch05a3-staging-bridge.js';
import {buildCapturedPayload} from './capture-contract.js';
import {assertCaptureContent} from './capture-integrity.js';

class Clock {
 constructor(){this.t=Date.parse('2026-10-07T12:00:00Z');this.onSleep=null}
 now(){return this.t}
 async sleep(ms){this.t+=ms;if(this.onSleep)await this.onSleep(ms);await new Promise(r=>setImmediate(r))}
}
class Statement {
 constructor(st,sql,db){Object.assign(this,{st,sql,db})}
 bind(...a){this.args=a;return this}
 async first(){return this.st.get(...(this.args||[]))||null}
 async all(){return {results:this.st.all(...(this.args||[]))}}
 async run(){if(this.db.beforeRun)await this.db.beforeRun(this.sql);return this.st.run(...(this.args||[]))}
}
class DB {
 constructor(){this.raw=new DatabaseSync(':memory:');this.raw.exec(fs.readFileSync(new URL('../staging_kit/batch05a3-staging-schema.sql',import.meta.url),'utf8'))}
 prepare(sql){return new Statement(this.raw.prepare(sql),sql,this)}
 close(){this.raw.close()}
}
const quota={'x-ratelimit-requests-limit':'75000','x-ratelimit-requests-remaining':'70000','x-ratelimit-limit':'100','x-ratelimit-remaining':'99'};
const fixture={fixture:{id:505,status:{short:'2H',elapsed:61},date:'2026-10-07T11:00:00Z'},league:{id:1,season:2026},teams:{home:{id:1,name:'HOME'},away:{id:2,name:'AWAY'}},goals:{home:0,away:0}};
const stats={response:[{team:{id:1},statistics:[{type:'Shots on Goal',value:5}]},{team:{id:2},statistics:[{type:'Shots on Goal',value:1}]}]};
function setup(pilot='P'){
 const clock=new Clock(),db=new DB(),env={BATCH05A3_STAGING_DB:db,BATCH05A3_BRIDGE_TOKEN:'OFFLINE'},calls=[];
 const router=(u,o)=>handleBatch05a3Bridge(new Request(u,o),env,{clock});
 const client=createNodeHttpD1BridgeA3({baseUrl:'https://offline.invalid',token:'OFFLINE',pilotId:pilot,ownerId:'RUNNER',fetchImpl:router});
 const tx=async url=>{const ep=new URL(url).pathname;calls.push(ep);let body=ep==='/status'?{response:{requests:{current:1,limit_day:75000}}}:ep==='/fixtures'?{response:[fixture]}:ep==='/fixtures/statistics'?stats:{response:[]};return {status:200,headers:{get:k=>quota[k]??null},text:async()=>JSON.stringify(body)}};
 const args={env:{APISPORTS_KEY:'OFFLINE'},fetchImpl:tx,captureSink:client.captureSink,persistLockedBundle:client.persistLockedBundle,clock,store:client.budgetStore,sessionStore:client.sessionStore,loadPersistedCaptures:client.loadPersistedCaptures,loadObservation:client.loadObservation,owner:client.owner,pilotId:pilot,maxTicks:1,ackMode:'REMOTE',networkReal:false,transportLabel:'OFFLINE_HTTP_SQLITE'};
 return {clock,db,client,calls,args,router};
}
const evidence={schema:'FE_FINAL_BLOCKERS_FIXED_REVIEW_V1',network_real_calls:0,deployed:false,raw:[],budget:[],stop:null};
// Same content in raw-text and canonical captures validates; caller hash lies reject.
const raw=await buildCapturedPayload({endpoint:'/fixtures/events',fixtureId:505,receivedAt:'2026-10-07T12:00:00Z',httpStatus:200,payload:{response:[]},rawText:'{ "response": [] }'});
await assertCaptureContent(raw);
await assert.rejects(()=>assertCaptureContent({...raw,payload:{response:[{fake:true}]}}),/RAW_PARSED_MISMATCH/);
const canonical=await buildCapturedPayload({endpoint:'/fixtures/events',fixtureId:505,receivedAt:raw.received_at,httpStatus:200,payload:{response:[]}});await assertCaptureContent(canonical);
{
 const x=setup('FIRST_WRITE');await x.client.owner.acquire();await assert.rejects(()=>x.client.captureSink({...raw,payload_hash:'CLAIMED_WRONG_HASH'}),/PAYLOAD_HASH_MISMATCH/);assert.equal(x.db.raw.prepare('SELECT COUNT(*) AS n FROM b4_capture_payloads').get().n,0);await x.client.owner.release();x.db.close();
}
// Stats, discovery, envelope and observation bytes must be checked before any new request.
for(const kind of ['stats_payload','discovery_payload','raw_text','observation_payload','paper_payload','old_payload']){
 const x=setup('TAMPER_'+kind),first=await runBatch05aSmoke(x.args);assert.equal(first.failure,null);assert.equal(first.observation_ids.length,1);
 if(kind==='observation_payload'){
  const row=x.db.raw.prepare('SELECT observation_id,observation_json FROM b4_locked_predictions').get(),obs=JSON.parse(row.observation_json);obs.prediction_snapshot={malicious:true};x.db.raw.prepare('UPDATE b4_locked_predictions SET observation_json=? WHERE observation_id=?').run(JSON.stringify(obs),row.observation_id);
 }else if(kind==='paper_payload'){
  x.db.raw.prepare('UPDATE b4_locked_predictions SET paper_json=?').run('{"fake":true}');
 }else if(kind==='old_payload'){
  const row=x.db.raw.prepare('SELECT record_id,payload_json FROM b4_old_exact_outputs').get(),old=JSON.parse(row.payload_json);old.evaluation={fake:true};x.db.raw.prepare('UPDATE b4_old_exact_outputs SET payload_json=? WHERE record_id=?').run(JSON.stringify(old),row.record_id);
 }else{
  const ep=kind==='discovery_payload'?'/fixtures':'/fixtures/statistics',row=x.db.raw.prepare('SELECT * FROM b4_capture_payloads WHERE endpoint=?').get(ep);
  if(kind==='raw_text'){const r=JSON.parse(row.capture_json);r.payload_text='{"response":[]}';x.db.raw.prepare('UPDATE b4_capture_payloads SET capture_json=? WHERE record_id=?').run(JSON.stringify(r),row.record_id)}
  else{const payload=JSON.parse(row.payload_json);if(kind==='stats_payload')payload.response[0].statistics[0].value=99;else payload.response[0].goals.home=9;x.db.raw.prepare('UPDATE b4_capture_payloads SET payload_json=? WHERE record_id=?').run(JSON.stringify(payload),row.record_id)}
 }
 const before=x.calls.length,dir=fs.mkdtempSync(path.join(os.tmpdir(),'fe-fixed-')),out=path.join(dir,'error.json'),r=await runBatch05aSmoke({...x.args,exportPath:out});
 assert.equal(r.stop_reason,'RESTART_STATE_FAILURE');assert.equal(x.calls.length,before);assert.ok(fs.existsSync(out));evidence.raw.push({kind,requests_after_tamper:x.calls.length-before,stop:r.stop_reason,error:r.failure});fs.rmSync(dir,{recursive:true,force:true});x.db.close();
}
// Delay the SQL write AFTER checks. Another writer commits the newer counter/stop.
for(const withStop of [false,true]){
 const x=setup('RACE_'+withStop),b=createD1StagingBridgeA3({db:x.db,pilotId:x.args.pilotId,ownerId:'RUNNER',clock:x.clock});await b.owner.acquire();await b.budgetStore.save({pilot_id:x.args.pilotId,total_requests:10,stop_reason:null});
 let release,entered;const reached=new Promise(r=>entered=r);let hold=true;
 x.db.beforeRun=async sql=>{if(hold&&sql.includes('INSERT INTO b4_pilot_budget_state')){hold=false;entered();await new Promise(r=>release=r)}};
 const delayed=b.budgetStore.save({pilot_id:x.args.pilotId,total_requests:11,stop_reason:null});const rejected=assert.rejects(delayed,/CAS_CONFLICT/);await reached;
 if(withStop){await b.budgetStore.save({pilot_id:x.args.pilotId,total_requests:20,stop_reason:null});await b.requestStop()}
 else await b.budgetStore.save({pilot_id:x.args.pilotId,total_requests:20,stop_reason:null});
 release();await rejected;const after=await b.budgetStore.load();assert.equal(after.total_requests,20);assert.equal(after.stop_reason,withStop?'OPERATOR_STOP':null);evidence.budget.push({delayed_save:'REJECTED',with_operator_stop:withStop,total_requests:after.total_requests,stop_reason:after.stop_reason});await b.owner.release();x.db.close();
}
// Stop the active runner in the 60s gap using HTTP, then restart/export the same pilot.
{
 const x=setup('ACTIVE_STOP');let stopped=false;x.clock.onSleep=async ms=>{if(ms===60000&&!stopped){stopped=true;await x.client.requestStop()}};
 const first=await runBatch05aSmoke({...x.args,maxTicks:3});assert.equal(first.stop_reason,'OPERATOR_STOP');assert.equal(x.calls.length,5);assert.equal(first.observation_ids.length,1);
 const before=x.calls.length,restarted=await runBatch05aSmoke({...x.args,maxTicks:1});assert.equal(restarted.stop_reason,'OPERATOR_STOP');assert.equal(x.calls.length,before);
 const exp=await x.client.exportEvidence();assert.equal(exp.budget.stop_reason,'OPERATOR_STOP');assert.equal(exp.budget.total_requests,5);assert.equal(exp.captures.length,5);assert.equal(exp.locked_observations.length,1);assert.ok(exp.captures.every(r=>r.payload_text!=null));assert.ok(exp.locked_observations[0].observation.feature_snapshot);assert.ok(exp.old_exact_outputs[0].payload);
 const other=createNodeHttpD1BridgeA3({baseUrl:'https://offline.invalid',token:'OFFLINE',pilotId:'OTHER',ownerId:'OTHER',fetchImpl:x.router});assert.equal((await other.exportEvidence()).captures.length,0);
 evidence.stop={during_active_run:true,stop:first.stop_reason,total_provider_attempts:exp.budget.total_requests,restart_additional_attempts:x.calls.length-before,export_captures:exp.captures.length,export_observations:exp.locked_observations.length,bytes_exported:true};x.db.close();
}
if(process.env.FINAL_FIXED_EVIDENCE)fs.writeFileSync(process.env.FINAL_FIXED_EVIDENCE,JSON.stringify(evidence,null,2));
console.log('FINAL FIX: raw/fixture/bundle tamper, concurrent budget CAS, active HTTP stop/restart/full export PASS');
