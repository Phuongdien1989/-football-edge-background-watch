import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {parseNdjson,buildRawSnapshotUniverse} from './raw-universe.js';
import {evaluateNewFromRawFixture} from './raw-new-evaluator.js';
import {evaluateSameUniverse,assertSameUniverseRows} from './same-universe-evaluator.js';
import {rankFootballRows,rankMarketOpportunities} from './dual-ranking.js';
import {buildSameUniverseReport} from './same-universe-report.js';

const dir=path.resolve(process.argv[2]||'./replay_data');
const read=n=>fs.readFileSync(path.join(dir,n),'utf8');
const summary=JSON.parse(read('football-edge-v2-real-raw-summary.json'));
const universe=buildRawSnapshotUniverse({
  fixtureCaptures:parseNdjson(read('football-edge-v2-real-fixture-captures.ndjson')),
  endpointEvidence:parseNdjson(read('football-edge-v2-real-endpoint-evidence.ndjson')),
  rawRequests:parseNdjson(read('football-edge-v2-real-raw.ndjson')),
  cutoff:summary.last_received_at,
  datasetId:'football-edge-v2-real-raw-2026-10-02',
  datasetHash:'5aeda0cf600c19a5b25d63756d78a2ed248b96ea5901866b7e31c74cb0ea1f92',
  datasetSummary:summary
});
assert.equal(universe.fixture_count,15);
assert.equal(universe.scope_claim,'NOT_ALL_LIVE');
assert.equal(universe.completeness.with_stats,0);
assert.equal(universe.completeness.with_market,0);

const evaluation=evaluateSameUniverse({
  universe,engines:['FT','H1','HC'],oldEvaluator:null,
  newEvaluator:({fixture,engine,universe})=>evaluateNewFromRawFixture(fixture,{engine,cutoffMs:Date.parse(universe.cutoff)})
});
assert.deepEqual(assertSameUniverseRows(evaluation),{ok:true,reason:'SAME_UNIVERSE_AND_CUTOFF'});
assert.equal(evaluation.rows.length,45);
assert.equal(evaluation.rows.filter(r=>r.old.replay_status==='OLD_REPLAY_UNAVAILABLE').length,45);
assert.equal(evaluation.rows.filter(r=>r.new.modelable===true).length,43);

const football=rankFootballRows(evaluation.rows);
assert.ok(football.rows.every(r=>r.requested_horizon_min===r.effective_horizon_min));
assert.ok(football.unsupported.every(r=>r.football_rank_status!=='RANKABLE_FULL_REQUESTED_HORIZON'));
const market=rankMarketOpportunities(evaluation.rows,{marketRowsByObservation:new Map(),strictMarket:true});
assert.equal(market.rows.filter(r=>r.market_rank!=null).length,0);

const strictRows=evaluation.rows.map(r=>({strict_valid:false,strict_metrics_eligible:false,strict_eligibility:{eligible:false,reasons:['PERSISTENCE_ACK_UNAVAILABLE_IN_RAW_ARTIFACT'],metric:'goal_10m'},reason:'PERSISTENCE_ACK_UNAVAILABLE_IN_RAW_ARTIFACT'}));
const outcomes=evaluation.rows.map(r=>({resolved:false,reason:'OUTCOME_NOT_REPLAYED_FROM_THIS_LIMITED_ARTIFACT'}));
const report=buildSameUniverseReport({universe,evaluation,footballRanking:football,marketRanking:market,outcomes,strictRows});
assert.equal(report.coverage.strict_valid,0);
assert.equal(report.coverage.strict_quarantined,45);
assert.equal(report.coverage.outcomes_unresolved,45);
assert.equal(report.coverage.market_ranked_observations,0);

console.log('Batch03 real-raw artifact replay test PASS');
