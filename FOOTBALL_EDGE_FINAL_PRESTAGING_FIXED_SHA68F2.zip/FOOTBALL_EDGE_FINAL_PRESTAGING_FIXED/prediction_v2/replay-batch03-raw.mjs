#!/usr/bin/env node
/* FOOTBALL EDGE — Prediction V2 / Batch 03
 * Offline replay of the existing real raw-capture export. No network access.
 */
import fs from 'node:fs';
import path from 'node:path';
import {parseNdjson,buildRawSnapshotUniverse} from './raw-universe.js';
import {evaluateNewFromRawFixture} from './raw-new-evaluator.js';
import {evaluateSameUniverse,assertSameUniverseRows} from './same-universe-evaluator.js';
import {rankFootballRows,rankMarketOpportunities} from './dual-ranking.js';
import {buildSameUniverseReport} from './same-universe-report.js';

const dir=path.resolve(process.argv[2]||'./replay_data');
const outPath=process.argv[3]?path.resolve(process.argv[3]):null;
const read=n=>fs.readFileSync(path.join(dir,n),'utf8');
const summary=JSON.parse(read('football-edge-v2-real-raw-summary.json'));
const rawRequests=parseNdjson(read('football-edge-v2-real-raw.ndjson'));
const fixtureCaptures=parseNdjson(read('football-edge-v2-real-fixture-captures.ndjson'));
const endpointEvidence=parseNdjson(read('football-edge-v2-real-endpoint-evidence.ndjson'));
const datasetHash=process.env.FE_RAW_DATASET_SHA256||null;
const cutoff=summary.last_received_at;
const universe=buildRawSnapshotUniverse({fixtureCaptures,endpointEvidence,rawRequests,cutoff,datasetId:'football-edge-v2-real-raw-2026-10-02',
  datasetHash,datasetSummary:summary});
const cutoffMs=Date.parse(universe.cutoff);
const evaluation=evaluateSameUniverse({
  universe,
  engines:['FT','H1','HC'],
  oldEvaluator:null,
  newEvaluator:({fixture,engine})=>evaluateNewFromRawFixture(fixture,{engine,cutoffMs})
});
const invariant=assertSameUniverseRows(evaluation);
if(!invariant.ok)throw new Error(invariant.reason);
const footballRanking=rankFootballRows(evaluation.rows);
const marketRanking=rankMarketOpportunities(evaluation.rows,{marketRowsByObservation:new Map(),strictMarket:true});
// No server persistence ACK exists in this raw artifact. Keep real raw replay out of strict metrics.
const strictRows=evaluation.rows.map(r=>({observation_id:r.observation_id,strict_valid:false,strict_metrics_eligible:false,strict_eligibility:{eligible:false,reasons:['PERSISTENCE_ACK_UNAVAILABLE_IN_RAW_ARTIFACT'],metric:'goal_10m'},reason:'PERSISTENCE_ACK_UNAVAILABLE_IN_RAW_ARTIFACT'}));
const outcomes=evaluation.rows.map(r=>({observation_id:r.observation_id,resolved:false,reason:'OUTCOME_NOT_REPLAYED_FROM_THIS_LIMITED_ARTIFACT'}));
const report=buildSameUniverseReport({universe,evaluation,footballRanking,marketRanking,outcomes,strictRows});
const payload={schema:'FE_PV2_BATCH03_RAW_REPLAY_V1',generated_at:new Date().toISOString(),replay_kind:'REAL_RAW_ARTIFACT_PIPELINE',
  predictive_lift_claim:false,old_replay_strict_available:false,old_replay_blocker:'OLD_REPLAY_UNAVAILABLE: raw export does not contain the complete historical OLD watch/baseline state required to reproduce the old engine at each cutoff.',
  market_data_present:false,universe,evaluation,footballRanking,marketRanking,report};
const text=JSON.stringify(payload,null,2);
if(outPath)fs.writeFileSync(outPath,text+'\n');else process.stdout.write(text+'\n');
