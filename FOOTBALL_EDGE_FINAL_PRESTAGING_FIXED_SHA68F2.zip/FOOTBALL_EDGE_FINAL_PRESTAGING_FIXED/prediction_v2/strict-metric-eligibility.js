/* FOOTBALL EDGE — Prediction V2 / Batch 02.2 strict metric eligibility
 * Strict eligibility is derived from evidence, not trusted booleans.
 * Prediction metrics are read from the immutable ACK-bound prediction snapshot.
 */
import {timestampMs,STRICT_VALID,PERSISTENCE_ACKNOWLEDGED,validatePersistenceAcknowledgement,sourceReplayStatus,validateObservationContent,contentFingerprint,ELIGIBILITY_INELIGIBLE} from './observation-contract.js';
const finite=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim())?null:(Number.isFinite(Number(v))?Number(v):null);
const boolOutcome=v=>v===true||v===1||v==='1'?true:v===false||v===0||v==='0'?false:null;
function push(a,x){if(x&&!a.includes(x))a.push(x)}
function minReceived(refs=[]){const xs=(refs||[]).map(r=>timestampMs(r?.received_at)).filter(v=>v!=null);return xs.length?Math.min(...xs):null}
function sameNumber(a,b){const x=finite(a),y=finite(b);if(x==null&&y==null)return true;if(x==null||y==null)return false;return Math.abs(x-y)<=1e-9}
function sameScalar(a,b){if(a==null&&b==null)return true;return String(a??'')===String(b??'')}
function explicitVeto(row){
  const state=String(row?.strict_eligibility_state||'').toUpperCase();
  if(state.startsWith(ELIGIBILITY_INELIGIBLE))return true;
  if(row?.strict_metrics_eligible===false&&!state.startsWith('PENDING'))return true;
  return false;
}
function persistenceCarrier(row,obs){
  const rowHas=!!row?.persistence_ack;
  return rowHas?row:obs;
}
function baseObservation(row,{allowSyntheticServerAck=false}={}){
  const reasons=[],obs=row?.observation||null;if(explicitVeto(row))push(reasons,'RECORD_EXPLICITLY_INELIGIBLE');
  if(!obs){push(reasons,'OBSERVATION_CONTRACT_MISSING');return {eligible:false,reasons,observation:null,persisted_ms:null}}
  if(String(obs?.strict_eligibility_state||'').toUpperCase().startsWith(ELIGIBILITY_INELIGIBLE))push(reasons,'OBSERVATION_EXPLICITLY_INELIGIBLE');
  if(row?.observation_id&&String(row.observation_id)!==String(obs.observation_id))push(reasons,'OBSERVATION_ID_MISMATCH');
  if(obs.strict_replay_status!==STRICT_VALID||obs.strict_replay_eligible!==true)push(reasons,obs.strict_replay_status||'OBSERVATION_REPLAY_NOT_STRICT');
  for(const ref of obs.source_references||[])if(ref?.required!==false&&sourceReplayStatus(ref,obs.evaluation_cutoff)!==STRICT_VALID)push(reasons,'SOURCE_NOT_STRICT_AT_CUTOFF');
  const integrity=validateObservationContent(obs);for(const r of integrity.reasons)push(reasons,r);
  const carrier=persistenceCarrier(row,obs),ackValidation=validatePersistenceAcknowledgement(carrier,carrier?.persistence_ack,{allowSyntheticServerAck});
  if(carrier?.persistence_status!==PERSISTENCE_ACKNOWLEDGED||!ackValidation.valid)for(const r of ackValidation.reasons.length?ackValidation.reasons:['PERSISTENCE_UNVERIFIED'])push(reasons,r);
  const persisted=timestampMs(carrier?.persisted_at);if(persisted==null)push(reasons,'PERSISTED_AT_MISSING');
  return {eligible:reasons.length===0,reasons,observation:obs,persisted_ms:persisted,ack_validation:ackValidation,persistence_carrier:carrier,integrity};
}
function recordPersistence(row,reasons,{allowSyntheticServerAck=false}={}){
  const v=validatePersistenceAcknowledgement(row,row?.persistence_ack,{allowSyntheticServerAck});if(row?.persistence_status!==PERSISTENCE_ACKNOWLEDGED||!v.valid)for(const r of v.reasons.length?v.reasons:['RECORD_PERSISTENCE_UNVERIFIED'])push(reasons,r);
  const persisted=timestampMs(row?.persisted_at);if(persisted==null)push(reasons,'RECORD_PERSISTED_AT_MISSING');return {persisted_ms:persisted,validation:v};
}
function assertBeforeOutcome(persisted,received,reasons){if(received==null)push(reasons,'OUTCOME_RECEIVED_AT_MISSING');else if(persisted!=null&&persisted>received)push(reasons,'PERSISTED_AFTER_OUTCOME_RECEIVED')}
function lockedPredictionProjection(obs){
  const p=obs?.prediction_snapshot||null,probs=p?.probabilities||{};if(!p)return null;
  return {p_goal_5m:finite(probs.goal_5m),p_goal_10m:finite(probs.goal_10m),p_goal_15m:finite(probs.goal_15m),p_home_next:finite(probs.home_next_goal_given_goal),
    confidence:finite(p?.confidence?.score_100),confidence_band:p?.confidence?.band??null};
}
function projectionIntegrity(row,obs){
  const reasons=[],locked=lockedPredictionProjection(obs);if(!locked){push(reasons,'LOCKED_PREDICTION_SNAPSHOT_MISSING');return {valid:false,reasons,locked:null}}
  for(const k of ['p_goal_5m','p_goal_10m','p_goal_15m','p_home_next','confidence'])if(row?.[k]!=null&&!sameNumber(row[k],locked[k]))push(reasons,`ROW_${k.toUpperCase()}_PROJECTION_MISMATCH`);
  if(row?.confidence_band!=null&&!sameScalar(row.confidence_band,locked.confidence_band))push(reasons,'ROW_CONFIDENCE_BAND_PROJECTION_MISMATCH');
  const s=obs?.state||{};if(row?.minute!=null&&!sameNumber(row.minute,s.minute))push(reasons,'ROW_STATE_MINUTE_MISMATCH');if(row?.score_home!=null&&!sameNumber(row.score_home,s.score_home))push(reasons,'ROW_STATE_SCORE_HOME_MISMATCH');
  if(row?.score_away!=null&&!sameNumber(row.score_away,s.score_away))push(reasons,'ROW_STATE_SCORE_AWAY_MISMATCH');if(row?.status!=null&&!sameScalar(row.status,s.status))push(reasons,'ROW_STATE_STATUS_MISMATCH');
  if(row?.feature_snapshot!=null&&contentFingerprint(row.feature_snapshot)!==obs?.feature_fingerprint)push(reasons,'ROW_FEATURE_SNAPSHOT_MISMATCH');
  return {valid:reasons.length===0,reasons,locked};
}
function projectedPredictionRow(row,locked){return {...row,p_goal_5m:locked?.p_goal_5m??null,p_goal_10m:locked?.p_goal_10m??null,p_goal_15m:locked?.p_goal_15m??null,p_home_next:locked?.p_home_next??null,
  confidence:locked?.confidence??row?.confidence??null,confidence_band:locked?.confidence_band??row?.confidence_band??null}}
export function predictionMetricEligibility(row,metric='goal_10m',options={}){
  const base=baseObservation(row,options),reasons=[...base.reasons],out=row?.outcome||{},we=out?.window_evidence?.[metric]||null,value=boolOutcome(out?.[metric]),projection=projectionIntegrity(row,base.observation);
  const obs=base.observation;if(row?.input_fingerprint&&obs?.input_fingerprint&&row.input_fingerprint!==obs.input_fingerprint)push(reasons,'INPUT_FINGERPRINT_MISMATCH');if(row?.feature_fingerprint&&obs?.feature_fingerprint&&row.feature_fingerprint!==obs.feature_fingerprint)push(reasons,'FEATURE_FINGERPRINT_MISMATCH');if(row?.prediction_fingerprint&&obs?.prediction_fingerprint&&row.prediction_fingerprint!==obs.prediction_fingerprint)push(reasons,'PREDICTION_FINGERPRINT_MISMATCH');if(row?.content_fingerprint&&obs?.content_fingerprint&&row.content_fingerprint!==obs.content_fingerprint)push(reasons,'CONTENT_FINGERPRINT_MISMATCH');
  for(const r of projection.reasons)push(reasons,r);if(out?.strict_outcome_eligible===false)push(reasons,'OUTCOME_EXPLICITLY_INELIGIBLE');if(value===null)push(reasons,'OUTCOME_UNRESOLVED');
  if(!we)push(reasons,'WINDOW_EVIDENCE_MISSING');else{if(we.model_target_compatible!==true)push(reasons,we.mismatch_reason||'MODEL_OUTCOME_HORIZON_MISMATCH');if(we.strict_provenance!==true)push(reasons,'OUTCOME_PROVENANCE_NOT_STRICT');if(we.metric_eligible!==true)push(reasons,'WINDOW_METRIC_INELIGIBLE')}
  const outcomeReceived=we?minReceived(we.refs):null;assertBeforeOutcome(base.persisted_ms,outcomeReceived,reasons);
  const eligible=reasons.length===0;return {eligible,reasons,eligibility_state:eligible?'ELIGIBLE':(reasons.some(r=>/MISMATCH|CONFLICT|AFTER_CUTOFF|EXPLICITLY_INELIGIBLE/.test(r))?'INELIGIBLE':'PENDING'),metric,value,
    outcome_received_at:outcomeReceived==null?null:new Date(outcomeReceived).toISOString(),projected_row:projection.locked?projectedPredictionRow(row,projection.locked):null};
}
export function paperMetricEligibility(row,options={}){
  const base=baseObservation(row,options),reasons=[...base.reasons];if(explicitVeto(row))push(reasons,'RECORD_EXPLICITLY_INELIGIBLE');if(row?.market_provenance_status!==STRICT_VALID)push(reasons,'MARKET_PROVENANCE_NOT_STRICT');
  const marketReceived=timestampMs(row?.received_at),cut=timestampMs(row?.evaluation_cutoff??base.observation?.evaluation_cutoff);if(marketReceived==null)push(reasons,'MARKET_RECEIVED_AT_MISSING');else if(cut!=null&&marketReceived>cut)push(reasons,'MARKET_AFTER_CUTOFF');
  const record=recordPersistence(row,reasons,options);if(row?.settled!==true)push(reasons,'SETTLEMENT_UNRESOLVED');if(String(row?.settlement_state||'').toUpperCase()==='VOID')push(reasons,'SETTLEMENT_VOID');if(row?.settlement_provenance_status!==STRICT_VALID)push(reasons,'SETTLEMENT_PROVENANCE_NOT_STRICT');
  const settlementReceived=timestampMs(row?.settlement_received_at);assertBeforeOutcome(record.persisted_ms,settlementReceived,reasons);return {eligible:reasons.length===0,reasons,settlement_received_at:settlementReceived==null?null:new Date(settlementReceived).toISOString()};
}
export function pairedMetricEligibility(row,options={}){
  const base=baseObservation(row,options),reasons=[...base.reasons];if(explicitVeto(row))push(reasons,'RECORD_EXPLICITLY_INELIGIBLE');const record=recordPersistence(row,reasons,options);
  if(row?.old_evaluation_status!==STRICT_VALID)push(reasons,'OLD_EVALUATION_NOT_STRICT');if(row?.new_evaluation_status!==STRICT_VALID)push(reasons,'NEW_EVALUATION_NOT_STRICT');if(boolOutcome(row?.hit)===null)push(reasons,'PAIRED_OUTCOME_UNRESOLVED');if(row?.outcome_provenance_status!==STRICT_VALID)push(reasons,'PAIRED_OUTCOME_PROVENANCE_NOT_STRICT');
  const received=timestampMs(row?.outcome_received_at);assertBeforeOutcome(record.persisted_ms,received,reasons);return {eligible:reasons.length===0,reasons,outcome_received_at:received==null?null:new Date(received).toISOString()};
}
export function strictEligibility(row,{kind='prediction',metric='goal_10m',allowSyntheticServerAck=false}={}){if(kind==='paper')return paperMetricEligibility(row,{allowSyntheticServerAck});if(kind==='paired')return pairedMetricEligibility(row,{allowSyntheticServerAck});return predictionMetricEligibility(row,metric,{allowSyntheticServerAck})}
