import assert from 'node:assert/strict';
import {buildRawSnapshotUniverse} from './raw-universe.js';
import {evaluateSameUniverse,assertSameUniverseRows,joinSameUniverseComparisons} from './same-universe-evaluator.js';
import {rankFootballRows,rankMarketOpportunities} from './dual-ranking.js';
import {buildSameUniverseReport} from './same-universe-report.js';

const cutoff='2026-10-07T10:01:00.000Z';
const cap=(id,at,{status='2H',minute=60,stats=false}={})=>({
  capture_id:`cap-${id}-${at}`,request_id:`req-${id}`,fixture_id:id,match_clock:minute,status_short:status,received_at:at,
  fixture_payload_hash:`hash-${id}-${at}`,has_events:0,has_stats:stats?1:0,has_lineups:0,has_players:0,
  fixture_json:{fixture:{id,status:{short:status,elapsed:minute,extra:null}},league:{id:1,name:'Test'},teams:{home:{id:id*10+1,name:`H${id}`},away:{id:id*10+2,name:`A${id}`}},
    goals:{home:0,away:0},score:{halftime:{home:0,away:0},fulltime:{home:null,away:null}},events:[],statistics:stats?[{team:{id:id*10+1},statistics:[]},{team:{id:id*10+2},statistics:[]}]:[]}
});
const captures=[
  cap(1,'2026-10-07T10:00:00Z',{stats:false}),
  cap(1,'2026-10-07T10:02:00Z',{stats:true}), // after cutoff: must not enter
  cap(2,'2026-10-07T10:00:20Z',{stats:true}),
  cap(3,'2026-10-07T10:00:30Z',{status:'1H',minute:30,stats:false})
];
const eps=[{evidence_id:'ev-after',fixture_id:1,evidence_kind:'STATISTICS',received_at:'2026-10-07T10:02:30Z',item_count:2,non_null_value_count:5,payload_hash:'late'}];
const universe=buildRawSnapshotUniverse({fixtureCaptures:captures,endpointEvidence:eps,cutoff,datasetId:'synthetic',datasetHash:'synthetic-hash'});
assert.equal(universe.fixture_count,3);
assert.equal(universe.fixtures.find(x=>x.fixture_id===1).capture_received_at,'2026-10-07T10:00:00.000Z');
assert.equal(universe.fixtures.find(x=>x.fixture_id===1).data_presence.stats,false);
assert.ok(universe.fixtures.find(x=>x.fixture_id===1).data_reasons.includes('NO_LIVE_STATS_AT_CUTOFF'));

function fakePrediction(engine,id){
  const base=engine==='H1'?62-id:engine==='HC'?58-id:70-id;
  return {engine,probabilities:{goal_5m:base-10,goal_10m:base,goal_15m:Math.min(95,base+8),home_next_goal_given_goal:55},
    confidence:{value:.70,score_100:70},live_update:{effective_lambda_90:2.4},base:{lambda_match:2.2},direction:{home_given_goal:.55}};
}
const newEval=({fixture,engine})=>({status:'MODELABLE_SYNTHETIC',modelable:true,prediction:fakePrediction(engine,fixture.fixture_id),
  packet:{state:{minute:fixture.match_clock,score_home:0,score_away:0,status:fixture.status_short}},reasons:fixture.data_reasons});
const oldA=({fixture})=>({replay_status:'OLD_REPLAY_OK',eligible:fixture.fixture_id!==1,selected:fixture.fixture_id===2,state:fixture.fixture_id===1?'FAIL':'READY',rank:fixture.fixture_id});
const oldB=({fixture})=>({replay_status:'OLD_REPLAY_OK',eligible:fixture.fixture_id!==1,selected:fixture.fixture_id===2,state:fixture.fixture_id===1?'FAIL':'READY',rank:100-fixture.fixture_id});

const evalA=evaluateSameUniverse({universe,engines:['FT','H1','HC'],oldEvaluator:oldA,newEvaluator:newEval});
assert.deepEqual(assertSameUniverseRows(evalA),{ok:true,reason:'SAME_UNIVERSE_AND_CUTOFF'});
assert.equal(evalA.rows.length,9);
assert.equal(evalA.rows.filter(r=>r.fixture_id===1).length,3);
assert.ok(evalA.rows.filter(r=>r.fixture_id===1).every(r=>r.old.eligible===false&&r.new.modelable===true)); // OLD rejects, NEW still sees
assert.deepEqual(evalA.rows.filter(r=>r.fixture_id===2).map(r=>r.engine).sort(),['FT','H1','HC'].sort()); // no FT>H1>HC collapse

const evalB=evaluateSameUniverse({universe,engines:['FT','H1','HC'],oldEvaluator:oldB,newEvaluator:newEval});
const newProjection=x=>x.rows.map(r=>({id:r.observation_id,p10:r.new.prediction?.probabilities?.goal_10m,status:r.new.status}));
assert.deepEqual(newProjection(evalA),newProjection(evalB)); // changing OLD rank cannot affect NEW universe or output
assert.deepEqual(evalA.rows.map(r=>r.observation_id),evalB.rows.map(r=>r.observation_id));

const footballA=rankFootballRows(evalA.rows);
const footballB=rankFootballRows(evalA.rows); // market is absent from input by construction
assert.deepEqual(footballA.rows,footballB.rows);
for(const sig of new Set(footballA.rows.map(r=>r.target_signature))){
  const hs=new Set(footballA.rows.filter(r=>r.target_signature===sig).map(r=>r.target_horizon_min));
  assert.equal(hs.size,1); // no P5/P15 mixing inside one rank cohort
}

// Market: fixture 1 has no market; fixtures 2/3 get deliberately poor prices so all supported edges are negative.
const mk=(period,line,odd)=>[{category:'over_under',market:period==='H1'?'Goals Over/Under - First Half':'Goals Over/Under',market_period:period,
  received_at:'2026-10-07T10:00:50Z',update:'2026-10-07T10:00:50Z',bookmaker:'TEST',
  values:[{value:`Over ${line}`,handicap:line,odd,main:true}]}];
const markets=new Map();
for(const r of evalA.rows){
  if(r.fixture_id===1)continue;
  markets.set(r.observation_id,mk(r.market_period,5.5,1.01));
}
const marketRank=rankMarketOpportunities(evalA.rows,{marketRowsByObservation:markets,strictMarket:true});
assert.ok(marketRank.rows.filter(r=>r.fixture_id===1).every(r=>r.market_rank==null&&r.market_top==null&&r.entry_decision==='NO_ENTRY'));
const ranked=marketRank.rows.filter(r=>r.market_rank!=null);
assert.ok(ranked.length>0);
assert.ok(ranked.every(r=>r.market_status!=='POSITIVE_EDGE'&&r.entry_decision==='NO_ENTRY')); // all negative/fair -> NO ENTRY

const footballNoMarket=rankFootballRows(evalA.rows);
assert.deepEqual(footballA.rows,footballNoMarket.rows); // removing markets does not change football rank

const report=buildSameUniverseReport({universe,evaluation:evalA,footballRanking:footballA,marketRanking:marketRank,
  outcomes:[],strictRows:evalA.rows.map(r=>({observation_id:r.observation_id,strict_valid:false,strict_metrics_eligible:false,strict_eligibility:{eligible:false,reasons:['PERSISTENCE_ACK_UNAVAILABLE'],metric:'goal_10m'},reason:'PERSISTENCE_ACK_UNAVAILABLE'}))});
assert.equal(report.coverage.universe_fixtures,3);
assert.equal(report.coverage.fixture_modelable,3);
assert.ok(report.reasons.raw_data.NO_LIVE_STATS_AT_CUTOFF>=2); // missing-data fixtures remain denominator
assert.equal(report.coverage.strict_valid,0);

// OLD/NEW join rejects different cutoff/universe.
const oldRows=evalA.rows.map(r=>({...r}));
const newRows=evalA.rows.map(r=>({...r}));
assert.equal(joinSameUniverseComparisons(oldRows,newRows).length,9);
assert.throws(()=>joinSameUniverseComparisons(oldRows,[...newRows.slice(0,1).map(r=>({...r,cutoff:'2026-10-07T10:02:00.000Z'})),...newRows.slice(1)]),/mismatch/i);

console.log('Batch03 same-universe / dual-ranking regressions PASS');
