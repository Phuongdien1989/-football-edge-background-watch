import assert from 'node:assert/strict';
import {buildObservationEnvelope,buildPersistenceAcknowledgement,withPersistenceAcknowledgement,buildGoalWindowTarget,STRICT_VALID} from './observation-contract.js';
import {compactShadowEvidence} from './shadow-evidence.js';
import {resolveStrictGoalWindows,normalizeOutcomeEvents} from './strict-outcome-resolver.js';
import {buildValidationReport} from './validation-report.js';

const cutoff='2026-10-07T10:01:00.000Z';
const sourceRefs=[{kind:'LIVE_STATISTICS',sourceId:'stats-1',requestId:'req-1',payloadHash:'hash-1',provider:'API_FOOTBALL',receivedAt:'2026-10-07T10:00:59Z'}];
const prediction={engine:'FT',probabilities:{goal_5m:40,goal_10m:55,goal_15m:65,home_next_goal_given_goal:56},confidence:{score_100:72,band:'HIGH'},live_update:{effective_lambda_90:2.8}};
const packet={fixture_id:501,engine:'FT',state:{minute:60,score_home:0,score_away:0,status:'2H'},quality:{dq:.9},live:{components:{pressure:.7,chance:.6,momentum:.65,game:.5,legacy_context:.5}}};
const item={id:501,latest:{minute:60,status:'2H',goals:{home:0,away:0}}};

// 1) Real lifecycle: compact evidence -> valid ACK -> outcome -> strict report. No manual flag override.
const row0=compactShadowEvidence({item,packet,prediction,now:Date.parse(cutoff),sourceRefs,marketPeriod:'FT',evaluationCutoff:cutoff,modelVersion:'TEST',configVersion:'TEST'});
assert.equal(row0.strict_metrics_eligible,null);assert.equal(row0.strict_eligibility_state,'PENDING_PERSISTENCE');
const ack=buildPersistenceAcknowledgement({subject:row0,persistedAt:'2026-10-07T10:01:00.500Z',ackId:'server-ack-501',source:'LOCAL_SYNTHETIC_SERVER_ADAPTER',ackOrigin:'SERVER',serverVerified:true});
const persisted=withPersistenceAcknowledgement(row0,ack);assert.equal(persisted.persistence_status,'ACKNOWLEDGED');assert.equal(persisted.strict_metrics_eligible,null);assert.equal(persisted.strict_eligibility_state,'PENDING_METRIC_EVIDENCE');
const resolved=resolveStrictGoalWindows(persisted,{events:[{event_id:'goal-501-a',source_id:'request-outcome-1',fixture_id:501,period:'H2',type:'Goal',time:{elapsed:63},received_at:'2026-10-07T10:05:00Z'}]});
const lifecycleReport=buildValidationReport({prediction:[resolved],paired:[],paper:[]},{strictMode:true});
assert.equal(lifecycleReport.calibration.goal_5m.n,1);assert.equal(lifecycleReport.calibration.goal_10m.n,1);assert.equal(lifecycleReport.quarantine.prediction_by_metric.goal_10m.included,1);

// 2) ACK-bound immutable projection: probability/feature/state mutation after JSON round-trip is rejected.
const control=JSON.parse(JSON.stringify(resolved));const controlReport=buildValidationReport({prediction:[control],paired:[],paper:[]},{strictMode:true});assert.equal(controlReport.calibration.goal_10m.n,1);assert.equal(controlReport.calibration.goal_10m.mean_probability,55);
const probabilityTamper=JSON.parse(JSON.stringify(resolved));probabilityTamper.p_goal_10m=99;const probabilityReport=buildValidationReport({prediction:[probabilityTamper],paired:[],paper:[]},{strictMode:true});
assert.equal(probabilityReport.calibration.goal_10m.n,0);assert.ok(probabilityReport.quarantine.prediction_by_metric.goal_10m.reasons.ROW_P_GOAL_10M_PROJECTION_MISMATCH>=1);
const featureTamper=JSON.parse(JSON.stringify(resolved));featureTamper.observation.feature_snapshot.live.components.pressure=.01;const featureReport=buildValidationReport({prediction:[featureTamper],paired:[],paper:[]},{strictMode:true});
assert.equal(featureReport.calibration.goal_10m.n,0);assert.ok(featureReport.quarantine.prediction_by_metric.goal_10m.reasons.OBSERVATION_FEATURE_FINGERPRINT_MISMATCH>=1);
const stateTamper=JSON.parse(JSON.stringify(resolved));stateTamper.minute=61;const stateReport=buildValidationReport({prediction:[stateTamper],paired:[],paper:[]},{strictMode:true});
assert.equal(stateReport.calibration.goal_10m.n,0);assert.ok(stateReport.quarantine.prediction_by_metric.goal_10m.reasons.ROW_STATE_MINUTE_MISMATCH>=1);
const lockedPredictionTamper=JSON.parse(JSON.stringify(resolved));lockedPredictionTamper.observation.prediction_snapshot.probabilities.goal_10m=99;const lockedPredictionReport=buildValidationReport({prediction:[lockedPredictionTamper],paired:[],paper:[]},{strictMode:true});
assert.equal(lockedPredictionReport.calibration.goal_10m.n,0);assert.ok(lockedPredictionReport.quarantine.prediction_by_metric.goal_10m.reasons.OBSERVATION_PREDICTION_FINGERPRINT_MISMATCH>=1);

// 3) Cross-half clock: H1 45+2 -> HT -> H2 minute 46 is ordered after the observation,
// but rolling elapsed across halftime is unsupported unless continuous elapsed is explicitly proven.
const crossObs=buildObservationEnvelope({fixtureId:601,engine:'FT',marketPeriod:'FT',state:{minute:45,score_home:0,score_away:0,status:'1H',match_clock:{period:'H1',regulation_minute:45,stoppage_minute:2,phase_clock_minute:47,display:'45+2'}},
  evaluationCutoff:cutoff,sourceRefs,predictionCreatedAt:cutoff,featurePacket:{x:1},predictionPayload:prediction,target:buildGoalWindowTarget({engine:'FT',minute:45})});
const crossRow={fixture_id:601,engine:'FT',market_period:'FT',minute:45,match_clock:crossObs.state.match_clock,score_home:0,score_away:0,observation_id:crossObs.observation_id,observation:crossObs,
  input_fingerprint:crossObs.input_fingerprint,feature_fingerprint:crossObs.feature_fingerprint,prediction_fingerprint:crossObs.prediction_fingerprint,content_fingerprint:crossObs.content_fingerprint,
  p_goal_5m:40,p_goal_10m:55,p_goal_15m:65,p_home_next:56,confidence:72,confidence_band:'HIGH',strict_metrics_eligible:null,outcome:{revision:0,history:[]}};
const atHt=resolveStrictGoalWindows(crossRow,{currentSnapshot:{fixture_id:601,period:'H1',minute:45,extra:2,status:'HT',goals:{home:0,away:0},received_at:'2026-10-07T10:03:00Z'},ended:false});
const cross=resolveStrictGoalWindows(atHt,{events:[{event_id:'h2-goal',source_id:'request-cross',fixture_id:601,period:'H2',type:'Goal',time:{elapsed:46},received_at:'2026-10-07T10:06:00Z'}]});
assert.equal(cross.outcome.first_goal_clock.period,'H2');assert.equal(cross.outcome.first_goal_clock.display,'46');assert.equal(cross.outcome.first_goal_min,null);
assert.equal(cross.outcome.goal_5m,null);assert.equal(cross.outcome.window_status.goal_5m,'UNSUPPORTED');assert.equal(cross.outcome.window_evidence.goal_5m.reason,'CROSS_PHASE_ELAPSED_UNPROVEN');
assert.ok(cross.outcome.evidence_ledger.events.some(e=>e.evidence_id==='EVENT:PROVIDER:h2-goal'));

// 4) Request/payload source ID is not event ID. Two goals in one response remain distinct.
const identityBase={fixture_id:701,engine:'FT',market_period:'FT',minute:60,score_home:0,score_away:0,observation:{target:buildGoalWindowTarget({engine:'FT',minute:60}),market_period:'FT',state:{minute:60,status:'2H'}},outcome:{revision:0,history:[]}};
const sameRequestEvents=[
  {source_id:'request-1',fixture_id:701,period:'H2',type:'Goal',team:{id:1},player:{id:11},time:{elapsed:63},received_at:'2026-10-07T10:05:00Z'},
  {source_id:'request-1',fixture_id:701,period:'H2',type:'Goal',team:{id:2},player:{id:22},time:{elapsed:69},received_at:'2026-10-07T10:05:00Z'}
];
const multi=resolveStrictGoalWindows(identityBase,{events:sameRequestEvents});assert.equal(multi.outcome.evidence_ledger.events.length,2);assert.equal(multi.outcome.first_goal_min,63);
const repeat=resolveStrictGoalWindows(multi,{events:sameRequestEvents});assert.equal(repeat.outcome.evidence_ledger.events.length,2);assert.equal(repeat.outcome.first_goal_min,63);
const explicitInitial=resolveStrictGoalWindows(identityBase,{events:[
  {event_id:'provider-g1',source_id:'request-2',fixture_id:701,period:'H2',type:'Goal',time:{elapsed:63},received_at:'2026-10-07T10:05:00Z'},
  {event_id:'provider-g2',source_id:'request-2',fixture_id:701,period:'H2',type:'Goal',time:{elapsed:69},received_at:'2026-10-07T10:05:00Z'}
]});
const oneCorrected=resolveStrictGoalWindows(explicitInitial,{events:[{event_id:'provider-g1',source_id:'request-3',fixture_id:701,period:'H2',type:'Goal',detail:'Cancelled Goal',time:{elapsed:63},received_at:'2026-10-07T10:08:00Z'}]});
assert.equal(oneCorrected.outcome.evidence_ledger.events.length,2);assert.equal(oneCorrected.outcome.evidence_ledger.events.find(e=>e.evidence_id==='EVENT:PROVIDER:provider-g1').state,'CANCELLED');assert.equal(oneCorrected.outcome.first_goal_min,69);

console.log('Batch02.2 four-review-probe regressions PASS');
