#!/usr/bin/env node
/* FOOTBALL EDGE — Batch 03 synthetic replay.
 * Demonstrates same-universe independence and split rankings only.
 * It must never be used to claim predictive lift.
 */
import fs from 'node:fs';
import {buildRawSnapshotUniverse} from './raw-universe.js';
import {evaluateSameUniverse} from './same-universe-evaluator.js';
import {rankFootballRows,rankMarketOpportunities} from './dual-ranking.js';
import {buildSameUniverseReport} from './same-universe-report.js';

const cutoff='2026-10-07T10:01:00.000Z';
const capture=(id,minute,status='2H')=>({capture_id:`syn-cap-${id}`,request_id:`syn-req-${id}`,fixture_id:id,match_clock:minute,status_short:status,
  received_at:'2026-10-07T10:00:30Z',fixture_payload_hash:`syn-hash-${id}`,has_events:0,has_stats:id===4?0:1,has_lineups:0,has_players:0,
  fixture_json:{fixture:{id,status:{short:status,elapsed:minute,extra:null}},league:{id:99,name:'SYNTHETIC'},teams:{home:{id:id*10+1,name:`SYN-H${id}`},away:{id:id*10+2,name:`SYN-A${id}`}},
    goals:{home:0,away:0},score:{halftime:{home:0,away:0}},events:[],statistics:[]}});
const universe=buildRawSnapshotUniverse({fixtureCaptures:[capture(1,30,'1H'),capture(2,55),capture(3,70),capture(4,40,'1H')],
  cutoff,datasetId:'BATCH03_SYNTHETIC',datasetHash:'synthetic-v1'});
function pred(engine,id){
  const p10={1:72,2:61,3:48,4:66}[id]-(engine==='H1'?2:0);
  return {engine,probabilities:{goal_5m:Math.max(1,p10-18),goal_10m:p10,goal_15m:Math.min(95,p10+12),home_next_goal_given_goal:55},
    confidence:{value:id===4?.42:.72,score_100:id===4?42:72},live_update:{effective_lambda_90:id===1?3.5:2.0},base:{lambda_match:2.2},direction:{home_given_goal:.55}};
}
const evaluation=evaluateSameUniverse({
  universe,engines:['FT','H1','HC'],
  oldEvaluator:({fixture,engine})=>({replay_status:'OLD_REPLAY_OK',eligible:fixture.fixture_id!==1,selected:fixture.fixture_id===2&&engine==='FT',
    state:fixture.fixture_id===1?'FAIL':'READY',gates:fixture.fixture_id===1?['OLD_GATE_FAIL_SYNTHETIC']:[]}),
  newEvaluator:({fixture,engine})=>({status:'MODELABLE_SYNTHETIC',modelable:true,prediction:pred(engine,fixture.fixture_id),
    packet:{state:{minute:fixture.match_clock,score_home:0,score_away:0,status:fixture.status_short}},reasons:fixture.data_reasons})
});
const football=rankFootballRows(evaluation.rows);
const marketMap=new Map();
for(const r of evaluation.rows){
  if(r.fixture_id===3||r.engine==='HC')continue; // explicit no-market examples
  const period=r.market_period;
  const odd=r.fixture_id===1?1.80:1.05;
  marketMap.set(r.observation_id,[{category:'over_under',market:period==='H1'?'Goals Over/Under - First Half':'Goals Over/Under',market_period:period,
    received_at:'2026-10-07T10:00:45Z',update:'2026-10-07T10:00:45Z',bookmaker:'SYN',
    values:[{value:'Over 0.5',handicap:.5,odd,main:true}]}]);
}
const market=rankMarketOpportunities(evaluation.rows,{marketRowsByObservation:marketMap,strictMarket:true});
const strictRows=evaluation.rows.map(r=>({observation_id:r.observation_id,strict_valid:false,strict_metrics_eligible:false,strict_eligibility:{eligible:false,reasons:['SYNTHETIC_NO_REAL_PERSISTENCE_ACK'],metric:'goal_10m'},reason:'SYNTHETIC_NO_REAL_PERSISTENCE_ACK'}));
const outcomes=evaluation.rows.map(r=>({observation_id:r.observation_id,resolved:false,reason:'SYNTHETIC_OUTCOME_NOT_SETTLED'}));
const report=buildSameUniverseReport({universe,evaluation,footballRanking:football,marketRanking:market,outcomes,strictRows});
const example=evaluation.rows.find(r=>r.fixture_id===1&&r.engine==='FT');
const payload={schema:'FE_PV2_BATCH03_SYNTHETIC_REPLAY_V1',replay_kind:'SYNTHETIC_PIPELINE_ONLY',predictive_lift_claim:false,
  old_rejected_new_seen:{fixture_id:1,engine:'FT',old_eligible:example.old.eligible,new_modelable:example.new.modelable,universe_id:example.universe_id,cutoff:example.cutoff},
  universe,evaluation,footballRanking:football,marketRanking:market,report};
const text=JSON.stringify(payload,null,2);
if(process.argv[2])fs.writeFileSync(process.argv[2],text+'\n');else process.stdout.write(text+'\n');
