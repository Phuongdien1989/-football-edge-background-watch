/* FOOTBALL EDGE — Prediction V2 / Batch 04
 * Replay-complete capture contract. Shadow/staging only.
 * No network calls live here; callers provide response bytes/payloads and timestamps.
 */
import {normalizeMarketPeriod,timestampIso,timestampMs,contentFingerprint} from './observation-contract.js';

export const CAPTURE_SCHEMA='FE_PV2_CAPTURE_PAYLOAD_V1';
export const CAPTURE_STATUS=Object.freeze({OK:'OK',EMPTY_VALID:'EMPTY_VALID',MISSING:'MISSING',FETCH_ERROR:'FETCH_ERROR'});
export const AVAILABILITY_STATUS=Object.freeze({AVAILABLE:'AVAILABLE',STALE:'STALE',AFTER_CUTOFF:'AFTER_CUTOFF',UNKNOWN_PROVENANCE:'UNKNOWN_PROVENANCE'});
const finite=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim())?null:(Number.isFinite(Number(v))?Number(v):null);
const stable=v=>{if(v===undefined)return '"__UNDEFINED__"';if(v===null||typeof v!=='object')return JSON.stringify(v);if(Array.isArray(v))return '['+v.map(stable).join(',')+']';return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')+'}'};
async function sha256Text(s){const bytes=new TextEncoder().encode(String(s??'')),digest=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('')}
function providerErrors(payload){const e=payload?.errors;if(!e)return [];if(Array.isArray(e))return e.filter(Boolean).map(String);if(typeof e==='object')return Object.entries(e).filter(([,v])=>v!==null&&v!==''&&v!==false).map(([k,v])=>`${k}:${typeof v==='string'?v:JSON.stringify(v)}`);return [String(e)]}
function responseRows(payload){return Array.isArray(payload?.response)?payload.response:null}
function inferFixtureId({fixtureId,params,payload}={}){const direct=finite(fixtureId??params?.fixture);if(direct!=null)return direct;const rows=responseRows(payload);const ids=[...new Set((rows||[]).map(x=>finite(x?.fixture?.id??x?.fixture_id)).filter(x=>x!=null))];return ids.length===1?ids[0]:null}
function inferProviderUpdatedAt(payload){const rows=responseRows(payload)||[];const candidates=[];for(const r of rows){for(const v of [r?.update,r?.fixture?.update,r?.fixture?.date,r?.updated_at]){const t=timestampIso(v);if(t)candidates.push(t)}}return candidates.sort().at(-1)||null}
function classify({payload,httpStatus,fetchError,wasRequested=true}={}){
  if(!wasRequested)return {status:CAPTURE_STATUS.MISSING,reason:'NOT_REQUESTED_OR_NOT_OBSERVED'};
  if(fetchError)return {status:CAPTURE_STATUS.FETCH_ERROR,reason:String(fetchError?.message||fetchError)};
  if(Number.isFinite(Number(httpStatus))&&Number(httpStatus)>=400)return {status:CAPTURE_STATUS.FETCH_ERROR,reason:`HTTP_${httpStatus}`};
  const errs=providerErrors(payload);if(errs.length)return {status:CAPTURE_STATUS.FETCH_ERROR,reason:`PROVIDER_ERROR:${errs.join('|').slice(0,300)}`};
  if(payload===null||payload===undefined)return {status:CAPTURE_STATUS.MISSING,reason:'PAYLOAD_MISSING'};
  const rows=responseRows(payload);if(rows&&rows.length===0)return {status:CAPTURE_STATUS.EMPTY_VALID,reason:'HTTP_OK_EMPTY_RESPONSE'};
  return {status:CAPTURE_STATUS.OK,reason:'PAYLOAD_PRESENT'};
}
export async function buildCapturedPayload({provider='API_FOOTBALL',source='BATCH04_STAGING',endpoint,params={},requestId=null,sourceId=null,fixtureId=null,period=null,
  requestStartedAt=null,receivedAt=null,providerUpdatedAt=null,httpStatus=null,fetchError=null,payload=null,rawText=null,payloadHash=null,wasRequested=true,metadata=null}={}){
  const received=timestampIso(receivedAt),started=timestampIso(requestStartedAt),providerUpdated=timestampIso(providerUpdatedAt)||inferProviderUpdatedAt(payload),cls=classify({payload,httpStatus,fetchError,wasRequested}),
    fid=inferFixtureId({fixtureId,params,payload}),p=normalizeMarketPeriod(period),body=rawText!=null?String(rawText):stable(payload),hash=payloadHash||await sha256Text(body),rid=requestId||`B4REQ-${hash.slice(0,20)}`,
    sid=sourceId||`${String(endpoint||'UNKNOWN')}:${fid??'MULTI'}:${received||'UNKNOWN'}:${hash.slice(0,12)}`;
  return {schema:CAPTURE_SCHEMA,record_id:`B4CAP-${contentFingerprint({provider,endpoint,params,rid,sid,hash,received})}`,provider,source,endpoint:endpoint||null,params,
    request_id:rid,source_id:sid,fixture_id:fid,market_period:p,request_started_at:started,received_at:received,provider_updated_at:providerUpdated,http_status:finite(httpStatus),
    payload_hash:hash,capture_status:cls.status,capture_reason:cls.reason,payload,payload_text:rawText!=null?String(rawText):null,metadata:metadata||null};
}
export function assessCaptureAvailability(record,{cutoff,maxAgeMs=null}={}){
  const cut=timestampMs(cutoff),received=timestampMs(record?.received_at),provider=timestampMs(record?.provider_updated_at),reasons=[];
  if(record?.capture_status===CAPTURE_STATUS.FETCH_ERROR)reasons.push('FETCH_ERROR');
  if(record?.capture_status===CAPTURE_STATUS.MISSING)reasons.push('MISSING');
  if(received==null)reasons.push('RECEIVED_AT_MISSING');
  if(cut!=null&&received!=null&&received>cut)reasons.push('AFTER_CUTOFF');
  const freshnessBase=provider??received,age=cut!=null&&freshnessBase!=null?Math.max(0,cut-freshnessBase):null;
  if(maxAgeMs!=null&&age!=null&&age>Number(maxAgeMs))reasons.push('STALE');
  let status=AVAILABILITY_STATUS.AVAILABLE;if(reasons.includes('AFTER_CUTOFF'))status=AVAILABILITY_STATUS.AFTER_CUTOFF;else if(reasons.includes('RECEIVED_AT_MISSING'))status=AVAILABILITY_STATUS.UNKNOWN_PROVENANCE;else if(reasons.includes('STALE'))status=AVAILABILITY_STATUS.STALE;
  return {available:!reasons.some(x=>['FETCH_ERROR','MISSING','RECEIVED_AT_MISSING','AFTER_CUTOFF','STALE'].includes(x)),availability_status:status,freshness_age_ms:age,reasons};
}
export function sourceReferenceFromCapture(record,{required=true}={}){return {kind:String(record?.endpoint||'CAPTURE'),provider:record?.provider||null,endpoint:record?.endpoint||null,source_id:record?.source_id||record?.record_id||null,request_id:record?.request_id||null,payload_hash:record?.payload_hash||null,provider_updated_at:record?.provider_updated_at||null,received_at:record?.received_at||null,required,metadata:{capture_status:record?.capture_status||null,record_id:record?.record_id||null}}}
export function classifyExpectedSource(records,{endpoint,fixtureId=null,period=null,cutoff,maxAgeMs=null}={}){
  const p=normalizeMarketPeriod(period),cut=timestampMs(cutoff),rows=(records||[]).filter(r=>String(r?.endpoint||'')===String(endpoint||'')&&(fixtureId==null||Number(r?.fixture_id)===Number(fixtureId))&&(p==null||r?.market_period==null||normalizeMarketPeriod(r.market_period)===p))
    .filter(r=>timestampMs(r?.received_at)!=null&&cut!=null&&timestampMs(r.received_at)<=cut).sort((a,b)=>timestampMs(a.received_at)-timestampMs(b.received_at));
  if(!rows.length)return {status:CAPTURE_STATUS.MISSING,record:null,availability:{available:false,availability_status:AVAILABILITY_STATUS.UNKNOWN_PROVENANCE,reasons:['MISSING_AT_CUTOFF'],freshness_age_ms:null}};
  const record=rows.at(-1),availability=assessCaptureAvailability(record,{cutoff,maxAgeMs});return {status:record.capture_status,record,availability};
}
export function captureContractSummary(records=[]){const counts={};for(const r of records||[])counts[r.capture_status]=(counts[r.capture_status]||0)+1;return {total:(records||[]).length,by_status:counts,with_received_at:(records||[]).filter(x=>timestampMs(x?.received_at)!=null).length,with_provider_updated_at:(records||[]).filter(x=>timestampMs(x?.provider_updated_at)!=null).length}}
