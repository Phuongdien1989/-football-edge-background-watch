// Staging evidence validation. Preserve the original capture hash algorithm.
import {timestampMs} from './observation-contract.js';
export function canonicalCaptureValue(v) {
  if (v === undefined) return '"__UNDEFINED__"';
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(canonicalCaptureValue).join(',') + ']';
  return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canonicalCaptureValue(v[k])).join(',') + '}';
}
export async function captureSha256(text) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('');
}
export async function validateCaptureContent(r) {
  const reasons = [];
  if (!r?.record_id || !r?.payload_hash || !r?.endpoint || timestampMs(r?.received_at) == null) reasons.push('CAPTURE_IDENTITY_INVALID');
  const body = r?.payload_text != null ? String(r.payload_text) : canonicalCaptureValue(r?.payload ?? null);
  if (await captureSha256(body) !== r?.payload_hash) reasons.push('CAPTURE_PAYLOAD_HASH_MISMATCH');
  if (r?.payload_text != null) {
    let parsed;
    try { parsed = JSON.parse(body); }
    catch { if (r.capture_status !== 'FETCH_ERROR' || r.payload != null) reasons.push('CAPTURE_RAW_JSON_INVALID'); }
    if (parsed !== undefined && canonicalCaptureValue(parsed) !== canonicalCaptureValue(r.payload)) reasons.push('CAPTURE_RAW_PARSED_MISMATCH');
  }
  return {valid: !reasons.length, reasons};
}
export async function assertCaptureContent(r) {
  const v = await validateCaptureContent(r);
  if (!v.valid) throw new Error(v.reasons.join(','));
  return r;
}
