import assert from 'node:assert/strict';
import {buildRawSnapshotUniverse} from './raw-universe.js';
import {evaluateNewFromRawFixture} from './raw-new-evaluator.js';
import {evaluateSameUniverse} from './same-universe-evaluator.js';
import {rankFootballRows,rankMarketOpportunities} from './dual-ranking.js';
import {buildSameUniverseReport} from './same-universe-report.js';

const cutoff='2026-10-07T10:01:00.000Z';
function capture(id,{status='2H',minute=60,home=0,away=0,received='2026-10-07T10:00:30Z'}={}){
  return {capture_id:`c-${id}-${minute}`,request_id:`r-${id}`,fixture_id:id,match_clock:minute,status_short:status,received_at:received,
    fixture_payload_hash:`h-${id}-${minute}`,has_events:0,has_stats:0,has_lineups:0,has_players:0,
    fixture_json:{fixture:{id,status:{short:status,elapsed:minute,extra:null}},league:{id:1,name:'T'},teams:{home:{id:id*10+1,name:`H${id}`},away:{id:id*10+2,name:`A${id}`}},goals:{home,away},score:{halftime:{home:0,away:0}},events:[],statistics:[]}};
}
function evalOne(c,engine='FT'){
  const universe=buildRawSnapshotUniverse({fixtureCaptures:[c],cutoff,datasetId:`d-${c.fixture_id}`,datasetHash:`x-${c.fixture_id}`});
  const row=evaluateSameUniverse({universe,engines:[engine],oldEvaluator:()=>({replay_status:'OLD_REPLAY_OK',eligible:false,selected:false}),
    newEvaluator:({fixture,engine,universe})=>evaluateNewFromRawFixture(fixture,{engine,cutoffMs:Date.parse(universe.cutoff)})}).rows[0];
  return {universe,row};
}

// 1) requested vs effective horizon: FT 60 and FT 88 must not be the same full rolling P10 cohort.
const a60=evalOne(capture(60,{minute:60}), 'FT').row;
const a88=evalOne(capture(88,{minute:88}), 'FT').row;
assert.equal(a60.new.modelable,true);assert.equal(a88.new.modelable,true);
const hr=rankFootballRows([a60,a88],{horizons:[10]});
const r60=hr.rows.find(r=>r.fixture_id===60),u88=hr.unsupported.find(r=>r.fixture_id===88&&r.requested_horizon_min===10);
assert.ok(r60);assert.equal(r60.requested_horizon_min,10);assert.equal(r60.effective_horizon_min,10);assert.equal(r60.football_rank_status,'RANKABLE_FULL_REQUESTED_HORIZON');
assert.ok(u88);assert.equal(u88.requested_horizon_min,10);assert.equal(u88.effective_horizon_min,2);assert.equal(u88.football_rank_status,'UNSUPPORTED_TARGET_FOR_RANKING');
assert.notEqual(r60.target_signature,u88.target_signature);

// H1 near nominal 45 and FT near/after nominal 90 stay observations but are not claimed as full rolling horizons.
const h43=evalOne(capture(143,{status:'1H',minute:43}), 'H1').row;
const hRank=rankFootballRows([h43],{horizons:[5,10]});
assert.equal(hRank.rows.length,0);assert.ok(hRank.unsupported.every(r=>r.football_rank_status==='UNSUPPORTED_TARGET_FOR_RANKING'));
assert.deepEqual(hRank.unsupported.map(r=>r.effective_horizon_min).sort((x,y)=>x-y),[2,2]);
const ft90=evalOne(capture(190,{status:'2H',minute:90}), 'FT').row;
const ft91=evalOne(capture(191,{status:'2H',minute:91}), 'FT').row;
const endRank=rankFootballRows([ft90,ft91],{horizons:[5]});
assert.equal(endRank.rows.length,0);assert.ok(endRank.unsupported.every(r=>r.effective_horizon_min===0));
assert.ok(endRank.unsupported.every(r=>r.actual_period_end_assumed===false));

// 2) missing state is not coerced to zero.
const invalidMinute=capture(201,{minute:null});
invalidMinute.match_clock=null;invalidMinute.fixture_json.fixture.status.elapsed=null;
const eMissingMinute=evalOne(invalidMinute,'FT').row.new;
assert.equal(eMissingMinute.modelable,false);assert.equal(eMissingMinute.status,'UNMODELABLE_INVALID_STATE');assert.ok(eMissingMinute.reasons.includes('MINUTE_MISSING'));assert.equal(eMissingMinute.prediction,null);
const invalidScore=capture(202,{minute:20,home:null,away:0});
invalidScore.fixture_json.goals.home=null;
const eMissingScore=evalOne(invalidScore,'FT').row.new;
assert.equal(eMissingScore.modelable,false);assert.equal(eMissingScore.status,'UNMODELABLE_INVALID_STATE');assert.ok(eMissingScore.reasons.includes('SCORE_HOME_MISSING'));
// Valid zero minute / 0-0 is distinct from missing.
const zero=evalOne(capture(203,{status:'1H',minute:0,home:0,away:0}),'FT').row.new;
assert.equal(zero.modelable,true);assert.equal(zero.packet.state.minute,0);assert.equal(zero.packet.state.score_home,0);assert.equal(zero.packet.state.score_away,0);

// Fixture remains in universe denominator when state is invalid/unmodelable.
const badUniverse=buildRawSnapshotUniverse({fixtureCaptures:[invalidMinute,invalidScore,capture(203,{status:'1H',minute:0,home:0,away:0})],cutoff,datasetId:'bad-state',datasetHash:'bad-state'});
const badEval=evaluateSameUniverse({universe:badUniverse,engines:['FT'],oldEvaluator:null,newEvaluator:({fixture,engine,universe})=>evaluateNewFromRawFixture(fixture,{engine,cutoffMs:Date.parse(universe.cutoff)})});
assert.equal(badEval.rows.length,3);assert.equal(badEval.rows.filter(r=>r.new.modelable).length,1);assert.equal(badEval.rows.filter(r=>r.new.status==='UNMODELABLE_INVALID_STATE').length,2);

// 3) OLD availability is whitelist-only. ERROR is not available.
const oldErrEval=evaluateSameUniverse({universe:badUniverse,engines:['FT'],oldEvaluator:()=>{throw new Error('synthetic old failure')},newEvaluator:({fixture,engine,universe})=>evaluateNewFromRawFixture(fixture,{engine,cutoffMs:Date.parse(universe.cutoff)})});
const oldErrFootball=rankFootballRows(oldErrEval.rows,{horizons:[10]});
const oldErrMarket=rankMarketOpportunities(oldErrEval.rows,{marketRowsByObservation:new Map(),strictMarket:true});
const oldErrReport=buildSameUniverseReport({universe:badUniverse,evaluation:oldErrEval,footballRanking:oldErrFootball,marketRanking:oldErrMarket,strictRows:[]});
assert.equal(oldErrReport.coverage.old_replay_available_observations,0);assert.equal(oldErrReport.coverage.old_replay_error_observations,3);

// Strict report requires authoritative eligibility; contradictory flags are quarantined.
const strictConflict=buildSameUniverseReport({universe:badUniverse,evaluation:badEval,footballRanking:rankFootballRows(badEval.rows,{horizons:[10]}),marketRanking:rankMarketOpportunities(badEval.rows,{marketRowsByObservation:new Map(),strictMarket:true}),
  strictRows:[{observation_id:'x',strict_valid:false,strict_metrics_eligible:true,strict_eligibility:{eligible:true,reasons:[],metric:'goal_10m'}}]});
assert.equal(strictConflict.coverage.strict_valid,0);assert.equal(strictConflict.coverage.strict_quarantined,1);assert.equal(strictConflict.reasons.strict_quarantine.STRICT_FLAG_CONTRADICTION,1);
const strictGood=buildSameUniverseReport({universe:badUniverse,evaluation:badEval,footballRanking:rankFootballRows(badEval.rows,{horizons:[10]}),marketRanking:rankMarketOpportunities(badEval.rows,{marketRowsByObservation:new Map(),strictMarket:true}),
  strictRows:[{observation_id:'y',strict_valid:true,strict_metrics_eligible:true,strict_eligibility:{eligible:true,reasons:[],metric:'goal_10m'}}]});
assert.equal(strictGood.coverage.strict_valid,1);assert.equal(strictGood.coverage.strict_quarantined,0);

// 4) Preserve Batch03 invariants: OLD does not filter NEW; no market TOP; negative edge remains NO_ENTRY; cutoff holds.
const caps=[capture(301,{minute:60,received:'2026-10-07T10:00:00Z'}),capture(302,{minute:61,received:'2026-10-07T10:02:00Z'})];
const uni=buildRawSnapshotUniverse({fixtureCaptures:caps,cutoff,datasetId:'cutoff',datasetHash:'cutoff'});
assert.deepEqual(uni.fixture_ids,[301]);
const ev=evaluateSameUniverse({universe:uni,engines:['FT'],oldEvaluator:()=>({replay_status:'OLD_REPLAY_OK',eligible:false,selected:false}),newEvaluator:({fixture,engine,universe})=>evaluateNewFromRawFixture(fixture,{engine,cutoffMs:Date.parse(universe.cutoff)})});
assert.equal(ev.rows[0].old.eligible,false);assert.equal(ev.rows[0].new.modelable,true);
const noMarket=rankMarketOpportunities(ev.rows,{marketRowsByObservation:new Map(),strictMarket:true});
assert.equal(noMarket.rows[0].market_rank,null);assert.equal(noMarket.rows[0].market_top,null);assert.equal(noMarket.rows[0].entry_decision,'NO_ENTRY');
const poorMarket=new Map([[ev.rows[0].observation_id,[{category:'over_under',market:'Goals Over/Under',market_period:'FT',received_at:'2026-10-07T10:00:30Z',update:'2026-10-07T10:00:30Z',bookmaker:'T',values:[{value:'Over 5.5',handicap:5.5,odd:1.01,main:true}]}]]]);
const neg=rankMarketOpportunities(ev.rows,{marketRowsByObservation:poorMarket,strictMarket:true});
assert.ok(neg.rows[0].market_rank!=null);assert.notEqual(neg.rows[0].market_status,'POSITIVE_EDGE');assert.equal(neg.rows[0].entry_decision,'NO_ENTRY');

console.log('Batch03.1 target/state/report regressions PASS');
