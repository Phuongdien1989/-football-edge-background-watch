/* FOOTBALL EDGE — Prediction V2 / Batch 03
 * Evaluate OLD and NEW independently on the same raw-universe fixture/time membership.
 * OLD results are comparator outputs only; they never filter NEW.
 */
import {marketPeriodForEngine} from './observation-contract.js';

const DEFAULT_ENGINES=['FT','H1','HC'];
const clone=v=>v==null?v:JSON.parse(JSON.stringify(v));
function obsId(universe,fixtureId,engine){
  return `${universe?.universe_id||'NO_UNIVERSE'}:${fixtureId}:${String(engine||'').toUpperCase()}:${universe?.cutoff||'NO_CUTOFF'}`;
}
export function evaluateSameUniverse({
  universe,
  engines=DEFAULT_ENGINES,
  oldEvaluator=null,
  newEvaluator=null
}={}){
  if(!universe?.universe_id||!universe?.cutoff||!Array.isArray(universe?.fixtures))throw new Error('valid raw universe required');
  const rows=[];
  for(const fixture of universe.fixtures){
    for(const engine0 of engines||[]){
      const engine=String(engine0||'').toUpperCase();if(!engine)continue;
      const common={
        universe_id:universe.universe_id,
        cutoff:universe.cutoff,
        fixture_id:Number(fixture.fixture_id),
        engine,
        market_period:marketPeriodForEngine(engine),
        observation_id:obsId(universe,fixture.fixture_id,engine),
        raw_capture_id:fixture.capture_id||null,
        raw_capture_received_at:fixture.capture_received_at||null,
        data_status:fixture.data_status||null,
        data_presence:clone(fixture.data_presence||{}),
        data_reasons:[...(fixture.data_reasons||[])],
        source_references:clone(fixture.source_references||[])
      };
      let oldResult,newResult;
      if(typeof oldEvaluator==='function'){
        try{oldResult=oldEvaluator({fixture:clone(fixture),engine,universe:clone(universe),common:clone(common)})}
        catch(e){oldResult={replay_status:'OLD_REPLAY_ERROR',eligible:null,selected:null,error:e?.message||String(e)}}
      }else{
        oldResult={replay_status:'OLD_REPLAY_UNAVAILABLE',eligible:null,selected:null,
          reason:'No exact OLD replay evaluator supplied for this raw artifact/cutoff.'};
      }
      if(typeof newEvaluator==='function'){
        try{newResult=newEvaluator({fixture:clone(fixture),engine,universe:clone(universe),common:clone(common)})}
        catch(e){newResult={status:'NEW_REPLAY_ERROR',modelable:false,prediction:null,error:e?.message||String(e)}}
      }else{
        newResult={status:'NEW_MODEL_UNAVAILABLE',modelable:false,prediction:null,reason:'No NEW evaluator supplied.'};
      }
      rows.push({...common,old:oldResult||{replay_status:'OLD_REPLAY_NULL'},new:newResult||{status:'NEW_REPLAY_NULL'}});
    }
  }
  return {
    schema:'FE_PV2_SAME_UNIVERSE_EVALUATION_V1',
    universe_id:universe.universe_id,
    cutoff:universe.cutoff,
    fixture_count:universe.fixture_count,
    engine_count:(engines||[]).length,
    row_count:rows.length,
    rows
  };
}
export function assertSameUniverseRows(evaluation){
  const uid=evaluation?.universe_id,cut=evaluation?.cutoff;
  if(!uid||!cut)return {ok:false,reason:'MISSING_UNIVERSE_ID_OR_CUTOFF'};
  for(const r of evaluation?.rows||[]){
    if(r.universe_id!==uid||r.cutoff!==cut)return {ok:false,reason:'ROW_UNIVERSE_OR_CUTOFF_MISMATCH',row:r.observation_id};
  }
  return {ok:true,reason:'SAME_UNIVERSE_AND_CUTOFF'};
}
export function joinSameUniverseComparisons(oldRows=[],newRows=[]){
  const key=r=>`${r?.universe_id}|${r?.cutoff}|${r?.fixture_id}|${r?.engine}|${r?.market_period}`;
  const om=new Map((oldRows||[]).map(r=>[key(r),r])),nm=new Map((newRows||[]).map(r=>[key(r),r])),keys=[...new Set([...om.keys(),...nm.keys()])].sort(),out=[];
  for(const k of keys){
    const o=om.get(k),n=nm.get(k);
    if(!o||!n)throw new Error(`OLD/NEW universe mismatch for ${k}`);
    if(o.universe_id!==n.universe_id||o.cutoff!==n.cutoff)throw new Error(`OLD/NEW cutoff mismatch for ${k}`);
    out.push({key:k,universe_id:n.universe_id,cutoff:n.cutoff,fixture_id:n.fixture_id,engine:n.engine,market_period:n.market_period,old:o,new:n});
  }
  return out;
}
