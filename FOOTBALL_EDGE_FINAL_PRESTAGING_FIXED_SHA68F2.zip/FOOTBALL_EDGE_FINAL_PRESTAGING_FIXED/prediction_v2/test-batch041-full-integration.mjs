import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {PilotBudgetController,MemoryBudgetStateStore} from '../staging_kit/batch041-budget-controller.js';
import {capturePilotTick,captureSlowContext} from '../staging_kit/batch04-collector-worker.js';
import {LocalEvidenceRecorder} from './local-evidence-recorder.mjs';
import {loadExactP2052Runtime} from '../staging_kit/test_fixtures/p2052-vm-helper.mjs';
import {buildExactOldOutputRecord,P2052_EXACT_SHA256} from './old-exact-contract.js';
import {buildReplayCompleteCohort} from './replay-complete-cohort.js';
import {compactShadowEvidence} from './shadow-evidence.js';
import {sourceReferenceFromCapture} from './capture-contract.js';
import {createPaperMarketRecord} from './paper-market-evidence.js';
import {resolveStrictGoalWindows} from './strict-outcome-resolver.js';
import {validatePersistenceAcknowledgement} from './observation-contract.js';

class FakeClock{
  constructor(t=Date.parse('2026-10-07T10:00:00Z')){this.t=t}
  now(){return this.t}
  async sleep(ms){this.t+=ms;await new Promise(r=>setImmediate(r))}
}
function headers(map={}){return {get:k=>map[String(k).toLowerCase()]??null}}
function response(obj,status=200,h={}){return {status,headers:headers(h),text:async()=>JSON.stringify(obj)}}
const fixture={fixture:{id:500,status:{short:'2H',elapsed:60},timestamp:Date.parse('2026-10-07T09:00:00Z')/1000,date:'2026-10-07T09:00:00Z'},league:{id:77,season:2026,name:'Test'},teams:{home:{id:50,name:'Home'},away:{id:60,name:'Away'}},goals:{home:0,away:0},score:{halftime:{home:0,away:0},fulltime:{home:null,away:null}}};
const liveStats={response:[
  {team:{id:50,name:'Home'},statistics:[{type:'Shots on Goal',value:4},{type:'Total Shots',value:10},{type:'Shots insidebox',value:6},{type:'Corner Kicks',value:4},{type:'Expected Goals',value:1.2},{type:'Ball Possession',value:'55%'}]},
  {team:{id:60,name:'Away'},statistics:[{type:'Shots on Goal',value:1},{type:'Total Shots',value:4},{type:'Shots insidebox',value:2},{type:'Corner Kicks',value:1},{type:'Expected Goals',value:.3},{type:'Ball Possession',value:'45%'}]}
]};
const liveOdds={response:[{fixture:{id:500,status:'2H'},update:'2026-10-07T10:00:00Z',status:{blocked:false,stopped:false,finished:false},odds:[
  {id:1,name:'Goals Over/Under',values:[{value:'Over 0.5',handicap:'0.5',odd:'1.85',main:true,suspended:false},{value:'Under 0.5',handicap:'0.5',odd:'1.95',main:true,suspended:false}]},
  {id:2,name:'First Half Goals Over/Under',values:[{value:'Over 0.5',handicap:'0.5',odd:'1.90',main:true,suspended:false},{value:'Under 0.5',handicap:'0.5',odd:'1.90',main:true,suspended:false}]}
]}]};
function teamStats(gf,ga){return {response:{form:'WWDLW',goals:{for:{average:{total:String(gf)}},against:{average:{total:String(ga)}}}}}}
const standings={response:[{league:{standings:[[
  {rank:2,team:{id:50},points:18,goalsDiff:8,all:{played:10},home:{played:5,win:4,draw:0}},
  {rank:8,team:{id:60},points:10,goalsDiff:-2,all:{played:10},away:{played:5,win:1,draw:1}}
]]}}]};
const recent=(team)=>({response:[{fixture:{date:'2026-10-01T12:00:00Z'},teams:{home:{id:team},away:{id:999}},goals:{home:2,away:1}}]});
const quotaHeaders={'x-ratelimit-requests-limit':'75000','x-ratelimit-requests-remaining':'74000','x-ratelimit-limit':'100','x-ratelimit-remaining':'99'};
function fakeTransport(clock,calls){return async url=>{
  const u=new URL(url),ep=u.pathname,params=Object.fromEntries(u.searchParams.entries());calls.push({endpoint:ep,params,at:clock.now()});
  if(ep==='/status')return response({response:{requests:{current:1000,limit_day:75000},subscription:{plan:'SYNTHETIC_TEST'}}},200,quotaHeaders);
  if(ep==='/fixtures'&&params.live==='all')return response({response:[fixture]},200,quotaHeaders);
  if(ep==='/fixtures/statistics')return response(liveStats,200,quotaHeaders);
  if(ep==='/fixtures/events')return response({response:[]},200,quotaHeaders);
  if(ep==='/odds/live')return response(liveOdds,200,quotaHeaders);
  if(ep==='/fixtures/lineups')return response({response:[]},200,quotaHeaders);
  if(ep==='/fixtures/players')return response({response:[]},200,quotaHeaders);
  if(ep==='/injuries')return response({response:[]},200,quotaHeaders);
  if(ep==='/predictions')return response({response:[]},200,quotaHeaders);
  if(ep==='/standings')return response(standings,200,quotaHeaders);
  if(ep==='/teams/statistics')return response(Number(params.team)===50?teamStats(1.7,.9):teamStats(1.0,1.4),200,quotaHeaders);
  if(ep==='/fixtures'&&params.team)return response(recent(Number(params.team)),200,quotaHeaders);
  if(ep==='/players')return response({response:[]},200,quotaHeaders);
  throw new Error(`UNEXPECTED_FAKE_ENDPOINT:${url}`);
}}

const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'fe-b41-full-')),dbPath=path.join(tmp,'evidence.sqlite'),recorder=new LocalEvidenceRecorder(dbPath),clock=new FakeClock(),calls=[];
const budget=new PilotBudgetController({pilotId:'b41-full',store:new MemoryBudgetStateStore(),clock,allowNewPilot:true,limits:{max_requests_total:100,max_requests_per_minute:30,provider_minute_fraction:.5,max_concurrency:4,request_start_gap_ms:250,daily_reserve_min:10000,minute_safety_remaining:2,duration_ms:90*60000}});
const sink=async r=>recorder.recordCapture(r),fetchImpl=fakeTransport(clock,calls);
const tick=await capturePilotTick({env:{APISPORTS_KEY:'SYNTHETIC_ONLY'},db:null,captureSink:sink,budget,fetchImpl,maxFixtures:1});
assert.equal(tick.status,'OK');assert.deepEqual(tick.fixtures,[500]);
const slow=await captureSlowContext({env:{APISPORTS_KEY:'SYNTHETIC_ONLY'},db:null,captureSink:sink,budget,fixture,fetchImpl,maxRequests:20});assert.equal(slow.status,'OK');
const all=recorder.listCaptures(),fxRecords=all.filter(r=>Number(r.fixture_id)===500),liveInputs=fxRecords.filter(r=>['/fixtures/statistics','/fixtures/events','/odds/live'].includes(r.endpoint));
const cutoffMs=Math.max(...all.map(r=>Date.parse(r.received_at)).filter(Number.isFinite)),cutoff=new Date(cutoffMs).toISOString();
assert.ok(all.every(r=>Date.parse(r.received_at)<=cutoffMs),'every capture used by replay must be available by cutoff');
const statsRec=liveInputs.find(r=>r.endpoint==='/fixtures/statistics'),eventsRec=liveInputs.find(r=>r.endpoint==='/fixtures/events'),oddsRec=liveInputs.find(r=>r.endpoint==='/odds/live');assert.ok(statsRec&&eventsRec&&oddsRec);

// Exact OLD runtime bridge: calls exact P2.0.5.2 function references loaded from the guarded runtime fixture.
const ctx=loadExactP2052Runtime({nowMs:cutoffMs+1000}),bridge=ctx.FE_B4_OLD_EXACT;assert.equal(bridge.baseline_sha256,P2052_EXACT_SHA256);assert.equal(Array.from(bridge.missing_functions()).length,0);
const oldRaw={fixture,statistics_payload:statsRec.payload,events_payload:eventsRec.payload,odds_payload:oddsRec.payload,cutoff_ms:cutoffMs,stats_received_at_ms:Date.parse(statsRec.received_at),source_received_at_ms:liveInputs.map(r=>Date.parse(r.received_at)),dq_score:90,integrity_score:95};
assert.ok(oldRaw.source_received_at_ms.every(t=>t<=oldRaw.cutoff_ms));
const bridged=bridge.evaluate(oldRaw,'FT');assert.equal(bridged.unavailable,undefined);assert.ok(bridged.evaluation);
const oldRecord=buildExactOldOutputRecord({fixtureId:500,engine:'FT',cutoff,evaluation:bridged.evaluation,state:{...bridged.state,selected:false},sourceReferences:liveInputs.map(r=>sourceReferenceFromCapture(r,{required:true})),metadata:{runtime_source:'EXACT_P2052_VM_BRIDGE',synthetic_auxiliary_dq:true}});recorder.recordOldExact(oldRecord);

// Captured cohort uses the same cutoff; OLD eligibility is output only, never NEW universe selection.
const cohort=buildReplayCompleteCohort({captureRecords:all,oldExactRecords:[oldRecord],cutoff,engines:['FT']});assert.equal(cohort.universe.fixture_count,1);const row=cohort.rows[0];assert.equal(row.fixture_id,500);assert.equal(row.old.status,'OLD_CAPTURED_EXACT');assert.equal(row.new.modelable,true);assert.ok(row.new.packet.capture_feature_support.stats);assert.ok(row.market.assessed_count>0);

const item={id:500,latest:{minute:row.new.packet.state.minute,status:row.new.packet.state.status,goals:{home:row.new.packet.state.score_home,away:row.new.packet.state.score_away}}},sourceRefs=fxRecords.map(r=>sourceReferenceFromCapture(r,{required:false})),createdAt=cutoffMs+1000;
const evidence=compactShadowEvidence({item,packet:row.new.packet,prediction:row.new.prediction,context:row.new.context,now:createdAt,sourceRefs,marketPeriod:'FT',evaluationCutoff:cutoff,modelVersion:'PV2_BATCH041_FULL_INTEGRATION',configVersion:'PV2_NO_WEIGHT_CHANGE'});
const paper=row.market.best?createPaperMarketRecord({fixtureId:500,capturedAt:createdAt,state:row.new.packet.state,bestMarket:row.market.best,marketPeriod:'FT',targetPeriod:'FT',evaluationCutoff:cutoff,observation:evidence.observation,strict:true,confidence:row.new.prediction?.confidence?.score_100}):null;assert.ok(paper);
const lockedPrediction=JSON.stringify(evidence.observation.prediction_snapshot),ack=recorder.persistLockedBundle({observation:evidence.observation,paperRecord:paper,oldExactRecord:oldRecord});assert.equal(recorder.verifyLocalAck(ack).valid,true);assert.equal(ack.ack_origin,'LOCAL_DURABLE_TEST');assert.equal(validatePersistenceAcknowledgement(evidence.observation,ack).valid,false);
const resolved=resolveStrictGoalWindows(evidence,{events:[{id:'late-goal-1',type:'Goal',time:{elapsed:63},received_at:new Date(cutoffMs+10*60000).toISOString()}],snapshots:[]});assert.equal(resolved.outcome.goal_5m,true);recorder.appendOutcome(evidence.observation_id,resolved.outcome,{receivedAt:new Date(cutoffMs+10*60000).toISOString()});
recorder.close();const reopened=new LocalEvidenceRecorder(dbPath),persisted=reopened.loadLockedObservation(evidence.observation_id);assert.equal(JSON.stringify(persisted.observation.prediction_snapshot),lockedPrediction);assert.equal(reopened.loadOutcomeHistory(evidence.observation_id).length,1);

const summary={schema:'FE_PV2_BATCH041_FULL_INTEGRATION_EVIDENCE_V1',synthetic_transport:true,real_local_sqlite:true,api_calls_real:0,fixture_id:500,cutoff,collector_requests:calls.length,budget:budget.snapshot(),all_sources_at_or_before_cutoff:all.every(r=>Date.parse(r.received_at)<=cutoffMs),exact_old_bridge_baseline_sha256:bridge.baseline_sha256,old_exact_status:row.old.status,old_eligible:row.old.eligible,new_modelable:row.new.modelable,new_status:row.new.status,market_assessed_count:row.market.assessed_count,local_ack_origin:ack.ack_origin,local_ack_valid:reopened.verifyLocalAck(ack).valid,server_ack_valid:validatePersistenceAcknowledgement(evidence.observation,ack).valid,prediction_unchanged_after_outcome:JSON.stringify(persisted.observation.prediction_snapshot)===lockedPrediction,outcome_goal_5m:resolved.outcome.goal_5m,outcome_revisions:reopened.loadOutcomeHistory(evidence.observation_id).length};
if(process.env.BATCH041_FULL_EVIDENCE_JSON)fs.writeFileSync(process.env.BATCH041_FULL_EVIDENCE_JSON,JSON.stringify(summary,null,2));
reopened.close();fs.rmSync(tmp,{recursive:true,force:true});
console.log('Batch04.1 collector→persistence→exact OLD/NEW→locked observation→outcome integration PASS');
