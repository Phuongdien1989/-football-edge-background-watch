/* FOOTBALL EDGE — Prediction V2 / Batch 03.1
 * Two independent ranking surfaces:
 * 1) FOOTBALL ranking: prediction/confidence only, grouped by exact engine/period/requested horizon,
 *    and only when the existing B3 model actually evaluated the full requested rolling horizon.
 * 2) MARKET ranking: actual supported offers only, using the existing B4 expected-return score.
 *
 * IMPORTANT: Batch 03.1 does not change probability-engine.js. Near the B3 nominal 45/90
 * regulation cap, B3 may produce a requested P5/P10/P15 value using a shorter effective horizon.
 * Such observations remain in coverage but are UNSUPPORTED_TARGET_FOR_RANKING.
 */
import {evaluateActualMarkets,EXPERIMENTAL_MARKET_FRESHNESS_POLICY} from './opportunity-ranking.js';

const finite=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim())?null:(Number.isFinite(Number(v))?Number(v):null);
const round=(v,d=5)=>{const n=finite(v);if(n==null)return null;const p=10**d;return Math.round(n*p)/p};
export const FOOTBALL_RANK_VERSION='PV2_FOOTBALL_RANK_V2_FULL_REQUESTED_HORIZON_PROVISIONAL';
export const MARKET_RANK_VERSION='PV2_MARKET_RANK_V1_EXISTING_B4_SCORE';
export const FOOTBALL_TARGET_SEMANTICS='ROLLING_NEXT_GOAL_REQUESTED_HORIZON';
export const FOOTBALL_MODEL_HORIZON_SEMANTICS='B3_NOMINAL_REGULATION_CAP_ONLY_NOT_ACTUAL_PERIOD_END';

function probFor(pred,h){return finite(pred?.probabilities?.[`goal_${h}m`])}
function confidenceFor(pred){return finite(pred?.confidence?.value)}
function nominalModelCap(engine){const e=String(engine||'').toUpperCase();return e==='H1'?45:(e==='FT'||e==='HC'?90:null)}
function requestedSignature(row,h){return `${String(row?.engine||'').toUpperCase()}|${row?.market_period||'UNKNOWN'}|GOAL_${h}M|REQUESTED_${h}M`}
function horizonMeta(row,h){
  const requested=finite(h),minute=finite(row?.new?.packet?.state?.minute),cap=nominalModelCap(row?.engine);
  if(requested==null||requested<=0)return {requested_horizon_min:requested,effective_horizon_min:null,target_rank_compatible:false,
    target_rank_status:'UNSUPPORTED_TARGET_FOR_RANKING',target_rank_reason:'INVALID_REQUESTED_HORIZON',nominal_model_cap_min:cap};
  if(minute==null||cap==null)return {requested_horizon_min:requested,effective_horizon_min:null,target_rank_compatible:false,
    target_rank_status:'UNSUPPORTED_TARGET_FOR_RANKING',target_rank_reason:minute==null?'STATE_MINUTE_MISSING_FOR_TARGET':'MODEL_PERIOD_CAP_UNDEFINED',nominal_model_cap_min:cap};
  const effective=Math.max(0,Math.min(requested,cap-minute)),compatible=Math.abs(effective-requested)<=1e-9;
  let reason=null;
  if(!compatible){
    reason=minute>=cap?'B3_MODEL_HORIZON_ZERO_AT_OR_AFTER_NOMINAL_REGULATION_CAP':'B3_MODEL_HORIZON_TRUNCATED_BEFORE_REQUESTED_WINDOW';
  }
  return {requested_horizon_min:requested,effective_horizon_min:effective,target_rank_compatible:compatible,
    target_rank_status:compatible?'FULL_REQUESTED_HORIZON':'UNSUPPORTED_TARGET_FOR_RANKING',target_rank_reason:reason,
    target_semantics:FOOTBALL_TARGET_SEMANTICS,model_horizon_semantics:FOOTBALL_MODEL_HORIZON_SEMANTICS,nominal_model_cap_min:cap,
    actual_period_end_assumed:false,stoppage_time_supported_by_model:false};
}
function effectiveSignature(row,h,meta){return `${requestedSignature(row,h)}|EFFECTIVE_${meta?.effective_horizon_min==null?'UNKNOWN':meta.effective_horizon_min}M|${meta?.target_rank_status||'UNKNOWN'}`}
function cmpFootball(a,b){
  const ap=finite(a.probability),bp=finite(b.probability);if(ap!==bp)return (bp??-Infinity)-(ap??-Infinity);
  const ac=finite(a.confidence),bc=finite(b.confidence);if(ac!==bc)return (bc??-Infinity)-(ac??-Infinity);
  return Number(a.fixture_id)-Number(b.fixture_id)||String(a.observation_id).localeCompare(String(b.observation_id));
}
export function rankFootballRows(evaluationRows=[],{horizons=[5,10,15]}={}){
  const candidates=[],unsupported=[];
  for(const row of evaluationRows||[]){
    const pred=row?.new?.prediction;
    if(!row?.new?.modelable||!pred){
      unsupported.push({...row,football_rank_status:'UNMODELABLE',football_rank_reason:row?.new?.status||'NO_PREDICTION'});
      continue;
    }
    for(const h0 of horizons||[]){
      const h=Number(h0),p=probFor(pred,h),c=confidenceFor(pred),hm=horizonMeta(row,h),reqSig=requestedSignature(row,h),effSig=effectiveSignature(row,h,hm);
      const base={
        universe_id:row.universe_id,cutoff:row.cutoff,fixture_id:row.fixture_id,engine:row.engine,market_period:row.market_period,
        observation_id:row.observation_id,target_horizon_min:h,requested_horizon_min:hm.requested_horizon_min,effective_horizon_min:hm.effective_horizon_min,
        target_key:`goal_${h}m`,requested_target_signature:reqSig,target_signature:effSig,target_semantics:hm.target_semantics,
        model_horizon_semantics:hm.model_horizon_semantics,nominal_model_cap_min:hm.nominal_model_cap_min,actual_period_end_assumed:false,
        stoppage_time_supported_by_model:false,probability:p,confidence:c,football_rank_version:FOOTBALL_RANK_VERSION,provisional:true,market_independent:true,
        data_status:row.data_status,data_reasons:row.data_reasons
      };
      if(![5,10,15].includes(h)||p==null||c==null){
        unsupported.push({...base,football_rank_status:'UNSUPPORTED_TARGET',football_rank_reason:'MISSING_PROBABILITY_OR_CONFIDENCE'});
        continue;
      }
      if(hm.target_rank_compatible!==true){
        unsupported.push({...base,football_rank_status:'UNSUPPORTED_TARGET_FOR_RANKING',football_rank_reason:hm.target_rank_reason});
        continue;
      }
      candidates.push({...base,football_rank_status:'RANKABLE_FULL_REQUESTED_HORIZON',football_rank_reason:null});
    }
  }
  const groups=new Map();
  for(const c of candidates){const cohort=c.requested_target_signature;if(!groups.has(cohort))groups.set(cohort,[]);groups.get(cohort).push(c)}
  const ranked=[];
  for(const [sig,rows] of groups){rows.sort(cmpFootball);rows.forEach((r,i)=>ranked.push({...r,rank_cohort_signature:sig,football_rank:i+1,football_top:i<3?i+1:null}))}
  ranked.sort((a,b)=>a.rank_cohort_signature.localeCompare(b.rank_cohort_signature)||a.football_rank-b.football_rank);
  return {schema:'FE_PV2_FOOTBALL_RANKING_V2',version:FOOTBALL_RANK_VERSION,provisional:true,
    target_semantics:FOOTBALL_TARGET_SEMANTICS,model_horizon_semantics:FOOTBALL_MODEL_HORIZON_SEMANTICS,
    note:'Only full requested rolling horizons are ranked. B3 nominal 45/90 caps are model semantics, not assumptions that the real period has ended. Truncated/stoppage-time cases remain in unsupported coverage.',
    rows:ranked,unsupported};
}
function marketRowsFor(row,marketRowsByObservation,marketRowsByFixture){
  const obs=marketRowsByObservation instanceof Map?marketRowsByObservation.get(row.observation_id):marketRowsByObservation?.[row.observation_id];
  if(Array.isArray(obs))return obs;
  const fk=`${row.fixture_id}|${row.engine}`;
  const fx=marketRowsByFixture instanceof Map?(marketRowsByFixture.get(fk)??marketRowsByFixture.get(row.fixture_id)):marketRowsByFixture?.[fk]??marketRowsByFixture?.[row.fixture_id];
  return Array.isArray(fx)?fx:[];
}
export function rankMarketOpportunities(evaluationRows=[],{
  marketRowsByObservation=new Map(),marketRowsByFixture=new Map(),strictMarket=true,freshnessPolicy=EXPERIMENTAL_MARKET_FRESHNESS_POLICY
}={}){
  const all=[],rankable=[];
  for(const row of evaluationRows||[]){
    const pred=row?.new?.prediction,marketRows=marketRowsFor(row,marketRowsByObservation,marketRowsByFixture);
    if(!row?.new?.modelable||!pred){all.push({...row,market_rows_count:marketRows.length,market_rank:null,market_top:null,market_status:'UNMODELABLE',entry_decision:'NO_ENTRY'});continue}
    const m=evaluateActualMarkets({prediction:pred,state:row?.new?.packet?.state||{},marketRows,targetPeriod:row.market_period,evaluationCutoff:row.cutoff,strictMarket,freshnessPolicy}),
      best=m.best,ev=finite(best?.edge?.expected_return),conf=confidenceFor(pred),score=ev==null?null:ev*(.55+.45*(conf??0))-(1-(conf??0))*.015;
    const base={...row,market_rows_count:marketRows.length,market_evaluation:m,best_market:best||null,market_rank_score:round(score,5),market_rank_version:MARKET_RANK_VERSION};
    if(!best||score==null){all.push({...base,market_rank:null,market_top:null,market_status:'NO_SUPPORTED_MARKET',entry_decision:'NO_ENTRY'});continue}
    const out={...base,market_rank:null,market_top:null,market_status:ev>0?'POSITIVE_EDGE':ev===0?'FAIR':'NO_EDGE',entry_decision:ev>0?'REVIEW_ONLY':'NO_ENTRY'};
    all.push(out);rankable.push(out);
  }
  rankable.sort((a,b)=>(finite(b.market_rank_score)??-Infinity)-(finite(a.market_rank_score)??-Infinity)
    ||(finite(b.new?.prediction?.confidence?.value)??0)-(finite(a.new?.prediction?.confidence?.value)??0)||Number(a.fixture_id)-Number(b.fixture_id));
  const rankMap=new Map(rankable.map((r,i)=>[r.observation_id,{rank:i+1,top:i<3?i+1:null}]));
  const rows=all.map(r=>{const x=rankMap.get(r.observation_id);return x?{...r,market_rank:x.rank,market_top:x.top}:r});
  return {schema:'FE_PV2_MARKET_RANKING_V1',version:MARKET_RANK_VERSION,note:'Only rows with an actual supported market receive market_rank/TOP. Negative edge remains NO_ENTRY.',rows};
}
