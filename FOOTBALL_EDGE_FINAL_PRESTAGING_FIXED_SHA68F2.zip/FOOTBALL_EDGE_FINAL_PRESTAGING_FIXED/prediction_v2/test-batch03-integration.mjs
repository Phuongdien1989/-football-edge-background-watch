import assert from 'node:assert/strict';
import {buildRawSnapshotUniverse} from './raw-universe.js';
import {evaluateNewFromRawFixture} from './raw-new-evaluator.js';
import {evaluateSameUniverse} from './same-universe-evaluator.js';
import {rankFootballRows,rankMarketOpportunities} from './dual-ranking.js';
import {buildSameUniverseReport} from './same-universe-report.js';

const cutoff='2026-10-07T12:00:00.000Z';
const captures=[
 {capture_id:'c10',request_id:'r1',fixture_id:10,match_clock:60,status_short:'2H',received_at:'2026-10-07T11:59:00Z',fixture_payload_hash:'h10',
  has_events:1,has_stats:0,has_lineups:0,has_players:0,
  fixture_json:{fixture:{id:10,status:{short:'2H',elapsed:60,extra:null}},league:{id:1,name:'L'},teams:{home:{id:101,name:'A'},away:{id:102,name:'B'}},goals:{home:1,away:0},score:{halftime:{home:1,away:0}},events:[],statistics:[]}},
 {capture_id:'c11',request_id:'r2',fixture_id:11,match_clock:31,status_short:'1H',received_at:'2026-10-07T11:59:10Z',fixture_payload_hash:'h11',
  has_events:0,has_stats:0,has_lineups:0,has_players:0,
  fixture_json:{fixture:{id:11,status:{short:'1H',elapsed:31,extra:null}},league:{id:1,name:'L'},teams:{home:{id:111,name:'C'},away:{id:112,name:'D'}},goals:{home:0,away:0},score:{halftime:{home:0,away:0}},events:[],statistics:[]}}
];
const universe=buildRawSnapshotUniverse({fixtureCaptures:captures,cutoff,datasetId:'integration',datasetHash:'int'});
const evaluation=evaluateSameUniverse({
 universe,engines:['FT','H1','HC'],
 oldEvaluator:({fixture})=>({replay_status:'OLD_REPLAY_OK',eligible:fixture.fixture_id!==10,selected:false,state:fixture.fixture_id===10?'FAIL':'WATCH'}),
 newEvaluator:({fixture,engine,universe})=>evaluateNewFromRawFixture(fixture,{engine,cutoffMs:Date.parse(universe.cutoff)})
});
assert.equal(evaluation.rows.length,6);
const oldRejected=evaluation.rows.filter(r=>r.fixture_id===10);
assert.ok(oldRejected.every(r=>r.old.eligible===false));
assert.ok(oldRejected.some(r=>r.new.modelable===true)); // NEW still evaluates fixture rejected by OLD

const football=rankFootballRows(evaluation.rows);
assert.ok(football.rows.some(r=>r.fixture_id===10));
const market=rankMarketOpportunities(evaluation.rows,{marketRowsByObservation:new Map(),strictMarket:true});
assert.ok(market.rows.every(r=>r.market_rank==null));
assert.ok(market.rows.every(r=>r.entry_decision==='NO_ENTRY'));

const report=buildSameUniverseReport({universe,evaluation,footballRanking:football,marketRanking:market,strictRows:evaluation.rows.map(r=>({strict_valid:false,strict_metrics_eligible:false,strict_eligibility:{eligible:false,reasons:['NO_REAL_PERSISTENCE_ACK'],metric:'goal_10m'},reason:'NO_REAL_PERSISTENCE_ACK'}))});
assert.equal(report.coverage.universe_fixtures,2);
assert.equal(report.coverage.market_ranked_observations,0);
assert.equal(report.coverage.strict_valid,0);
console.log('Batch03 local raw-path integration PASS');
