import {createHash} from 'node:crypto';
import {canonicalCaptureValue} from './capture-integrity.js';
/* Batch 04.1 — real local durable persistence for offline tests.
 * Uses node:sqlite with synchronous=FULL. ACK origin is LOCAL_DURABLE_TEST, never SERVER.
 * Content is recomputed/validated before write and after durable readback.
 */
import {DatabaseSync} from 'node:sqlite';
import {contentFingerprint,timestampIso} from './observation-contract.js';
import {validateExactOldOutputRecord} from './old-exact-contract.js';
import {validateLockedBundle,compareStoredBundle} from './locked-bundle-validator.js';

export const LOCAL_ACK_SCHEMA='FE_PV2_LOCAL_DURABLE_ACK_V2';
export class LocalEvidenceRecorder{
  constructor(path,{faultInjector=null,clock={now:()=>Date.now()}}={}){this.path=path;this.faultInjector=faultInjector;this.clock=clock;this.db=new DatabaseSync(path);this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON;`);this.init()}
  init(){this.db.exec(`
    CREATE TABLE IF NOT EXISTS capture_payloads(
      record_id TEXT PRIMARY KEY, request_id TEXT, source_id TEXT, provider TEXT, endpoint TEXT,
      fixture_id INTEGER, market_period TEXT, received_at TEXT, provider_updated_at TEXT,
      payload_hash TEXT NOT NULL, capture_status TEXT NOT NULL, payload_json TEXT, metadata_json TEXT,
      persisted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );
    CREATE INDEX IF NOT EXISTS idx_b4_capture_fx_time ON capture_payloads(fixture_id,received_at);
    CREATE INDEX IF NOT EXISTS idx_b4_capture_endpoint_time ON capture_payloads(endpoint,received_at);
    CREATE TABLE IF NOT EXISTS old_exact_outputs(
      record_id TEXT PRIMARY KEY, fixture_id INTEGER, engine TEXT, cutoff TEXT, baseline_sha256 TEXT,
      record_fingerprint TEXT NOT NULL, record_json TEXT NOT NULL,
      persisted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );
    CREATE TABLE IF NOT EXISTS locked_predictions(
      observation_id TEXT PRIMARY KEY, fixture_id INTEGER, engine TEXT, market_period TEXT, evaluation_cutoff TEXT,
      content_fingerprint TEXT NOT NULL, bundle_fingerprint TEXT NOT NULL,
      observation_json TEXT NOT NULL, paper_json TEXT, old_exact_record_id TEXT,
      persisted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );
    CREATE TABLE IF NOT EXISTS persistence_acks(
      ack_id TEXT PRIMARY KEY, subject_id TEXT NOT NULL, content_fingerprint TEXT NOT NULL, bundle_fingerprint TEXT NOT NULL,
      persisted_at TEXT NOT NULL, ack_origin TEXT NOT NULL, source TEXT NOT NULL, ack_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS outcome_revisions(
      observation_id TEXT NOT NULL, revision INTEGER NOT NULL, outcome_received_at TEXT,
      outcome_fingerprint TEXT NOT NULL, outcome_json TEXT NOT NULL,
      persisted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      PRIMARY KEY(observation_id,revision)
    );
  `);if(!this.db.prepare('PRAGMA table_info(capture_payloads)').all().some(c=>c.name==='capture_json'))this.db.exec('ALTER TABLE capture_payloads ADD COLUMN capture_json TEXT')}
  close(){this.db.close()}
  checkpoint(){this.db.exec('PRAGMA wal_checkpoint(FULL);')}
  inject(point,ctx={}){if(typeof this.faultInjector==='function')this.faultInjector(point,ctx)}
  recordCapture(r){const body=r?.payload_text!=null?String(r.payload_text):canonicalCaptureValue(r?.payload??null);if(createHash('sha256').update(body).digest('hex')!==r?.payload_hash)throw new Error('CAPTURE_PAYLOAD_HASH_MISMATCH');if(r.payload_text!=null){let parsed;try{parsed=JSON.parse(body)}catch{if(r.capture_status!=='FETCH_ERROR'||r.payload!=null)throw new Error('CAPTURE_RAW_JSON_INVALID')}if(parsed!==undefined&&canonicalCaptureValue(parsed)!==canonicalCaptureValue(r.payload))throw new Error('CAPTURE_RAW_PARSED_MISMATCH')}if(!r?.record_id||!r?.payload_hash)throw new Error('CAPTURE_RECORD_INVALID');const existing=this.db.prepare('SELECT payload_hash,payload_json,metadata_json FROM capture_payloads WHERE record_id=?').get(r.record_id),payloadJson=JSON.stringify(r.payload??null),metadataJson=JSON.stringify(r.metadata??null);if(existing&&(existing.payload_hash!==r.payload_hash||existing.payload_json!==payloadJson||existing.metadata_json!==metadataJson))throw new Error('CAPTURE_RECORD_ID_CONFLICT');if(existing)return {ok:true,idempotent:true,record_id:r.record_id};this.db.prepare(`INSERT INTO capture_payloads(record_id,request_id,source_id,provider,endpoint,fixture_id,market_period,received_at,provider_updated_at,payload_hash,capture_status,payload_json,metadata_json,capture_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(r.record_id,r.request_id??null,r.source_id??null,r.provider??null,r.endpoint??null,r.fixture_id??null,r.market_period??null,r.received_at??null,r.provider_updated_at??null,r.payload_hash,r.capture_status,payloadJson,metadataJson,JSON.stringify(r));return {ok:true,idempotent:false,record_id:r.record_id}}
  recordOldExact(r){const v=validateExactOldOutputRecord(r,{fixtureId:r?.fixture_id,engine:r?.engine,cutoff:r?.cutoff});if(!v.valid)throw new Error(`OLD_EXACT_INVALID:${v.reasons.join(',')}`);const id=`OLD:${r.fixture_id}:${r.engine}:${r.cutoff}`,json=JSON.stringify(r),ex=this.db.prepare('SELECT record_fingerprint,record_json FROM old_exact_outputs WHERE record_id=?').get(id);if(ex&&(ex.record_fingerprint!==r.record_fingerprint||ex.record_json!==json))throw new Error('OLD_EXACT_IMMUTABLE_CONFLICT');if(!ex)this.db.prepare('INSERT INTO old_exact_outputs(record_id,fixture_id,engine,cutoff,baseline_sha256,record_fingerprint,record_json) VALUES(?,?,?,?,?,?,?)').run(id,r.fixture_id,r.engine,r.cutoff,r.baseline_sha256,r.record_fingerprint,json);return id}
  readBundle(id){const r=this.db.prepare('SELECT * FROM locked_predictions WHERE observation_id=?').get(id);if(!r)return null;const old=r.old_exact_record_id?this.db.prepare('SELECT record_json FROM old_exact_outputs WHERE record_id=?').get(r.old_exact_record_id):null;return {...r,observation:JSON.parse(r.observation_json),paper:r.paper_json?JSON.parse(r.paper_json):null,old:old?.record_json?JSON.parse(old.record_json):null}}
  persistLockedBundle({observation,paperRecord=null,oldExactRecord=null}={}){
    const pre=validateLockedBundle({observation,paperRecord,oldExactRecord});if(!pre.valid)throw new Error(`LOCKED_BUNDLE_INVALID:${pre.reasons.join(',')}`);
    const oid=observation.observation_id,fp=observation.content_fingerprint,bundleFp=pre.bundle_fingerprint,oldId=oldExactRecord?`OLD:${oldExactRecord.fixture_id}:${oldExactRecord.engine}:${oldExactRecord.cutoff}`:null,
      obsJson=JSON.stringify(observation),paperJson=paperRecord?JSON.stringify(paperRecord):null;
    this.db.exec('BEGIN IMMEDIATE');
    try{
      if(oldExactRecord)this.recordOldExact(oldExactRecord);
      const ex=this.readBundle(oid);
      if(ex){const cmp=compareStoredBundle({storedObservation:ex.observation,storedPaper:ex.paper,storedOld:ex.old,expectedObservation:observation,expectedPaper:paperRecord,expectedOld:oldExactRecord,storedBundleFingerprint:ex.bundle_fingerprint});if(!cmp.valid)throw new Error(`IMMUTABLE_BUNDLE_CONFLICT:${cmp.reasons.join(',')}`);if(ex.observation_json!==obsJson||String(ex.paper_json??'')!==String(paperJson??''))throw new Error('IMMUTABLE_BUNDLE_SERIALIZED_CONTENT_CONFLICT')}
      else this.db.prepare(`INSERT INTO locked_predictions(observation_id,fixture_id,engine,market_period,evaluation_cutoff,content_fingerprint,bundle_fingerprint,observation_json,paper_json,old_exact_record_id,persisted_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(oid,observation.fixture_id??null,observation.engine??null,observation.market_period??null,observation.evaluation_cutoff??null,fp,bundleFp,obsJson,paperJson,oldId,new Date(this.clock.now()).toISOString());
      this.db.exec('COMMIT');
    }catch(e){try{this.db.exec('ROLLBACK')}catch{};throw e}
    this.checkpoint();this.inject('before_readback',{observation_id:oid});
    const row=this.readBundle(oid);if(!row)throw new Error('DURABLE_READBACK_FAILED');const cmp=compareStoredBundle({storedObservation:row.observation,storedPaper:row.paper,storedOld:row.old,expectedObservation:observation,expectedPaper:paperRecord,expectedOld:oldExactRecord,storedBundleFingerprint:row.bundle_fingerprint});
    if(!cmp.valid||row.content_fingerprint!==fp||row.observation_json!==obsJson||String(row.paper_json??'')!==String(paperJson??''))throw new Error(`DURABLE_READBACK_CONTENT_MISMATCH:${cmp.reasons.join(',')}`);
    this.inject('after_readback_before_ack',{observation_id:oid});
    const ackId=`LOCALACK:${contentFingerprint({oid,fp,bundle_fingerprint:bundleFp,persisted_at:row.persisted_at,path:this.path})}`,ack={schema:LOCAL_ACK_SCHEMA,ack_id:ackId,subject_id:oid,content_fingerprint:fp,bundle_fingerprint:bundleFp,persisted_at:row.persisted_at,ack_origin:'LOCAL_DURABLE_TEST',source:'NODE_SQLITE_SYNCHRONOUS_FULL',server_verified:false,metadata:{database_path:this.path,readback_verified:true,bundle_readback_verified:true}};
    const ax=this.db.prepare('SELECT ack_id,content_fingerprint,bundle_fingerprint FROM persistence_acks WHERE ack_id=?').get(ackId);if(ax&&(ax.content_fingerprint!==fp||ax.bundle_fingerprint!==bundleFp))throw new Error('LOCAL_ACK_ID_CONFLICT');if(!ax)this.db.prepare('INSERT INTO persistence_acks(ack_id,subject_id,content_fingerprint,bundle_fingerprint,persisted_at,ack_origin,source,ack_json) VALUES(?,?,?,?,?,?,?,?)').run(ackId,oid,fp,bundleFp,row.persisted_at,ack.ack_origin,ack.source,JSON.stringify(ack));this.checkpoint();return ack;
  }
  verifyLocalAck(ack){if(ack?.schema!==LOCAL_ACK_SCHEMA||ack?.ack_origin!=='LOCAL_DURABLE_TEST'||!ack?.ack_id||!ack?.subject_id||!ack?.content_fingerprint||!ack?.bundle_fingerprint)return {valid:false,reasons:['LOCAL_ACK_SHAPE_INVALID']};const row=this.readBundle(ack.subject_id),reasons=[];if(!row)reasons.push('SUBJECT_NOT_PERSISTED');else{const v=validateLockedBundle({observation:row.observation,paperRecord:row.paper,oldExactRecord:row.old});if(!v.valid)reasons.push(...v.reasons.map(x=>`STORED_${x}`));if(row.content_fingerprint!==ack.content_fingerprint)reasons.push('CONTENT_FINGERPRINT_MISMATCH');if(row.bundle_fingerprint!==ack.bundle_fingerprint||v.bundle_fingerprint!==ack.bundle_fingerprint)reasons.push('BUNDLE_FINGERPRINT_MISMATCH');if(row.persisted_at!==ack.persisted_at)reasons.push('PERSISTED_AT_MISMATCH')}const ar=this.db.prepare('SELECT ack_id FROM persistence_acks WHERE ack_id=?').get(ack.ack_id);if(!ar)reasons.push('ACK_ROW_MISSING');return {valid:reasons.length===0,reasons}}
  appendOutcome(observationId,outcome,{receivedAt=null}={}){const row=this.db.prepare('SELECT observation_id FROM locked_predictions WHERE observation_id=?').get(observationId);if(!row)throw new Error('OUTCOME_WITHOUT_PERSISTED_PREDICTION');const last=this.db.prepare('SELECT MAX(revision) AS n FROM outcome_revisions WHERE observation_id=?').get(observationId),revision=Number(last?.n||0)+1,fp=contentFingerprint(outcome);this.db.prepare('INSERT INTO outcome_revisions(observation_id,revision,outcome_received_at,outcome_fingerprint,outcome_json) VALUES(?,?,?,?,?)').run(observationId,revision,timestampIso(receivedAt),fp,JSON.stringify(outcome));this.checkpoint();return {revision,outcome_fingerprint:fp}}
  loadLockedObservation(id){const r=this.readBundle(id);return r?{...r,old:undefined}:null}
  loadOutcomeHistory(id){return this.db.prepare('SELECT * FROM outcome_revisions WHERE observation_id=? ORDER BY revision').all(id).map(r=>({...r,outcome:JSON.parse(r.outcome_json)}))}
  countAcks(){return Number(this.db.prepare('SELECT COUNT(*) AS n FROM persistence_acks').get()?.n||0)}
  listCaptures({fixtureId=null,endpoint=null}={}){let sql='SELECT * FROM capture_payloads WHERE 1=1',p=[];if(fixtureId!=null){sql+=' AND fixture_id=?';p.push(Number(fixtureId))}if(endpoint){sql+=' AND endpoint=?';p.push(endpoint)}sql+=' ORDER BY received_at';return this.db.prepare(sql).all(...p).map(r=>({...JSON.parse(r.capture_json||'null'),...r,payload:JSON.parse(r.payload_json||'null'),metadata:JSON.parse(r.metadata_json||'null')}))}
}
