/* FOOTBALL EDGE — Prediction V2 / Batch 03.1
 * Fair coverage/reporting for same-universe replay.
 * Reporting is aggregation only: it does not create OLD replay success or strict-metric validity.
 */
const finite=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim())?null:(Number.isFinite(Number(v))?Number(v):null);
const pct=(n,d)=>d?Math.round((n/d)*10000)/100:null;
export const OLD_REPLAY_SUCCESS_STATUSES=Object.freeze(['OLD_REPLAY_OK']);
const OLD_SUCCESS=new Set(OLD_REPLAY_SUCCESS_STATUSES);
function reasons(rows,fn){const out={};for(const r of rows||[]){for(const x of fn(r)||[]){const k=String(x||'UNKNOWN');out[k]=(out[k]||0)+1}}return out}
function oldReplayClass(row){
  const st=String(row?.old?.replay_status||'OLD_REPLAY_NULL').toUpperCase();
  if(OLD_SUCCESS.has(st))return 'AVAILABLE';
  if(st==='OLD_REPLAY_ERROR')return 'ERROR';
  if(st==='OLD_REPLAY_NULL')return 'NULL';
  if(st.startsWith('OLD_REPLAY_UNAVAILABLE'))return 'UNAVAILABLE';
  return 'OTHER';
}
function authoritativeStrictDecision(row){
  const auth=row?.strict_eligibility??row?.metric_eligibility??row?.eligibility_result??null,flags={strict_valid:row?.strict_valid,strict_metrics_eligible:row?.strict_metrics_eligible};
  if(!auth||typeof auth?.eligible!=='boolean')return {valid:false,reason:'STRICT_ELIGIBILITY_RESULT_MISSING',auth:null};
  const contradictions=[];
  if(auth.eligible===true&&(flags.strict_valid===false||flags.strict_metrics_eligible===false))contradictions.push('AUTH_ELIGIBLE_BUT_RECORD_FALSE');
  if(auth.eligible===false&&(flags.strict_valid===true||flags.strict_metrics_eligible===true))contradictions.push('AUTH_INELIGIBLE_BUT_RECORD_TRUE');
  if(contradictions.length)return {valid:false,reason:'STRICT_FLAG_CONTRADICTION',contradictions,auth};
  if(auth.eligible!==true)return {valid:false,reason:auth?.reasons?.[0]||row?.reason||row?.quarantine_reason||'STRICT_ELIGIBILITY_FALSE',auth};
  if(Array.isArray(auth?.reasons)&&auth.reasons.length)return {valid:false,reason:'STRICT_ELIGIBILITY_TRUE_WITH_REASONS',auth};
  return {valid:true,reason:null,auth};
}
export function buildSameUniverseReport({universe,evaluation,footballRanking,marketRanking,outcomes=[],strictRows=[]}={}){
  const erows=evaluation?.rows||[],fixtures=universe?.fixtures||[],fixtureCount=Number(universe?.fixture_count)||fixtures.length,
    modeled=erows.filter(r=>r?.new?.modelable===true),unmodeled=erows.filter(r=>r?.new?.modelable!==true),fallback=modeled.filter(r=>/FALLBACK/.test(String(r?.new?.status||''))),partial=modeled.filter(r=>/PARTIAL/.test(String(r?.new?.status||''))),
    oldAvailable=erows.filter(r=>oldReplayClass(r)==='AVAILABLE'),oldError=erows.filter(r=>oldReplayClass(r)==='ERROR'),oldNull=erows.filter(r=>oldReplayClass(r)==='NULL'),oldUnavailable=erows.filter(r=>oldReplayClass(r)==='UNAVAILABLE'),oldOther=erows.filter(r=>oldReplayClass(r)==='OTHER'),
    oldEligible=oldAvailable.filter(r=>r?.old?.eligible===true),oldSelected=oldAvailable.filter(r=>r?.old?.selected===true),
    fr=footballRanking?.rows||[],fu=footballRanking?.unsupported||[],footballTargetUnsupported=fu.filter(r=>r?.football_rank_status==='UNSUPPORTED_TARGET_FOR_RANKING'),
    mr=marketRanking?.rows||[],marketModelable=mr.filter(r=>r?.new?.modelable===true),marketRanked=mr.filter(r=>finite(r?.market_rank)!=null),positive=marketRanked.filter(r=>r?.market_status==='POSITIVE_EDGE'),noMarket=mr.filter(r=>r?.market_status==='NO_SUPPORTED_MARKET'),
    fixtureModelable=new Set(modeled.map(r=>Number(r.fixture_id))).size,fixtureUnmodelable=fixtureCount-fixtureModelable,outcomeResolved=(outcomes||[]).filter(x=>x?.resolved===true||x?.outcome?.settled===true).length,outcomeUnresolved=(outcomes||[]).length-outcomeResolved,
    strictDecisions=(strictRows||[]).map(r=>({row:r,decision:authoritativeStrictDecision(r)})),strictValid=strictDecisions.filter(x=>x.decision.valid).length,quarantined=strictDecisions.length-strictValid;
  return {schema:'FE_PV2_SAME_UNIVERSE_REPORT_V2',
    old_replay_success_whitelist:OLD_REPLAY_SUCCESS_STATUSES,
    strict_reporting_policy:'AUTHORITATIVE_ELIGIBILITY_RESULT_REQUIRED; summary flags never create strict validity',
    universe:{universe_id:universe?.universe_id||null,cutoff:universe?.cutoff||null,scope:universe?.scope||null,scope_claim:universe?.scope_claim||null,fixture_count:fixtureCount,dataset:universe?.dataset||null,completeness:universe?.completeness||null},
    coverage:{universe_fixtures:fixtureCount,fixture_modelable:fixtureModelable,fixture_unmodelable:fixtureUnmodelable,fixture_modelable_pct:pct(fixtureModelable,fixtureCount),engine_observations:erows.length,
      new_modelable_observations:modeled.length,new_modelable_fallback_observations:fallback.length,new_modelable_partial_observations:partial.length,new_unmodelable_observations:unmodeled.length,
      old_replay_available_observations:oldAvailable.length,old_replay_unavailable_observations:oldUnavailable.length,old_replay_error_observations:oldError.length,old_replay_null_observations:oldNull.length,old_replay_other_observations:oldOther.length,
      old_eligible_observations:oldEligible.length,old_selected_observations:oldSelected.length,new_football_ranked_rows:fr.length,new_football_unsupported_rows:fu.length,new_football_unsupported_target_rows:footballTargetUnsupported.length,
      market_candidate_observations:mr.length,market_modelable_observations:marketModelable.length,market_ranked_observations:marketRanked.length,market_positive_edge_observations:positive.length,market_no_supported_observations:noMarket.length,
      market_valid_pct_of_modelable:pct(marketRanked.length,marketModelable.length),market_valid_pct_of_all_engine_observations:pct(marketRanked.length,erows.length),
      outcomes_total:(outcomes||[]).length,outcomes_resolved:outcomeResolved,outcomes_unresolved:outcomeUnresolved,strict_total:strictDecisions.length,strict_valid:strictValid,strict_quarantined:quarantined},
    reasons:{new_unmodelable:reasons(unmodeled,r=>[r?.new?.status||'UNMODELABLE',...(r?.new?.reasons||[])]),raw_data:reasons(fixtures,r=>r?.data_reasons||[]),
      old_replay_unavailable:reasons(oldUnavailable,r=>[r?.old?.reason||r?.old?.replay_status||'OLD_REPLAY_UNAVAILABLE']),old_replay_error:reasons(oldError,r=>[r?.old?.error||r?.old?.reason||'OLD_REPLAY_ERROR']),
      old_replay_null:reasons(oldNull,r=>[r?.old?.reason||'OLD_REPLAY_NULL']),old_replay_other:reasons(oldOther,r=>[r?.old?.replay_status||'OLD_REPLAY_OTHER']),
      football_not_ranked:reasons(fu,r=>[r?.football_rank_reason||r?.football_rank_status||'FOOTBALL_NOT_RANKED']),market_not_ranked:reasons(noMarket,r=>{const xs=r?.market_evaluation?.rejection_reasons||[];return xs.length?xs:[r?.market_status||'NO_SUPPORTED_MARKET']}),
      outcome_unresolved:reasons((outcomes||[]).filter(x=>!(x?.resolved===true||x?.outcome?.settled===true)),r=>[r?.reason||'OUTCOME_UNRESOLVED']),strict_quarantine:reasons(strictDecisions.filter(x=>!x.decision.valid),x=>[x.decision.reason,...(x.decision.contradictions||[])])}
  };
}
