/* FOOTBALL EDGE — Prediction V2 / Batch 03.1
 * NEW-model replay adapter for raw fixture captures.
 * OLD rank/eligibility is never an input.
 * Missing stats/context may use the existing B3 fallback, but missing/invalid fixture state
 * (fixture identity, status, minute, score) is UNMODELABLE_INVALID_STATE and is never coerced to 0.
 */
import {buildLiveFeaturePacket} from './live-feature-adapter.js';
import {predictShadowProbability} from './probability-engine.js';
import {marketPeriodForEngine} from './observation-contract.js';

const LIVE_FT=new Set(['1H','HT','2H','ET','BT','INT']);
const LIVE_H1=new Set(['1H']);
const finite=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim())?null:(Number.isFinite(Number(v))?Number(v):null);

function metricsFromStatistics(statistics=[]){
  const out={home:{},away:{}};if(!Array.isArray(statistics)||!statistics.length)return out;
  const normName=s=>String(s||'').toLowerCase(),mapStat=rows=>{const m={};for(const r of rows||[])m[normName(r?.type)]=finite(String(r?.value??'').replace('%',''));return m};
  const h=mapStat(statistics?.[0]?.statistics),a=mapStat(statistics?.[1]?.statistics);
  const set=(side,m)=>{out[side].shots=m['total shots']??null;out[side].sot=m['shots on goal']??null;out[side].inbox=m['shots insidebox']??m['shots inside box']??null;out[side].corners=m['corner kicks']??null;out[side].red=m['red cards']??null;out[side].xg=m['expected goals']??null};
  set('home',h);set('away',a);return out;
}
function rawLatest(entry){
  const s=entry?.snapshot||{},f=s?.fixture||{},stats=metricsFromStatistics(s?.statistics||[]),goals=s?.goals??null;
  return {fixture:f,league:s?.league||null,teams:s?.teams||null,
    goals:{home:goals?.home??null,away:goals?.away??null},status:f?.status?.short??entry?.status_short??null,
    minute:finite(f?.status?.elapsed??entry?.match_clock),fresh_at:entry?.capture_received_at?Date.parse(entry.capture_received_at):null,
    metrics:stats,dq:null,stats_presence:{coverage:entry?.data_presence?.stats?1:0},raw_capture_received_at:entry?.capture_received_at||null};
}
function engineLive(engine,status){const e=String(engine||'FT').toUpperCase(),st=String(status||'').toUpperCase();return e==='H1'?LIVE_H1.has(st):LIVE_FT.has(st)}
function validateState(entry,latest,engine){
  const reasons=[],entryId=finite(entry?.fixture_id),snapshotId=finite(latest?.fixture?.id),status=String(latest?.status||'').toUpperCase(),minute=finite(latest?.minute),
    home=finite(latest?.goals?.home),away=finite(latest?.goals?.away);
  if(entryId==null)reasons.push('FIXTURE_ID_MISSING');
  if(snapshotId==null)reasons.push('SNAPSHOT_FIXTURE_ID_MISSING');
  if(entryId!=null&&snapshotId!=null&&entryId!==snapshotId)reasons.push('FIXTURE_ID_MISMATCH');
  if(!status)reasons.push('STATUS_MISSING');
  if(minute==null)reasons.push('MINUTE_MISSING');else if(minute<0)reasons.push('MINUTE_INVALID');
  if(home==null)reasons.push('SCORE_HOME_MISSING');else if(home<0)reasons.push('SCORE_HOME_INVALID');
  if(away==null)reasons.push('SCORE_AWAY_MISSING');else if(away<0)reasons.push('SCORE_AWAY_INVALID');
  return {valid:reasons.length===0,reasons,entry_id:entryId,snapshot_id:snapshotId,status,minute,score_home:home,score_away:away,engine_active:status?engineLive(engine,status):false};
}
export function evaluateNewFromRawFixture(entry,{engine='FT',cutoffMs=null,fallbackLambda90=2.5}={}){
  const eng=String(engine||'FT').toUpperCase(),latest=rawLatest(entry),period=marketPeriodForEngine(eng),baseReasons=[...(entry?.data_reasons||[])],state=validateState(entry,latest,eng);
  if(!state.valid){return {engine:eng,market_period:period,status:'UNMODELABLE_INVALID_STATE',modelable:false,prediction:null,packet:null,
    reasons:[...new Set([...baseReasons,...state.reasons])],state_validation:state,source_references:entry?.source_references||[]}}
  if(!state.engine_active){return {engine:eng,market_period:period,status:'UNMODELABLE_TARGET_STATE',modelable:false,prediction:null,packet:null,
    reasons:[...new Set([...baseReasons,`TARGET_NOT_ACTIVE_${state.status||'UNKNOWN'}`])],state_validation:state,source_references:entry?.source_references||[]}}
  const scoreMode=entry?.data_presence?.stats?'RAW_STATS_UNMAPPED':'NO_STATS';
  const item={id:state.entry_id,latest,eval:{game:null,pressure:null,chance:null,momentum:null,context:null,quality:null,scoreMode,mature:false,baselineAge:null,accel:null}};
  const parsedCutoff=Date.parse(entry.universe_cutoff||''),nowMs=cutoffMs??(Number.isFinite(parsedCutoff)?parsedCutoff:Date.now());
  const packet=buildLiveFeaturePacket({fixtureId:state.entry_id,engine:eng,item,context:null,now:nowMs}),prediction=predictShadowProbability(packet,{fallbackLambda90}),fallback=prediction?.base?.fallback===true||!entry?.data_presence?.stats;
  return {engine:eng,market_period:period,status:fallback?'MODELABLE_FALLBACK':'MODELABLE_PARTIAL',modelable:true,prediction,packet,
    reasons:[...new Set(baseReasons)],state_validation:state,source_references:entry?.source_references||[]};
}
