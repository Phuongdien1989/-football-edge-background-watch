/* FOOTBALL EDGE — Prediction V2 / Batch 02.2 strict outcome resolver
 * Key rules:
 * - received_at controls provenance, never event chronology.
 * - phase order (H1 before H2) controls football event order.
 * - rolling +5/+10/+15 elapsed time is computed only inside the same phase unless
 *   a source provides a proven continuous play-clock coordinate across phases.
 * - halftime duration is never fabricated. Cross-phase rolling windows without a
 *   proven continuous coordinate remain UNRESOLVED/UNSUPPORTED.
 * - request/payload identity is transport provenance; event identity is separate.
 * - outcome evidence is cumulative. Omission in a later incremental batch is not cancellation.
 */
import {timestampIso,timestampMs,STRICT_VALID,UNKNOWN_PROVENANCE,normalizeMarketPeriod,contentFingerprint} from './observation-contract.js';
const finite=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim())?null:(Number.isFinite(Number(v))?Number(v):null);
const totalGoals=s=>{const h=finite(s?.goals?.home??s?.score_home),a=finite(s?.goals?.away??s?.score_away);return h==null||a==null?null:h+a};
const TERMINAL_FT=new Set(['FT','AET','PEN','CANC','CANCELLED','ABD','ABANDONED','AWD','WO']);
const normalizePhase=v=>{const s=String(v??'').trim().toUpperCase().replace(/[\s_-]+/g,'');if(['H1','1H','FIRSTHALF','1STHALF'].includes(s))return 'H1';if(['H2','2H','SECONDHALF','2NDHALF'].includes(s))return 'H2';return null};
const phaseOrder=p=>p==='H1'?1:p==='H2'?2:0;
function phaseFromStatus(v){const s=String(v??'').toUpperCase();if(s==='1H'||s==='HT')return 'H1';if(s==='2H'||TERMINAL_FT.has(s))return 'H2';return null}
function inferPhase({explicit=null,status=null,base=null,extra=null,targetPeriod=null}={}){
  const x=normalizePhase(explicit)||phaseFromStatus(status);if(x)return x;const b=finite(base),e=finite(extra);if(b==null)return normalizeMarketPeriod(targetPeriod)==='H1'?'H1':null;
  if(b<45)return 'H1';if(b===45&&e!=null&&e>0)return 'H1';if(b<=45&&normalizeMarketPeriod(targetPeriod)==='H1')return 'H1';return 'H2';
}
export function normalizeMatchClock(input={},targetPeriod=null){
  const existingPeriod=normalizePhase(input?.period)||normalizeMarketPeriod(input?.period),explicitContinuous=finite(input?.continuous_elapsed_minute??input?.play_elapsed_minute??input?.elapsed_play_minute);
  if(input?.phase_clock_minute!=null&&existingPeriod){
    const pc=finite(input.phase_clock_minute),base=finite(input.regulation_minute??input.minute),extra=finite(input.stoppage_minute??input.extra)||0;
    if(pc==null)return null;return {period:existingPeriod,phase_order:phaseOrder(existingPeriod),regulation_minute:base,stoppage_minute:extra,phase_clock_minute:pc,
      continuous_elapsed_minute:explicitContinuous,display:input.display||`${base??pc}${extra>0?`+${extra}`:''}`};
  }
  const time=input?.time&&typeof input.time==='object'?input.time:{},base=finite(input?.event_minute??input?.minute??input?.fixture?.status?.elapsed??time?.elapsed??(typeof input?.time==='number'?input.time:null)),
    extra=finite(input?.extra??input?.stoppage??time?.extra)||0,status=input?.status??input?.fixture?.status?.short??null,explicit=input?.period??input?.phase??input?.half??input?.match_period??null,
    period=inferPhase({explicit,status,base,extra,targetPeriod});
  if(base==null||!period)return null;const phaseClock=base+(extra>0?extra:0);
  return {period,phase_order:phaseOrder(period),regulation_minute:base,stoppage_minute:extra,phase_clock_minute:phaseClock,continuous_elapsed_minute:explicitContinuous,
    display:`${base}${extra>0?`+${extra}`:''}`};
}
function compareClock(a,b){if(!a||!b)return null;if(a.phase_order!==b.phase_order)return a.phase_order-b.phase_order;return a.phase_clock_minute-b.phase_clock_minute}
function afterClock(a,b){const c=compareClock(a,b);return c!=null&&c>0}
function elapsedDelta(a,b){
  if(!a||!b)return {known:false,minutes:null,reason:'CLOCK_MISSING'};
  if(a.period===b.period)return {known:true,minutes:b.phase_clock_minute-a.phase_clock_minute,reason:'SAME_PHASE_PLAY_CLOCK'};
  const ac=finite(a.continuous_elapsed_minute),bc=finite(b.continuous_elapsed_minute);if(ac!=null&&bc!=null&&bc>=ac)return {known:true,minutes:bc-ac,reason:'PROVEN_CONTINUOUS_ELAPSED'};
  return {known:false,minutes:null,reason:'CROSS_PHASE_ELAPSED_UNPROVEN'};
}
function eventState(e){const type=String(e?.type??e?.event_type??'').toUpperCase(),detail=String(e?.detail??e?.event_detail??'').toUpperCase();if(type!=='GOAL')return null;return /CANCEL|CANCELLED|NO GOAL|DISALLOW/.test(detail)?'CANCELLED':/MISSED/.test(detail)?'NON_GOAL':'ACTIVE'}
function transportSourceId(row){return row?.source_id??row?.request_id??row?.payload_hash??null}
function providerEventId(row){
  const explicit=row?.event_id??row?.provider_event_id??row?.event?.id??null;if(explicit!=null)return String(explicit);
  const transport=transportSourceId(row),id=row?.id??null;
  // Generic `id` is accepted as an event ID only when no request/payload identity is present.
  // When transport provenance exists, adapters must map a real provider event ID to event_id/provider_event_id explicitly.
  if(transport==null&&id!=null)return String(id);return null;
}
function compositeEventBase(row,clock){return contentFingerprint({fixture_id:row?.fixture?.id??row?.fixture_id??null,period:clock?.period??null,regulation_minute:clock?.regulation_minute??null,
  stoppage_minute:clock?.stoppage_minute??0,team:row?.team?.id??row?.team_id??null,player:row?.player?.id??row?.player_id??null,type:String(row?.type??row?.event_type??'').toUpperCase()})}
function eventEvidenceId(row,clock,occurrence){const eid=providerEventId(row);if(eid!=null)return `EVENT:PROVIDER:${eid}`;return `EVENT:COMPOSITE:${compositeEventBase(row,clock)}:OCC:${occurrence}`}
function snapshotEvidenceId(row,clock){const explicit=row?.capture_id??row?.snapshot_id??null;if(explicit!=null)return `SNAPSHOT:${explicit}`;return `SNAPSHOT:${contentFingerprint({fixture_id:row?.fixture?.id??row?.fixture_id??null,period:clock?.period,clock:clock?.phase_clock_minute,
  goals:totalGoals(row),status:row?.status??row?.fixture?.status?.short??null,source:transportSourceId(row),payload_hash:row?.payload_hash??null})}`}
function evidenceRef(kind,row){return {kind,evidence_id:row?.evidence_id??null,received_at:timestampIso(row?.received_at??row?.__received_at),provider_updated_at:timestampIso(row?.provider_updated_at??row?.update),
  source_id:row?.source_id??row?.request_id??null,payload_hash:row?.payload_hash??null}}
function evidenceStrict(refs){return refs.length>0&&refs.every(r=>timestampMs(r?.received_at)!=null)}
function receivedRank(v){const t=timestampMs(v);return t==null?-Infinity:t}
function sortEvidence(a,b){const c=compareClock(a?.clock,b?.clock);return (c??0)||receivedRank(a?.received_at)-receivedRank(b?.received_at)||String(a?.evidence_id||'').localeCompare(String(b?.evidence_id||''))}
function mergeLedger(prior=[],incoming=[]){const m=new Map();for(const x of prior||[])if(x?.evidence_id)m.set(x.evidence_id,x);for(const x of incoming||[]){if(!x?.evidence_id)continue;const p=m.get(x.evidence_id);if(!p||receivedRank(x.received_at)>=receivedRank(p.received_at))m.set(x.evidence_id,x)}return [...m.values()].sort(sortEvidence)}
export function normalizeOutcomeEvents(events=[],targetPeriod=null){
  const counters=new Map(),out=[];for(const e of events||[]){const state=eventState(e);if(!state)continue;const clock=normalizeMatchClock(e,targetPeriod);if(!clock)continue;const composite=compositeEventBase(e,clock),n=(counters.get(composite)||0)+1;counters.set(composite,n);
    const eid=eventEvidenceId(e,clock,n);out.push({evidence_id:eid,event_identity_kind:providerEventId(e)!=null?'PROVIDER_EVENT_ID':'COMPOSITE_OCCURRENCE',event_occurrence:n,state,clock,
      received_at:timestampIso(e?.received_at??e?.__received_at),provider_updated_at:timestampIso(e?.provider_updated_at??e?.update),source_id:transportSourceId(e),payload_hash:e?.payload_hash??null,raw:e})}return out;
}
export function normalizeOutcomeSnapshots(snapshots=[],targetPeriod=null){
  const out=[];for(const s of snapshots||[]){const clock=normalizeMatchClock(s,targetPeriod),goals=totalGoals(s);if(!clock||goals==null)continue;const status=String(s?.status??s?.fixture?.status?.short??'').toUpperCase();out.push({evidence_id:snapshotEvidenceId(s,clock),clock,goals_total:goals,status,
    received_at:timestampIso(s?.received_at??s?.__received_at),provider_updated_at:timestampIso(s?.provider_updated_at??s?.update),source_id:transportSourceId(s),payload_hash:s?.payload_hash??null,raw:s})}return out;
}
function observationClock(row,target){return normalizeMatchClock(row?.match_clock||row?.observation?.state?.match_clock||{minute:row?.minute,status:row?.status,period:target==='H1'?'H1':target==='H2'?'H2':null},target)}
function allowedPeriod(clock,targetPeriod){const target=normalizeMarketPeriod(targetPeriod);if(!clock)return false;if(target==='H1')return clock.period==='H1';if(target==='H2')return clock.period==='H2';if(target==='FT')return ['H1','H2'].includes(clock.period);return false}
function allowedAfterStart(clock,target,startClock){return allowedPeriod(clock,target)&&afterClock(clock,startClock)}
function firstScoreIncreaseInterval(row,snapshots,startClock,target){
  const startGoals=(finite(row?.score_home)||0)+(finite(row?.score_away)||0);let prev=null;
  for(const s of snapshots.filter(x=>allowedPeriod(x.clock,target)&&afterClock(x.clock,startClock)).sort(sortEvidence)){
    if(s.goals_total>startGoals)return {after_clock:prev?.clock||startClock,before_or_at_clock:s.clock,upper:s,lower:prev};if(s.goals_total===startGoals)prev=s;
  }return null;
}
function periodEndEvidence(target,snapshots,events,startClock,endedFlag){
  const targetP=normalizeMarketPeriod(target),terms=[];for(const s of snapshots){const st=String(s.status||'').toUpperCase(),isEnd=targetP==='H1'?(st==='HT'||st==='2H'||TERMINAL_FT.has(st)):(targetP==='H2'||targetP==='FT'?TERMINAL_FT.has(st):false);if(isEnd)terms.push(s)}
  const matching=[...snapshots,...events].filter(x=>allowedPeriod(x.clock,targetP)&&afterClock(x.clock,startClock)),term=terms.sort(sortEvidence).at(-1)||null;if(!term&&!endedFlag)return {ended:false,end_clock:null,ref:null,known:false};
  return {ended:true,end_clock:term?.clock||null,ref:term?evidenceRef('PERIOD_END_SNAPSHOT',term):null,known:!!term?.clock};
}
function noGoalProofAt(row,snapshots,startClock,target,requested){
  const startGoals=(finite(row?.score_home)||0)+(finite(row?.score_away)||0);for(const s of snapshots.filter(x=>allowedPeriod(x.clock,target)&&afterClock(x.clock,startClock)).sort(sortEvidence)){
    const d=elapsedDelta(startClock,s.clock);if(!d.known)continue;if(d.minutes>=requested&&s.goals_total===startGoals)return {value:false,refs:[evidenceRef('SCORE_SNAPSHOT',s)],reason:'SCORE_UNCHANGED_THROUGH_WINDOW'};
  }return null;
}
function intervalWindowRelation(interval,startClock,requested){
  const lo=elapsedDelta(startClock,interval.after_clock),hi=elapsedDelta(startClock,interval.before_or_at_clock);if(!lo.known||!hi.known)return {kind:'UNKNOWN',reason:'CROSS_PHASE_SCORE_INTERVAL_ELAPSED_UNPROVEN'};
  if(hi.minutes<=requested)return {kind:'TRUE',reason:'SCORE_INTERVAL_FULLY_WITHIN_WINDOW'};if(lo.minutes>=requested&&interval.lower)return {kind:'FALSE',reason:'NO_GOAL_THROUGH_WINDOW_BOUNDARY'};return {kind:'UNKNOWN',reason:'GOAL_INTERVAL_CROSSES_WINDOW_BOUNDARY'};
}
function windowKey(h){return `goal_${h}m`}
function windowStatus(value,reason){if(reason==='CENSORED_PERIOD_END')return 'CENSORED';if(/UNPROVEN|UNSUPPORTED/.test(reason))return 'UNSUPPORTED';return value===true?'RESOLVED_TRUE':value===false?'RESOLVED_FALSE':'UNRESOLVED'}
function compactOutcome(out){return {goal_5m:out.goal_5m,goal_10m:out.goal_10m,goal_15m:out.goal_15m,first_goal_min:out.first_goal_min,first_goal_clock:out.first_goal_clock,first_goal_interval:out.first_goal_interval,status:out.status,provenance_status:out.provenance_status,window_status:out.window_status}}
function targetWindow(row,k,h){const t=row?.observation?.target?.windows?.[k]??row?.target?.windows?.[k]??null;return t||{requested_horizon_min:h,model_horizon_min:null,model_target_compatible:false,mismatch_reason:'TARGET_CONTRACT_MISSING'}}

export function resolveStrictGoalWindows(row,{events=[],snapshots=[],currentSnapshot=null,ended=false,changedAt=Date.now()}={}){
  if(!row)return row;const target=normalizeMarketPeriod(row.market_period??row?.observation?.market_period),startClock=observationClock(row,target);if(!startClock)return row;
  const prior=row.outcome||{},priorLedger=prior.evidence_ledger||{events:[],snapshots:[]},incomingEvents=normalizeOutcomeEvents(events,target),incomingSnapshots=normalizeOutcomeSnapshots([...(snapshots||[]),...(currentSnapshot?[currentSnapshot]:[])],target),
    eventLedger=mergeLedger(priorLedger.events,incomingEvents),snapshotLedger=mergeLedger(priorLedger.snapshots,incomingSnapshots),activeEvents=eventLedger.filter(x=>x.state==='ACTIVE'),eligibleGoals=activeEvents.filter(x=>allowedAfterStart(x.clock,target,startClock)).sort(sortEvidence),
    firstEvent=eligibleGoals[0]||null,interval=firstScoreIncreaseInterval(row,snapshotLedger,startClock,target),periodEnd=periodEndEvidence(target,snapshotLedger,eventLedger,startClock,ended),next={...prior};
  next.evidence_ledger={events:eventLedger,snapshots:snapshotLedger};next.first_goal_clock=firstEvent?.clock??null;const firstDelta=firstEvent?elapsedDelta(startClock,firstEvent.clock):null;next.first_goal_min=firstDelta?.known?(startClock.phase_clock_minute+firstDelta.minutes):null;
  next.first_goal_interval=firstEvent?null:(interval?{after_clock:interval.after_clock,before_or_at_clock:interval.before_or_at_clock}:null);next.window_status={};next.window_evidence={};
  for(const h of [5,10,15]){
    const k=windowKey(h),tw=targetWindow(row,k,h),requested=finite(tw.requested_horizon_min)??h;let value=null,refs=[],reason='INSUFFICIENT_EVIDENCE';
    if(firstEvent){const d=elapsedDelta(startClock,firstEvent.clock);if(d.known){if(d.minutes<=requested){value=true;refs=[evidenceRef('GOAL_EVENT',firstEvent)];reason='EXACT_EVENT_ELAPSED_IN_WINDOW'}else{const proof=noGoalProofAt(row,snapshotLedger,startClock,target,requested);if(proof){value=false;refs=proof.refs;reason=proof.reason}else reason='FIRST_GOAL_AFTER_WINDOW_NO_BOUNDARY_PROOF'}}else{refs=[evidenceRef('GOAL_EVENT',firstEvent)];reason=d.reason}}
    else if(interval){const rel=intervalWindowRelation(interval,startClock,requested);reason=rel.reason;if(rel.kind==='TRUE'){value=true;refs=[evidenceRef('SCORE_SNAPSHOT',interval.upper)]}else if(rel.kind==='FALSE'){value=false;refs=[evidenceRef('SCORE_SNAPSHOT',interval.lower)]}else refs=[evidenceRef('SCORE_SNAPSHOT',interval.upper)]}
    else{const proof=noGoalProofAt(row,snapshotLedger,startClock,target,requested);if(proof){value=proof.value;refs=proof.refs;reason=proof.reason}else if(periodEnd.ended&&periodEnd.known){const d=elapsedDelta(startClock,periodEnd.end_clock);if(d.known&&d.minutes<requested){value=null;refs=periodEnd.ref?[periodEnd.ref]:[];reason='CENSORED_PERIOD_END'}else if(!d.known){refs=periodEnd.ref?[periodEnd.ref]:[];reason=d.reason}}else if(periodEnd.ended&&!periodEnd.known)reason='PERIOD_ENDED_CLOCK_UNKNOWN'}
    const strictProv=value===null?false:evidenceStrict(refs),targetCompatible=tw.model_target_compatible===true;next[k]=value;next.window_status[k]=windowStatus(value,reason);next.window_evidence[k]={reason,refs,strict_provenance:strictProv,
      requested_horizon_min:requested,model_horizon_min:finite(tw.model_horizon_min),model_target_compatible:targetCompatible,mismatch_reason:tw.mismatch_reason??null,metric_eligible:typeof value==='boolean'&&strictProv&&targetCompatible,
      period_end:periodEnd.ended?{known:periodEnd.known,clock:periodEnd.end_clock}:null};
  }
  next.settled=[5,10,15].every(h=>typeof next[windowKey(h)]==='boolean'||['CENSORED','UNSUPPORTED'].includes(next.window_status[windowKey(h)]));next.status=next.settled?'SETTLED_CENSORED_OR_UNSUPPORTED':([5,10,15].some(h=>typeof next[windowKey(h)]==='boolean')?'PARTIAL':'UNRESOLVED');
  const strictWindows=[5,10,15].map(h=>next.window_evidence[windowKey(h)]).filter(Boolean);next.provenance_status=strictWindows.some(x=>x.metric_eligible)?STRICT_VALID:UNKNOWN_PROVENANCE;next.strict_outcome_eligible=strictWindows.length===3&&strictWindows.every(x=>x.metric_eligible===true)?true:null;next.period_clock_contract='PHASE_ORDERED_PLAY_CLOCK_V2';
  const changed=JSON.stringify(compactOutcome(prior))!==JSON.stringify(compactOutcome(next))||JSON.stringify(priorLedger)!==JSON.stringify(next.evidence_ledger);if(!changed)return row;
  const revision=(finite(prior.revision)||0)+1,history=[...(prior.history||[]),{revision,changed_at:timestampIso(changedAt),reason:'OUTCOME_EVIDENCE_MERGE_OR_CORRECTION',prior:compactOutcome(prior),next:compactOutcome(next)}];next.revision=revision;next.history=history;return {...row,outcome:next};
}

export function confirmedPeriodResult({period,snapshot=null,home=null,away=null,status=null,receivedAt=null,confirmed=false,clock=null}={}){
  const p=normalizeMarketPeriod(period),h=finite(home??snapshot?.goals?.home??snapshot?.score_home),a=finite(away??snapshot?.goals?.away??snapshot?.score_away),st=String(status??snapshot?.status??snapshot?.fixture?.status?.short??'').toUpperCase(),recv=timestampIso(receivedAt??snapshot?.received_at??snapshot?.__received_at),mc=clock??normalizeMatchClock(snapshot||{},p);
  return {period:p,home:h,away:a,status:st,received_at:recv,match_clock:mc,confirmed:confirmed===true&&!!p&&h!=null&&a!=null,provenance_status:recv?STRICT_VALID:UNKNOWN_PROVENANCE};
}
