import assert from 'node:assert/strict';
import {buildCapturedPayload,assessCaptureAvailability,CAPTURE_STATUS} from './capture-contract.js';
import {normalizeApiFootballOddsCapture} from './api-football-market-normalizer.js';
import {buildSnapshotHistoryFeatures} from './capture-history-features.js';
import {buildCapturedFixtureUniverse} from './capture-universe.js';
import {buildExactOldOutputRecord,validateExactOldOutputRecord} from './old-exact-contract.js';
import {buildNewFromCapturedPayloads} from './capture-feature-adapter.js';
import {evaluateActualMarkets} from './opportunity-ranking.js';

const t0='2026-10-07T10:00:00.000Z',t5='2026-10-07T10:05:00.000Z',cut='2026-10-07T10:05:30.000Z';
const fixture={fixture:{id:100,status:{short:'2H',elapsed:60},date:'2026-10-07T09:00:00Z'},league:{id:1,season:2026},teams:{home:{id:10,name:'Home'},away:{id:20,name:'Away'}},goals:{home:0,away:0}};
const stat=(h,a)=>[{team:{id:10},statistics:[{type:'Total Shots',value:h.sh},{type:'Shots on Goal',value:h.sot},{type:'Shots insidebox',value:h.inbox},{type:'Corner Kicks',value:h.corners},{type:'Expected Goals',value:h.xg}]},{team:{id:20},statistics:[{type:'Total Shots',value:a.sh},{type:'Shots on Goal',value:a.sot},{type:'Shots insidebox',value:a.inbox},{type:'Corner Kicks',value:a.corners},{type:'Expected Goals',value:a.xg}]}];
async function cap(endpoint,received,payload,{fixtureId=100,role=null,period=null,httpStatus=200,fetchError=null,wasRequested=true,providerUpdatedAt=null,params=null,metadata=null}={}){return buildCapturedPayload({endpoint,params:params??(fixtureId?{fixture:fixtureId}:{}),fixtureId,period,receivedAt:received,requestStartedAt:new Date(Date.parse(received)-100).toISOString(),httpStatus,fetchError,payload,wasRequested,providerUpdatedAt,metadata:{...(role?{role}:{}),...(metadata||{})}})}

const empty=await cap('/fixtures/statistics',t0,{response:[]});assert.equal(empty.capture_status,CAPTURE_STATUS.EMPTY_VALID);
const err=await cap('/fixtures/statistics',t0,{response:[]},{fetchError:new Error('network')});assert.equal(err.capture_status,CAPTURE_STATUS.FETCH_ERROR);
const miss=await cap('/fixtures/statistics',t0,null,{wasRequested:false});assert.equal(miss.capture_status,CAPTURE_STATUS.MISSING);
assert.equal(assessCaptureAvailability(await cap('/fixtures/statistics',t0,{response:stat({sh:1,sot:0,inbox:0,corners:0,xg:.1},{sh:1,sot:0,inbox:0,corners:0,xg:.1})}),{cutoff:'2026-10-07T10:10:00Z',maxAgeMs:120000}).availability_status,'STALE');

const odds=await cap('/odds/live',t5,{response:[{fixture:{id:100,status:'2H'},update:t5,status:{blocked:false,stopped:false,finished:false},odds:[{id:1,name:'Goals Over/Under',values:[{value:'Over 2.5',handicap:'2.5',odd:'2.00',main:true,suspended:false},{value:'Under 2.5',handicap:'2.5',odd:'1.80',main:true,suspended:false}]},{id:2,name:'First Half Goals Over/Under',values:[{value:'Over 0.5',handicap:'.5',odd:'1.90',main:true,suspended:false},{value:'Under 0.5',handicap:'.5',odd:'1.90',main:true,suspended:false}]}]}]});
const mrows=normalizeApiFootballOddsCapture(odds);assert.equal(mrows.filter(x=>x.market_period==='FT').length,1);assert.equal(mrows.filter(x=>x.market_period==='H1').length,1);

const records=[];
records.push(await buildCapturedPayload({endpoint:'/fixtures',params:{live:'all'},receivedAt:t5,httpStatus:200,payload:{response:[fixture]}}));
records.push(await cap('/fixtures/statistics',t0,{response:stat({sh:5,sot:2,inbox:3,corners:2,xg:.6},{sh:3,sot:1,inbox:1,corners:1,xg:.2})}));
records.push(await cap('/fixtures/statistics',t5,{response:stat({sh:9,sot:4,inbox:6,corners:4,xg:1.2},{sh:4,sot:1,inbox:2,corners:1,xg:.3})}));
records.push(await cap('/fixtures/statistics','2026-10-07T10:07:00Z',{response:stat({sh:99,sot:20,inbox:30,corners:20,xg:8},{sh:4,sot:1,inbox:2,corners:1,xg:.3})}));
records.push(await cap('/fixtures/events',t5,{response:[]}));records.push(odds);
records.push(await cap('/fixtures/lineups',t5,{response:[{team:{id:10},formation:'4-3-3',startXI:[{player:{id:101}},{player:{id:102}}]},{team:{id:20},formation:'4-4-2',startXI:[{player:{id:201}},{player:{id:202}}]}]},{role:'LINEUPS'}));
records.push(await cap('/injuries',t5,{response:[]},{role:'INJURIES'}));
records.push(await cap('/fixtures/players',t5,{response:[]},{role:'FIXTURE_PLAYERS'}));
records.push(await cap('/standings',t5,{response:[{league:{standings:[[{rank:1,team:{id:10},points:20,goalsDiff:8,all:{played:10},home:{played:5,win:4,draw:1}},{rank:5,team:{id:20},points:14,goalsDiff:1,all:{played:10},away:{played:5,win:1,draw:2}}]]}}]},{role:'STANDINGS',params:{league:1,season:2026}}));
records.push(await cap('/teams/statistics',t5,{response:{goals:{for:{average:{total:'1.8'}},against:{average:{total:'0.8'}}}}},{role:'HOME_TEAM_STATS',params:{league:1,season:2026,team:10}}));
records.push(await cap('/teams/statistics',t5,{response:{goals:{for:{average:{total:'1.1'}},against:{average:{total:'1.5'}}}}},{role:'AWAY_TEAM_STATS',params:{league:1,season:2026,team:20}}));
records.push(await cap('/fixtures',t5,{response:[]},{role:'HOME_RECENT',params:{team:10,last:8}}));records.push(await cap('/fixtures',t5,{response:[]},{role:'AWAY_RECENT',params:{team:20,last:8}}));
records.push(await cap('/players',t5,{response:[]},{role:'HOME_SEASON_PLAYERS',params:{team:10,season:2026,page:1}}));records.push(await cap('/players',t5,{response:[]},{role:'AWAY_SEASON_PLAYERS',params:{team:20,season:2026,page:1}}));

const hist=buildSnapshotHistoryFeatures(records,{fixtureId:100,cutoff:cut,homeTeamId:10,awayTeamId:20});assert.equal(hist.snapshot_count,2);assert.equal(hist.recent5.delta.home.shots,4);assert.equal(hist.current.home.shots,9);
const u=buildCapturedFixtureUniverse(records,{cutoff:cut});assert.equal(u.fixture_count,1);assert.equal(u.fixtures[0].source_status.stats.capture_status,'OK');

const old=buildExactOldOutputRecord({fixtureId:100,engine:'FT',cutoff:cut,evaluation:{game:10,pressure:14,chance:13,momentum:9,context:5,quality:4,scoreMode:'FULL',mature:true,baselineAge:5,accel:.4,recent5:{delta:{shots:5,sot:2,inbox:3,corners:2,xg:.4}},recent10:{delta:{shots:7,sot:3,inbox:4,corners:2,xg:.6}},market_available:true,market:8},state:{old_state:'CANDIDATE',eligible:false,selected:false}});assert.equal(validateExactOldOutputRecord(old,{fixtureId:100,engine:'FT',cutoff:cut}).valid,true);
const badOld=buildExactOldOutputRecord({fixtureId:100,engine:'FT',cutoff:cut,baselineSha256:'bad',evaluation:{game:1}});assert.equal(validateExactOldOutputRecord(badOld).valid,false);
const n=buildNewFromCapturedPayloads({fixture,records,oldExactRecord:old,engine:'FT',cutoff:cut});assert.equal(n.modelable,true);assert.equal(n.status,'MODELABLE_CAPTURED_FEATURES');assert.ok(n.packet.live.components.pressure>0);assert.equal(n.history.snapshot_count,2);assert.equal(n.packet.capture_feature_support.old_exact_components,true);assert.equal(n.prediction.base.fallback,false);
const me=evaluateActualMarkets({prediction:n.prediction,state:n.packet.state,marketRows:mrows,targetPeriod:'FT',evaluationCutoff:cut,strictMarket:true});assert.ok(me.offers.length===2&&me.offers.every(x=>x.market_period==='FT'));

// Missing stats and fetch error remain different coverage statuses.
const fx2={...fixture,fixture:{...fixture.fixture,id:101},teams:{home:{id:11,name:'H2'},away:{id:21,name:'A2'}}};
const fx3={...fixture,fixture:{...fixture.fixture,id:102},teams:{home:{id:12,name:'H3'},away:{id:22,name:'A3'}}};
const r2=[await buildCapturedPayload({endpoint:'/fixtures',params:{live:'all'},receivedAt:t5,httpStatus:200,payload:{response:[fx2,fx3]}}),await buildCapturedPayload({endpoint:'/fixtures/statistics',params:{fixture:102},fixtureId:102,receivedAt:t5,httpStatus:500,fetchError:new Error('boom'),payload:null})];
const u2=buildCapturedFixtureUniverse(r2,{cutoff:cut});assert.equal(u2.fixtures.find(x=>x.fixture_id===101).source_status.stats.capture_status,'MISSING');assert.equal(u2.fixtures.find(x=>x.fixture_id===102).source_status.stats.capture_status,'FETCH_ERROR');
console.log('Batch04 capture/feature contract tests PASS');
