import assert from 'node:assert/strict';
import {buildCapturedPayload} from './capture-contract.js';
import {buildCapturedContextInput,buildNewFromCapturedPayloads} from './capture-feature-adapter.js';
import {normalizeApiFootballOddsCaptureDetailed} from './api-football-market-normalizer.js';
import {evaluateActualMarkets} from './opportunity-ranking.js';

const cut='2026-10-07T10:05:30.000Z';
const fixture=(id=500,season=2026)=>({fixture:{id,status:{short:'2H',elapsed:60},date:'2026-10-07T09:00:00Z'},league:{id:77,season},teams:{home:{id:10,name:'Home'},away:{id:20,name:'Away'}},goals:{home:0,away:0}});
async function cap({endpoint,received='2026-10-07T10:05:00Z',fixtureId=500,params={},payload,role=null,metadata={},period=null}){return buildCapturedPayload({endpoint,params,fixtureId,receivedAt:received,requestStartedAt:new Date(Date.parse(received)-100).toISOString(),httpStatus:200,payload,period,metadata:{...(role?{role}:{}),...metadata}})}
const teamStats=g=>({response:{form:'WWDLW',goals:{for:{average:{total:String(g)}},against:{average:{total:'0.9'}}}}});
const records=[
 await cap({endpoint:'/teams/statistics',params:{league:77,season:2026,team:10},payload:teamStats(1.2),role:'HOME_TEAM_STATS'}),
 await cap({endpoint:'/teams/statistics',received:'2026-10-07T10:05:10Z',fixtureId:999,params:{league:77,season:2026,team:10},payload:teamStats(4.5),role:'HOME_TEAM_STATS'}),
 await cap({endpoint:'/teams/statistics',received:'2026-10-07T10:05:20Z',params:{league:77,season:2025,team:10},payload:teamStats(3.7),role:'HOME_TEAM_STATS'}),
 await cap({endpoint:'/teams/statistics',received:'2026-10-07T10:06:00Z',params:{league:77,season:2026,team:10},payload:teamStats(9.9),role:'HOME_TEAM_STATS'}),
 await cap({endpoint:'/teams/statistics',received:'2026-10-07T10:05:15Z',fixtureId:null,params:{league:77,season:2025,team:10},payload:teamStats(8.8),role:'HOME_TEAM_STATS',metadata:{shared_context:true}}),
 await cap({endpoint:'/teams/statistics',params:{league:77,season:2026,team:20},payload:teamStats(1.0),role:'AWAY_TEAM_STATS'})
];
const c1=buildCapturedContextInput(records,fixture(),cut),c2=buildCapturedContextInput([...records].reverse(),fixture(),cut);
assert.equal(c1.input.homeTeamStats.goals.for.average.total,'1.2');assert.equal(c2.input.homeTeamStats.goals.for.average.total,'1.2');
assert.equal(c1.selection.HOME_TEAM_STATS.record.fixture_id,500);assert.ok(c1.selection.HOME_TEAM_STATS.rejected.some(x=>x.reason==='FIXTURE_SCOPE_MISMATCH'));assert.ok(c1.selection.HOME_TEAM_STATS.rejected.some(x=>x.reason==='PARAM_SEASON_MISMATCH'||x.reason==='AFTER_CUTOFF'));

// Interleaved records from another fixture must not alter NEW packet/context for fixture 500.
const liveStats=await cap({endpoint:'/fixtures/statistics',params:{fixture:500},payload:{response:[{team:{id:10},statistics:[{type:'Total Shots',value:8},{type:'Shots on Goal',value:3}]},{team:{id:20},statistics:[{type:'Total Shots',value:4},{type:'Shots on Goal',value:1}]}]}});
const baseRecords=[liveStats,...records.filter(x=>x.fixture_id===500)];const n1=buildNewFromCapturedPayloads({fixture:fixture(),records:baseRecords,engine:'FT',cutoff:cut}),n2=buildNewFromCapturedPayloads({fixture:fixture(),records:[...baseRecords,records[1]],engine:'FT',cutoff:cut});
assert.equal(n1.context.home.strength.goals_for_avg,1.2);assert.equal(n2.context.home.strength.goals_for_avg,1.2);assert.deepEqual(n1.packet.context,n2.packet.context);

// Actual API-Football live schema: response[].odds[] (not bookmakers[].bets[]).
const livePayload={response:[{fixture:{id:500,status:'2H'},update:'2026-10-07T10:05:00Z',status:{blocked:false,stopped:false,finished:false},odds:[
 {id:1,name:'Goals Over/Under',values:[{value:'Over 2.25',handicap:'2.25',odd:'1.95',main:true,suspended:false},{value:'Under 2.25',handicap:'2.25',odd:'1.95',main:true,suspended:false}]},
 {id:2,name:'First Half Goals Over/Under',values:[{value:'Over 0.5',handicap:'0.5',odd:'1.90',main:true,suspended:false},{value:'Under 0.5',handicap:'0.5',odd:'1.90',main:true,suspended:false}]}
]}]};
const marketRec=await cap({endpoint:'/odds/live',payload:livePayload,role:'LIVE_MARKET'}),md=normalizeApiFootballOddsCaptureDetailed(marketRec);
assert.equal(md.schema_status,'LIVE_SCHEMA_MATCH');assert.equal(md.rows.length,2);assert.equal(md.rows.find(x=>x.market_period==='FT').values[0].handicap,2.25);assert.equal(md.rows.find(x=>x.market_period==='H1').values[0].handicap,.5);assert.equal(md.rows[0].integrity.valid,null);assert.equal(md.rows[0].feed_status.blocked,false);
const prediction={engine:'FT',live_update:{effective_lambda_90:2.5},base:{lambda_match:2.5},direction:{home_given_goal:.55},confidence:{value:.8}};
const priced=evaluateActualMarkets({prediction,state:{minute:60,score_home:0,score_away:0},marketRows:md.rows,targetPeriod:'FT',evaluationCutoff:cut,strictMarket:true});assert.equal(priced.offers.length,2);assert.ok(priced.offers.every(x=>x.market_period==='FT'));
const blockedPayload=structuredClone(livePayload);blockedPayload.response[0].status.blocked=true;const blocked=normalizeApiFootballOddsCaptureDetailed(await cap({endpoint:'/odds/live',payload:blockedPayload,role:'LIVE_MARKET'}));assert.equal(evaluateActualMarkets({prediction,state:{minute:60,score_home:0,score_away:0},marketRows:blocked.rows,targetPeriod:'FT',evaluationCutoff:cut,strictMarket:true}).offers.length,0);
const suspPayload=structuredClone(livePayload);for(const v of suspPayload.response[0].odds[0].values)v.suspended=true;const susp=normalizeApiFootballOddsCaptureDetailed(await cap({endpoint:'/odds/live',payload:suspPayload,role:'LIVE_MARKET'}));const suspEval=evaluateActualMarkets({prediction,state:{minute:60,score_home:0,score_away:0},marketRows:susp.rows.filter(x=>x.market_period==='FT'),targetPeriod:'FT',evaluationCutoff:cut,strictMarket:true});assert.equal(suspEval.offers.length,0);
const unknownPayload={response:[{fixture:{id:500,status:'2H'},update:'2026-10-07T10:05:00Z',status:{blocked:false,stopped:false,finished:false},odds:[{id:9,name:'Goals Over/Under Special Segment',values:[{value:'Over 0.5',handicap:'.5',odd:'1.9',main:true,suspended:false},{value:'Under 0.5',handicap:'.5',odd:'1.9',main:true,suspended:false}]}]}]};const unknown=normalizeApiFootballOddsCaptureDetailed(await cap({endpoint:'/odds/live',payload:unknownPayload}));assert.equal(unknown.rows[0].market_period,null);const unknownEval=evaluateActualMarkets({prediction,state:{minute:60,score_home:0,score_away:0},marketRows:unknown.rows,targetPeriod:'FT',evaluationCutoff:cut,strictMarket:true});assert.equal(unknownEval.offers.length,0);assert.ok(unknownEval.rejection_reasons.includes('UNKNOWN_PERIOD'));
const mismatch=normalizeApiFootballOddsCaptureDetailed({...marketRec,endpoint:'/fixtures'});assert.equal(mismatch.rows.length,0);assert.equal(mismatch.schema_status,'ENDPOINT_SCHEMA_MISMATCH');
console.log('Batch04.1 context isolation + live market schema regressions PASS');
