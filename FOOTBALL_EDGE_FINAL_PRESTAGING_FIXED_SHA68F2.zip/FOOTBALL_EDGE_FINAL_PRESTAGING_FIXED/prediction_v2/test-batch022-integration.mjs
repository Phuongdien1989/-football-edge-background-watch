import assert from 'node:assert/strict';
import {compactShadowEvidence} from './shadow-evidence.js';
import {buildPersistenceAcknowledgement,withPersistenceAcknowledgement} from './observation-contract.js';
import {resolveStrictGoalWindows} from './strict-outcome-resolver.js';
import {buildValidationReport} from './validation-report.js';

const t0='2026-10-07T10:01:00.000Z';
const item={id:9001,latest:{minute:60,status:'2H',goals:{home:0,away:0}}};
const packet={fixture_id:9001,engine:'FT',state:{minute:60,score_home:0,score_away:0,status:'2H'},quality:{dq:.88},live:{components:{pressure:.6,chance:.7,momentum:.65,game:.5,legacy_context:.45}}};
const prediction={engine:'FT',probabilities:{goal_5m:42,goal_10m:58,goal_15m:68,home_next_goal_given_goal:54},confidence:{score_100:74,band:'HIGH'},live_update:{effective_lambda_90:2.9}};
const sourceRefs=[{kind:'LIVE_STATISTICS',sourceId:'raw-stats-9001',requestId:'req-stats-9001',payloadHash:'hash-stats-9001',receivedAt:'2026-10-07T10:00:58Z'}];

let row=compactShadowEvidence({item,packet,prediction,now:Date.parse(t0),sourceRefs,marketPeriod:'FT',evaluationCutoff:t0,modelVersion:'TEST_RUNTIME_PATH',configVersion:'TEST_RUNTIME_PATH'});
const ack=buildPersistenceAcknowledgement({subject:row,persistedAt:'2026-10-07T10:01:00.500Z',ackId:'runtime-ack-9001',source:'LOCAL_SYNTHETIC_ACK_ADAPTER',ackOrigin:'SERVER',serverVerified:true});
row=withPersistenceAcknowledgement(row,ack);
row=resolveStrictGoalWindows(row,{events:[]});
let openReport=buildValidationReport({prediction:[row],paired:[],paper:[]},{strictMode:true});assert.equal(openReport.calibration.goal_10m.n,0);
row=resolveStrictGoalWindows(row,{events:[{event_id:'rt-goal',source_id:'rt-request-1',fixture_id:9001,period:'H2',type:'Goal',time:{elapsed:67},received_at:'2026-10-07T10:08:00Z'}]});
let validReport=buildValidationReport({prediction:[row],paired:[],paper:[]},{strictMode:true});assert.equal(validReport.calibration.goal_10m.n,1);assert.equal(validReport.calibration.goal_10m.mean_probability,58);
row=resolveStrictGoalWindows(row,{events:[],snapshots:[]});
validReport=buildValidationReport({prediction:[row],paired:[],paper:[]},{strictMode:true});assert.equal(validReport.calibration.goal_10m.n,1);
const invalid=JSON.parse(JSON.stringify(row));invalid.p_goal_10m=99;const invalidReport=buildValidationReport({prediction:[invalid],paired:[],paper:[]},{strictMode:true});assert.equal(invalidReport.calibration.goal_10m.n,0);
console.log('Batch02.2 local runtime-path integration PASS');
