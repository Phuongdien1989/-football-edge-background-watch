/* Batch 04.1 — captured payloads -> existing B2/B3 NEW model inputs.
 * Context lookup is fixture/identity isolated; no role-only "latest" lookup.
 * No probability/confidence coefficient changes.
 */
import {buildMatchContextFeatures} from './context-feature-layer.js';
import {buildLiveFeaturePacket} from './live-feature-adapter.js';
import {predictShadowProbability} from './probability-engine.js';
import {buildSnapshotHistoryFeatures,statsSnapshotFromCapture} from './capture-history-features.js';
import {classifyExpectedSource,sourceReferenceFromCapture} from './capture-contract.js';
import {oldEvaluationAsNewFeatures,validateExactOldOutputRecord} from './old-exact-contract.js';
import {marketPeriodForEngine,timestampMs} from './observation-contract.js';

const finite=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim())?null:(Number.isFinite(Number(v))?Number(v):null);
const LIVE_FT=new Set(['1H','HT','2H','ET','BT','INT','LIVE']);
const LIVE_H1=new Set(['1H','LIVE']);
const usableCapture=r=>['OK','EMPTY_VALID'].includes(String(r?.capture_status||''));
const normRole=v=>String(v||'').trim().toUpperCase();
const sameNum=(a,b)=>finite(a)!=null&&finite(b)!=null&&Number(a)===Number(b);

function fixtureState(f){return {
  fixture_id:finite(f?.fixture?.id),status:String(f?.fixture?.status?.short||''),minute:finite(f?.fixture?.status?.elapsed),
  score_home:finite(f?.goals?.home),score_away:finite(f?.goals?.away),home_team_id:finite(f?.teams?.home?.id),away_team_id:finite(f?.teams?.away?.id),
  league_id:finite(f?.league?.id),season:finite(f?.league?.season)
}}
function validateState(s,engine){const reasons=[];if(s.fixture_id==null)reasons.push('FIXTURE_ID_MISSING');if(!s.status)reasons.push('STATUS_MISSING');if(s.minute==null)reasons.push('MINUTE_MISSING');if(s.score_home==null)reasons.push('SCORE_HOME_MISSING');if(s.score_away==null)reasons.push('SCORE_AWAY_MISSING');if(s.home_team_id==null||s.away_team_id==null)reasons.push('TEAM_ID_MISSING');const active=String(engine).toUpperCase()==='H1'?LIVE_H1.has(s.status):LIVE_FT.has(s.status);if(!active)reasons.push(`TARGET_NOT_ACTIVE_${s.status||'UNKNOWN'}`);return {valid:reasons.length===0,reasons}}

const ROLE_SPEC=Object.freeze({
  LINEUPS:{endpoint:'/fixtures/lineups',params:id=>({fixture:id.fixture_id})},
  INJURIES:{endpoint:'/injuries',params:id=>({fixture:id.fixture_id})},
  FIXTURE_PLAYERS:{endpoint:'/fixtures/players',params:id=>({fixture:id.fixture_id})},
  STANDINGS:{endpoint:'/standings',params:id=>({league:id.league_id,season:id.season})},
  HOME_TEAM_STATS:{endpoint:'/teams/statistics',params:id=>({league:id.league_id,season:id.season,team:id.home_team_id})},
  AWAY_TEAM_STATS:{endpoint:'/teams/statistics',params:id=>({league:id.league_id,season:id.season,team:id.away_team_id})},
  HOME_RECENT:{endpoint:'/fixtures',params:id=>({team:id.home_team_id})},
  AWAY_RECENT:{endpoint:'/fixtures',params:id=>({team:id.away_team_id})},
  HOME_SEASON_PLAYERS:{endpoint:'/players',params:id=>({team:id.home_team_id,season:id.season})},
  AWAY_SEASON_PLAYERS:{endpoint:'/players',params:id=>({team:id.away_team_id,season:id.season})}
});

function paramsMatch(record,expected={}){const p=record?.params||{};for(const [k,v] of Object.entries(expected)){if(v==null)return {ok:false,reason:`EXPECTED_${k.toUpperCase()}_MISSING`};if(!sameNum(p?.[k],v))return {ok:false,reason:`PARAM_${k.toUpperCase()}_MISMATCH`}}return {ok:true,reason:null}}
function fixtureScopeMatch(record,identity){
  const rf=finite(record?.fixture_id);if(rf!=null)return rf===identity.fixture_id?{ok:true}:{ok:false,reason:'FIXTURE_SCOPE_MISMATCH'};
  return record?.metadata?.shared_context===true?{ok:true}:{ok:false,reason:'FIXTURE_SCOPE_UNPROVEN'};
}
export function selectContextRecord(records,{role,fixture,cutoff}={}){
  const rr=normRole(role),spec=ROLE_SPEC[rr],identity=fixtureState(fixture),cut=timestampMs(cutoff),rejected=[];
  if(!spec)return {record:null,status:'UNSUPPORTED_ROLE',reasons:['ROLE_NOT_SUPPORTED'],rejected};
  const candidates=[];
  for(const r of records||[]){
    if(normRole(r?.metadata?.role)!==rr)continue;
    if(String(r?.endpoint||'')!==spec.endpoint){rejected.push({record_id:r?.record_id||null,reason:'ENDPOINT_ROLE_MISMATCH'});continue}
    const rt=timestampMs(r?.received_at);if(rt==null){rejected.push({record_id:r?.record_id||null,reason:'RECEIVED_AT_MISSING'});continue}
    if(cut==null||rt>cut){rejected.push({record_id:r?.record_id||null,reason:'AFTER_CUTOFF'});continue}
    if(!usableCapture(r)){rejected.push({record_id:r?.record_id||null,reason:`CAPTURE_STATUS_${r?.capture_status||'UNKNOWN'}`});continue}
    const fs=fixtureScopeMatch(r,identity);if(!fs.ok){rejected.push({record_id:r?.record_id||null,reason:fs.reason});continue}
    const pm=paramsMatch(r,spec.params(identity));if(!pm.ok){rejected.push({record_id:r?.record_id||null,reason:pm.reason});continue}
    candidates.push(r);
  }
  candidates.sort((a,b)=>timestampMs(a.received_at)-timestampMs(b.received_at)||String(a.record_id||'').localeCompare(String(b.record_id||'')));
  const record=candidates.at(-1)||null;
  return {record,status:record?(record.capture_status==='EMPTY_VALID'?'EMPTY_VALID':'AVAILABLE'):'MISSING_IDENTITY_MATCH',reasons:record?[]:['NO_IDENTITY_MATCH_AT_CUTOFF'],rejected};
}

function responseValue(r){return r?.payload?.response}
function responseArray(r){const x=responseValue(r);return Array.isArray(x)?x:[]}
function teamStatsObject(r){const x=responseValue(r);if(x&&typeof x==='object'&&!Array.isArray(x))return x;if(Array.isArray(x)&&x.length===1&&x[0]&&typeof x[0]==='object'&&!Array.isArray(x[0]))return x[0];return null}
function standingRows(raw){const r=responseArray(raw)?.[0]?.league?.standings;return Array.isArray(r)?r.flat():[]}
function mapLivePlayers(raw){return responseArray(raw).map(team=>({team_id:team?.team?.id,players:(team?.players||[]).map(p=>{const st=(p?.statistics||[])[0]||{};return {id:p?.player?.id,name:p?.player?.name,rating:finite(st?.games?.rating),minutes:finite(st?.games?.minutes),position:st?.games?.position}})}))}

export function buildCapturedContextInput(records,fixture,cutoff){
  const s=fixtureState(fixture),sel={};for(const role of Object.keys(ROLE_SPEC))sel[role]=selectContextRecord(records,{role,fixture,cutoff});
  const lineups=sel.LINEUPS.record,inj=sel.INJURIES.record,players=sel.FIXTURE_PLAYERS.record,stand=sel.STANDINGS.record,hts=sel.HOME_TEAM_STATS.record,ats=sel.AWAY_TEAM_STATS.record,
    hr=sel.HOME_RECENT.record,ar=sel.AWAY_RECENT.record,hp=sel.HOME_SEASON_PLAYERS.record,ap=sel.AWAY_SEASON_PLAYERS.record,sr=standingRows(stand);
  const input={homeId:s.home_team_id,awayId:s.away_team_id,homeSeasonPlayers:responseArray(hp),awaySeasonPlayers:responseArray(ap),lineups:responseArray(lineups),injuries:inj?responseArray(inj):undefined,
    livePlayers:mapLivePlayers(players),homeStanding:sr.find(x=>Number(x?.team?.id)===Number(s.home_team_id))||null,awayStanding:sr.find(x=>Number(x?.team?.id)===Number(s.away_team_id))||null,
    homeTeamStats:teamStatsObject(hts),awayTeamStats:teamStatsObject(ats),homeRecent:responseArray(hr),awayRecent:responseArray(ar)};
  const selectedRecords=Object.values(sel).map(x=>x.record).filter(Boolean);
  return {input,selection:sel,selected_records:selectedRecords};
}

export function buildNewFromCapturedPayloads({fixture,records=[],oldExactRecord=null,engine='FT',cutoff,fallbackLambda90=2.5}={}){
  const eng=String(engine||'FT').toUpperCase(),state=fixtureState(fixture),sv=validateState(state,eng),period=marketPeriodForEngine(eng);
  if(!sv.valid)return {status:'UNMODELABLE_INVALID_STATE',modelable:false,reasons:sv.reasons,prediction:null,packet:null,context:null,history:null,source_references:[]};
  const stats=classifyExpectedSource(records,{endpoint:'/fixtures/statistics',fixtureId:state.fixture_id,cutoff}),statsRec=stats.record,
    history=buildSnapshotHistoryFeatures(records,{fixtureId:state.fixture_id,cutoff,homeTeamId:state.home_team_id,awayTeamId:state.away_team_id}),
    statSnap=statsRec?statsSnapshotFromCapture(statsRec,{homeTeamId:state.home_team_id,awayTeamId:state.away_team_id}):null,
    capturedContext=buildCapturedContextInput(records,fixture,cutoff),ctx=buildMatchContextFeatures(capturedContext.input),
    old=oldExactRecord?oldEvaluationAsNewFeatures(oldExactRecord):{available:false,reasons:['OLD_EXACT_COMPONENTS_NOT_CAPTURED'],evaluation:null},
    evaluation=old.available?old.evaluation:{game:null,pressure:null,chance:null,momentum:null,context:null,quality:null,scoreMode:statsRec?'CAPTURED_STATS_NO_OLD_COMPONENTS':'NO_STATS',mature:false,baselineAge:null,accel:history?.acceleration??null};
  const metrics={home:statSnap?.home||{},away:statSnap?.away||{}},snapshot={minute:state.minute,status:state.status,goals:{home:state.score_home,away:state.score_away},metrics,
    fresh_at:statsRec?timestampMs(statsRec.received_at):timestampMs(cutoff),dq:null,stats_presence:{coverage:statsRec?1:0}},item={id:state.fixture_id,latest:snapshot,eval:evaluation},
    packet=buildLiveFeaturePacket({fixtureId:state.fixture_id,engine:eng,item,context:ctx,now:timestampMs(cutoff)});
  packet.capture_history=history;
  const have=role=>!!capturedContext.selection?.[role]?.record;
  const support={old_exact_components:old.available,stats:!!statsRec,context:{lineups:have('LINEUPS'),injuries:have('INJURIES'),fixture_players:have('FIXTURE_PLAYERS'),standings:have('STANDINGS'),
    team_stats:have('HOME_TEAM_STATS')&&have('AWAY_TEAM_STATS'),recent:have('HOME_RECENT')&&have('AWAY_RECENT'),season_players:have('HOME_SEASON_PLAYERS')&&have('AWAY_SEASON_PLAYERS')}};
  support.unsupported=[];if(!support.old_exact_components)support.unsupported.push('OLD_DERIVED_GAME_PRESSURE_CHANCE_MOMENTUM_CONTEXT');if(!support.stats)support.unsupported.push('LIVE_STATS');for(const [k,v] of Object.entries(support.context))if(v===false)support.unsupported.push(`CONTEXT_${k.toUpperCase()}`);
  packet.capture_feature_support=support;packet.capture_context_selection=Object.fromEntries(Object.entries(capturedContext.selection).map(([k,v])=>[k,{status:v.status,record_id:v.record?.record_id||null,reasons:v.reasons||[],rejected:v.rejected||[]}]))
  const prediction=predictShadowProbability(packet,{fallbackLambda90});
  const baseRefs=(records||[]).filter(r=>Number(r?.fixture_id)===Number(state.fixture_id)&&timestampMs(r?.received_at)!=null&&timestampMs(r.received_at)<=timestampMs(cutoff)),selected=capturedContext.selected_records,
    unique=new Map([...baseRefs,...selected].map(r=>[r.record_id||`${r.endpoint}:${r.source_id}`,r])),refs=[...unique.values()].map(r=>sourceReferenceFromCapture(r,{required:false}));
  return {status:old.available?'MODELABLE_CAPTURED_FEATURES':'MODELABLE_PARTIAL_CAPTURED',modelable:true,reasons:[...(old.reasons||[]),...(statsRec?[]:['NO_STATS_AT_CUTOFF'])],market_period:period,prediction,packet,context:ctx,history,
    source_references:refs,context_source_selection:capturedContext.selection,old_component_validation:oldExactRecord?validateExactOldOutputRecord(oldExactRecord,{fixtureId:state.fixture_id,engine:eng,cutoff}):null};
}
