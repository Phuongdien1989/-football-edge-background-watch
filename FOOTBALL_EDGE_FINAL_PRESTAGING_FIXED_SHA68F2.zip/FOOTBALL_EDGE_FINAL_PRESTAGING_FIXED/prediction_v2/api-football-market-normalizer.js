/* Batch 04.1 — API-Football raw odds -> existing B4 market row contract.
 * Supports the actual `/odds/live` response shape (`response[].odds[]`) and
 * prematch `/odds` bookmaker shape separately. Feed/integrity flags are never
 * fabricated as "false/true" when the provider payload does not prove them.
 */
import {normalizeMarketPeriod} from './observation-contract.js';
const text=v=>String(v??'').trim();
const boolOrNull=v=>typeof v==='boolean'?v:null;
function inferPeriod(name,explicit=null){const p=normalizeMarketPeriod(explicit);if(p)return p;const n=text(name).toUpperCase();if(/FIRST\s*HALF|1ST\s*HALF|\b1H\b|\bH1\b|HALF\s*TIME/.test(n))return 'H1';if(/SECOND\s*HALF|2ND\s*HALF|\b2H\b|\bH2\b/.test(n))return 'H2';if(/FULL\s*TIME|MATCH|90\s*MIN/.test(n))return 'FT';if(/^(GOALS? OVER\/UNDER|ASIAN HANDICAP|ASIAN TOTAL|TOTAL GOALS?)$/i.test(n))return 'FT';return null}
function category(name){const n=text(name).toLowerCase();if(/over.?under|total goals|asian total|goal line/.test(n))return 'over_under';if(/asian handicap|handicap/.test(n))return 'asian_handicap';return null}
function lineFrom(v){const x=Number(v?.handicap);if(Number.isFinite(x))return x;const m=text(v?.value).match(/[-+]?\d+(?:\.\d+)?/);return m?Number(m[0]):null}
function valueRow(v){return {value:v?.value??v?.name??v?.label??null,odd:v?.odd??v?.price??null,handicap:lineFrom(v),main:typeof v?.main==='boolean'?v.main:null,suspended:boolOrNull(v?.suspended),provider_updated_at:v?.update??null}}
function feedStatus(block){const s=block?.status;return {blocked:boolOrNull(s?.blocked),stopped:boolOrNull(s?.stopped),finished:boolOrNull(s?.finished)}}
function fixtureId(block,record){const x=Number(block?.fixture?.id??block?.fixture_id??record?.fixture_id);return Number.isFinite(x)?x:null}

function normalizeLive(record){
  if(String(record?.endpoint||'')!=='/odds/live')return {rows:[],schema_status:'ENDPOINT_SCHEMA_MISMATCH',reasons:['LIVE_SCHEMA_REQUIRES_ODDS_LIVE_ENDPOINT']};
  const resp=Array.isArray(record?.payload?.response)?record.payload.response:[],out=[],reasons=[];
  for(const block of resp){
    if(!Array.isArray(block?.odds)){reasons.push('LIVE_BLOCK_ODDS_ARRAY_MISSING');continue}
    const providerUpdated=block?.update??record?.provider_updated_at??null,status=feedStatus(block),fid=fixtureId(block,record);
    for(const bet of block.odds){
      const cat=category(bet?.name);if(!cat)continue;const period=inferPeriod(bet?.name,record?.market_period),values=Array.isArray(bet?.values)?bet.values.map(valueRow):[];
      const liveBookmaker=block?.bookmaker?.name??(typeof block?.bookmaker==='string'?block.bookmaker:null),liveBookmakerId=block?.bookmaker?.id??block?.bookmaker_id??null;
      out.push({source:'API_FOOTBALL_LIVE',source_schema:'API_FOOTBALL_LIVE_ODDS_V3',endpoint:'/odds/live',fixture_id:fid,fixture_status:block?.fixture?.status??null,
        category:cat,market:bet?.name||null,market_period:period,bet_id:bet?.id??null,bookmaker:liveBookmaker,bookmaker_id:liveBookmakerId,received_at:record?.received_at??null,provider_updated_at:providerUpdated,
        feed_status:status,integrity:{valid:null,reason:'CAPTURE_NORMALIZER_DOES_NOT_ASSERT_MARKET_INTEGRITY'},values});
    }
  }
  return {rows:out,schema_status:reasons.length?'LIVE_SCHEMA_PARTIAL':'LIVE_SCHEMA_MATCH',reasons};
}
function normalizePrematch(record){
  if(String(record?.endpoint||'')!=='/odds')return {rows:[],schema_status:'ENDPOINT_SCHEMA_MISMATCH',reasons:['PREMATCH_SCHEMA_REQUIRES_ODDS_ENDPOINT']};
  const resp=Array.isArray(record?.payload?.response)?record.payload.response:[],out=[],reasons=[];
  for(const block of resp){
    if(!Array.isArray(block?.bookmakers)){reasons.push('PREMATCH_BOOKMAKERS_ARRAY_MISSING');continue}
    const providerUpdated=block?.update??record?.provider_updated_at??null,fid=fixtureId(block,record);
    for(const book of block.bookmakers||[])for(const bet of book?.bets||[]){const cat=category(bet?.name);if(!cat)continue;const period=inferPeriod(bet?.name,record?.market_period),values=Array.isArray(bet?.values)?bet.values.map(valueRow):[];
      out.push({source:'API_FOOTBALL_PREMATCH',source_schema:'API_FOOTBALL_PREMATCH_ODDS_V3',endpoint:'/odds',fixture_id:fid,category:cat,market:bet?.name||null,market_period:period,
        bet_id:bet?.id??null,bookmaker:book?.name??null,bookmaker_id:book?.id??null,received_at:record?.received_at??null,provider_updated_at:providerUpdated,
        feed_status:null,integrity:{valid:null,reason:'CAPTURE_NORMALIZER_DOES_NOT_ASSERT_MARKET_INTEGRITY'},values});}
  }
  return {rows:out,schema_status:reasons.length?'PREMATCH_SCHEMA_PARTIAL':'PREMATCH_SCHEMA_MATCH',reasons};
}
export function normalizeApiFootballOddsCaptureDetailed(record){const ep=String(record?.endpoint||'');if(ep==='/odds/live')return normalizeLive(record);if(ep==='/odds')return normalizePrematch(record);return {rows:[],schema_status:'ENDPOINT_SCHEMA_MISMATCH',reasons:[`UNSUPPORTED_ODDS_ENDPOINT:${ep||'MISSING'}`]}}
export function normalizeApiFootballOddsCapture(record){return normalizeApiFootballOddsCaptureDetailed(record).rows}
