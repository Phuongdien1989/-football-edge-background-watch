/* Batch04.1 — immutable prediction bundle validator shared by local/staging persistence. */
import {validateObservationContent,contentFingerprint,timestampMs,normalizeMarketPeriod} from './observation-contract.js';
import {validatePaperMarketRecordContent} from './paper-market-evidence.js';
import {validateExactOldOutputRecord} from './old-exact-contract.js';
const finite=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim())?null:(Number.isFinite(Number(v))?Number(v):null);
export function validateObservationForPersistence(observation){
  const reasons=[],o=observation||{},c=validateObservationContent(o);if(!c.valid)reasons.push(...c.reasons);
  if(!o.observation_id)reasons.push('OBSERVATION_ID_MISSING');if(finite(o.fixture_id)==null)reasons.push('OBSERVATION_FIXTURE_ID_INVALID');if(!String(o.engine||'').trim())reasons.push('OBSERVATION_ENGINE_MISSING');
  if(!normalizeMarketPeriod(o.market_period))reasons.push('OBSERVATION_MARKET_PERIOD_INVALID');const cut=timestampMs(o.evaluation_cutoff),created=timestampMs(o.prediction_created_at);if(cut==null)reasons.push('OBSERVATION_CUTOFF_INVALID');if(created==null)reasons.push('PREDICTION_CREATED_AT_INVALID');if(cut!=null&&created!=null&&created<cut)reasons.push('PREDICTION_CREATED_BEFORE_EVALUATION_CUTOFF');
  return {valid:reasons.length===0,reasons,recomputed:c.recomputed};
}
export function immutableBundleDescriptor({observation,paperRecord=null,oldExactRecord=null}={}){
  return {observation_id:observation?.observation_id??null,observation_content_fingerprint:observation?.content_fingerprint??null,paper_content_fingerprint:paperRecord?.content_fingerprint??null,
    old_record_fingerprint:oldExactRecord?.record_fingerprint??null,fixture_id:observation?.fixture_id??null,engine:observation?.engine??null,market_period:observation?.market_period??null,evaluation_cutoff:observation?.evaluation_cutoff??null};
}
export function immutableBundleFingerprint(bundle){return contentFingerprint(immutableBundleDescriptor(bundle))}
export function validateLockedBundle({observation,paperRecord=null,oldExactRecord=null}={}){
  const reasons=[],ov=validateObservationForPersistence(observation);if(!ov.valid)reasons.push(...ov.reasons);
  if(paperRecord){const pv=validatePaperMarketRecordContent(paperRecord,{observation});if(!pv.valid)reasons.push(...pv.reasons)}
  if(oldExactRecord){const oldv=validateExactOldOutputRecord(oldExactRecord,{fixtureId:observation?.fixture_id,engine:observation?.engine,cutoff:observation?.evaluation_cutoff});if(!oldv.valid)reasons.push(...oldv.reasons)}
  return {valid:reasons.length===0,reasons,bundle_fingerprint:immutableBundleFingerprint({observation,paperRecord,oldExactRecord})};
}
export function compareStoredBundle({storedObservation,storedPaper=null,storedOld=null,expectedObservation,expectedPaper=null,expectedOld=null,storedBundleFingerprint=null}={}){
  const reasons=[],stored=validateLockedBundle({observation:storedObservation,paperRecord:storedPaper,oldExactRecord:storedOld}),expected=validateLockedBundle({observation:expectedObservation,paperRecord:expectedPaper,oldExactRecord:expectedOld});
  if(!stored.valid)reasons.push(...stored.reasons.map(x=>`STORED_${x}`));if(!expected.valid)reasons.push(...expected.reasons.map(x=>`EXPECTED_${x}`));if(stored.bundle_fingerprint!==expected.bundle_fingerprint)reasons.push('BUNDLE_FINGERPRINT_READBACK_MISMATCH');if(storedBundleFingerprint&&stored.bundle_fingerprint!==storedBundleFingerprint)reasons.push('STORED_BUNDLE_COLUMN_MISMATCH');
  return {valid:reasons.length===0,reasons,stored_bundle_fingerprint:stored.bundle_fingerprint,expected_bundle_fingerprint:expected.bundle_fingerprint};
}
