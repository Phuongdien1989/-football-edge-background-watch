# FOOTBALL EDGE — BATCH05A.2 RESULT
Date: 2026-10-07
Scope: LOCAL/OFFLINE ONLY. No deploy. No real API-Football. No production/model coefficient changes.

## Source lock
Continued directly from audited Batch05A.1 ZIP. Incoming `evidence/BATCH05A1_SHA256SUMS.txt` verified 117/117 before edits. Probability engine remains locked at `194b0c5b9870dbdcb4e06b2a823e1b0afd81f6626fb98c44917172de87257b16`. Exact P2.0.5.2 runtime fixture remains `a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844`.

## Before → after
1. Restart previously preserved request count but not fixture pin/OLD history. Now durable smoke session stores start/pin/completed cutoff+observation metadata; restart restores exact OLD history by replaying persisted captures in locked cutoff order. Missing/corrupt state or locked-observation/capture mismatch fails closed before provider requests.
2. ACK previously only required parseable `persisted_at`. Now ACK timeline requires persisted_at >= cutoff and prediction_created_at and <= readback time + 5 s skew. Old/future ACK probes reject; valid retry accepts.
3. Staging persistence previously lacked a complete Node→D1 ownership path. Now prepared bridge includes authenticated Node HTTP client, staging Worker route, D1 capture/budget/session/bundle/readback adapters and a D1 single-owner lease.
4. Report now represents whole session: original session start, invocation start/elapsed, cumulative + invocation attempts, pinned fixture, cumulative observation IDs, restored OLD history, actual mode/transport and stop/failure.

## Restart evidence
Probe run 1 pins fixture 505 and spends 5 attempts. Restart discovery contains fixture 1 and 505; pin remains 505, cumulative attempts become 10, original observation remains immutable, restored OLD history depth is 1, new tick OLD history depth is 2 and baseline age is 1250 ms. Pin-disappears probe stops after status+discovery without enriching fixture 1.

## ACK evidence
- persisted_at year 2000 for 2026 prediction: REJECT.
- persisted_at 10 minutes beyond readback with 5 s skew: REJECT.
- persisted_at after prediction and before readback: ACCEPT.
- ACK mismatch/persistence failure persists stop; restart spends no additional provider request.

## Bridge evidence
`createD1StagingBridge` was exercised offline against SQLite through a D1-compatible API for owner/session/budget/capture/immutable bundle/readback. The authenticated HTTP Node→Worker→D1 routing layer was also exercised offline. This is NOT a remote D1 verification and must not be described as one.

## Tests
26/26 test programs PASS, 0 FAIL. Includes all 25 prior Batch05A.1 programs plus `test-batch05a2-regressions.mjs`. Syntax checks PASS for all Batch05A.2 entry/bridge/session/test modules. Offline remote preflight PASS with network_calls=0/deployed=false.

## Evidence files
- `evidence/BATCH05A2_FULL_TESTS.log`
- `evidence/BATCH05A2_RESTART_ACK_BRIDGE_EVIDENCE.json`
- `evidence/BATCH05A2_8TICK_SMOKE_EVIDENCE.json`
- `evidence/BATCH05A2_HASH_GUARDS.txt`
- `docs/BATCH05A2_REMOTE_RUN_PLAN.md`

## Remaining blockers before remote smoke
1. No staging deploy has occurred; therefore Worker route/D1 binding/auth/Cloudflare behavior is not remotely verified.
2. Real API-Football daily/minute quota is not verified.
3. Exact staging worker URL/name, D1 database ID, and previous staging version ID must be confirmed before any approved deployment.
4. Production frontend baseline bytes are not present as a standalone frontend artifact in this package. Only the frozen production/reference hash is retained: `a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844`; do not claim a frontend rollback file from this ZIP.

## Stop gate
STOP after local/offline Batch05A.2. Do not deploy, call real API, open pilot, or claim NEW > OLD without explicit next approval.
