# FOOTBALL EDGE — BATCH05A RESULT

**Date:** 2026-10-07  
**Scope:** local/offline pre-pilot staging-smoke completion.  
**Remote status:** NOT DEPLOYED / NO REAL API CALL / NO PILOT.

## 1. Source lock
- Continued from `01_BATCH041_CURRENT/source/` in the supplied master handoff.
- Parent handoff `SHA256SUMS.txt`: full verification PASS (exit 0).
- Exact frozen production P2.0.5.2 SHA256: `a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844`.
- Exact OLD runtime guard uses the same SHA.
- `probability-engine.js` remains unchanged from Batch04.1; no coefficient tuning.

## 2. Implemented
Added `staging_kit/batch05a-smoke-orchestrator.mjs` as the explicit smoke entrypoint/orchestrator. It wires:
`collector -> shared budget/stop -> exact OLD bridge -> same-universe NEW -> football/market evaluation -> durable locked-bundle ACK -> evidence export`.

Hard smoke envelope is independent of the older 8-fixture/90-minute pilot plan:
- max fixtures: 1;
- max duration: 10 minutes;
- max provider attempts: 40 total;
- every `/status`, discovery, data request and retry is budgeted;
- no default network transport is allowed by the orchestrator; a transport must be injected explicitly;
- provider quota remains a runtime precondition; lower/unsafe quota means reduce scope or STOP.

Added:
- `staging_kit/pilot-plan-batch05a-smoke.json`;
- `prediction_v2/test-batch05a-smoke.mjs`;
- `docs/BATCH05A_REMOTE_RUN_PLAN.md`;
- evidence/test/hash manifests.

## 3. Local smoke evidence
Synthetic/fake transport + fake clock + real local SQLite:
- fixture count: 1;
- provider attempts: 40;
- simulated elapsed: 428,000 ms (7m08s), below 10m cap;
- real provider calls: 0;
- deploys: 0;
- exact OLD: `OLD_CAPTURED_EXACT`;
- exact OLD baseline SHA: P2.0.5.2 frozen hash;
- NEW: `MODELABLE_CAPTURED_FEATURES`;
- actual supported market offers assessed from the fake live-market payload: 2;
- all replay sources at/before cutoff: true;
- durable ACK: `LOCAL_DURABLE_TEST`, `server_verified=false`.

This proves orchestration and local durability only. It does not prove API-Football runtime, remote staging D1, Cloudflare bindings, or predictive lift.

## 4. Regression
Full suite: **24 PASS / 0 FAIL**.
This is the prior 23-test Batch04.1 suite plus the new Batch05A smoke test.

## 5. Explicitly not done
- no staging deployment;
- no production deployment/change;
- no API-Football/API-Sports real request;
- no `/status` real request;
- no remote D1 write/readback;
- no live pilot;
- no model coefficient/weight change;
- no OLD production rule change;
- no claim NEW > OLD;
- no claim predictive lift.

## 6. Blockers before remote smoke
1. User must explicitly approve a remote staging smoke after independent review of this ZIP.
2. Current provider daily/minute quota is still UNVERIFIED; first approved `/status` request must verify it and counts toward the 40-request cap.
3. Staging service target and D1 bindings must be verified as staging-only and must exclude production P2.0.5.2.
4. Remote SERVER ACK remains unproven until staging D1 write/readback succeeds.

## 7. Release decision
**BATCH05A LOCAL/OFFLINE: PASS.**  
**REMOTE STAGING SMOKE: HOLD / REQUIRES SEPARATE USER APPROVAL.**
