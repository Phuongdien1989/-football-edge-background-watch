# FOOTBALL EDGE — FINAL PRE-STAGING SMOKE PACKAGE

Status: LOCAL/OFFLINE COMPLETE. REMOTE NOT EXECUTED.

## Before
Batch05A.3 had the hardened orchestrator, fenced HTTP/D1 bridge and remote helper, but operational use was split across helper/config/plan and export did not return the complete pilot evidence set.

## After
- One operational surface: `staging_kit/batch05a-final-ops.sh` with `preflight|db-init|deploy|run|stop|export|rollback`.
- One guarded CLI: `staging_kit/batch05a-final-remote-cli.mjs` for target/model/limit preflight and run/stop/export.
- Hard smoke limits remain 1 detailed fixture / 600000 ms / 40 provider attempts; budget persists across restart.
- Server-side pilot export returns session, budget, captures, locked observations and exact OLD output references, isolated by pilot.
- Existing DB-enforced owner lease/fencing, ACK timeline, restart replay, clock injection and failure-stop evidence remain in force.
- Full offline path is tested: Node orchestrator -> authenticated Worker handler -> SQLite/D1-compatible adapter -> ACK/readback -> restart -> export.

## Verification on final bytes
- 28/28 `prediction_v2/test-*.mjs` PASS, 0 FAIL.
- JS/MJS syntax checks: 0 failures.
- Final package probe: PASS; restart retained fixture 505, cumulative budget and OLD history; export contained only the selected pilot.
- Probability engine SHA256 unchanged: `194b0c5b9870dbdcb4e06b2a823e1b0afd81f6626fb98c44917172de87257b16`.
- Exact runtime fixture file SHA256: `b38b8f3d398db714b7c6a6e7c2e3de0a8cf9e317bb408942f4bcbe8e5a754714`.
- Frozen production P2.0.5.2 frontend/reference SHA256 remains `a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844`; standalone production frontend bytes are NOT in this package.

## What is not proved
No Cloudflare deployment, remote D1 mutation, real SERVER ACK over the Internet, API-Football request/quota check, or remote smoke was performed. This package does not claim NEW > OLD.

## Real remote blockers / inputs needed once staging smoke is approved
1. Dedicated staging Worker hostname/URL (must not be the frozen production hostname).
2. Dedicated staging D1 database name + database ID, and confirmation it is disposable/staging-only.
3. A new staging bridge secret (`BATCH05A3_BRIDGE_TOKEN`) set on the Worker and available to the Node runner.
4. API-Football key with confirmed remaining quota >= the approved scope (max 40 attempts; runner may stop earlier).
5. Previous staging Worker version ID if rollback to a specific prior staging version is required.
6. Explicit approval to execute the one-fixture / 10-minute / 40-attempt remote staging smoke.

Production and model coefficients were not modified.
