# FOOTBALL EDGE — BATCH05A.1 RESULT
Date: 2026-10-07
Scope: LOCAL/OFFLINE ONLY. No deploy. No real API call. No production/model coefficient change.

## Source / locks
- Continued from audited Batch05A package, itself locked to Batch04.1 exact source.
- Frozen production P2.0.5.2 reference SHA256 remains `a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844` (reference guard; production not touched).
- `prediction_v2/probability-engine.js` SHA256 remains `194b0c5b9870dbdcb4e06b2a823e1b0afd81f6626fb98c44917172de87257b16`.
- Model coefficients were not edited.

## Before -> after
1. Prediction timing
   - Before: collect many ticks, instantiate exact OLD VM near the end, lock one final prediction.
   - After: one persistent exact OLD runtime per smoke session. Every successful tick establishes cutoff, evaluates OLD and NEW from data available at/before that cutoff, runs both ranking surfaces, persists immutable bundle + verifies ACK, then and only then permits the next tick.
   - Offline evidence: 8 ticks -> 8 unique observation IDs. OLD history depth 1..8; baseline age 0ms on tick 1 then 61,000ms on tick 2 and continues increasing.
   - No +10/+15/FT forced settlement in 10-minute smoke; outcomes remain `UNRESOLVED` absent confirmed outcome evidence.

2. Fixture scope
   - Before: each discovery could reselect lowest fixture ID; detailed capture could cross fixtures before cap detection.
   - After: first valid discovery pins exactly one fixture. Later discovery is universe observation only; it cannot replace the pin. Detailed stats/events/odds are requested only for pinned fixture. If pinned fixture disappears/ends, durable budget is halted with `PINNED_FIXTURE_DISAPPEARED_OR_ENDED` and no substitute is selected.
   - Full discovery universe is explicitly not called a complete enriched cohort.

3. DQ / integrity
   - Removed hard-coded `dq_score=90`, `integrity_score=95`.
   - OLD DQ input is now evidence-derived required-source coverage at cutoff: stats/events/market usable + <=120s freshness. EMPTY_VALID remains explicit and usable but is reported as a limitation. FETCH_ERROR/MISSING/STALE reduce coverage and are propagated.
   - Integrity is `null` with `UNKNOWN_NOT_SYNTHESIZED`; no unsupported high integrity score is invented.
   - Regression probes: clean/EMPTY_VALID, missing, fetch error and stale PASS.

4. ACK / persistence failure
   - ACK validation now checks subject ID, observation content fingerprint, immutable bundle fingerprint, persisted_at timestamp and origin policy.
   - LOCAL requires `LOCAL_DURABLE_TEST`, `server_verified=false` and recorder readback verification.
   - REMOTE policy requires `SERVER`, `server_verified=true`.
   - Bad/missing ACK, persistence exception/readback mismatch stop the session and the final evidence report is still exported. No further collection occurs after the failure.
   - Failure probe stopped after 5 provider attempts and exported the ACK error.

5. Runtime / ranking / report
   - Runtime is explicitly `NODE_LOCAL_RUNNER`; it is NOT claimed to be a Cloudflare Worker entrypoint. `node:fs` and guarded `node:vm` are Node-specific.
   - Calls real `rankFootballRows()` and `rankMarketOpportunities()` implementations.
   - Report records runtime, mode, transport, real-network count policy, provider attempts, actual elapsed, pinned fixture, stop reason, observation IDs, per-tick ACK, per-tick rankings and data limitations.
   - `network_real_calls=0` only for the injected fake/offline transport. The orchestrator accepts an explicit `networkReal` flag for a future real transport rather than hard-coding zero.

## Main offline smoke evidence
File: `evidence/BATCH05A1_SMOKE_EVIDENCE.json`
- runtime: NODE_LOCAL_RUNNER
- mode: LOCAL_OFFLINE_ONLY
- transport: INJECTED_FAKE_OFFLINE
- network_real_calls: 0
- provider_attempts: 40
- pinned_fixture_id: 505
- detailed_fixture_count: 1
- actual_elapsed_ms: 428000
- stop_reason: COMPLETED_SCOPE
- locked observations: 8 unique IDs
- ACK origin each locked tick: LOCAL_DURABLE_TEST, server_verified=false
- exact OLD SHA guard: P2.0.5.2 `a82bf...c844`
- tick 1 OLD history depth=1, baseline age=0ms
- tick 2 OLD history depth=2, baseline age=61000ms
- all tick outcomes: UNRESOLVED
- test discovery intentionally introduces fixture ID 1 after fixture 505 was pinned; detailed requests remain fixture 505.

## Tests
`evidence/BATCH05A1_FULL_TESTS.log`
`evidence/BATCH05A1_TEST_SUMMARY.txt`
Final: **PASS=25 FAIL=0**.
This includes the prior 24-test surface plus the new Batch05A.1 regression suite; the prior Batch05A smoke test was upgraded to the per-tick/pinned/ACK contract.

New/expanded probes include:
- persistent OLD history and 8 immutable per-tick predictions;
- fixture pin survives lower-ID discovery;
- pinned fixture disappearance stops without substitution;
- clean / EMPTY_VALID / missing / FETCH_ERROR / STALE evidence;
- malformed ACK subject/content/bundle/timestamp/origin;
- remote SERVER ACK requires server_verified=true;
- durable budget restart 5 -> 10 attempts (no reset);
- ACK failure stops after first tick and exports failure evidence;
- real football and market ranking calls;
- unresolved settlement policy.

## Remote staging preparation — NOT executed
Files:
- `staging_kit/batch05a1-remote-config.json`
- `staging_kit/batch05a1-remote-preflight.mjs`
- `docs/BATCH05A1_REMOTE_RUN_PLAN.md`

Offline remote preflight PASS: model hash/limits/target config verified; zero network calls; zero deploys.

Important remaining remote integration blocker: the exact OLD runtime is deliberately a guarded Node VM path, while D1 durable budget/capture/locked-bundle adapters are Cloudflare bindings. A staging-only persistence bridge between the standalone Node smoke runner and those D1 adapters is not yet independently verified. Therefore this package does NOT enable a real provider smoke command and does NOT claim Cloudflare Worker compatibility for the Node orchestrator. This is fail-closed and must be resolved/verified before remote smoke approval.

## Not done / claims not made
- No staging deploy.
- No production deploy/change.
- No real API-Football call.
- No remote D1 execution/readback.
- No pilot expansion.
- No proof or claim that NEW/V2 is better than OLD.
