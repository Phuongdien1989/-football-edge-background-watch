/* Offline-only remote readiness preflight. Does not deploy and does not call API-Football. */
import fs from 'node:fs';import crypto from 'node:crypto';
const cfg=JSON.parse(fs.readFileSync(new URL('./batch05a1-remote-config.json',import.meta.url),'utf8'));
const required=['staging_target','budget_store','capture_persistence','locked_bundle_persistence','max_provider_requests','max_duration_seconds','max_fixtures','rollback'];
const missing=required.filter(k=>cfg[k]==null);if(missing.length)throw new Error(`REMOTE_CONFIG_MISSING:${missing.join(',')}`);
if(cfg.max_provider_requests!==40||cfg.max_duration_seconds!==600||cfg.max_fixtures!==1)throw new Error('REMOTE_LIMITS_NOT_BATCH05A1');
const pe=new URL('../prediction_v2/probability-engine.js',import.meta.url),sha=crypto.createHash('sha256').update(fs.readFileSync(pe)).digest('hex');
if(sha!==cfg.probability_engine_sha256)throw new Error('MODEL_LOCK_HASH_MISMATCH');
if(cfg.exact_old_runtime_target!=='NODE_VM_P2052_GUARDED')throw new Error('EXACT_OLD_RUNTIME_TARGET_UNVERIFIED');
console.log(JSON.stringify({status:'PASS_OFFLINE_PREFLIGHT_ONLY',network_calls:0,deployed:false,config:cfg.staging_target,probability_engine_sha256:sha,remote_execution_blocked_until_explicit_approval:true},null,2));
