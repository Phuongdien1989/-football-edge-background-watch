/* FOOTBALL EDGE pre-staging final CLI. Network actions remain approval-gated. */
import fs from 'node:fs';
import crypto from 'node:crypto';
import {createNodeHttpD1BridgeA3} from './batch05a3-http-d1-bridge.js';
import {runBatch05aSmoke,BATCH05A_SMOKE_LIMITS} from './batch05a-smoke-orchestrator.mjs';
const MODEL='194b0c5b9870dbdcb4e06b2a823e1b0afd81f6626fb98c44917172de87257b16';
const PROD='https://shiny-silence-d892.ngophuonghuy.workers.dev';
const [,,cmd,configPath]=process.argv;
if(!cmd||!configPath)throw new Error('USAGE: node staging_kit/batch05a-final-remote-cli.mjs <preflight|run|stop|export> <config.json>');
const c=JSON.parse(fs.readFileSync(configPath,'utf8'));
function assertConfig(){
 const errs=[]; let u=null; try{u=new URL(c.bridge_base_url)}catch{errs.push('BRIDGE_URL_INVALID')}
 if(!u||u.protocol!=='https:')errs.push('STAGING_HTTPS_REQUIRED');
 if(c.bridge_base_url===PROD||/shiny-silence-d892\.ngophuonghuy\.workers\.dev/i.test(c.bridge_base_url||''))errs.push('PRODUCTION_TARGET_FORBIDDEN');
 if(!c.staging_target_confirmed)errs.push('STAGING_TARGET_NOT_CONFIRMED');
 if(c.production_target_forbidden!==true)errs.push('PRODUCTION_GUARD_MISSING');
 if(c.hard_limits?.fixtures!==1||c.hard_limits?.duration_ms!==600000||c.hard_limits?.provider_attempts!==40)errs.push('HARD_LIMITS_MISMATCH');
 if(!c.pilot_id||!c.owner_id)errs.push('PILOT_OWNER_REQUIRED');
 const sha=crypto.createHash('sha256').update(fs.readFileSync(new URL('../prediction_v2/probability-engine.js',import.meta.url))).digest('hex');
 if(sha!==MODEL)errs.push('MODEL_LOCK_HASH_MISMATCH');
 return {valid:!errs.length,reasons:errs,model_sha256:sha,limits:BATCH05A_SMOKE_LIMITS,target:c.bridge_base_url};
}
const pf=assertConfig();if(cmd==='preflight'){process.stdout.write(JSON.stringify({...pf,network_calls:0,deployed:false},null,2));process.exit(pf.valid?0:2)}if(!pf.valid)throw new Error(`PREFLIGHT_FAILED:${pf.reasons.join(',')}`);
const token=process.env[c.bridge_token_env||'BATCH05A3_BRIDGE_TOKEN'];if(!token)throw new Error('BRIDGE_TOKEN_MISSING');
const client=createNodeHttpD1BridgeA3({baseUrl:c.bridge_base_url,token,pilotId:c.pilot_id,ownerId:c.owner_id});
if(cmd==='export'){const value=await client.exportEvidence();process.stdout.write(JSON.stringify({...value,exported_at:new Date().toISOString(),transport:'HTTPS_STAGING_BRIDGE'},null,2));}
else if(cmd==='stop'){process.stdout.write(JSON.stringify(await client.requestStop(),null,2));}
else if(cmd==='run'){if(process.env.FE_APPROVE_REMOTE_SMOKE!=='YES')throw new Error('REMOTE_SMOKE_NOT_APPROVED');const apiKey=process.env[c.api_key_env||'APISPORTS_KEY'];if(!apiKey)throw new Error('APISPORTS_KEY_MISSING');const clock={now:()=>Date.now(),sleep:ms=>new Promise(r=>setTimeout(r,ms))};const out=await runBatch05aSmoke({env:{APISPORTS_KEY:apiKey},fetchImpl:fetch,captureSink:client.captureSink,persistLockedBundle:client.persistLockedBundle,clock,store:client.budgetStore,sessionStore:client.sessionStore,loadPersistedCaptures:client.loadPersistedCaptures,loadObservation:client.loadObservation,owner:client.owner,pilotId:c.pilot_id,maxTicks:Math.min(8,Number(c.max_ticks||8)),ackMode:'REMOTE',networkReal:true,transportLabel:'REAL_API_FOOTBALL_NODE_TO_STAGING_HTTP_D1'});process.stdout.write(JSON.stringify(out,null,2));}
else throw new Error('UNKNOWN_COMMAND');
