/* Batch04.1 — executable pilot budget/pacing controller.
 * Every HTTP attempt, including /status, discovery, live/context endpoints and retries,
 * must acquire a token here. State is persisted BEFORE request start.
 * Restart without state fails closed; restart with unresolved in-flight requests also fails closed.
 */
const num=v=>v===null||v===undefined||v===''?null:(Number.isFinite(Number(v))?Number(v):null);
const clone=v=>JSON.parse(JSON.stringify(v));
const sysClock={now:()=>Date.now(),sleep:ms=>new Promise(r=>setTimeout(r,ms))};
export const DEFAULT_PILOT_LIMITS=Object.freeze({
  max_requests_total:3000,
  max_requests_per_minute:30,
  provider_minute_fraction:.50,
  max_concurrency:4,
  request_start_gap_ms:250,
  duration_ms:90*60*1000,
  daily_reserve_min:10000,
  daily_reserve_fraction:.20,
  minute_safety_remaining:2,
  repeated_429_stop:2
});

export class MemoryBudgetStateStore{
  constructor(seed=null){this.value=seed?clone(seed):null}
  async load(){return this.value?clone(this.value):null}
  async save(v){this.value=clone(v)}
}
export function createD1BudgetStateStore(db,pilotId){
  if(!db)throw new Error('B4_BUDGET_DB_REQUIRED');
  return {
    async load(){const r=await db.prepare('SELECT state_json FROM b4_pilot_budget_state WHERE pilot_id=?').bind(pilotId).first();return r?.state_json?JSON.parse(r.state_json):null},
    async save(v){await db.prepare(`INSERT INTO b4_pilot_budget_state(pilot_id,state_json,updated_at) VALUES(?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(pilot_id) DO UPDATE SET state_json=excluded.state_json,updated_at=CURRENT_TIMESTAMP`).bind(pilotId,JSON.stringify(v)).run()}
  };
}
function initialState(pilotId,now,limits){return {
  schema:'FE_PV2_PILOT_BUDGET_STATE_V2',pilot_id:pilotId,started_at_ms:now,last_request_start_ms:null,request_starts_ms:[],total_requests:0,in_flight:0,stop_reason:null,
  daily_verified:false,daily_limit:null,daily_remaining:null,minute_verified:false,minute_limit:null,minute_remaining:null,consecutive_429:0,limits:{...limits}
}}
export class PilotBudgetController{
  constructor({pilotId,store,clock=sysClock,limits={},allowNewPilot=false}={}){
    if(!pilotId)throw new Error('B4_PILOT_ID_REQUIRED');
    if(!store)throw new Error('B4_BUDGET_STATE_STORE_REQUIRED');
    this.pilotId=pilotId;this.store=store;this.clock=clock;this.limits={...DEFAULT_PILOT_LIMITS,...limits};this.allowNewPilot=allowNewPilot;
    this.state=null;this.initialized=false;this._initPromise=null;this._mutex=Promise.resolve();
  }
  async _withLock(fn){const run=this._mutex.then(fn,fn);this._mutex=run.then(()=>undefined,()=>undefined);return run}
  async init(){
    if(this.initialized)return this;
    if(this._initPromise){await this._initPromise;return this}
    this._initPromise=(async()=>{
      const loaded=await this.store.load();
      if(loaded){
        if(String(loaded.pilot_id)!==String(this.pilotId))throw new Error('B4_BUDGET_PILOT_ID_MISMATCH');
        this.state=loaded;this.state.limits={...this.limits,...(loaded.limits||{})};this.limits={...this.state.limits};
        // A process restart cannot know whether previously in-flight HTTP attempts completed.
        // Fail closed rather than silently freeing those slots and double-spending budget.
        if(Number(this.state.in_flight||0)>0&&!this.state.stop_reason){this.state.stop_reason='RESTART_WITH_INFLIGHT_REQUESTS';await this.store.save(this.state)}
      }else{
        if(!this.allowNewPilot)throw new Error('B4_BUDGET_STATE_MISSING_FAIL_CLOSED');
        this.state=initialState(this.pilotId,this.clock.now(),this.limits);await this.store.save(this.state);
      }
      this.initialized=true;
    })();
    try{await this._initPromise}finally{this._initPromise=null}
    return this;
  }
  snapshot(){if(!this.state)throw new Error('B4_BUDGET_NOT_INITIALIZED');return clone(this.state)}
  async persist(){await this.store.save(this.state)}
  _dailyReserve(){const l=num(this.state.daily_limit),min=Number(this.limits.daily_reserve_min)||0,frac=Number(this.limits.daily_reserve_fraction)||0;return l==null?min:Math.max(min,Math.ceil(l*frac))}
  _rollingCap(){
    const configured=Math.max(1,Number(this.limits.max_requests_per_minute)||1),provider=num(this.state.minute_limit);
    if(provider==null)return configured;
    const frac=Math.max(0.01,Math.min(1,Number(this.limits.provider_minute_fraction)||.5));
    return Math.max(1,Math.min(configured,Math.floor(provider*frac)));
  }
  async _haltLocked(reason){if(!this.state.stop_reason)this.state.stop_reason=String(reason||'STOPPED');await this.persist();return clone(this.state)}
  async halt(reason){await this.init();return this._withLock(()=>this._haltLocked(reason))}
  async updateProviderQuota({dailyLimit=null,dailyRemaining=null,minuteLimit=null,minuteRemaining=null}={}){
    await this.init();return this._withLock(async()=>{
      if(num(dailyLimit)!=null&&num(dailyRemaining)!=null){this.state.daily_verified=true;this.state.daily_limit=num(dailyLimit);this.state.daily_remaining=num(dailyRemaining)}
      if(num(minuteLimit)!=null&&num(minuteRemaining)!=null){this.state.minute_verified=true;this.state.minute_limit=num(minuteLimit);this.state.minute_remaining=num(minuteRemaining)}
      await this.persist();return clone(this.state);
    });
  }
  async acquire({kind='DATA'}={}){
    await this.init();
    for(;;){
      const decision=await this._withLock(async()=>{
        const now=this.clock.now();
        const stop=async reason=>{await this._haltLocked(reason);return {error:`B4_PILOT_STOPPED:${reason}`}};
        if(this.state.stop_reason)return {error:`B4_PILOT_STOPPED:${this.state.stop_reason}`};
        if(now-this.state.started_at_ms>=Number(this.limits.duration_ms))return stop('DURATION_CAP');
        if(this.state.total_requests>=Number(this.limits.max_requests_total))return stop('TOTAL_REQUEST_CAP');
        if(String(kind)!=='STATUS'&&!this.state.minute_verified)return stop('MINUTE_QUOTA_UNVERIFIED');
        if(String(kind)!=='STATUS'&&!this.state.daily_verified)return stop('DAILY_QUOTA_UNVERIFIED');
        if(this.state.daily_verified&&num(this.state.daily_remaining)!=null&&this.state.daily_remaining<=this._dailyReserve())return stop('DAILY_RESERVE_GUARD');
        if(this.state.minute_verified&&num(this.state.minute_remaining)!=null&&this.state.minute_remaining<=Number(this.limits.minute_safety_remaining))return stop('MINUTE_REMAINING_GUARD');
        this.state.request_starts_ms=(this.state.request_starts_ms||[]).filter(t=>now-Number(t)<60000);
        const cap=this._rollingCap();
        if(this.state.request_starts_ms.length>=cap){const wait=Math.max(1,60000-(now-Number(this.state.request_starts_ms[0])));return {wait}}
        if(Number(this.state.in_flight||0)>=Number(this.limits.max_concurrency))return {wait:Math.max(1,Number(this.limits.request_start_gap_ms)||1)};
        const last=num(this.state.last_request_start_ms),gap=Math.max(0,Number(this.limits.request_start_gap_ms)||0);
        if(last!=null&&now-last<gap)return {wait:gap-(now-last)};
        const start=this.clock.now();
        this.state.total_requests+=1;this.state.in_flight=Number(this.state.in_flight||0)+1;this.state.last_request_start_ms=start;this.state.request_starts_ms.push(start);
        if(this.state.minute_remaining!=null)this.state.minute_remaining=Math.max(0,this.state.minute_remaining-1);
        if(this.state.daily_remaining!=null)this.state.daily_remaining=Math.max(0,this.state.daily_remaining-1);
        await this.persist();
        return {token:{pilot_id:this.pilotId,request_number:this.state.total_requests,started_at_ms:start,kind}};
      });
      if(decision.token)return decision.token;
      if(decision.error)throw new Error(decision.error);
      await this.clock.sleep(Math.max(1,Number(decision.wait)||1));
    }
  }
  async release(token,{status=null,headers=null,persistenceOk=true}={}){
    await this.init();return this._withLock(async()=>{
      this.state.in_flight=Math.max(0,Number(this.state.in_flight||0)-1);
      const get=k=>headers?.get?.(k)??headers?.[k]??headers?.[String(k).toLowerCase()]??null,
        dl=num(get('x-ratelimit-requests-limit')),dr=num(get('x-ratelimit-requests-remaining')),ml=num(get('x-ratelimit-limit')),mr=num(get('x-ratelimit-remaining'));
      if(dl!=null&&dr!=null){this.state.daily_verified=true;this.state.daily_limit=dl;this.state.daily_remaining=dr}
      if(ml!=null&&mr!=null){this.state.minute_verified=true;this.state.minute_limit=ml;this.state.minute_remaining=mr}
      if(Number(status)===429)this.state.consecutive_429=Number(this.state.consecutive_429||0)+1;else if(status!=null)this.state.consecutive_429=0;
      if(!persistenceOk&&!this.state.stop_reason)this.state.stop_reason='PERSISTENCE_FAILURE';
      if(this.state.consecutive_429>=Number(this.limits.repeated_429_stop)&&!this.state.stop_reason)this.state.stop_reason='REPEATED_HTTP_429';
      if(this.state.daily_verified&&num(this.state.daily_remaining)!=null&&this.state.daily_remaining<=this._dailyReserve()&&!this.state.stop_reason)this.state.stop_reason='DAILY_RESERVE_GUARD';
      if(this.state.minute_verified&&num(this.state.minute_remaining)!=null&&this.state.minute_remaining<=Number(this.limits.minute_safety_remaining)&&!this.state.stop_reason)this.state.stop_reason='MINUTE_REMAINING_GUARD';
      await this.persist();return clone(this.state);
    });
  }
}
