/* Batch04.1 staging-only collector core. No automatic schedule/deploy.
 * All HTTP attempts — /status, discovery, live, context and retries — MUST pass
 * through PilotBudgetController. No approved pilot => no network calls.
 */
import {buildCapturedPayload} from '../prediction_v2/capture-contract.js';
const BASE='https://v3.football.api-sports.io';
const LIVE=new Set(['1H','HT','2H','ET','BT','INT','LIVE','P']);
const num=v=>v===null||v===undefined||v===''?null:(Number.isFinite(Number(v))?Number(v):null);
const isoAt=ms=>new Date(ms).toISOString();
function quotaHeaders(h){return {daily_limit:num(h?.get?.('x-ratelimit-requests-limit')),daily_remaining:num(h?.get?.('x-ratelimit-requests-remaining')),minute_limit:num(h?.get?.('x-ratelimit-limit')),minute_remaining:num(h?.get?.('x-ratelimit-remaining'))}}
export async function persistCaptureD1(db,r){if(!db)throw new Error('STAGING_DB_REQUIRED');await db.prepare(`INSERT INTO b4_capture_payloads(record_id,request_id,source_id,provider,endpoint,fixture_id,market_period,received_at,provider_updated_at,payload_hash,capture_status,payload_json,metadata_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(record_id) DO NOTHING`).bind(r.record_id,r.request_id,r.source_id,r.provider,r.endpoint,r.fixture_id,r.market_period,r.received_at,r.provider_updated_at,r.payload_hash,r.capture_status,JSON.stringify(r.payload??null),JSON.stringify(r.metadata??null)).run();const row=await db.prepare('SELECT record_id,payload_hash FROM b4_capture_payloads WHERE record_id=?').bind(r.record_id).first();if(!row||row.payload_hash!==r.payload_hash)throw new Error('B4_CAPTURE_DURABLE_READBACK_MISMATCH');return r}
function headersOf(res){return res?.headers??null}
function responseOk(status){return Number(status)>=200&&Number(status)<300}
export async function providerGet({env,db,captureSink=null,budget,endpoint,params={},fixtureId=null,period=null,metadata=null,fetchImpl=fetch,retries=0}={}){
  if(!env?.APISPORTS_KEY)throw new Error('APISPORTS_KEY_MISSING');if(!budget)throw new Error('B4_BUDGET_CONTROLLER_REQUIRED');await budget.init();let lastRecord=null,lastError=null;
  for(let attempt=0;attempt<=Math.max(0,Number(retries)||0);attempt++){
    const token=await budget.acquire({kind:endpoint==='/status'?'STATUS':'DATA'}),started=isoAt(token.started_at_ms),url=`${BASE}${endpoint}?${new URLSearchParams(params)}`;let res,text,payload,error=null,status=null,headers=null,persisted=true;
    try{res=await fetchImpl(url,{headers:{'x-apisports-key':env.APISPORTS_KEY,accept:'application/json'}});status=res.status;headers=headersOf(res);text=await res.text();try{payload=JSON.parse(text)}catch{payload=null;error=new Error('INVALID_JSON')}}catch(e){error=e}
    const received=isoAt(budget.clock?.now?.()??Date.now()),qh=quotaHeaders(headers),record=await buildCapturedPayload({provider:'API_FOOTBALL',source:'BATCH041_STAGING_COLLECTOR',endpoint,params,fixtureId,period,requestStartedAt:started,receivedAt:received,httpStatus:status,fetchError:error,payload,rawText:text,
      metadata:{...(metadata||{}),attempt,quota:qh}});lastRecord=record;
    try{if(db)await persistCaptureD1(db,record);else if(typeof captureSink==='function')await captureSink(record)}catch(e){persisted=false;lastError=e}
    await budget.release(token,{status,headers,persistenceOk:persisted});
    if(!persisted)throw lastError;
    if(!error&&responseOk(status))return record;
    lastError=error||new Error(`API_HTTP_${status}`);
    if(attempt>=Math.max(0,Number(retries)||0))break;
    const snap=budget.snapshot();if(snap.stop_reason)break;await budget.clock.sleep(Math.max(1000,Number(budget.limits?.request_start_gap_ms)||250));
  }
  if(lastRecord)return lastRecord;throw lastError||new Error('B4_PROVIDER_REQUEST_FAILED');
}
export async function fetchProviderQuota({env,db=null,captureSink=null,budget,fetchImpl=fetch}={}){
  const r=await providerGet({env,db,captureSink,budget,endpoint:'/status',params:{},metadata:{role:'PROVIDER_STATUS'},fetchImpl,retries:0}),body=Array.isArray(r?.payload?.response)?r.payload.response[0]:r?.payload?.response,
    current=num(body?.requests?.current),limit_day=num(body?.requests?.limit_day),remaining=current!=null&&limit_day!=null?Math.max(0,limit_day-current):null,plan=body?.subscription?.plan??null,q=r?.metadata?.quota||{};
  if(current!=null&&limit_day!=null)await budget.updateProviderQuota({dailyLimit:limit_day,dailyRemaining:remaining,minuteLimit:q.minute_limit,minuteRemaining:q.minute_remaining});
  const snap=budget.snapshot();
  if(snap.stop_reason)return {verified:false,record:r,reason:snap.stop_reason,budget:snap};
  if(r.capture_status!=='OK'||current==null||limit_day==null)return {verified:false,record:r,reason:'PROVIDER_DAILY_QUOTA_UNVERIFIED',budget:snap};
  if(!snap.minute_verified)return {verified:false,record:r,reason:'PROVIDER_MINUTE_QUOTA_UNVERIFIED',budget:snap};
  return {verified:true,current,limit_day,remaining,plan,minute_limit:snap.minute_limit,minute_remaining:snap.minute_remaining,record:r,budget:snap};
}
function liveFixtures(record){return (record?.payload?.response||[]).filter(f=>LIVE.has(String(f?.fixture?.status?.short||'').toUpperCase())&&Number.isFinite(Number(f?.fixture?.id))).sort((a,b)=>Number(a.fixture.id)-Number(b.fixture.id))}
export async function capturePilotTick({env,db,captureSink=null,budget,fetchImpl=fetch,maxFixtures=8}={}){
  if(!budget)throw new Error('B4_BUDGET_CONTROLLER_REQUIRED');const quota=await fetchProviderQuota({env,db,captureSink,budget,fetchImpl});if(!quota.verified){await budget.halt(quota.reason);return {status:'STOP',reason:quota.reason,records:[quota.record],budget:budget.snapshot()}}
  const records=[quota.record],discovery=await providerGet({env,db,captureSink,budget,endpoint:'/fixtures',params:{live:'all'},metadata:{role:'LIVE_UNIVERSE_DISCOVERY'},fetchImpl,retries:1});records.push(discovery);const fixtures=liveFixtures(discovery).slice(0,Math.max(0,Number(maxFixtures)||0));
  try{for(const f of fixtures){const fid=Number(f.fixture.id);for(const spec of [['/fixtures/statistics',{fixture:fid},'LIVE_STATS'],['/fixtures/events',{fixture:fid},'EVENTS'],['/odds/live',{fixture:fid},'LIVE_MARKET']])records.push(await providerGet({env,db,captureSink,budget,endpoint:spec[0],params:spec[1],fixtureId:fid,metadata:{role:spec[2],identity:{fixture_id:fid}},fetchImpl,retries:1}))}}
  catch(e){return {status:'STOP',reason:budget.snapshot().stop_reason||String(e?.message||e),quota,fixtures:fixtures.map(x=>x.fixture.id),records,budget:budget.snapshot()}}
  return {status:'OK',quota,fixtures:fixtures.map(x=>x.fixture.id),records,selection_policy:'FIXTURE_ID_ASC_NOT_OLD_RANK',budget:budget.snapshot()};
}
export async function captureSlowContext({env,db,captureSink=null,budget,fixture,fetchImpl=fetch,maxRequests=20}={}){
  if(!budget)throw new Error('B4_BUDGET_CONTROLLER_REQUIRED');await budget.init();const snap=budget.snapshot();if(!snap.minute_verified||!snap.daily_verified)return {status:'STOP',reason:!snap.minute_verified?'MINUTE_QUOTA_UNVERIFIED':'DAILY_QUOTA_UNVERIFIED',records:[]};
  const f=fixture,league=f?.league?.id,season=f?.league?.season,home=f?.teams?.home?.id,away=f?.teams?.away?.id,fid=f?.fixture?.id;if(![league,season,home,away,fid].every(x=>x!=null))return {status:'SKIP',reason:'CONTEXT_KEYS_MISSING',records:[]};
  const specs=[['/fixtures/lineups',{fixture:fid},'LINEUPS',null],['/fixtures/players',{fixture:fid},'FIXTURE_PLAYERS',null],['/injuries',{fixture:fid},'INJURIES',null],['/predictions',{fixture:fid},'PREDICTIONS',null],['/standings',{league,season},'STANDINGS',null],
    ['/teams/statistics',{league,season,team:home},'HOME_TEAM_STATS',home],['/teams/statistics',{league,season,team:away},'AWAY_TEAM_STATS',away],['/fixtures',{team:home,last:8},'HOME_RECENT',home],['/fixtures',{team:away,last:8},'AWAY_RECENT',away],
    ['/players',{team:home,season,page:1},'HOME_SEASON_PLAYERS',home],['/players',{team:away,season,page:1},'AWAY_SEASON_PLAYERS',away]];
  const records=[];try{for(const [endpoint,params,role,teamId] of specs.slice(0,maxRequests))records.push(await providerGet({env,db,captureSink,budget,endpoint,params,fixtureId:fid,metadata:{role,identity:{fixture_id:fid,league_id:league,season,team_id:teamId}},fetchImpl,retries:1}))}catch(e){return {status:'STOP',reason:budget.snapshot().stop_reason||String(e?.message||e),records,budget:budget.snapshot()}}
  return {status:'OK',records,budget:budget.snapshot()};
}

// Batch05A.1 pinned-scope tick. Discovery remains a provider-universe observation;
// detailed enrichment is restricted to the immutable selected fixture.
export async function capturePinnedSmokeTick({env,db,captureSink=null,budget,fetchImpl=fetch,pinnedFixtureId=null}={}){
  if(!budget)throw new Error('B4_BUDGET_CONTROLLER_REQUIRED');
  const quota=await fetchProviderQuota({env,db,captureSink,budget,fetchImpl});
  if(!quota.verified){await budget.halt(quota.reason);return {status:'STOP',reason:quota.reason,records:[quota.record],pinned_fixture_id:pinnedFixtureId,budget:budget.snapshot()}}
  const records=[quota.record];
  let discovery;
  try{discovery=await providerGet({env,db,captureSink,budget,endpoint:'/fixtures',params:{live:'all'},metadata:{role:'LIVE_UNIVERSE_DISCOVERY'},fetchImpl,retries:0});records.push(discovery)}
  catch(e){return {status:'STOP',reason:budget.snapshot().stop_reason||String(e?.message||e),records,pinned_fixture_id:pinnedFixtureId,budget:budget.snapshot()}}
  const live=liveFixtures(discovery),ids=live.map(x=>Number(x.fixture.id));
  const selected=pinnedFixtureId==null?(ids[0]??null):Number(pinnedFixtureId);
  if(selected==null){await budget.halt('NO_LIVE_FIXTURE_TO_PIN');return {status:'STOP',reason:'NO_LIVE_FIXTURE_TO_PIN',records,pinned_fixture_id:null,discovery_fixture_ids:ids,budget:budget.snapshot()}}
  if(pinnedFixtureId!=null&&!ids.includes(selected)){await budget.halt('PINNED_FIXTURE_DISAPPEARED_OR_ENDED');return {status:'STOP',reason:'PINNED_FIXTURE_DISAPPEARED_OR_ENDED',records,pinned_fixture_id:selected,discovery_fixture_ids:ids,budget:budget.snapshot()}}
  const fixture=live.find(x=>Number(x.fixture.id)===selected);
  try{
    for(const spec of [['/fixtures/statistics',{fixture:selected},'LIVE_STATS'],['/fixtures/events',{fixture:selected},'EVENTS'],['/odds/live',{fixture:selected},'LIVE_MARKET']]){
      records.push(await providerGet({env,db,captureSink,budget,endpoint:spec[0],params:spec[1],fixtureId:selected,metadata:{role:spec[2],identity:{fixture_id:selected},smoke_scope:'PINNED_FIXTURE_ONLY'},fetchImpl,retries:0}));
    }
  }catch(e){return {status:'STOP',reason:budget.snapshot().stop_reason||String(e?.message||e),records,pinned_fixture_id:selected,fixture,budget:budget.snapshot()}}
  return {status:'OK',records,pinned_fixture_id:selected,fixture,discovery_fixture_ids:ids,selection_policy:pinnedFixtureId==null?'PIN_FIRST_DISCOVERY_ONCE':'KEEP_EXISTING_PIN',scope_claim:'DISCOVERY_UNIVERSE_SEPARATE_FROM_SINGLE_FIXTURE_ENRICHMENT',budget:budget.snapshot()};
}
