-- Apply exactly once ONLY to an existing dedicated staging database already at A3.
-- For a fresh staging DB, use batch05a3-staging-schema.sql instead.
ALTER TABLE b4_capture_payloads ADD COLUMN capture_json TEXT;
ALTER TABLE b4_capture_payloads ADD COLUMN capture_envelope_hash TEXT;
