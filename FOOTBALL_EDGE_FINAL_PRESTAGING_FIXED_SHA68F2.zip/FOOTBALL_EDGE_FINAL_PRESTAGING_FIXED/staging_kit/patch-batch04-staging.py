#!/usr/bin/env python3
from pathlib import Path
import hashlib,re,sys
EXPECTED='a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844'
p=Path(sys.argv[1] if len(sys.argv)>1 else 'index.html')
b=p.read_bytes();sha=hashlib.sha256(b).hexdigest()
if sha!=EXPECTED: raise SystemExit(f'Refuse patch: expected exact P2.0.5.2 {EXPECTED}, got {sha}')
s=b.decode('utf-8');marker='FE BATCH04.1 STAGING CAPTURE KIT 2026-10-07'
if marker in s: raise SystemExit('Already patched')
# Export exact function references from INSIDE the original P2.0.5.2 closure.
m=re.search(r'(<script[^>]*>)([\s\S]*?)(</script>)',s)
if not m or 'function watchEvaluate' not in m.group(2): raise SystemExit('P2052 main runtime script not found')
body=m.group(2);close=body.rfind('})();')
if close<0: raise SystemExit('P2052 runtime closure end not found')
export_js="""
  // FE BATCH04.1 EXACT OLD EXPORT — references only; no scoring code copied/reimplemented.
  window.FE_B4_P2052_EXACT_EXPORT={
    compactFixtureMeta,autoModeForFixture,statMap,eventsCompact,oddsCompact,
    watchSnapshotFromBundle,watchEvaluate,watchApplyState,
    watchNewResetEvent:(typeof watchNewResetEvent==='function'?watchNewResetEvent:null),
    h1WatchSnapshotFromBundle,h1WatchEvaluate,h1WatchApplyState,
    h1WatchNewResetEvent:(typeof h1WatchNewResetEvent==='function'?h1WatchNewResetEvent:null),
    handicapAggregate,hcMarketFromRows,hcMarketHistory,hcEvaluate,feMasterRankMeta
  };
"""
body=body[:close]+export_js+body[close:]
s=s[:m.start(2)]+body+s[m.end(2):]
insert=f'''\n<!-- {marker} -->\n<script src="/staging_kit/batch04-old-exact-runtime-bridge.js"></script>\n'''
if '</body>' not in s: raise SystemExit('body marker missing')
s=s.replace('</body>',insert+'</body>',1)
p.write_text(s,encoding='utf-8')
print('patched_sha256',hashlib.sha256(s.encode()).hexdigest())
