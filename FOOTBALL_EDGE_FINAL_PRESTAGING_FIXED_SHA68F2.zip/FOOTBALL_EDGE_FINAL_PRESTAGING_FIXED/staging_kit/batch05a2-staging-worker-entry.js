/* Staging-only Worker entrypoint for Batch05A.2 bridge. Prepared, NOT deployed. */
import base from '../worker_notify_v138_provider_quota75k.js';
import {handleBatch05a2Bridge} from './batch05a2-http-d1-bridge.js';
export {BackgroundWatcher} from '../worker_notify_v138_provider_quota75k.js';
export default {...base,async fetch(request,env,ctx){const u=new URL(request.url);if(u.pathname.startsWith('/__fe_batch05a2/'))return handleBatch05a2Bridge(request,env);return base.fetch(request,env,ctx)}};
