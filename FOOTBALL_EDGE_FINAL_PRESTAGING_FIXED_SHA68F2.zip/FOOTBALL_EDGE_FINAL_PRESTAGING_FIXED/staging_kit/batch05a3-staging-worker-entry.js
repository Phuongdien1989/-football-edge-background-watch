/* Batch05A.3 STAGING-ONLY Worker entry. Prepared, not deployed. */
import {handleBatch05a3Bridge} from './batch05a3-http-d1-bridge.js';
export default {async fetch(request,env){const r=await handleBatch05a3Bridge(request,env);return r??new Response('Not Found',{status:404})}};
