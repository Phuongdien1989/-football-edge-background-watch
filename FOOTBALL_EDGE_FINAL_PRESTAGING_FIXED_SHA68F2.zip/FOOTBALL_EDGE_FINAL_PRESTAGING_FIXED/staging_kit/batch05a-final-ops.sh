#!/usr/bin/env bash
set -euo pipefail
# PREPARED ONLY. Do not execute deploy/run until explicit staging-smoke approval.
CFG="${CFG:-staging_kit/batch05a-final-staging-config.json}"
WRANGLER="${WRANGLER:-staging_kit/wrangler.batch05a-final.toml}"
case "${1:-}" in
  preflight) node staging_kit/batch05a-final-remote-cli.mjs preflight "$CFG" ;;
  db-init) test "${FE_APPROVE_REMOTE_SMOKE:-}" = YES; npx wrangler d1 execute football-edge-b05a-staging --remote --config "$WRANGLER" --file staging_kit/batch05a3-staging-schema.sql ;;
  deploy) test "${FE_APPROVE_REMOTE_SMOKE:-}" = YES; npx wrangler deploy --config "$WRANGLER" ;;
  run) test "${FE_APPROVE_REMOTE_SMOKE:-}" = YES; node staging_kit/batch05a-final-remote-cli.mjs run "$CFG" ;;
  stop) node staging_kit/batch05a-final-remote-cli.mjs stop "$CFG" ;;
  export) node staging_kit/batch05a-final-remote-cli.mjs export "$CFG" ;;
  rollback) test -n "${STAGING_PREVIOUS_VERSION_ID:-}"; npx wrangler rollback "$STAGING_PREVIOUS_VERSION_ID" --config "$WRANGLER" ;;
  *) echo "usage: $0 {preflight|db-init|deploy|run|stop|export|rollback}" >&2; exit 2;;
esac
