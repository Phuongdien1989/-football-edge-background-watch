-- Batch04.1 staging-only evidence schema. DO NOT apply to production without separate approval.
CREATE TABLE IF NOT EXISTS b4_capture_payloads(
  record_id TEXT PRIMARY KEY, request_id TEXT, source_id TEXT, provider TEXT, endpoint TEXT,
  fixture_id INTEGER, market_period TEXT, received_at TEXT, provider_updated_at TEXT,
  payload_hash TEXT NOT NULL, capture_status TEXT NOT NULL, payload_json TEXT, metadata_json TEXT,
  persisted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_b4_capture_fx_time ON b4_capture_payloads(fixture_id,received_at);
CREATE TABLE IF NOT EXISTS b4_old_exact_outputs(
  record_id TEXT PRIMARY KEY, observation_id TEXT, fixture_id INTEGER, engine TEXT, cutoff TEXT,
  baseline_sha256 TEXT NOT NULL, record_fingerprint TEXT NOT NULL, payload_json TEXT NOT NULL,
  persisted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS b4_locked_predictions(
  observation_id TEXT PRIMARY KEY, fixture_id INTEGER, engine TEXT, market_period TEXT, evaluation_cutoff TEXT,
  content_fingerprint TEXT NOT NULL, bundle_fingerprint TEXT NOT NULL,
  observation_json TEXT NOT NULL, paper_json TEXT, old_exact_record_id TEXT,
  persisted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS b4_outcome_revisions(
  observation_id TEXT NOT NULL, revision INTEGER NOT NULL, outcome_received_at TEXT,
  outcome_fingerprint TEXT NOT NULL, outcome_json TEXT NOT NULL, persisted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(observation_id,revision)
);
CREATE TABLE IF NOT EXISTS b4_pilot_budget_state(
  pilot_id TEXT PRIMARY KEY, state_json TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
-- Batch05A.2 staging-only durable session ownership/state. One active owner lease per pilot.
CREATE TABLE IF NOT EXISTS b5_smoke_sessions(
  pilot_id TEXT PRIMARY KEY, state_json TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS b5_smoke_session_owner(
  pilot_id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, lease_until_ms INTEGER NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
