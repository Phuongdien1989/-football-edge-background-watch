# FOOTBALL EDGE Batch04.1 Staging Kit

## Status
**NOT DEPLOYED. NOT RUN. NO LIVE API CALLS IN BATCH04.1.**

Batch04.1 hardens the capture kit before any pilot is allowed.

## Components
- `batch041-budget-controller.js` — executable total/minute/gap/concurrency/duration/daily-reserve controller. All HTTP attempts including `/status`, retries and context requests must acquire a token. State is persisted before request start; restart without state fails closed.
- `batch04-collector-worker.js` — independent live universe collector. Requires the budget controller; no automatic schedule.
- `batch04-staging-schema.sql` — additive staging tables, including `b4_pilot_budget_state`.
- `batch04-server-persistence.js` — validates observation/paper/OLD immutable content before write and after readback; SERVER ACK only after matching readback. Not remotely verified.
- `batch04-old-exact-runtime-bridge.js` — calls exact P2.0.5.2 function references exported from inside the exact guarded runtime closure.
- `patch-batch04-staging.py` — refuses any input other than exact P2.0.5.2 SHA and injects only exact-reference export + staging bridge.
- `pilot-plan.json` — limits mirrored by executable controller.
- `ENV.example` — non-secret example.

## Mandatory preflight for a future approved pilot
1. Exact frontend input SHA must be `a82bf87e1db875fb975b94ac9b6df9e785818de37b7bb55fec6f290efca9c844`.
2. Use a dedicated staging service/database only.
3. Apply `batch04-staging-schema.sql` to staging only.
4. Bind API key as a staging secret.
5. Create a `PILOT_ID` and initialize `PilotBudgetController` with persistent D1 state. After restart, load that state; never create a fresh budget silently.
6. `/status` is the only request permitted before minute quota is proven. Daily quota from the status body and minute limit/remaining from provider headers must both be verified. Otherwise STOP.
7. Start independent `/fixtures?live=all` capture. OLD rank/eligibility is never used for fixture selection.
8. All discovery/live/context/retry requests go through the same controller.
9. Persist raw payload history and market snapshots with `received_at` before building OLD/NEW observations.
10. On the exact staging page, the patch exports exact P2.0.5.2 function references from inside its closure; `FE_B4_OLD_EXACT` calls those references. If export/function/hash guard fails, STOP.
11. Validate and persist the immutable observation/paper/OLD bundle before accepting outcome data.

## Stop
Set `CAPTURE_ENABLED=false`, stop invocation/schedule, preserve staging DB/artifacts read-only. Controller stop reasons are durable state and must not be cleared to resume the same pilot.

## Rollback
Batch04.1 does not touch production. Rollback means disable/delete only the staging service/schedule and retain/export staging evidence for audit. Frozen production remains exact P2.0.5.2.
