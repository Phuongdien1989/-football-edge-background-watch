
(() => {
  'use strict';
  const TZ='Asia/Ho_Chi_Minh';
  const APP_VERSION='1.16.2';
  const API_TIMEOUT_MS=15000;
  const $=id=>document.getElementById(id);
  const state={fixtures:[],selected:null,mode:'PRE',scan:'live',scanLabel:'LIVE',scanPurpose:'single',fixtureFilter:'all',fixtureSearch:'',fixtureFilterOpen:false,lastBundle:null,lastPacket:'',lastPacketKind:'single',scanning:false,
    scanProgress:{active:false,label:'',stage:'',done:0,total:0,pct:0,detail:'',startedAt:0},
    singleAnalyzer:{running:false,last:null}};
  const els={provider:$('footballProvider'),fkey:$('footballKey'),projectUrl:$('projectUrl'),fbase:$('footballBase'),remember:$('rememberKeys'),conn:$('connStatus'),scanStatus:$('scanStatus'),matches:$('matches'),selected:$('selectedMatch'),coverage:$('coverage'),result:$('result'),packetBox:$('packetBox'),packetText:$('packetText'),packetMeta:$('packetMeta'),log:$('log'),overlay:$('overlay'),loadingTitle:$('loadingTitle'),loadingText:$('loadingText'),groupPanel:$('groupScanPanel'),groupCount:$('groupCount'),groupProgress:$('groupProgress'),
    bgEnabled:$('backgroundEnabled'),bgUrl:$('backgroundWorkerUrl'),bgToken:$('backgroundWorkerToken'),bgStatus:$('backgroundStatus'),
    storageHealthValue:$('storageHealthValue'),storageHealthBar:$('storageHealthBar'),storageHealthNote:$('storageHealthNote'),
    scanLiveProgress:$('scanLiveProgress'),scanProgressTitle:$('scanProgressTitle'),scanProgressPercent:$('scanProgressPercent'),scanProgressBar:$('scanProgressBar'),scanProgressDetail:$('scanProgressDetail'),
    fixtureListSummaryCount:$('fixtureListSummaryCount'),fixtureFilterToggle:$('fixtureFilterToggle'),toggleFixtureFilterBtn:$('toggleFixtureFilterBtn'),fixtureFilterToggleMeta:$('fixtureFilterToggleMeta'),fixtureFilterBar:$('fixtureFilterBar'),fixtureFilterTabs:$('fixtureFilterTabs'),fixtureFilterSearch:$('fixtureFilterSearch'),fixtureFilterSummary:$('fixtureFilterSummary'),
    smaResult:$('singleAnalyzerResult'),smaAutoMode:$('smaAutoMode')};

  function log(msg,obj){const t=new Date().toLocaleTimeString('vi-VN');let line=`[${t}] ${msg}`;if(obj!==undefined){try{line+=' '+JSON.stringify(obj)}catch{line+=' '+String(obj)}}els.log.value=(line+'\n'+els.log.value).slice(0,22000)}
  function status(el,msg,type=''){el.className='status'+(type?' '+type:'');el.textContent=msg}
  function loading(show,title='Đang xử lý...',text='Đang tải dữ liệu.'){els.overlay.classList.toggle('show',show);els.loadingTitle.textContent=title;els.loadingText.textContent=text}
  function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
  function clamp(n,a=0,b=100){return Math.max(a,Math.min(b,Number(n)||0))}
  function fmtDateInTZ(date){const p=new Intl.DateTimeFormat('en-CA',{timeZone:TZ,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date);const o=Object.fromEntries(p.map(x=>[x.type,x.value]));return `${o.year}-${o.month}-${o.day}`}
  function fmtTime(ts){return new Intl.DateTimeFormat('vi-VN',{timeZone:TZ,hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(ts*1000))}
  function fmtDateTime(ts){return new Intl.DateTimeFormat('vi-VN',{timeZone:TZ,day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(ts*1000))}
  function currentHM(){const p=new Intl.DateTimeFormat('en-GB',{timeZone:TZ,hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date());const o=Object.fromEntries(p.map(x=>[x.type,x.value]));return `${o.hour}:${o.minute}`}
  function setDefaultTimes(){const now=new Date();$('fromTime').value=currentHM();const later=new Date(now.getTime()+2*3600000);const p=new Intl.DateTimeFormat('en-GB',{timeZone:TZ,hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(later);const o=Object.fromEntries(p.map(x=>[x.type,x.value]));$('toTime').value=`${o.hour}:${o.minute}`}

  function loadConfig(){
    let session={},saved={};try{session=JSON.parse(sessionStorage.getItem('fe_cfg_v11')||'{}')}catch{session={}}try{saved=JSON.parse(localStorage.getItem('fe_cfg_v11')||'{}')}catch{saved={}}
    const c=Object.keys(saved).length?saved:session;
    if(c.provider)els.provider.value=c.provider;if(c.fkey)els.fkey.value=c.fkey;if(c.projectUrl)els.projectUrl.value=c.projectUrl;if(c.fbase)els.fbase.value=c.fbase;els.remember.checked=!!c.remember;
    if(els.bgEnabled)els.bgEnabled.checked=!!c.backgroundEnabled;
    if(els.bgUrl&&c.backgroundWorkerUrl)els.bgUrl.value=c.backgroundWorkerUrl;
    if(els.bgToken&&c.backgroundWorkerToken)els.bgToken.value=c.backgroundWorkerToken;
    updateProviderBase(false)
  }
  function saveConfig(silent=false){const c={provider:els.provider.value,fkey:els.fkey.value.trim(),projectUrl:els.projectUrl.value.trim(),fbase:els.fbase.value.trim(),remember:els.remember.checked,
      backgroundEnabled:!!els.bgEnabled?.checked,backgroundWorkerUrl:els.bgUrl?.value?.trim()||'',backgroundWorkerToken:els.bgToken?.value?.trim()||''};
    sessionStorage.setItem('fe_cfg_v11',JSON.stringify(c));if(c.remember)localStorage.setItem('fe_cfg_v11',JSON.stringify(c));else localStorage.removeItem('fe_cfg_v11');if(!silent)status(els.conn,'Đã lưu cấu hình trên thiết bị.','ok')}
  function updateProviderBase(force=true){if(!force && els.fbase.value.trim())return;if(els.provider.value==='rapid')els.fbase.value='https://api-football-v1.p.rapidapi.com/v3';else els.fbase.value='https://v3.football.api-sports.io'}
  els.provider.addEventListener('change',()=>updateProviderBase(true));$('saveBtn').addEventListener('click',()=>saveConfig(false));

  function footballHeaders(){
    const key=els.fkey.value.trim();if(!key)throw new Error('Chưa nhập Football API Key.');
    if(els.provider.value==='rapid')return {'x-rapidapi-key':key,'x-rapidapi-host':'api-football-v1.p.rapidapi.com','Accept':'application/json'};
    return {'x-apisports-key':key,'Accept':'application/json'}
  }
  const API_CACHE_NS='fe_api_cache_v15_';
  const API_CACHE_INDEX='fe_api_cache_index_v15';
  const API_USAGE_KEY='fe_api_usage_v15';
  const API_CACHE_RUNTIME=new Map();
  const CACHE_TTL={
    standings:60*60*1000,
    team_stats:6*60*60*1000,
    injuries:4*60*60*1000,
    recent:20*60*1000,
    h2h:6*60*60*1000,
    prediction:60*60*1000,
    prematch_odds:5*60*1000,
    lineups:2*60*1000,
    league_coverage:24*60*60*1000,
    bet_reference:24*60*60*1000,
    reference:24*60*60*1000
  };
  const LIVE_ODDS_HISTORY_NS='fe_live_odds_history_v154_';
  const LIVE_ODDS_HISTORY_INDEX='fe_live_odds_history_index_v154';
  const LIVE_ODDS_HISTORY_MAX_SNAPSHOTS=30;
  const LIVE_ODDS_HISTORY_MAX_AGE=12*60*60*1000;
  function stableParamString(params={}){return Object.keys(params).sort().map(k=>`${k}=${String(params[k])}`).join('&')}
  function tinyHash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(36)}
  function cacheKey(path,params={}){return API_CACHE_NS+tinyHash(`${els.provider.value}|${els.fbase.value}|${path}?${stableParamString(params)}`)}
  function cacheRuntimeStatus(path,params={}){return API_CACHE_RUNTIME.get(cacheKey(path,params))||null}
  function cacheRuntimeSummary(entries={}){const out={};for(const [label,spec] of Object.entries(entries)){const x=cacheRuntimeStatus(spec[0],spec[1]);if(x)out[label]=x}return out}
  function cacheIndexRead(){try{return JSON.parse(localStorage.getItem(API_CACHE_INDEX)||'[]')}catch{return []}}
  function cacheIndexWrite(x){try{localStorage.setItem(API_CACHE_INDEX,JSON.stringify(x.slice(-90)))}catch{}}
  function cacheGetEntry(path,params={}){
    try{const k=cacheKey(path,params),raw=localStorage.getItem(k);if(!raw)return null;const e=JSON.parse(raw);return {...e,_key:k}}catch{return null}
  }
  function cacheGetFresh(path,params={},ttl=0){const e=cacheGetEntry(path,params);if(!e)return null;const maxAge=ttl||e.ttl||0;return Date.now()-e.ts<=maxAge?e.data:null}
  function cachePeek(path,params={}){const e=cacheGetEntry(path,params);return e?.data??null}
  function cachePut(path,params,data,ttl){
    if(data==null)return;const k=cacheKey(path,params);try{
      localStorage.setItem(k,JSON.stringify({ts:Date.now(),ttl,data,path,params}));
      let idx=cacheIndexRead().filter(x=>x.k!==k);idx.push({k,ts:Date.now()});
      if(idx.length>90){const drop=idx.splice(0,idx.length-90);drop.forEach(x=>{try{localStorage.removeItem(x.k)}catch{}})}
      cacheIndexWrite(idx);
    }catch(e){
      log('Cache write skipped',e.message);
      if(/quota/i.test(String(e?.message||'')))setTimeout(()=>storageCleanupTransient({toast:false}),0)
    }
  }
  function apiUsageSnapshot(){
    const day=new Date().toISOString().slice(0,10);try{const x=JSON.parse(localStorage.getItem(API_USAGE_KEY)||'{}');if(x.day!==day)return {day,network_calls:0,remaining_header:null,limit_header:null,minute_remaining_header:null,minute_limit_header:null};return x}catch{return {day,network_calls:0,remaining_header:null,limit_header:null,minute_remaining_header:null,minute_limit_header:null}}
  }
  function recordApiNetwork(headers){
    const day=new Date().toISOString().slice(0,10),x=apiUsageSnapshot();x.day=day;x.network_calls=(x.network_calls||0)+1;
    try{
      const rem=headers?.get?.('x-ratelimit-requests-remaining');
      const lim=headers?.get?.('x-ratelimit-requests-limit');
      const minRem=headers?.get?.('x-ratelimit-remaining')||headers?.get?.('X-RateLimit-Remaining');
      const minLim=headers?.get?.('x-ratelimit-limit')||headers?.get?.('X-RateLimit-Limit');
      if(rem!=null)x.remaining_header=Number(rem);if(lim!=null)x.limit_header=Number(lim);
      if(minRem!=null)x.minute_remaining_header=Number(minRem);if(minLim!=null)x.minute_limit_header=Number(minLim);
    }catch{}
    try{localStorage.setItem(API_USAGE_KEY,JSON.stringify(x))}catch{}
  }
  function footballApiErrors(errors){
    if(errors==null)return [];
    if(Array.isArray(errors))return errors.filter(v=>v!=null&&String(v).trim()!=='').map(v=>String(v));
    if(typeof errors==='object')return Object.entries(errors).filter(([,v])=>v!=null&&String(v).trim()!=='').map(([k,v])=>`${k}: ${typeof v==='string'?v:JSON.stringify(v)}`);
    return String(errors).trim()?[String(errors)]:[]
  }
  function footballQuotaLabel(){
    const u=apiUsageSnapshot(),p=[];
    if(Number.isFinite(Number(u.limit_header))&&Number.isFinite(Number(u.remaining_header)))p.push(`ngày còn ${Number(u.remaining_header)}/${Number(u.limit_header)}`);
    if(Number.isFinite(Number(u.minute_limit_header))&&Number.isFinite(Number(u.minute_remaining_header)))p.push(`phút còn ${Number(u.minute_remaining_header)}/${Number(u.minute_limit_header)}`);
    return p.join(' • ')
  }
  async function football(path,params={},optional=false){
    const base=els.fbase.value.trim().replace(/\/$/,'');const u=new URL(base+path);Object.entries(params).forEach(([k,v])=>{if(v!==undefined&&v!==null&&v!=='')u.searchParams.set(k,String(v))});
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),API_TIMEOUT_MS);
    try{const r=await fetch(u,{headers:footballHeaders(),signal:controller.signal});recordApiNetwork(r.headers);const txt=await r.text();let data;try{data=JSON.parse(txt)}catch{throw new Error(`Football API trả dữ liệu không phải JSON (HTTP ${r.status})`)}
      if(!r.ok)throw new Error(`Football API HTTP ${r.status}: ${JSON.stringify(data.errors||data).slice(0,220)}`);
      const apiErrors=footballApiErrors(data?.errors);
      if(apiErrors.length){
        const quota=footballQuotaLabel();
        const err=new Error(`Football API từ chối: ${apiErrors.join(' | ').slice(0,320)}${quota?` • ${quota}`:''}`);
        err.api_errors=data.errors;err.http_status=r.status;throw err
      }
      return data.response??[];
    }catch(e){const err=e?.name==='AbortError'?new Error(`Football API quá thời gian chờ ${Math.round(API_TIMEOUT_MS/1000)} giây`):e;log(`Lỗi ${path}: ${err.message}`);if(optional)return null;throw err}finally{clearTimeout(timeout)}
  }
  const API_INFLIGHT=new Map();
  async function footballCached(path,params={},ttl=60000,optional=true){
    const k=cacheKey(path,params),entry=cacheGetEntry(path,params),maxAge=ttl||entry?.ttl||0,ageMs=entry?Math.max(0,Date.now()-Number(entry.ts||0)):null;
    if(entry&&ageMs<=maxAge){API_CACHE_RUNTIME.set(k,{status:'CACHE_FRESH',age_sec:Math.round(ageMs/1000)});return entry.data}
    const stale=entry?.data??null;if(API_INFLIGHT.has(k))return API_INFLIGHT.get(k);
    const task=(async()=>{try{const data=await football(path,params,false);API_CACHE_RUNTIME.set(k,{status:'NETWORK',age_sec:0});if(!(Array.isArray(data)&&data.length===0&&path==='/fixtures/lineups'))cachePut(path,params,data,ttl);return data}catch(e){if(stale!==null){const meta={status:'CACHE_STALE',age_sec:Math.round((ageMs||0)/1000),error:e.message};API_CACHE_RUNTIME.set(k,meta);log('Dùng cache stale do API lỗi',{path,...meta});return stale}API_CACHE_RUNTIME.set(k,{status:'ERROR',age_sec:null,error:e.message});if(optional)return null;throw e}finally{API_INFLIGHT.delete(k)}})();
    API_INFLIGHT.set(k,task);return task;
  }


  /* ===== V1.18.2 PERSISTENT BACKGROUND WATCH ADAPTER =====
     Foreground app registers fixtures with a Cloudflare Durable Object Worker.
     The server continues collecting score/stats/events/odds while iOS suspends
     this PWA. When the app becomes visible again it syncs missed snapshots into
     local watch histories and market history.

     This adapter DOES NOT change any RUNG / CORE / threshold formula. */
  const BG_REGISTRY_KEY='FE_BACKGROUND_REGISTRY_V1182';
  const BG_SYNC_KEY='FE_BACKGROUND_SYNC_V1182';
  const BG_DB_NAME='FOOTBALL_EDGE_BACKGROUND_SYNC_V1';
  const BG_DB_STORE='snapshots';
  const BG_MAX_REGISTER=300;
  const BG_STATE={dbp:null,syncing:false,lastSyncAt:0,lastHealth:null};

  function bgEnabled(){return !!els.bgEnabled?.checked&&!!els.bgUrl?.value?.trim()}
  function bgBase(){return String(els.bgUrl?.value||'').trim().replace(/\/$/,'')}
  function bgHeaders(){
    const h={'Content-Type':'application/json','Accept':'application/json'},tok=String(els.bgToken?.value||'').trim();
    if(tok)h['Authorization']='Bearer '+tok;
    return h
  }
  function bgRegistryRead(){try{const x=JSON.parse(localStorage.getItem(BG_REGISTRY_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return []}}
  function bgRegistryWrite(rows){try{localStorage.setItem(BG_REGISTRY_KEY,JSON.stringify((rows||[]).slice(-BG_MAX_REGISTER)))}catch{}}
  function bgSyncStateRead(){try{return JSON.parse(localStorage.getItem(BG_SYNC_KEY)||'{}')||{}}catch{return {}}}
  function bgSyncStateWrite(x){try{localStorage.setItem(BG_SYNC_KEY,JSON.stringify(x||{}))}catch{}}
  function bgFixturePayload(f,level='screen',engine='SCAN'){
    return {
      fixture_id:Number(f?.fixture?.id||f?.id),
      level,engine,
      home:f?.teams?.home?.name||f?.home||null,
      away:f?.teams?.away?.name||f?.away||null,
      league:f?.league?.name||f?.league||null,
      country:f?.league?.country||null,
      kickoff:Number(f?.fixture?.timestamp||0)||null,
      status:f?.fixture?.status?.short||f?.status||null,
      minute:Number(f?.fixture?.status?.elapsed??f?.minute??0)||0
    }
  }
  async function bgRequest(path,{method='GET',body=null,timeout=12000}={}){
    if(!bgBase())throw new Error('Chưa nhập Background Worker URL.');
    const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),timeout);
    try{
      const r=await fetch(bgBase()+path,{method,headers:bgHeaders(),body:body==null?undefined:JSON.stringify(body),signal:ctl.signal});
      const txt=await r.text();let data={};try{data=txt?JSON.parse(txt):{}}catch{data={raw:txt}}
      if(!r.ok)throw new Error(data?.error||data?.message||`Background Worker HTTP ${r.status}`);
      return data
    }catch(e){
      if(e?.name==='AbortError')throw new Error('Background Worker quá thời gian chờ.');
      throw e
    }finally{clearTimeout(timer)}
  }
  function bgMergeRegistry(fixtures,level,engine){
    let rows=bgRegistryRead(),map=new Map(rows.map(x=>[String(x.fixture_id),x])),now=Date.now();
    for(const f of fixtures||[]){
      const p=bgFixturePayload(f,level,engine);if(!Number.isFinite(p.fixture_id))continue;
      const old=map.get(String(p.fixture_id))||{};
      map.set(String(p.fixture_id),{...old,...p,level:(old.level==='focus'||level==='focus')?'focus':'screen',registered_at:old.registered_at||now,last_registered_at:now})
    }
    rows=[...map.values()].sort((a,b)=>Number(a.kickoff||0)-Number(b.kickoff||0)).slice(-BG_MAX_REGISTER);bgRegistryWrite(rows);return rows
  }
  async function bgRegisterFixtures(fixtures,level='screen',engine='SCAN',silent=true){
    if(!bgEnabled()||!Array.isArray(fixtures)||!fixtures.length)return {skipped:true};
    const payload=(fixtures||[]).slice(0,BG_MAX_REGISTER).map(f=>bgFixturePayload(f,level,engine)).filter(x=>Number.isFinite(x.fixture_id));
    if(!payload.length)return {skipped:true};
    bgMergeRegistry(fixtures,level,engine);
    try{
      const data=await bgRequest('/api/watch/register',{method:'POST',body:{fixtures:payload,level,engine,ttl_minutes:360}});
      BG_STATE.lastHealth=data;
      if(els.bgStatus)status(els.bgStatus,`Background ON • đăng ký ${data.registered??payload.length} fixture • ${data.active??'-'} active`,'ok');
      if(!silent)showToast('ok','BACKGROUND WATCH',`Đã giao ${payload.length} fixture cho Cloudflare theo dõi nền.`);
      return data
    }catch(e){
      if(els.bgStatus)status(els.bgStatus,'Background lỗi: '+e.message,'err');
      log('Background register error',e.message);
      if(!silent)showToast('err','BACKGROUND WATCH',e.message);
      return {error:e.message}
    }
  }
  async function bgRegisterItems(items,mode='FT'){
    if(!bgEnabled()||!items?.length)return;
    /* V1.19.4: H1/FT/HC no longer bulk-register every workspace item.
       Smart Follow schedules a focused subset after Master Board ranking. */
    if(['H1','FT','HC'].includes(String(mode))&&typeof feSmartFollowSchedule==='function'){feSmartFollowSchedule('ENGINE_START_'+mode);return {smart_follow:true}}
    const fixtures=(items||[]).map(it=>{
      const f=(state.fixtures||[]).find(x=>Number(x?.fixture?.id)===Number(it.id));
      return f||{id:it.id,home:it.home,away:it.away,league:it.league,status:it.latest?.status,minute:it.latest?.minute}
    });
    return bgRegisterFixtures(fixtures,'focus',mode,true)
  }

  /* V1.18.7: terminal cleanup for persistent background registry.
     Removing an ended fixture does not delete local watch history / validation. */
  async function bgUnregisterFixtureIds(ids,silent=true){
    const clean=[...new Set((ids||[]).map(Number).filter(Number.isFinite))];
    if(!clean.length)return {skipped:true};
    const drop=new Set(clean.map(String));
    bgRegistryWrite(bgRegistryRead().filter(x=>!drop.has(String(x.fixture_id))));
    const sync=bgSyncStateRead();for(const id of clean)delete sync[String(id)];bgSyncStateWrite(sync);
    if(!bgEnabled())return {ok:true,local_only:true,removed:clean.length};
    try{
      const data=await bgRequest('/api/watch/unregister',{method:'POST',body:{fixture_ids:clean}});
      if(!silent)showToast('ok','BACKGROUND CLEANUP',`Đã gỡ ${clean.length} fixture terminal khỏi theo dõi nền.`);
      return data;
    }catch(e){
      log('Background unregister error',{ids:clean,error:e.message});
      if(!silent)showToast('err','BACKGROUND CLEANUP',e.message);
      return {error:e.message};
    }
  }

  function bgIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(BG_STATE.dbp)return BG_STATE.dbp;
    BG_STATE.dbp=new Promise(resolve=>{
      try{
        const r=indexedDB.open(BG_DB_NAME,1);
        r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains(BG_DB_STORE)){const st=db.createObjectStore(BG_DB_STORE,{keyPath:'id'});st.createIndex('fixture_id','fixture_id',{unique:false});st.createIndex('captured_at','captured_at',{unique:false})}};
        r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null)
      }catch{resolve(null)}
    });return BG_STATE.dbp
  }
  async function bgLocalPut(snap){
    try{const db=await bgIDBOpen();if(!db)return;await new Promise(resolve=>{const tx=db.transaction(BG_DB_STORE,'readwrite');tx.objectStore(BG_DB_STORE).put({...snap,id:snap.id||`${snap.fixture_id}:${snap.captured_at}`});tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()})}catch{}
  }
  function bgAppendHistory(key,rows,maxRows,cutoffMs){
    try{
      const old=JSON.parse(localStorage.getItem(key)||'[]'),map=new Map();
      for(const x of [...(Array.isArray(old)?old:[]),...(rows||[])])if(Number(x?.captured_at))map.set(String(x.captured_at),x);
      const cutoff=Date.now()-cutoffMs,merged=[...map.values()].filter(x=>Number(x.captured_at)>=cutoff).sort((a,b)=>Number(a.captured_at)-Number(b.captured_at)).slice(-maxRows);
      localStorage.setItem(key,JSON.stringify(merged));return merged.length
    }catch{return 0}
  }
  function bgSnapshotMarkets(snap,f){
    if(!Array.isArray(snap?.odds_raw)||!snap.odds_raw.length)return [];
    try{return oddsCompact(snap.odds_raw,true,{homeName:f?.teams?.home?.name,awayName:f?.teams?.away?.name})||[]}catch{return []}
  }
  function bgToWatchSnapshot(snap,mode='FT'){
    const f=snap?.fixture;if(!f?.fixture?.id)return null;
    const meta=compactFixtureMeta(f,autoModeForFixture(f)),rawMap=statMap(snap.stats_raw||[]),
          metrics=watchAggregate(rawMap,meta),presence=watchStatsPresence(rawMap,meta),markets=bgSnapshotMarkets(snap,f),
          marketHistory=markets.length?saveLiveOddsSnapshot(f.fixture.id,{fixture:f.fixture,goals:f.goals},markets):null,
          market=mode==='H1'?h1WatchMarketInfo(markets,marketHistory):watchMarketInfo(markets,marketHistory);
    return {
      captured_at:Number(snap.captured_at||Date.now()),minute:Number(f.fixture?.status?.elapsed||0),status:f.fixture?.status?.short||'',
      goals:{home:Number(f.goals?.home||0),away:Number(f.goals?.away||0)},metrics,stats_presence:presence,
      data_health:watchDataHealth(presence,null),market,market_rows:markets,dq:0,integrity:null,
      events:eventsCompact(snap.events_raw||[]).slice(-40),fresh_at:Number(snap.captured_at||Date.now()),
      fixture:f,source:'BACKGROUND_WORKER'
    }
  }
  async function bgIngestSnapshots(snaps){
    let ft=0,h1=0,stored=0;
    for(const snap of snaps||[]){
      if(!snap?.fixture_id||!snap?.captured_at)continue;
      await bgLocalPut(snap);stored++;
      if(!snap.stats_raw?.length)continue;
      const minute=Number(snap?.fixture?.fixture?.status?.elapsed||0),status=snap?.fixture?.fixture?.status?.short||'';
      if(['1H','HT'].includes(status)||minute<=45){
        const s=bgToWatchSnapshot(snap,'H1');if(s){bgAppendHistory(H1_WATCH_HISTORY_PREFIX+snap.fixture_id,[s],90,28*60*1000);h1++}
      }else if(minute>=44){
        const s=bgToWatchSnapshot(snap,'FT');if(s){bgAppendHistory(WATCH_HISTORY_PREFIX+snap.fixture_id,[s],80,30*60*1000);ft++}
      }
    }
    return {stored,ft,h1}
  }
  async function bgSyncBatch(entries,maxPerFixture=12){
    if(!entries.length)return {snapshots:[]};
    const sync=bgSyncStateRead(),since={};for(const e of entries)since[String(e.fixture_id)]=Number(sync[String(e.fixture_id)]||0);
    const data=await bgRequest('/api/watch/sync',{method:'POST',body:{fixture_ids:entries.map(x=>Number(x.fixture_id)),since_by_fixture:since,max_snapshots_per_fixture:maxPerFixture}});
    const snaps=Array.isArray(data.snapshots)?data.snapshots:[];
    for(const s of snaps)sync[String(s.fixture_id)]=Math.max(Number(sync[String(s.fixture_id)]||0),Number(s.captured_at||0));
    bgSyncStateWrite(sync);
    return {snapshots:snaps,server:data}
  }
  async function bgSyncNow({silent=false}={}){
    if(!bgEnabled()||BG_STATE.syncing)return {skipped:true};
    BG_STATE.syncing=true;
    try{
      const remote=await bgRequest('/api/watch/list'),remoteRows=Array.isArray(remote.watches)?remote.watches:[],
            local=bgRegistryRead(),map=new Map(local.map(x=>[String(x.fixture_id),x]));
      for(const r of remoteRows){const old=map.get(String(r.fixture_id))||{};map.set(String(r.fixture_id),{...old,...r})}
      const terminalIds=remoteRows.filter(x=>x.ended).map(x=>Number(x.fixture_id)).filter(Number.isFinite),
            rows=[...map.values()].filter(x=>!x.ended),focus=rows.filter(x=>x.level==='focus').slice(0,40),
            screen=rows.filter(x=>x.level!=='focus').slice(0,120);
      bgRegistryWrite(rows);
      if(terminalIds.length)bgUnregisterFixtureIds(terminalIds,true).catch(()=>{});
      const a=await bgSyncBatch(focus,24),b=await bgSyncBatch(screen,8),snaps=[...(a.snapshots||[]),...(b.snapshots||[])],
            ing=await bgIngestSnapshots(snaps);
      BG_STATE.lastSyncAt=Date.now();
      if(els.bgStatus)status(els.bgStatus,`Background SYNC • ${snaps.length} snapshot • FT ${ing.ft} • H1 ${ing.h1} • server active ${remote.active??'-'}`,'ok');
      if(!silent)showToast('ok','BACKGROUND SYNC',`Nhận ${snaps.length} snapshot bị bỏ lỡ • FT ${ing.ft} • H1 ${ing.h1}.`);
      return {remote,snaps,ing}
    }catch(e){
      if(els.bgStatus)status(els.bgStatus,'Background sync lỗi: '+e.message,'err');
      log('Background sync error',e.message);
      if(!silent)showToast('err','BACKGROUND SYNC',e.message);
      return {error:e.message}
    }finally{BG_STATE.syncing=false}
  }
  async function bgTestConnection(){
    if(!els.bgEnabled?.checked){status(els.bgStatus,'Background Watch đang tắt.','err');return}
    if(!String(els.bgUrl?.value||'').trim()){status(els.bgStatus,'Chưa có Worker URL — cần deploy Cloudflare Background Worker trước.','err');return}
    if(!String(els.bgToken?.value||'').trim()){status(els.bgStatus,'Chưa có Background Token — nhập đúng token đã tạo trên Cloudflare.','err');return}
    saveConfig(true);status(els.bgStatus,'Đang kiểm tra Background Worker...','busy');
    try{
      const h=await bgRequest('/health'),l=await bgRequest('/api/watch/list');
      status(els.bgStatus,`Background Worker OK • ${l.active??0} active • alarm ${l.next_alarm?new Date(l.next_alarm).toLocaleTimeString('vi-VN'):'idle'}`,'ok');
      showToast('ok','BACKGROUND WORKER OK',`Active ${l.active??0} fixture.`);
    }catch(e){status(els.bgStatus,'Background Worker lỗi: '+e.message,'err');showToast('err','BACKGROUND WORKER',e.message)}
  }
  function bgAutoSyncOnVisible(){
    if(!bgEnabled())return;
    if(document.visibilityState==='visible'&&Date.now()-Number(BG_STATE.lastSyncAt||0)>15000)bgSyncNow({silent:true})
  }


  /* ===== V1.23.2 EVIDENCE DATABASE PERSISTENCE — D1 LONG-TERM STORAGE =====
     Additive persistence only. D1 is accessed through the existing authenticated
     Cloudflare Worker. IndexedDB is an offline outbox; local engines remain the
     source of runtime continuity when D1 is unavailable. No core/ranking mutation. */
  const FE_DB_OUTBOX_NAME='FOOTBALL_EDGE_DB_OUTBOX_V1',FE_DB_OUTBOX_STORE='events',FE_DB_SYNC_STORE='sync_state',FE_DB_MAX_BATCH=60;
  const FE_DB_STATE={dbp:null,syncing:false,lastHealth:null,lastStats:null,lastSyncAt:0,timer:null,smartQueued:0,lastSmartByKey:new Map(),syncFp:new Map(),evidenceQueueing:false,queueRevision:0,evidenceWriteChain:Promise.resolve(),validationPending:new Map(),validationDrain:null,validationSchedule:false};
  function feDbConfigured(){return !!bgBase()&&!!String(els.bgToken?.value||'').trim()}
  function feDbOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);if(FE_DB_STATE.dbp)return FE_DB_STATE.dbp;
    FE_DB_STATE.dbp=new Promise(resolve=>{try{const r=indexedDB.open(FE_DB_OUTBOX_NAME,2);r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains(FE_DB_OUTBOX_STORE)){const st=db.createObjectStore(FE_DB_OUTBOX_STORE,{keyPath:'id'});st.createIndex('created_at','created_at',{unique:false});st.createIndex('type','type',{unique:false})}if(!db.objectStoreNames.contains(FE_DB_SYNC_STORE)){const st=db.createObjectStore(FE_DB_SYNC_STORE,{keyPath:'id'});st.createIndex('synced_at','synced_at',{unique:false})}};r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null)}catch{resolve(null)}});return FE_DB_STATE.dbp
  }
  async function feDbOutboxPut(evt){
    const record=JSON.parse(JSON.stringify(evt));record.queue_revision=`${Date.now()}:${++FE_DB_STATE.queueRevision}:${Math.random().toString(36).slice(2)}`;
    try{const db=await feDbOpen();if(!db)return false;return await new Promise(resolve=>{
      const tx=db.transaction(FE_DB_OUTBOX_STORE,'readwrite');tx.objectStore(FE_DB_OUTBOX_STORE).put(record);
      tx.oncomplete=()=>resolve(true);tx.onerror=tx.onabort=()=>resolve(false)
    })}catch{return false}
  }
  async function feDbOutboxGet(id){
    const db=await feDbOpen();if(!db)return null;
    return new Promise((resolve,reject)=>{const tx=db.transaction(FE_DB_OUTBOX_STORE,'readonly'),r=tx.objectStore(FE_DB_OUTBOX_STORE).get(id);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>reject(r.error)})
  }
  async function feDbOutboxCount(){try{const db=await feDbOpen();if(!db)return 0;return await new Promise(resolve=>{const tx=db.transaction(FE_DB_OUTBOX_STORE,'readonly'),r=tx.objectStore(FE_DB_OUTBOX_STORE).count();r.onsuccess=()=>resolve(Number(r.result||0));r.onerror=()=>resolve(0)})}catch{return 0}}
  async function feDbOutboxList(limit=FE_DB_MAX_BATCH){try{const db=await feDbOpen();if(!db)return [];return await new Promise(resolve=>{const tx=db.transaction(FE_DB_OUTBOX_STORE,'readonly'),st=tx.objectStore(FE_DB_OUTBOX_STORE),idx=st.index('created_at'),rows=[],r=idx.openCursor();r.onsuccess=e=>{const c=e.target.result;if(c&&rows.length<limit){rows.push(c.value);c.continue()}else resolve(rows)};r.onerror=()=>resolve([])})}catch{return []}}
  async function feDbOutboxDelete(sentRows){
    if(!sentRows?.length)return;
    const db=await feDbOpen();if(!db)throw new Error('D1 outbox unavailable');
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(FE_DB_OUTBOX_STORE,'readwrite'),st=tx.objectStore(FE_DB_OUTBOX_STORE);
      for(const sent of sentRows){const req=st.get(sent.id);req.onsuccess=()=>{
        const current=req.result;
        if(current&&(sent.queue_revision?current.queue_revision===sent.queue_revision:JSON.stringify(current)===JSON.stringify(sent)))st.delete(sent.id);
      }}
      tx.oncomplete=()=>resolve();tx.onerror=tx.onabort=()=>reject(tx.error||new Error('D1 outbox acknowledgement failed'));
    });
  }
  async function feDbSyncStateGet(id){
    if(FE_DB_STATE.syncFp.has(id))return FE_DB_STATE.syncFp.get(id);try{const db=await feDbOpen();if(!db)return null;const row=await new Promise(resolve=>{const tx=db.transaction(FE_DB_SYNC_STORE,'readonly'),r=tx.objectStore(FE_DB_SYNC_STORE).get(id);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>resolve(null)});const fp=row?.fingerprint??null;FE_DB_STATE.syncFp.set(id,fp);return fp}catch{return null}
  }
  async function feDbSyncStateMark(events){
    const rows=(events||[]).filter(x=>x?.sync_key&&x?.fingerprint);if(!rows.length)return;try{const db=await feDbOpen();if(!db)return;await new Promise(resolve=>{const tx=db.transaction(FE_DB_SYNC_STORE,'readwrite'),st=tx.objectStore(FE_DB_SYNC_STORE);for(const x of rows){const rec={id:x.sync_key,fingerprint:x.fingerprint,synced_at:Date.now(),type:x.type};st.put(rec);FE_DB_STATE.syncFp.set(x.sync_key,x.fingerprint)}tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()})}catch{}
  }
  function feDbEvidenceFingerprint(r,kind){
    if(kind==='QSIG')return JSON.stringify([r?.wave_open??null,r?.release_reason??null,r?.closed_at??null,r?.resolved??null,r?.resolved_at??null,r?.goal_3m??null,r?.goal_5m??null,r?.goal_10m??null,r?.goal_15m??null,r?.goal_ft??null,r?.first_goal_min??null,r?.goal_before_ht??null,r?.state_5m??null,r?.state_10m??null,r?.state_15m??null,r?.direction_15m??null,r?.void_reason??null,r?.goal_event??null,r?.goal_for_direction??null,r?.goal_delta??null,r?.peak_level??null]);
    return JSON.stringify([r?.resolution??null,r?.outcome??null,r?.hit??null,r?.resolved_at??null,r?.profit??null,r?.profit_unit??null,r?.unit_pl??null,r?.signal_state??null,r?.signal_score??null,r?.line??null,r?.odds??r?.price??null,r?.policy_status??null]);
  }
  async function feDbQueueEvidence(type,payload,syncKey,fingerprint,{schedule=true,force=false}={}){
    if(!payload?.id)return false;
    const snapshot=JSON.parse(JSON.stringify(payload));
    const run=async()=>{
      const id=`${type}:${snapshot.id}`,pending=await feDbOutboxGet(id);
      const old=pending?.fingerprint??await feDbSyncStateGet(syncKey);
      if(!force&&old===fingerprint)return false;
      const ok=await feDbOutboxPut({id,type,created_at:Date.now(),payload:snapshot,sync_key:syncKey,fingerprint});
      if(!ok)throw new Error('Không lưu được hàng đợi D1; dữ liệu chưa được xác nhận đồng bộ.');
      if(schedule)feDbScheduleSync();return true;
    };
    const task=FE_DB_STATE.evidenceWriteChain.then(run);FE_DB_STATE.evidenceWriteChain=task.catch(e=>log('Evidence queue error',e.message));return task;
  }
  async function feDbQueueQsigResult(engine,r,opts={}){
    if(!r?.id)return false;const payload={...r,engine:r.engine||engine};return feDbQueueEvidence('QSIG_RESULT',payload,`QSIG:${engine}:${r.id}`,feDbEvidenceFingerprint(payload,'QSIG'),opts)
  }
  async function feDbQueueValidationResult(r,opts={}){
    if(!r?.id)return false;return feDbQueueEvidence('VALIDATION_RESULT',r,`VAL:${r.id}`,feDbEvidenceFingerprint(r,'VALIDATION'),opts)
  }
  async function feDbQueueValidationBatch(rows,{schedule=true}={}){
    for(const row of rows||[])if(row?.id)FE_DB_STATE.validationPending.set(row.id,JSON.parse(JSON.stringify(row)));
    FE_DB_STATE.validationSchedule=FE_DB_STATE.validationSchedule||schedule;
    if(FE_DB_STATE.validationDrain)return FE_DB_STATE.validationDrain;
    if(!FE_DB_STATE.validationPending.size){FE_DB_STATE.validationSchedule=false;return 0}
    FE_DB_STATE.evidenceQueueing=true;
    FE_DB_STATE.validationDrain=(async()=>{
      let n=0;
      try{
        while(FE_DB_STATE.validationPending.size){
          const [id,row]=FE_DB_STATE.validationPending.entries().next().value;
          if(await feDbQueueValidationResult(row,{schedule:false}))n++;
          if(FE_DB_STATE.validationPending.get(id)===row)FE_DB_STATE.validationPending.delete(id);
        }
        return n;
      }finally{
        if(n&&FE_DB_STATE.validationSchedule)feDbScheduleSync();
        FE_DB_STATE.validationSchedule=false;FE_DB_STATE.evidenceQueueing=false;FE_DB_STATE.validationDrain=null;
      }
    })();return FE_DB_STATE.validationDrain;
  }
  async function feDbQueueEntryDecision(r,{schedule=true}={}){
    if(!r?.id)return false;const evt={id:`ENTRY:${r.id}`,type:'ENTRY_DECISION',created_at:Date.now(),payload:r};const ok=await feDbOutboxPut(evt);if(ok&&schedule)feDbScheduleSync();return ok
  }
  async function feDbQueueLiveSnapshot(r,{schedule=true}={}){
    if(!r?.id)return false;const evt={id:`LIVE:${r.id}`,type:'LIVE_SNAPSHOT',created_at:Date.now(),payload:r};const ok=await feDbOutboxPut(evt);if(ok){FE_DB_STATE.smartQueued++;if(schedule)feDbScheduleSync()}return ok
  }
  function feDbRound(v,d=2){const n=Number(v);if(!Number.isFinite(n))return null;const m=10**d;return Math.round(n*m)/m}
  function feDbLiveRecord(x,engine){
    const it=engine==='H1'?x?.h1:engine==='FT'?x?.ft:x?.hc;if(!it||!x?.__rank?.top)return null;const e=it.eval||{},snap=it.latest||{},d=typeof feMasterDescriptor==='function'?feMasterDescriptor(it,engine):null,p=typeof epPolicyForEngine==='function'?epPolicyForEngine(x,engine):null,c=p?.candidate||null,b=String(p?.behavior?.state||'NEUTRAL'),state=engine==='HC'?String(e.state||'WAIT'):String(it.state||'WAIT'),score=engine==='HC'?Number(e.live_gap??e.states?.gap):Number(e.score),dq=Number(d?.dq??(engine==='HC'?e.dq:e.quality)),line=Number(c?.market?.line??c?.line),price=Number(c?.dec),gh=Number(snap?.goals?.home??0),ga=Number(snap?.goals?.away??0),minute=Number(snap?.minute??0),status=String(snap?.status||snap?.status_short||'LIVE');
    const rec={fixture_id:Number(x.id),league:x.league||'',home:x.home||'',away:x.away||'',kickoff:Number(x.kickoff||0)||null,source:'FOREGROUND_TOP5',engine,snapshot_kind:'ENGINE_DECISION',captured_at:Date.now(),minute:Number.isFinite(minute)?minute:null,status,score_home:Number.isFinite(gh)?gh:null,score_away:Number.isFinite(ga)?ga:null,top_rank:Number(x.__rank.top),signal_state:state,signal_score:Number.isFinite(score)?score:null,dq:Number.isFinite(dq)?dq:null,policy_status:p?.status||null,behavior_state:b,market_type:c?.market?.category||null,selection:c?.selection||null,line:Number.isFinite(line)?line:null,price:Number.isFinite(price)?price:null};
    rec.fingerprint=JSON.stringify([rec.score_home,rec.score_away,rec.signal_state,rec.policy_status,rec.behavior_state,feDbRound(rec.line,2),feDbRound(rec.price,2),rec.top_rank]);
    rec.payload={rank_why:typeof feMasterRankWhy==='function'?feMasterRankWhy(x.__rank):null,signal_state:state,policy_reason:p?.reason||null,market_reason:p?.market?.reason||null,price_zone:c?.zone?.key||null,model_prob:Number.isFinite(Number(c?.modelProb))?Number(c.modelProb):null,break_even:Number.isFinite(Number(c?.breakEven))?Number(c.breakEven):null,edge:Number.isFinite(Number(c?.edge))?Number(c.edge):null,model_ev:Number.isFinite(Number(c?.ev))?Number(c.ev):null};
    return rec
  }
  function feDbSmartReason(prev,cur,now){
    if(!prev)return 'FIRST_TOP';if(cur.score_home!==prev.score_home||cur.score_away!==prev.score_away)return 'SCORE_CHANGE';if(cur.signal_state!==prev.signal_state)return 'SIGNAL_STATE_CHANGE';if(cur.policy_status!==prev.policy_status)return 'POLICY_CHANGE';if(cur.behavior_state!==prev.behavior_state)return 'MARKET_BEHAVIOR_CHANGE';
    const ld=Number(cur.line)-Number(prev.line),pd=Number(cur.price)-Number(prev.price);if((Number.isFinite(ld)&&Math.abs(ld)>=.25)||(Number.isFinite(pd)&&Math.abs(pd)>=.03))return 'MARKET_MOVE';if(cur.top_rank!==prev.top_rank)return 'TOP_RANK_CHANGE';if(now-Number(prev.captured_at||0)>=5*60*1000)return 'PERIODIC_5M';return null
  }
  async function feDbCaptureLiveRows(rows){
    const top=(rows||[]).filter(x=>x?.__rank?.top).slice(0,5),now=Date.now();for(const x of top){for(const engine of ['H1','FT','HC']){const cur=feDbLiveRecord(x,engine);if(!cur)continue;const key=`${cur.fixture_id}:${engine}`,prev=FE_DB_STATE.lastSmartByKey.get(key),reason=feDbSmartReason(prev,cur,now);if(!reason)continue;cur.persistence_reason=reason;cur.id=`LIVE-${cur.fixture_id}-${engine}-${reason}-${Math.floor(now/60000)}`;FE_DB_STATE.lastSmartByKey.set(key,{...cur,captured_at:now});await feDbQueueLiveSnapshot(cur,{schedule:false})}}
    if(FE_DB_STATE.smartQueued)feDbScheduleSync()
  }
  function feDbScheduleSync(){if(!feDbConfigured()||FE_DB_STATE.timer)return;FE_DB_STATE.timer=setTimeout(()=>{FE_DB_STATE.timer=null;feDbSyncOutbox({silent:true,drain:false}).catch(()=>{})},5000)}
  async function feDbSyncOutbox({silent=false,drain=false}={}){
    if(FE_DB_STATE.syncing)return {skipped:true};if(!feDbConfigured()){if(!silent)showToast('err','DATABASE','Cần Worker URL + token trước khi đồng bộ.');return {skipped:true}}
    FE_DB_STATE.syncing=true;let sent=0,batches=0;
    try{
      do{const rows=await feDbOutboxList(FE_DB_MAX_BATCH);if(!rows.length)break;const res=await bgRequest('/api/db/sync',{method:'POST',body:{events:rows},timeout:20000});if(!res?.ok)throw new Error(res?.error||'D1 sync failed');await feDbSyncStateMark(rows);await feDbOutboxDelete(rows);sent+=Number(res.accepted||rows.length);batches++;if(!drain)break}while(batches<50);
      FE_DB_STATE.lastSyncAt=Date.now();await feDbRefreshPanel(false);if(!silent)showToast('ok','DATABASE SYNC',`Đã đồng bộ ${sent} event lên D1.`);return {ok:true,sent,batches}
    }catch(e){log('Database sync error',e.message);await feDbRefreshPanel(false);if(!silent)showToast('err','DATABASE SYNC',e.message);return {ok:false,error:e.message}}
    finally{FE_DB_STATE.syncing=false;if(sent&&await feDbOutboxCount())feDbScheduleSync()}
  }
  async function feDbTest(show=true){
    if(!feDbConfigured()){if(show)status($('databaseStatus'),'Chưa có Worker URL/token. Database chưa thể kết nối.','err');return null}
    try{const h=await bgRequest('/api/db/health',{timeout:15000});FE_DB_STATE.lastHealth=h;let st=null;if(h?.configured&&h?.schema_ready)st=await bgRequest('/api/db/stats',{timeout:15000});FE_DB_STATE.lastStats=st;await feDbRefreshPanel(false);if(show)showToast(h?.schema_ready?'ok':'err','DATABASE',h?.schema_ready?'D1 đã sẵn sàng.':'D1 binding có nhưng schema chưa được khởi tạo.');return {h,st}}
    catch(e){FE_DB_STATE.lastHealth={ok:false,error:e.message};await feDbRefreshPanel(false);if(show)showToast('err','DATABASE',e.message);return null}
  }
  async function feDbMigrateLocalEntries(){
    const rows=typeof evRead==='function'?evRead():[];if(!rows.length){showToast('ok','DATABASE','Không có Entry Validation local để đưa lên D1.');return}
    status($('databaseStatus'),`Đang đưa ${rows.length} Entry record vào hàng đợi...`,'busy');for(const r of rows)await feDbQueueEntryDecision(r,{schedule:false});await feDbRefreshPanel(false);const out=await feDbSyncOutbox({silent:true,drain:true});if(out?.ok)showToast('ok','DATABASE MIGRATION',`Đã đồng bộ ${out.sent} event từ lịch sử local.`);else showToast('err','DATABASE MIGRATION',out?.error||'Chưa đồng bộ được.')
  }
  async function feDbMigrateEvidence(){
    status($('databaseStatus'),'Đang rà QSIG + Validation local và chỉ xếp hàng record mới/thay đổi...','busy');let queued=0;
    for(const engine of ['FT','H1','HC'])for(const r of (typeof qsigRead==='function'?qsigRead(engine):[]))if(await feDbQueueQsigResult(engine,r,{schedule:false}))queued++;
    const vals=(typeof validationState!=='undefined'&&Array.isArray(validationState.rows)?validationState.rows:[]);queued+=await feDbQueueValidationBatch(vals,{schedule:false});await feDbRefreshPanel(false);
    if(!queued){showToast('ok','EVIDENCE DATABASE','Không có QSIG/Validation mới cần đồng bộ.');return}
    const out=await feDbSyncOutbox({silent:true,drain:true});if(out?.ok)showToast('ok','EVIDENCE DATABASE',`Đã xếp ${queued} record mới/thay đổi • gửi ${out.sent} event lên D1.`);else showToast('err','EVIDENCE DATABASE',out?.error||'Chưa đồng bộ được.')
  }
  async function feDbRefreshPanel(fetchRemote=false){
    const q=await feDbOutboxCount(),local=typeof evRead==='function'?evRead().length:0,h=FE_DB_STATE.lastHealth,st=FE_DB_STATE.lastStats;
    if($('databaseLocalEntries'))$('databaseLocalEntries').textContent=String(local);if($('databaseQueueCount'))$('databaseQueueCount').textContent=String(q);if($('databaseRemoteEntries'))$('databaseRemoteEntries').textContent=st?.entry_decisions==null?'—':String(st.entry_decisions);if($('databaseRemoteLive'))$('databaseRemoteLive').textContent=st?.live_snapshots==null?'—':String(st.live_snapshots);if($('databaseRemoteQsig'))$('databaseRemoteQsig').textContent=st?.qsig_results==null?'—':String(st.qsig_results);if($('databaseRemoteValidation'))$('databaseRemoteValidation').textContent=st?.validation_results==null?'—':String(st.validation_results);
    const badge=$('databaseHealthBadge'),mini=$('databaseMiniState');if(badge){badge.className='';if(h?.configured&&h?.schema_ready){badge.textContent='D1 READY';badge.classList.add('ok')}else if(h?.configured&&!h?.schema_ready){badge.textContent='SCHEMA NEEDED';badge.classList.add('warn')}else if(h?.ok===false){badge.textContent='OFFLINE / ERROR';badge.classList.add('bad')}else{badge.textContent='LOCAL ONLY';badge.classList.add('warn')}}if(mini)mini.textContent=h?.configured&&h?.schema_ready?'D1 READY':q?`QUEUE ${q}`:'LOCAL ONLY';
    if($('databaseStatus')){if(h?.configured&&h?.schema_ready)status($('databaseStatus'),`D1 READY • schema ${h.schema_version||'?'} • queue ${q} • Entry ${st?.entry_decisions??'—'} • Live ${st?.live_snapshots??'—'} • QSIG ${st?.qsig_results??'—'} • Validation ${st?.validation_results??'—'}`,'ok');else if(h?.configured)status($('databaseStatus'),'D1 binding đã có nhưng schema chưa sẵn sàng. Chạy schema_v1231.sql rồi kiểm tra lại.','err');else status($('databaseStatus'),q?`Database chưa sẵn sàng • ${q} event đang chờ trong IndexedDB.`:'Database chưa kết nối. App vẫn chạy local bình thường.','')}
    if(fetchRemote&&feDbConfigured())return feDbTest(false)
  }
  async function feDbExportLiveCsv(){
    if(!feDbConfigured()){showToast('err','DATABASE EXPORT','Cần Worker URL + token.');return}try{const url=bgBase()+'/api/db/export/live?format=csv&limit=10000',r=await fetch(url,{headers:{authorization:`Bearer ${String(els.bgToken?.value||'').trim()}`}});if(!r.ok)throw new Error(`HTTP ${r.status}`);const txt=await r.text(),blob=new Blob([txt],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`football_edge_live_${new Date().toISOString().slice(0,10)}.csv`;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500);showToast('ok','DATABASE EXPORT','Đã xuất tối đa 10.000 LIVE snapshot gần nhất.') }catch(e){showToast('err','DATABASE EXPORT',e.message)}
  }
  // FE_D1_EVIDENCE_EXPORT_START — read-only export, no sync or engine mutation.
  let feDbEvidenceExportBusy=false;
  function feDbEvidencePayload(q,v,stats=null){
    if(q?.ok!==true||v?.ok!==true||q.schema!=='QSIG_EXPORT_V1.23.2'||v.schema!=='VALIDATION_EXPORT_V1.23.2'||!Array.isArray(q.rows)||!Array.isArray(v.rows))throw new Error('Worker chưa trả đúng dữ liệu QSIG + Validation. Kiểm tra Worker V1.2.2.');
    const warnings=[],qsig={FT:[],H1:[],HC:[],OTHER:[]};
    function unpack(row,kind){
      let p=row.payload_json;
      try{if(typeof p==='string')p=JSON.parse(p)}catch{p=null}
      if(!p||typeof p!=='object'||Array.isArray(p)){warnings.push(`${kind}: bản ghi ${row.id||'?'} thiếu payload hợp lệ; giữ nguyên dòng D1.`);return {...row}}
      return {...p,id:p.id??row.id,fixture_id:p.fixture_id??row.fixture_id,engine:p.engine??row.engine};
    }
    for(const row of q.rows){const p=unpack(row,'QSIG'),key=String(p.engine||'').toUpperCase();qsig[Object.hasOwn(qsig,key)?key:'OTHER'].push(p)}
    const rows=v.rows.map(row=>unpack(row,'Validation'));
    const total=(key)=>stats?.[key]!=null&&Number.isFinite(Number(stats[key]))?Number(stats[key]):null;
    const qt=total('qsig_results'),vt=total('validation_results');
    const limited=q.rows.length>=10000||v.rows.length>=10000||(qt!=null&&qt>q.rows.length)||(vt!=null&&vt>v.rows.length);
    if(limited)warnings.push('Có thể chưa đủ dữ liệu: Worker xuất tối đa 10.000 bản ghi mới nhất mỗi nhóm.');
    if(qt==null||vt==null)warnings.push('Không lấy được tổng số bản ghi D1 để đối chiếu.');
    return {schema:'FOOTBALL_EDGE_D1_EVIDENCE_EXPORT_V1',source:'CLOUDFLARE_D1',app_version:APP_VERSION,exported_at:new Date().toISOString(),
      counts:{qsig_exported:q.rows.length,validation_exported:v.rows.length,qsig_remote:qt,validation_remote:vt},
      limit_per_dataset:10000,possibly_truncated:limited,warnings,rows,qsig,
      raw_d1:{qsig:q.rows,validation:v.rows},server_exported_at:{qsig:q.exported_at,validation:v.exported_at}};
  }
  async function feDbExportEvidenceJson(){
    if(feDbEvidenceExportBusy)return;
    const btn=$('databaseExportEvidenceBtn'),msg=$('databaseEvidenceExportStatus');
    if(!feDbConfigured()){status(msg,'Cần nhập Worker URL và token trước khi xuất D1.','err');return}
    feDbEvidenceExportBusy=true;if(btn)btn.disabled=true;status(msg,'Đang đọc QSIG + Validation từ D1...','busy');
    try{
      const [q,v,stats]=await Promise.all([
        bgRequest('/api/db/export/qsig?limit=10000',{timeout:30000}),
        bgRequest('/api/db/export/validation?limit=10000',{timeout:30000}),
        bgRequest('/api/db/stats',{timeout:15000}).catch(()=>null)
      ]);
      const payload=feDbEvidencePayload(q,v,stats);
      validationDownload(`football-edge-d1-evidence-${Date.now()}.json`,'application/json;charset=utf-8',JSON.stringify(payload,null,2));
      const note=`Đã tạo JSON: ${payload.counts.qsig_exported} QSIG + ${payload.counts.validation_exported} Validation. ${payload.warnings.length?'Có lưu ý trong file: '+payload.warnings.join(' '):'Gửi file này để kiểm tra tín hiệu.'}`;
      status(msg,note,payload.warnings.length?'':'ok');showToast('ok','D1 EVIDENCE EXPORT',note);
    }catch(e){status(msg,`Chưa xuất được D1: ${e.message}. Kiểm tra kết nối và Worker V1.2.2; không tạo file thiếu một nhóm dữ liệu.`,'err');showToast('err','D1 EVIDENCE EXPORT',e.message)}
    finally{feDbEvidenceExportBusy=false;if(btn)btn.disabled=false}
  }
  $('databaseExportEvidenceBtn')?.addEventListener('click',feDbExportEvidenceJson);
  // FE_D1_EVIDENCE_EXPORT_END
  // FE_EVIDENCE_REVIEW_CLIENT_START
  let feEvidenceReviewReport=null,feEvidenceReviewBusy=false;
  async function feLoadEvidenceReview(){
    if(feEvidenceReviewBusy)return;
    const btn=$('databaseReviewBtn'),exportBtn=$('databaseReviewExportBtn'),msg=$('databaseReviewStatus');
    if(!feDbConfigured()){status(msg,'Nhập Worker URL và token trước khi đối soát.','err');return}
    feEvidenceReviewBusy=true;btn.disabled=true;exportBtn.disabled=true;feEvidenceReviewReport=null;$('databaseReviewDetails').hidden=true;
    status(msg,'Đang đọc bằng chứng D1 và trạng thái theo dõi nền…','busy');
    try{
      const rows=[],seen=new Set();let next=null,pages=0;
      const tracking=await bgRequest('/api/watch/evidence-status',{timeout:30000});
      if(!tracking.ok||!Array.isArray(tracking.jobs))throw new Error('Worker chưa trả được trạng thái theo dõi');
      do{
        const query=next?`?before=${encodeURIComponent(next.before)}&after_id=${encodeURIComponent(next.after_id)}`:'';
        const page=await bgRequest('/api/db/evidence-review'+query,{timeout:30000});
        if(!page.ok||!Array.isArray(page.rows)||page.schema!=='FE_EVIDENCE_REVIEW_EXPORT_V1')throw new Error('Worker chưa hỗ trợ đối soát hoặc trả dữ liệu không hợp lệ');
        for(const row of page.rows){const key=`${row.engine}:${row.signal_id}`;if(!seen.has(key)){seen.add(key);rows.push(row)}}
        next=page.next;pages++;status(msg,`Đang đối soát: ${rows.length} tín hiệu…`,'busy');
      }while(next&&pages<50);
      const counts={};for(const row of rows)counts[row.status]=(counts[row.status]||0)+1;
      const now=Date.now(),jobs=tracking.jobs,active=jobs.filter(j=>!j.done&&j.until>now).length,
        pending=jobs.filter(j=>j.pending).length,failed=jobs.filter(j=>j.last_error).length;
      feEvidenceReviewReport={schema:'FOOTBALL_EDGE_EVIDENCE_REVIEW_V1',exported_at:new Date().toISOString(),read_only:true,
        counts,possibly_truncated:!!next,next_cursor:next,rows,tracking,
        notes:['Không sửa QSIG/Validation gốc.','HIT/MISS là có/không có bàn trong cửa sổ đánh giá, không phải thắng/thua cược.',
          'OBSERVED là kết quả tạm thời khi trận đang diễn ra.','HC RECORDED_ONLY chỉ là dữ liệu engine đã ghi, chưa replay độc lập.',
          'CENSORED là cửa sổ vượt phạm vi hiệp/trận; UNKNOWN không được tính là MISS.']};
      const text=`${rows.length} QSIG • Xác nhận: ${counts.CONFIRMED||0} • Tạm thời: ${counts.OBSERVED||0} • Chờ: ${counts.WAITING||0} • Thiếu dữ liệu: ${counts.MISSING_DATA||0} • Khác kết quả gốc: ${counts.CONFLICT||0} • Hủy: ${counts.VOID||0} • HC chỉ ghi nhận: ${counts.RECORDED_ONLY||0}. Nền: ${active} trận; ${pending} bản ghi chờ D1; ${failed} nhiệm vụ báo lỗi.${next?' Báo cáo bị giới hạn 1.000 mẫu; có con trỏ tiếp tục trong JSON.':''}`;
      status(msg,text,(failed||next||counts.CONFLICT)?'':'ok');exportBtn.disabled=false;
      const labels={CONFIRMED:'Đã xác nhận',OBSERVED:'Tạm thời',WAITING:'Đang chờ',MISSING_DATA:'Thiếu dữ liệu',CONFLICT:'Khác kết quả gốc',VOID:'Hủy',RECORDED_ONLY:'HC chưa replay',HIT:'Có bàn',MISS:'Không bàn',UNKNOWN:'Chưa rõ',CENSORED:'Ngoài phạm vi'};
      $('databaseReviewRows').innerHTML='<table style="width:100%;font-size:inherit"><thead><tr><th>Trận / mode</th><th>Cửa sổ</th><th>Đối soát</th></tr></thead><tbody>'+rows.slice(0,50).map(r=>`<tr><td>${esc(r.home&&r.away?`${r.home} – ${r.away}`:r.fixture_id)}<br>${esc(r.engine)} · ${esc(r.fixture_id)}</td><td>${Object.entries(r.windows||{}).map(([w,v])=>`${esc(w)}′: ${esc(labels[v]||v)}`).join('<br>')}</td><td>${esc(labels[r.status]||r.status)}<br><small>${esc(r.reason)}</small></td></tr>`).join('')+'</tbody></table>';
      $('databaseReviewDetails').hidden=false;
    }catch(e){status(msg,`Chưa đối soát được: ${e.message}. Không tạo báo cáo thiếu nhóm dữ liệu.`,'err')}
    finally{feEvidenceReviewBusy=false;btn.disabled=false}
  }
  $('databaseReviewBtn')?.addEventListener('click',feLoadEvidenceReview);
  $('databaseReviewExportBtn')?.addEventListener('click',()=>{if(feEvidenceReviewReport)validationDownload(`football-edge-review-${Date.now()}.json`,'application/json;charset=utf-8',JSON.stringify(feEvidenceReviewReport,null,2))});
  // FE_EVIDENCE_REVIEW_CLIENT_END
  $('databaseTestBtn')?.addEventListener('click',()=>feDbTest(true));
  $('databaseSyncBtn')?.addEventListener('click',()=>feDbSyncOutbox({silent:false,drain:true}));
  $('databaseMigrateBtn')?.addEventListener('click',()=>feDbMigrateLocalEntries());
  $('databaseMigrateEvidenceBtn')?.addEventListener('click',()=>feDbMigrateEvidence());
  $('databaseExportLiveBtn')?.addEventListener('click',()=>feDbExportLiveCsv());
  setTimeout(()=>feDbRefreshPanel(false),1400);

  function boolOrNull(v){return v===true?true:v===false?false:null}
  function normalizeLeagueCoverage(resp,league,season){
    const rows=Array.isArray(resp)?resp:[];
    const row=rows.find(x=>Number(x?.league?.id)===Number(league))||rows[0]||null;
    if(!row)return {known:false,league_id:league||null,season:season||null,source:'NO_LEAGUE_RESPONSE'};
    const seasons=Array.isArray(row.seasons)?row.seasons:[];
    const seasonRow=seasons.find(x=>Number(x?.year)===Number(season))
      || seasons.find(x=>x?.current===true)
      || null;
    const c=seasonRow?.coverage;
    if(!c)return {known:false,league_id:row.league?.id??league??null,season:seasonRow?.year??season??null,source:'NO_COVERAGE_OBJECT'};
    return {
      known:true,
      league_id:row.league?.id??league??null,
      league_name:row.league?.name??null,
      season:seasonRow?.year??season??null,
      fixtures:{
        events:boolOrNull(c.fixtures?.events),
        lineups:boolOrNull(c.fixtures?.lineups),
        statistics_fixtures:boolOrNull(c.fixtures?.statistics_fixtures),
        statistics_players:boolOrNull(c.fixtures?.statistics_players)
      },
      standings:boolOrNull(c.standings),
      players:boolOrNull(c.players),
      injuries:boolOrNull(c.injuries),
      predictions:boolOrNull(c.predictions),
      odds:boolOrNull(c.odds),
      source:'LEAGUES_COVERAGE'
    };
  }
  async function getLeagueCoverage(league,season){
    if(!league||!season)return {known:false,league_id:league||null,season:season||null,source:'MISSING_LEAGUE_OR_SEASON'};
    const resp=await footballCached('/leagues',{id:league,season},CACHE_TTL.league_coverage,true);
    return normalizeLeagueCoverage(resp,league,season);
  }
  function coverageValue(c,path){
    if(!c?.known)return null;
    const parts=String(path).split('.');
    let cur=c;
    for(const p of parts){if(cur==null)return null;cur=cur[p]}
    return cur===true?true:cur===false?false:null;
  }
  function coverageAllows(c,path){return coverageValue(c,path)!==false}
  function coverageSkipList(c,paths){
    return (paths||[]).filter(p=>coverageValue(c,p)===false);
  }

  function normalizeBetReference(rows,source){
    const byId={};
    (Array.isArray(rows)?rows:[]).forEach(x=>{
      if(x?.id==null)return;
      byId[String(x.id)]={id:x.id,name:x.name||null,source};
    });
    return {source,count:Object.keys(byId).length,byId};
  }
  async function getBetReference(source='prematch'){
    const live=source==='live';
    const path=live?'/odds/live/bets':'/odds/bets';
    const rows=await footballCached(path,{},CACHE_TTL.bet_reference,true);
    return normalizeBetReference(rows,source);
  }
  function betReferenceLookup(ref,betId){
    if(betId==null||!ref?.byId)return null;
    return ref.byId[String(betId)]||null;
  }

  function liveHistoryKey(fixtureId){return LIVE_ODDS_HISTORY_NS+String(fixtureId)}
  function liveHistoryIndexRead(){try{return JSON.parse(localStorage.getItem(LIVE_ODDS_HISTORY_INDEX)||'[]')}catch{return []}}
  function liveHistoryIndexWrite(v){try{localStorage.setItem(LIVE_ODDS_HISTORY_INDEX,JSON.stringify((v||[]).slice(-40)))}catch{}}
  function liveHistoryRead(fixtureId){
    try{
      const raw=localStorage.getItem(liveHistoryKey(fixtureId));
      const rows=raw?JSON.parse(raw):[];
      const cutoff=Date.now()-LIVE_ODDS_HISTORY_MAX_AGE;
      return (Array.isArray(rows)?rows:[]).filter(x=>Number(x?.captured_at||0)>=cutoff);
    }catch{return []}
  }
  function liveHistoryWrite(fixtureId,rows){
    try{
      const keep=(rows||[]).slice(-LIVE_ODDS_HISTORY_MAX_SNAPSHOTS);
      localStorage.setItem(liveHistoryKey(fixtureId),JSON.stringify(keep));
      let idx=liveHistoryIndexRead().filter(x=>String(x.fixture_id)!==String(fixtureId));
      idx.push({fixture_id:fixtureId,ts:Date.now()});
      const cutoff=Date.now()-LIVE_ODDS_HISTORY_MAX_AGE;
      const drop=idx.filter(x=>x.ts<cutoff);
      drop.forEach(x=>{try{localStorage.removeItem(liveHistoryKey(x.fixture_id))}catch{}});
      idx=idx.filter(x=>x.ts>=cutoff).slice(-40);
      liveHistoryIndexWrite(idx);
    }catch(e){log('Live odds history write skipped',e.message)}
  }
  function marketValueKey(v){
    return v?.selection_outcome||v?.selection_side||String(v?.value??'').trim()||'selection';
  }
  function compactMovementLine(m){
    const vals=(m?.values||[]).filter(v=>!v.suspended).slice(0,4).map(v=>({
      key:marketValueKey(v),
      value:v.value??null,
      handicap:v.handicap??null,
      odd:v.odd??null,
      main:v.main===true
    }));
    return {
      bet:m?.bet??m?.market??null,
      category:m?.category??null,
      line:m?.main_line??vals.find(v=>v.main)?.handicap??vals[0]?.handicap??null,
      update:m?.update??null,
      values:vals
    };
  }
  function liveSnapshotFingerprint(snap){
    try{return JSON.stringify(snap?.lines||{})}catch{return String(Date.now())}
  }
  function createLiveOddsSnapshot(fixtureId,meta,markets){
    const lines={};
    for(const m of (markets||[])){
      if(!m?.category||m?.integrity?.valid===false)continue;
      if(lines[m.category])continue;
      const c=compactMovementLine(m);
      if(c.values.length)lines[m.category]=c;
    }
    const status=meta?.fixture?.status||meta?.status||{};
    const goals=meta?.goals||{};
    return {
      captured_at:Date.now(),
      fixture_id:fixtureId,
      minute:status?.elapsed??null,
      status:status?.short??null,
      score:{home:goals?.home??null,away:goals?.away??null},
      lines
    };
  }
  function priceMap(line){
    const o={};(line?.values||[]).forEach(v=>{if(v?.odd!=null)o[v.key||v.value||'selection']=v.odd});return o
  }
  function numericMaybe(v){const n=Number(v);return Number.isFinite(n)?n:null}
  function movementForCategory(first,last){
    const a=numericMaybe(first?.line),b=numericMaybe(last?.line);
    return {
      from_line:first?.line??null,
      to_line:last?.line??null,
      line_delta:a!=null&&b!=null?Math.round((b-a)*100)/100:null,
      from_prices:priceMap(first),
      to_prices:priceMap(last),
      changed:JSON.stringify({l:first?.line,p:priceMap(first)})!==JSON.stringify({l:last?.line,p:priceMap(last)})
    };
  }
  function summarizeLiveOddsHistory(rows){
    const r=(rows||[]).slice(-LIVE_ODDS_HISTORY_MAX_SNAPSHOTS);
    if(!r.length)return {snapshot_count:0,status:'NO_LOCAL_HISTORY',window_minutes:0,categories:{},timeline:[]};
    const first=r[0],last=r[r.length-1];
    const cats=new Set();
    r.forEach(x=>Object.keys(x.lines||{}).forEach(k=>cats.add(k)));
    const categories={};
    cats.forEach(cat=>{
      const f=r.find(x=>x.lines?.[cat])?.lines?.[cat]||null;
      const l=[...r].reverse().find(x=>x.lines?.[cat])?.lines?.[cat]||null;
      if(f&&l)categories[cat]=movementForCategory(f,l);
    });
    return {
      snapshot_count:r.length,
      status:r.length>=2?'HISTORY_AVAILABLE':'BASELINE_ONLY',
      window_minutes:Math.round(((last.captured_at-first.captured_at)/60000)*10)/10,
      first:{captured_at:first.captured_at,minute:first.minute,score:first.score},
      latest:{captured_at:last.captured_at,minute:last.minute,score:last.score},
      categories,
      timeline:r.slice(-10).map(x=>({
        captured_at:x.captured_at,minute:x.minute,score:x.score,
        lines:Object.fromEntries(Object.entries(x.lines||{}).map(([k,v])=>[k,{line:v.line,prices:priceMap(v)}]))
      }))
    };
  }
  function saveLiveOddsSnapshot(fixtureId,meta,markets){
    if(!fixtureId||(markets||[]).length===0)return summarizeLiveOddsHistory(liveHistoryRead(fixtureId));
    const snap=createLiveOddsSnapshot(fixtureId,meta,markets);
    if(!Object.keys(snap.lines||{}).length)return summarizeLiveOddsHistory(liveHistoryRead(fixtureId));
    const rows=liveHistoryRead(fixtureId);
    const last=rows[rows.length-1];
    const same=last&&liveSnapshotFingerprint(last)===liveSnapshotFingerprint(snap);
    const elapsed=last?Date.now()-last.captured_at:Infinity;
    // Store changed snapshots immediately; unchanged snapshots at most every 3 min.
    if(!same||elapsed>=3*60*1000)rows.push(snap);
    liveHistoryWrite(fixtureId,rows);
    return summarizeLiveOddsHistory(rows);
  }
  function movementCompactText(h){
    if(!h||h.snapshot_count<2)return null;
    const parts=[];
    Object.entries(h.categories||{}).forEach(([cat,x])=>{
      if(!x.changed)return;
      const fp=Object.entries(x.from_prices||{}).map(([k,v])=>`${k}@${v}`).join('/');
      const tp=Object.entries(x.to_prices||{}).map(([k,v])=>`${k}@${v}`).join('/');
      parts.push(`${cat}: ${x.from_line??'-'} ${fp||''} → ${x.to_line??'-'} ${tp||''}`.trim());
    });
    return parts.length?`n=${h.snapshot_count} / ${h.window_minutes}m | ${parts.slice(0,3).join(' || ')}`:`n=${h.snapshot_count} / ${h.window_minutes}m | line/price chưa đổi`;
  }

  $('testBtn').addEventListener('click',async()=>{
    saveConfig(true);loading(true,'Đang kiểm tra Football API','Kiểm tra key, gói API và quota thực tế.');status(els.conn,'Đang kiểm tra...','busy');
    try{
      if(els.provider.value==='direct'){
        const s=await football('/status',{}),req=s?.requests||{},sub=s?.subscription||{},current=Number(req.current),limit=Number(req.limit_day),remain=Number.isFinite(limit)&&Number.isFinite(current)?Math.max(0,limit-current):null;
        const plan=String(sub.plan||'').trim(),parts=['Football API: OK'];
        if(plan)parts.push(plan.toUpperCase());
        if(Number.isFinite(current)&&Number.isFinite(limit))parts.push(`${current}/${limit} request hôm nay${remain!=null?` • còn ${remain}`:''}`);
        const q=footballQuotaLabel();if(q)parts.push(q);
        status(els.conn,parts.join(' • '),'ok')
      }else{
        const d=fmtDateInTZ(new Date()),f=await football('/fixtures',{date:d,timezone:TZ}),q=footballQuotaLabel();
        status(els.conn,`Football API: OK (${Array.isArray(f)?f.length:0} trận ngày ${d})${q?` • ${q}`:''}`,'ok')
      }
    }catch(e){status(els.conn,'Football API: LỖI — '+e.message,'err')}finally{loading(false)}
  });

  function isLive(f){const s=f.fixture?.status?.short||'';return ['1H','HT','2H','ET','BT','P','INT','SUSP','LIVE'].includes(s)}
  /* V1.18.8 LIVE SOURCE AGE GUARD
     Request freshness (e.g. fresh 1s) is NOT the same thing as fixture freshness.
     A stale/ghost fixture returned by a live feed must never enter H1/FT/HC workspaces. */
  const FE_LIVE_SOURCE_GUARD={max_age_min:360,future_grace_min:45,max_clock_lag_min:180,rejected:0,last:[]};
  function feLiveSourceCheck(f){
    const st=String(f?.fixture?.status?.short||''),elapsed=Number(f?.fixture?.status?.elapsed),rawTs=Number(f?.fixture?.timestamp),dateMs=Date.parse(String(f?.fixture?.date||'')),kickoffMs=Number.isFinite(rawTs)&&rawTs>0?rawTs*1000:(Number.isFinite(dateMs)?dateMs:null),now=Date.now();
    if(!isLive(f))return {ok:false,reason:'NOT_LIVE_STATUS',age_min:null};
    if(!Number.isFinite(kickoffMs))return {ok:false,reason:'NO_KICKOFF_TIME',age_min:null};
    const ageMin=(now-kickoffMs)/60000;
    if(ageMin < -FE_LIVE_SOURCE_GUARD.future_grace_min)return {ok:false,reason:'KICKOFF_IN_FUTURE',age_min:ageMin};
    if(ageMin > FE_LIVE_SOURCE_GUARD.max_age_min)return {ok:false,reason:'FIXTURE_TOO_OLD',age_min:ageMin};
    if(Number.isFinite(elapsed)&&!['ET','BT','P','INT','SUSP'].includes(st)&&ageMin-elapsed>FE_LIVE_SOURCE_GUARD.max_clock_lag_min)return {ok:false,reason:'CLOCK_KICKOFF_MISMATCH',age_min:ageMin};
    return {ok:true,reason:'OK',age_min:ageMin};
  }
  function feLiveSourceValid(f){
    const g=feLiveSourceCheck(f);if(g.ok)return true;
    FE_LIVE_SOURCE_GUARD.rejected++;FE_LIVE_SOURCE_GUARD.last.push({id:Number(f?.fixture?.id)||null,status:f?.fixture?.status?.short||null,elapsed:f?.fixture?.status?.elapsed??null,reason:g.reason,age_min:g.age_min==null?null:Math.round(g.age_min)});FE_LIVE_SOURCE_GUARD.last=FE_LIVE_SOURCE_GUARD.last.slice(-20);
    return false;
  }
  function fixtureLabel(f){const st=f.fixture?.status||{};if(isLive(f))return `${st.elapsed??''}' ${st.short||'LIVE'}`.trim();return fmtDateTime(f.fixture.timestamp)}

  function xienEligibleFixtures(fixtures=state.fixtures,purpose=state.scanPurpose){
    if(purpose==='xien_pre'){
      return (fixtures||[]).filter(f=>!isLive(f)&&!['FT','AET','PEN','PST','CANC','ABD','AWD','WO'].includes(f?.fixture?.status?.short));
    }
    if(purpose==='xien_live'){
      return (fixtures||[]).filter(f=>isLive(f)&&!['FT','AET','PEN'].includes(f?.fixture?.status?.short));
    }
    return fixtures||[];
  }

  function scanPurposeLabel(p=state.scanPurpose){
    return p==='xien_pre'?'XIÊN 5 PRE':p==='xien_live'?'XIÊN 5 LIVE':'ĐƠN';
  }

  function setScanPurpose(p){
    state.scanPurpose=p;
    document.querySelectorAll('#scanPurposeButtons button').forEach(b=>b.classList.toggle('active',b.dataset.purpose===p));
    const note=$('xienModeNote'),xbtn=$('prepareXienBtn'),sbtn=$('prepareAllBtn'),wbtn=$('watchTop5Btn'),h1btn=$('watchH1Top5Btn'),cbtn=$('watchHandicapTop5Btn');

    if(p==='single'){
      note.classList.add('hidden');
      xbtn.classList.add('hidden');
      sbtn.classList.remove('hidden');
    }else{
      note.classList.remove('hidden');
      xbtn.classList.remove('hidden');
      sbtn.classList.add('hidden');
      wbtn?.classList.add('hidden');
      h1btn?.classList.add('hidden');
      cbtn?.classList.add('hidden');
      note.innerHTML=p==='xien_pre'
        ?'<b>XIÊN 5 PRE:</b> chỉ gom các trận CHƯA ĐÁ. GPT phải chọn 5 chân ở 5 fixture khác nhau và ghi đủ GIỜ VN • GIẢI • TRẬN • KÈO • LINE/GIÁ.'
        :'<b>XIÊN 5 LIVE:</b> chỉ gom các trận ĐANG LIVE. GPT phải ghi thêm PHÚT • TỶ SỐ hiện tại và ưu tiên game-state / live stats / live market.';
    }

    if(state.fixtures.length)updateGroupPanelForPurpose();
  }

  function updateGroupPanelForPurpose(){
    const eligible=xienEligibleFixtures();
    const total=state.fixtures.length;
    const liveCount=state.fixtures.filter(isLive).length;
    const h1Count=state.fixtures.filter(h1WatchEligible).length;
    const ftCount=state.fixtures.filter(watchLiveEligible).length;
    const handicapCount=state.fixtures.filter(handicapWatchEligible).length;

    if(state.scanPurpose==='single'){
      status(els.scanStatus,`${total} trận • ${liveCount} LIVE • H1 ${h1Count} • FT ${ftCount} • HC ${handicapCount}.`,'ok');
      els.groupCount.textContent=String(total);
      $('prepareAllBtn').textContent=`📦 GOM ${total} TRẬN → GÓI COMPACT`;
      const wb=$('watchTop5Btn'),hb=$('watchH1Top5Btn'),cb=$('watchHandicapTop5Btn');
      if(wb){wb.classList.toggle('hidden',ftCount===0);wb.textContent=`🔥 CANH TOP ${Math.min(5,ftCount)} RUNG TÀI FT`;}
      if(hb){hb.classList.toggle('hidden',h1Count===0);hb.textContent=`🔥 CANH TOP ${Math.min(5,h1Count)} RUNG TÀI H1`;}
      if(cb){cb.classList.toggle('hidden',handicapCount===0);cb.textContent=`⚖️ CANH TOP ${Math.min(5,handicapCount)} HANDICAP`; }
      els.groupProgress.textContent='LIVE WATCH: H1 • FT • HANDICAP. HANDICAP dùng Team State Home/Away, GAP, delta 3/5/10m, CORE 3/4 và Market Fit.';
      return;
    }

    const label=scanPurposeLabel();
    status(els.scanStatus,`${total} trận trong khung • ${eligible.length} trận phù hợp ${label}${state.scanPurpose==='xien_live'?` • ${liveCount} LIVE`:''}.`,'ok');
    els.groupCount.textContent=String(eligible.length);
    $('prepareXienBtn').textContent=`🧩 GOM ${eligible.length} TRẬN → GÓI ${label}`;
    els.groupProgress.textContent=eligible.length>=5
      ?`${label} • GPT so sánh toàn bộ ứng viên và chỉ lập bộ 5 chân nếu đủ điều kiện.`
      :`${label} • Hiện chỉ có ${eligible.length} trận phù hợp; cần tối thiểu 5 fixture để lập XIÊN 5.`;
  }

  function fixturePreEligible(f){
    const st=f?.fixture?.status?.short||'';
    return !isLive(f)&&!['FT','AET','PEN','PST','CANC','ABD','AWD','WO'].includes(st);
  }
  function fixtureLiveGuardOkUI(f){return feLiveSourceCheck(f).ok}
  function fixtureH1EligibleUI(f){const st=f?.fixture?.status?.short||'',m=Number(f?.fixture?.status?.elapsed);return fixtureLiveGuardOkUI(f)&&['1H','LIVE'].includes(st)&&Number.isFinite(m)&&m>=20&&m<=45}
  function fixtureFTEligibleUI(f){const st=f?.fixture?.status?.short||'',m=Number(f?.fixture?.status?.elapsed);return fixtureLiveGuardOkUI(f)&&['2H','HT','ET','BT','LIVE','INT'].includes(st)&&Number.isFinite(m)&&m>=45&&m<=89}
  function fixtureHCEligibleUI(f){const st=f?.fixture?.status?.short||'',m=Number(f?.fixture?.status?.elapsed);return fixtureLiveGuardOkUI(f)&&['1H','2H','ET','BT','LIVE','INT','HT'].includes(st)&&Number.isFinite(m)&&m>=25&&m<=88}
  function fixtureMatchesViewFilter(f,filter=state.fixtureFilter){
    if(filter==='live')return isLive(f);
    if(filter==='h1')return fixtureH1EligibleUI(f);
    if(filter==='ft')return fixtureFTEligibleUI(f);
    if(filter==='hc')return fixtureHCEligibleUI(f);
    if(filter==='pre')return fixturePreEligible(f);
    return true;
  }
  function fixtureMatchesSearch(f,q=state.fixtureSearch){
    q=String(q||'').trim().toLowerCase();if(!q)return true;
    const hay=[f?.teams?.home?.name,f?.teams?.away?.name,f?.league?.name,f?.league?.country,f?.league?.round,f?.fixture?.id]
      .filter(v=>v!=null).join(' ').toLowerCase();
    return hay.includes(q);
  }
  function fixtureFilterCounts(fixtures=state.fixtures){
    const rows=Array.isArray(fixtures)?fixtures:[];
    return {all:rows.length,live:rows.filter(isLive).length,h1:rows.filter(fixtureH1EligibleUI).length,ft:rows.filter(fixtureFTEligibleUI).length,hc:rows.filter(fixtureHCEligibleUI).length,pre:rows.filter(fixturePreEligible).length};
  }
  function fixtureFilterIsActive(){
    return state.fixtureFilter!=='all'||String(state.fixtureSearch||'').trim()!=='';
  }
  function renderFixtureFilterMeta(visibleCount){
    const c=fixtureFilterCounts(),ids={all:'fixtureFilterCountAll',live:'fixtureFilterCountLive',h1:'fixtureFilterCountH1',ft:'fixtureFilterCountFT',hc:'fixtureFilterCountHC',pre:'fixtureFilterCountPre'};
    Object.entries(ids).forEach(([k,id])=>{const el=$(id);if(el)el.textContent=String(c[k]||0)});
    if(els.fixtureFilterSummary)els.fixtureFilterSummary.textContent=`${visibleCount} / ${c.all} trận`;
    if(els.fixtureListSummaryCount)els.fixtureListSummaryCount.textContent=fixtureFilterIsActive()?`${visibleCount}/${c.all} trận`:`${c.all} trận`;
    if(els.fixtureFilterTabs)els.fixtureFilterTabs.querySelectorAll('button[data-fixture-filter]').forEach(b=>b.classList.toggle('active',b.dataset.fixtureFilter===state.fixtureFilter));
    const active=fixtureFilterIsActive(),label=String(state.fixtureFilter||'all').toUpperCase();
    if(els.fixtureFilterToggleMeta)els.fixtureFilterToggleMeta.textContent=active?`${label} • ${visibleCount}/${c.all}`:`${c.all} trận`;
    if(els.toggleFixtureFilterBtn){
      els.toggleFixtureFilterBtn.classList.toggle('active',active);
      const t=state.fixtureFilterOpen?'🙈 ẨN BỘ LỌC ':'🔎 HIỆN BỘ LỌC ';
      if(els.toggleFixtureFilterBtn.firstChild)els.toggleFixtureFilterBtn.firstChild.nodeValue=t;
    }
  }
  function renderFixtureList(){
    els.matches.innerHTML='';
    const visible=(state.fixtures||[]).map((f,i)=>({f,i})).filter(x=>fixtureMatchesViewFilter(x.f)&&fixtureMatchesSearch(x.f));
    renderFixtureFilterMeta(visible.length);
    if(!visible.length){
      els.matches.innerHTML='<div class="fixture-filter-empty">Không có trận khớp bộ lọc hiện tại. Chọn TẤT CẢ hoặc xóa từ khóa để xem lại toàn bộ danh sách.</div>';
      return;
    }
    const selectedId=Number(state.selected?.fixture?.id);
    visible.forEach(({f,i})=>{
      const div=document.createElement('div');div.className='match';div.dataset.i=i;
      if(Number.isFinite(selectedId)&&Number(f?.fixture?.id)===selectedId)div.classList.add('selected');
      const g=f.goals||{}, liveNow=isLive(f);
      const home=f.teams?.home||{}, away=f.teams?.away||{};
      const homeLogo=home.logo?`<img class="team-logo" src="${esc(home.logo)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">`:'';
      const awayLogo=away.logo?`<img class="team-logo" src="${esc(away.logo)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">`:'';
      div.innerHTML=`
        <div class="match-top">
          <div class="league-line"><i class="country-dot"></i><span>${esc(f.league?.name||'Giải đấu')} • ${esc(f.league?.country||'')}</span></div>
          <span class="status-pill ${liveNow?'live':''}">${esc(fixtureLabel(f))}</span>
        </div>
        <div class="match-main">
          <div class="team-block">${homeLogo}<span>${esc(home.name||'Home')}</span></div>
          <div class="score-block">
            <strong>${liveNow?`${esc(g.home??0)} - ${esc(g.away??0)}`:'VS'}</strong>
            <small>${liveNow?'LIVE SCORE':'FIXTURE'}</small>
          </div>
          <div class="team-block away"><span>${esc(away.name||'Away')}</span>${awayLogo}</div>
        </div>
        <div class="match-foot">
          <span>Fixture #${esc(f.fixture?.id||'')}</span>
          <span>${esc(f.league?.round||'')}</span>
        </div>`;
      div.addEventListener('click',()=>selectFixture(i));els.matches.appendChild(div)
    });
  }
  function renderFixtures(fixtures){
    state.fixtures=Array.isArray(fixtures)?fixtures:[];state.selected=null;state.lastPacket='';
    state.fixtureFilter='all';state.fixtureSearch='';state.fixtureFilterOpen=false;
    if(els.fixtureFilterSearch)els.fixtureFilterSearch.value='';
    if(bgEnabled()&&state.fixtures.length)setTimeout(()=>bgRegisterFixtures(state.fixtures,'screen','SCAN',true),0);
    els.packetBox.classList.add('hidden');els.coverage.classList.add('hidden');els.result.classList.add('hidden');
    status(els.selected,'Chưa chọn trận.');
    if(!state.fixtures.length){
      els.fixtureFilterToggle?.classList.add('hidden');els.fixtureFilterBar?.classList.add('hidden');els.matches.innerHTML='';
      els.groupPanel.classList.add('hidden');$('watchTop5Btn')?.classList.add('hidden');$('watchHandicapTop5Btn')?.classList.add('hidden');status(els.scanStatus,'Không có trận phù hợp trong khung đã chọn.','err');return
    }
    els.fixtureFilterToggle?.classList.remove('hidden');
    els.fixtureFilterBar?.classList.add('hidden');
    els.groupPanel.classList.remove('hidden');
    updateGroupPanelForPurpose();
    renderFixtureList();
  }
  function selectFixture(i){state.selected=state.fixtures[i];[...els.matches.children].forEach(x=>x.classList.toggle('selected',Number(x.dataset.i)===Number(i)));const f=state.selected;status(els.selected,`⚽ ${f.teams.home.name}  ${isLive(f)?(f.goals?.home??0)+' - '+(f.goals?.away??0):'vs'}  ${f.teams.away.name}\n${f.league?.name||''} • ${fixtureLabel(f)} • Fixture #${f.fixture.id}`,'ok');els.result.classList.add('hidden');els.coverage.classList.add('hidden');els.packetBox.classList.add('hidden');els.smaResult?.classList.add('hidden');state.lastPacket='';state.singleAnalyzer.last=null;
    const auto=isLive(f)&&['1H','HT'].includes(f.fixture.status.short)?'LIVE H1':isLive(f)?'LIVE FT':'PRE-MATCH';
    if(els.smaAutoMode)els.smaAutoMode.textContent=auto;
    if(isLive(f)&&['1H','HT'].includes(f.fixture.status.short)){setMode('H1')}else if(isLive(f)){setMode('FT')}else setMode('PRE')
    $('analysisCard').scrollIntoView({behavior:'smooth',block:'start'})
  }
  function setMode(m){state.mode=m;document.querySelectorAll('#modeButtons button').forEach(b=>b.classList.toggle('active',b.dataset.mode===m))}
  document.querySelectorAll('#modeButtons button').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.mode)));
  document.querySelectorAll('#scanPurposeButtons button').forEach(b=>b.addEventListener('click',()=>{
    setScanPurpose(b.dataset.purpose);
    if(b.dataset.purpose==='xien_live' && state.scan!=='live'){
      document.querySelectorAll('#scanButtons button').forEach(x=>x.classList.toggle('active',x.dataset.h==='live'));
      state.scan='live';state.scanLabel='LIVE';
      scanHorizon('live');
    }
  }));


  if(els.toggleFixtureFilterBtn)els.toggleFixtureFilterBtn.addEventListener('click',()=>{
    state.fixtureFilterOpen=!state.fixtureFilterOpen;
    els.fixtureFilterBar?.classList.toggle('hidden',!state.fixtureFilterOpen);
    const visible=(state.fixtures||[]).filter(f=>fixtureMatchesViewFilter(f)&&fixtureMatchesSearch(f)).length;
    renderFixtureFilterMeta(visible);
    if(state.fixtureFilterOpen)els.fixtureFilterBar?.scrollIntoView({behavior:'smooth',block:'nearest'});
  });


  if(els.fixtureFilterTabs)els.fixtureFilterTabs.addEventListener('click',e=>{
    const b=e.target.closest('button[data-fixture-filter]');if(!b)return;
    state.fixtureFilter=b.dataset.fixtureFilter||'all';renderFixtureList();
  });
  if(els.fixtureFilterSearch)els.fixtureFilterSearch.addEventListener('input',()=>{
    state.fixtureSearch=els.fixtureFilterSearch.value||'';renderFixtureList();
  });
  $('fixtureFilterClear')?.addEventListener('click',()=>{
    state.fixtureSearch='';if(els.fixtureFilterSearch)els.fixtureFilterSearch.value='';renderFixtureList();els.fixtureFilterSearch?.focus();
  });



  function scanProgressSnapshot(){
    const p=state.scanProgress||{};
    const total=Math.max(0,Number(p.total||0)),done=Math.max(0,Math.min(total||Infinity,Number(p.done||0))),
          pct=total>0?Math.max(0,Math.min(100,Math.round(done/total*100))):Number(p.pct||0);
    return {...p,total,done,pct:Number.isFinite(pct)?pct:0}
  }
  function scanProgressRender(){
    const p=scanProgressSnapshot();
    if(!els.scanLiveProgress)return;
    els.scanLiveProgress.classList.toggle('hidden',!p.active);
    if(!p.active)return;
    if(els.scanProgressTitle)els.scanProgressTitle.textContent=p.total>0?`ĐANG QUÉT ${p.done}/${p.total} TRẬN`:'ĐANG QUÉT DỮ LIỆU';
    if(els.scanProgressPercent)els.scanProgressPercent.textContent=p.total>0?`${p.pct}%`:'...';
    if(els.scanProgressBar)els.scanProgressBar.style.width=(p.total>0?p.pct:Math.max(8,Number(p.pct||8)))+'%';
    if(els.scanProgressDetail)els.scanProgressDetail.textContent=p.detail||p.stage||'Đang xử lý...';
    if(p.total>0){
      status(els.scanStatus,`Đang quét ${p.done}/${p.total} trận • ${p.pct}% • không cần bấm lại.`,'busy');
      if(els.loadingText)els.loadingText.textContent=`${p.done}/${p.total} trận • ${p.pct}% • ${p.detail||p.stage||''}`;
    }else{
      status(els.scanStatus,`${p.stage||'Đang quét dữ liệu'} • không cần bấm lại.`,'busy');
      if(els.loadingText)els.loadingText.textContent=p.detail||p.stage||'Đang chờ Football API trả dữ liệu...';
    }
  }
  function scanProgressStart(label,stage='Đang lấy danh sách trận từ Football API.'){
    state.scanProgress={active:true,label:String(label||state.scanLabel||'SCAN'),stage,done:0,total:0,pct:8,detail:stage,startedAt:Date.now()};
    scanProgressRender()
  }
  function scanProgressUpdate(done,total,detail='',stage='Đang xử lý danh sách trận'){
    const p=state.scanProgress||{};
    state.scanProgress={...p,active:true,stage,done:Number(done||0),total:Number(total||0),detail:detail||stage,pct:Number(total)>0?Math.round(Number(done||0)/Number(total)*100):Math.max(8,Number(p.pct||8))};
    scanProgressRender()
  }
  function scanProgressStage(stage,detail='',pct=null){
    const p=state.scanProgress||{};
    state.scanProgress={...p,active:true,stage,detail:detail||stage,pct:pct==null?Math.max(8,Number(p.pct||8)):Number(pct)};
    scanProgressRender()
  }
  function scanProgressFinish(total,detail='Quét hoàn tất.'){
    const p=state.scanProgress||{};
    state.scanProgress={...p,active:true,stage:'HOÀN TẤT',done:Number(total||p.total||0),total:Number(total||p.total||0),pct:100,detail};
    scanProgressRender();
    setTimeout(()=>{
      if(state.scanning)return;
      state.scanProgress={...state.scanProgress,active:false};
      els.scanLiveProgress?.classList.add('hidden')
    },1400)
  }
  function scanProgressFail(message){
    const p=state.scanProgress||{};
    state.scanProgress={...p,active:true,stage:'QUÉT LỖI',detail:String(message||'Không thể hoàn tất lượt quét.')};
    if(els.scanProgressTitle)els.scanProgressTitle.textContent='QUÉT CHƯA HOÀN TẤT';
    if(els.scanProgressPercent)els.scanProgressPercent.textContent='!';
    if(els.scanProgressBar)els.scanProgressBar.style.width='100%';
    if(els.scanProgressDetail)els.scanProgressDetail.textContent=state.scanProgress.detail;
    els.scanLiveProgress?.classList.add('scan-error');
    setTimeout(()=>els.scanLiveProgress?.classList.remove('scan-error'),2500)
  }
  function scanBusyNotice(){
    const p=scanProgressSnapshot(),elapsed=p.startedAt?Math.max(0,Math.round((Date.now()-p.startedAt)/1000)):0;
    const title=p.total>0?`ĐANG QUÉT ${p.done}/${p.total} TRẬN • ${p.pct}%`:'ĐANG QUÉT DỮ LIỆU';
    const sub=p.total>0
      ?`${p.detail||p.stage||'Đang xử lý'} • ${elapsed}s. Không cần bấm lại.`
      :`${p.detail||p.stage||'Đang chờ Football API'} • ${elapsed}s. Không cần bấm lại.`;
    showToast('busy',title,sub);
    scanProgressRender()
  }
  async function fetchDatesProgress(dates,onProgress){
    const uniq=[...new Set(dates)],total=uniq.length;let done=0;
    const chunks=await Promise.all(uniq.map(async d=>{
      const rows=await football('/fixtures',{date:d,timezone:TZ});
      done++;
      if(onProgress)onProgress(done,total,d,Array.isArray(rows)?rows.length:0);
      return rows
    }));
    return chunks.flat()
  }
  async function filterFixturesProgress(fixtures,predicate,detailPrefix='Đang lọc fixture'){
    const src=Array.isArray(fixtures)?fixtures:[],out=[],total=src.length,chunk=12;
    if(!total){scanProgressUpdate(0,0,'Football API trả về 0 fixture.','Đang xử lý danh sách');return out}
    for(let i=0;i<total;i++){
      const f=src[i];
      if(!predicate||predicate(f))out.push(f);
      if((i+1)%chunk===0||i===total-1){
        const name=`${f?.teams?.home?.name||''} vs ${f?.teams?.away?.name||''}`.trim();
        scanProgressUpdate(i+1,total,`${detailPrefix} • ${out.length} trận phù hợp${name?` • ${name}`:''}`,'Đang xử lý danh sách trận');
        await new Promise(r=>setTimeout(r,0))
      }
    }
    return out
  }
  async function fetchDates(dates){return fetchDatesProgress(dates)}

  async function scanHorizon(h){
    if(state.scanning){scanBusyNotice();return}
    state.scanning=true;
    state.scanLabel=h==='live'?'LIVE':`+${h}H`;
    els.scanLiveProgress?.classList.remove('scan-error');
    scanProgressStart(state.scanLabel,h==='live'?'Đang lấy toàn bộ fixture LIVE từ Football API.':`Đang lấy fixture cho khung +${h}H.`);
    saveConfig(true);loading(true,'Đang quét trận',state.scanProgress.detail);els.matches.innerHTML='';state.selected=null;status(els.selected,'Chưa chọn trận.');
    try{
      let fixtures;
      if(h==='live'){
        let raw=await football('/fixtures',{live:'all',timezone:TZ}),liveSource='LIVE_ALL';
        if(!Array.isArray(raw))raw=[];
        if(raw.length===0){
          const now=Date.now(),dates=[fmtDateInTZ(new Date(now-86400000)),fmtDateInTZ(new Date(now))];
          scanProgressStage('LIVE feed trả 0',`Đang đối chiếu fixture theo ngày ${dates.join(' / ')} để tránh bỏ sót trận đang diễn ra.`,12);
          const fallback=(await Promise.all([...new Set(dates)].map(d=>football('/fixtures',{date:d,timezone:TZ})))).flat();
          raw=fallback.filter(feLiveSourceValid);liveSource='DATE_FALLBACK'
        }
        const q=footballQuotaLabel();
        scanProgressStage('Đã nhận danh sách LIVE',`Nguồn ${liveSource} • ${raw.length} fixture${q?` • ${q}`:''} • đang kiểm tra từng trận.`,15);
        fixtures=await filterFixturesProgress(raw,()=>true,'Đang kiểm tra LIVE');
      }else{
        const now=Date.now(),end=now+Number(h)*3600000,
              dates=[fmtDateInTZ(new Date(now)),fmtDateInTZ(new Date(end))];
        const raw=await fetchDatesProgress(dates,(done,total,date,count)=>{
          scanProgressStage('Đang lấy fixture theo ngày',`Đã nhận ${done}/${total} ngày • ${date}: ${count} fixture`,8+Math.round(done/Math.max(1,total)*12))
        });
        scanProgressStage('Đã nhận danh sách fixture',`Football API trả về ${raw.length} fixture • đang lọc đúng khung +${h}H.`,20);
        fixtures=await filterFixturesProgress(raw,f=>{
          const ts=(f.fixture?.timestamp||0)*1000;
          return ts>=now-90000&&ts<=end&&!['FT','AET','PEN','PST','CANC','ABD','AWD','WO'].includes(f.fixture?.status?.short)
        },`Đang lọc khung +${h}H`)
      }
      scanProgressStage('Đang sắp xếp kết quả',`${fixtures.length} trận phù hợp • đang dựng danh sách.`,96);
      fixtures.sort((a,b)=>(a.fixture.timestamp||0)-(b.fixture.timestamp||0));
      renderFixtures(fixtures);
      scanProgressFinish(fixtures.length,`Hoàn tất • ${fixtures.length} trận phù hợp ${state.scanLabel}.`);
      if(h==='live')setTimeout(()=>refreshSlateRegime(false),80);else resetSlateRegime('Chỉ đánh giá nhịp khi quét LIVE.')
    }catch(e){
      scanProgressFail(e.message);status(els.scanStatus,e.message,'err');log('Quét lỗi',e.message)
    }finally{state.scanning=false;loading(false)}
  }
  document.querySelectorAll('#scanButtons button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('#scanButtons button').forEach(x=>x.classList.remove('active'));b.classList.add('active');state.scan=b.dataset.h;state.scanLabel=b.dataset.h==='live'?'LIVE':`+${b.dataset.h}H`;scanHorizon(b.dataset.h)}));

  function localDateWithHM(baseDate,hm,dayOffset=0){
    const dateStr=fmtDateInTZ(new Date(baseDate.getTime()+dayOffset*86400000));const [y,m,d]=dateStr.split('-').map(Number),[hh,mm]=hm.split(':').map(Number);
    // Asia/Ho_Chi_Minh = UTC+7 (no DST)
    return Date.UTC(y,m-1,d,hh-7,mm,0,0)
  }
  $('customScanBtn').addEventListener('click',async()=>{
    if(state.scanning){scanBusyNotice();return}
    const from=$('fromTime').value,to=$('toTime').value;if(!from||!to){status(els.scanStatus,'Hãy nhập đủ giờ bắt đầu và kết thúc.','err');return}
    state.scanning=true;
    state.scan='custom';state.scanLabel=`${from}-${to}`;
    els.scanLiveProgress?.classList.remove('scan-error');
    scanProgressStart(state.scanLabel,`Đang lấy fixture cho khung ${from}–${to} giờ Việt Nam.`);
    saveConfig(true);loading(true,'Đang quét khung giờ',state.scanProgress.detail);
    try{
      const now=new Date();let start=localDateWithHM(now,from),end=localDateWithHM(now,to);if(end<start)end=localDateWithHM(now,to,1);
      const dates=[fmtDateInTZ(new Date(start)),fmtDateInTZ(new Date(end))];
      const fs=await fetchDatesProgress(dates,(done,total,date,count)=>{
        scanProgressStage('Đang lấy fixture theo ngày',`Đã nhận ${done}/${total} ngày • ${date}: ${count} fixture`,8+Math.round(done/Math.max(1,total)*12))
      });
      scanProgressStage('Đã nhận danh sách fixture',`Football API trả về ${fs.length} fixture • đang lọc đúng ${from}–${to}.`,20);
      const out=await filterFixturesProgress(fs,f=>{
        const ts=(f.fixture.timestamp||0)*1000;
        return ts>=start&&ts<=end&&!['FT','AET','PEN','PST','CANC','ABD','AWD','WO'].includes(f.fixture.status.short)
      },`Đang lọc ${from}–${to}`);
      scanProgressStage('Đang sắp xếp kết quả',`${out.length} trận phù hợp • đang dựng danh sách.`,96);
      out.sort((a,b)=>a.fixture.timestamp-b.fixture.timestamp);
      renderFixtures(out);
      scanProgressFinish(out.length,`Hoàn tất • ${out.length} trận trong khung ${from}–${to}.`);
      resetSlateRegime('Khung giờ PRE/custom không dùng SLATE REGIME LIVE.')
    }catch(e){
      scanProgressFail(e.message);status(els.scanStatus,e.message,'err');log('Quét khung giờ lỗi',e.message)
    }finally{state.scanning=false;loading(false)}
  });

  function statListToObject(arr){const o={};(arr||[]).forEach(s=>{if(s?.type!=null)o[s.type]=s.value});return o}
  function statMap(statsResponse){const out={};(statsResponse||[]).forEach(side=>{const key=side.team?.id;if(key==null)return;out[key]={team:side.team,stats:statListToObject(side.statistics)}});return out}
  function assignSegment(out,team,stats){if(!team?.id||!stats)return;out[team.id]={team,stats:Array.isArray(stats)?statListToObject(stats):(stats.stats||stats)}}
  function halfLabel(x){const s=String(x??'').toLowerCase();if(/(^|\D)1(\D|$)|first|1st|h1/.test(s))return 'first_half';if(/(^|\D)2(\D|$)|second|2nd|h2/.test(s))return 'second_half';if(/full|ft|total/.test(s))return 'full';return null}
  function numericStat(v){if(v==null||v===''||typeof v==='object')return null;const s=String(v).trim();if(s.endsWith('%'))return null;const n=Number(s);return Number.isFinite(n)?n:null}
  function additiveStatName(k){return /shot|blocked|foul|corner|offside|yellow|red|save|pass|expected[_ ]?goals|throw|free kick|goal kick|attack/i.test(String(k))&&!/%|possession|accuracy/i.test(String(k))}
  function deriveH2(full,h1){
    const out={};let any=false;
    Object.keys(full||{}).forEach(id=>{const f=full[id],a=h1?.[id];if(!f||!a)return;const stats={};Object.entries(f.stats||{}).forEach(([k,v])=>{if(!additiveStatName(k))return;const fv=numericStat(v),hv=numericStat(a.stats?.[k]);if(fv==null||hv==null)return;stats[k]=Math.round((fv-hv)*100)/100});if(Object.keys(stats).length){out[id]={team:f.team,stats};any=true}});
    return {map:out,derived:any};
  }
  function normalizeHalfStatistics(resp,fullFallback){
    const full=statMap(fullFallback||resp),first={},second={};
    (resp||[]).forEach(side=>{
      const team=side.team;if(!team?.id)return;
      const seg=halfLabel(side.half??side.period??side.time??side.segment);
      if(seg&&Array.isArray(side.statistics)){assignSegment(seg==='first_half'?first:seg==='second_half'?second:full,team,side.statistics)}
      const containers={
        first_half:side.statistics_1half??side.statistics_first_half??side.first_half??side.firstHalf??side.halftime,
        second_half:side.statistics_2half??side.statistics_second_half??side.second_half??side.secondHalf,
        full:side.full??side.fulltime??side.full_time
      };
      if(containers.first_half)assignSegment(first,team,containers.first_half);
      if(containers.second_half)assignSegment(second,team,containers.second_half);
      if(containers.full)assignSegment(full,team,containers.full);
      if(Array.isArray(side.statistics)){
        const f1={},f2={},ft={};
        side.statistics.forEach(s=>{
          const v=s?.value;if(v&&typeof v==='object'){
            const a=v.first_half??v.firstHalf??v.halftime??v.h1,b=v.second_half??v.secondHalf??v.h2,t=v.full??v.fulltime??v.total;
            if(a!==undefined)f1[s.type]=a;if(b!==undefined)f2[s.type]=b;if(t!==undefined)ft[s.type]=t;
          }
          const a=s?.halftime??s?.first_half??s?.firstHalf,b=s?.second_half??s?.secondHalf;
          if(a!==undefined)f1[s.type]=a;if(b!==undefined)f2[s.type]=b;
        });
        if(Object.keys(f1).length)assignSegment(first,team,{stats:f1});if(Object.keys(f2).length)assignSegment(second,team,{stats:f2});if(Object.keys(ft).length)assignSegment(full,team,{stats:ft});
      }
    });
    let derived=false;if(!Object.keys(second).length&&Object.keys(full).length&&Object.keys(first).length){const d=deriveH2(full,first);Object.assign(second,d.map);derived=d.derived}
    return {full,first_half:first,second_half:second,second_half_derived:derived};
  }
  function eventsCompact(events){return (events||[]).slice(-90).map(e=>({time:e.time?.elapsed,extra:e.time?.extra,team:e.team?.name,team_id:e.team?.id,player:e.player?.name,player_id:e.player?.id,assist:e.assist?.name||null,assist_id:e.assist?.id||null,type:e.type,detail:e.detail,comments:e.comments||null}))}
  function marketCategoryFromName(name){
    const s=String(name||'').toLowerCase().replace(/[–—]/g,'-').replace(/\s+/g,' ').trim();

    if(/corner/.test(s))return 'corners';

    if(/first half|1st half|half time|halftime|first-half/.test(s)){
      if(/handicap result|european handicap|3[- ]?way handicap/.test(s))return 'h1_handicap_result';
      if(/asian handicap/.test(s)||(/\bhandicap\b/.test(s)&&!/result/.test(s)))return 'h1_handicap';
      if(/over|under|total|goal/.test(s))return 'h1_total';
    }

    if(/second half|2nd half|second-half/.test(s)){
      if(/handicap result|european handicap|3[- ]?way handicap/.test(s))return 'h2_handicap_result';
      if(/asian handicap/.test(s)||(/\bhandicap\b/.test(s)&&!/result/.test(s)))return 'h2_handicap';
      if(/over|under|total|goal/.test(s))return 'h2_total';
    }

    if(/team.*total|total.*team|home.*over|away.*over|home.*under|away.*under/.test(s))return 'team_total';
    if(/handicap result|european handicap|3[- ]?way handicap/.test(s))return 'handicap_result';
    if(/asian handicap/.test(s))return 'asian_handicap';
    if(/^handicap$/.test(s))return 'handicap_result';
    if(/match winner|winner|1x2|home\/draw\/away/.test(s))return 'match_winner';
    if(/over|under|total goals|goals over|goals under|over\/under/.test(s))return 'over_under';
    return null;
  }
  function marketIdentity(name,betId,source='prematch',betRefs=null){
    const ref=betReferenceLookup(betRefs,betId);
    const canonical=ref?.name||name||'';
    return {
      category:marketCategoryFromName(canonical),
      canonical_name:canonical||null,
      feed_name:name||null,
      bet_id:betId??null,
      mapped_by:ref?'BET_ID_REFERENCE':'NAME_FALLBACK',
      reference_source:ref?.source||source
    };
  }

  const MARKET_PRIORITY=[
    'asian_handicap','match_winner','over_under',
    'h1_handicap','h1_total','h2_handicap','h2_total',
    'team_total','handicap_result','h1_handicap_result','h2_handicap_result','corners'
  ];

  const ASIAN_HANDICAP_CATEGORIES=new Set(['asian_handicap','h1_handicap','h2_handicap']);
  const HANDICAP_RESULT_CATEGORIES=new Set(['handicap_result','h1_handicap_result','h2_handicap_result']);
  const ALL_HANDICAP_CATEGORIES=new Set([...ASIAN_HANDICAP_CATEGORIES,...HANDICAP_RESULT_CATEGORIES]);

  // Backward-compatible alias for display helpers that only need to know
  // whether a handicap number exists. Validation MUST use the two sets above.
  const HANDICAP_CATEGORIES=ALL_HANDICAP_CATEGORIES;

  function numericHandicap(v){
    if(v===null||v===undefined||v==='')return null;
    const n=Number(String(v).replace(',','.').replace(/[^0-9+\-.]/g,''));
    return Number.isFinite(n)?n:null;
  }

  function handicapFromLabel(label){
    const s=String(label||'').trim();
    const m=s.match(/([+-]?\d+(?:[.,]\d+)?)\s*$/);
    return m?numericHandicap(m[1]):null;
  }

  function normalizedKey(v){
    return String(v||'')
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  }

  function selectionOutcome(label,ctx={}){
    const s=normalizedKey(label);
    if(!s)return null;

    if(/^(draw|x|tie)(\s|$)/.test(s)||/\bdraw\b/.test(s))return 'draw';
    if(/^(home|home team|team 1)(\s|$)/.test(s)||/\bhome\b/.test(s))return 'home';
    if(/^(away|away team|team 2)(\s|$)/.test(s)||/\baway\b/.test(s))return 'away';
    if(/^1(\s|$)/.test(s))return 'home';
    if(/^x(\s|$)/.test(s))return 'draw';
    if(/^2(\s|$)/.test(s))return 'away';

    const hk=normalizedKey(ctx.homeName),ak=normalizedKey(ctx.awayName);
    if(hk && (s===hk || s.startsWith(hk+' ') || s.includes(' '+hk+' ')))return 'home';
    if(ak && (s===ak || s.startsWith(ak+' ') || s.includes(' '+ak+' ')))return 'away';
    return null;
  }

  function selectionSide(label,ctx={}){
    const o=selectionOutcome(label,ctx);
    return o==='home'||o==='away'?o:null;
  }

  function sameAbs(a,b){
    return Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(Math.abs(a)-Math.abs(b))<1e-9;
  }

  // Validator #1: ASIAN HANDICAP
  // Two-way market. Home/Away lines should be complementary, e.g. -0.5 / +0.5.
  function asianHandicapIntegrity(values,category,ctx={}){
    if(!ASIAN_HANDICAP_CATEGORIES.has(category)){
      return {valid:true,status:'not_applicable',warnings:[],trusted:true,validator:'ASIAN_HANDICAP'};
    }

    const active=(values||[]).filter(v=>!v.suspended);
    if(!active.length){
      return {valid:false,status:'no_active_values',warnings:['AH_NO_ACTIVE_VALUES'],trusted:false,validator:'ASIAN_HANDICAP'};
    }

    const primary=active.some(v=>v.main===true)?active.filter(v=>v.main===true):active;
    const warnings=[];
    let home=primary.find(v=>v.selection_outcome==='home'||v.selection_side==='home');
    let away=primary.find(v=>v.selection_outcome==='away'||v.selection_side==='away');

    // Some feeds mark only one selection main=true. Find the opposite side on
    // the same absolute line from all active values.
    if(home&&!away){
      const h=numericHandicap(home.handicap);
      away=active.find(v=>(v.selection_outcome==='away'||v.selection_side==='away')&&sameAbs(numericHandicap(v.handicap),h))
        || active.find(v=>v.selection_outcome==='away'||v.selection_side==='away');
    }
    if(away&&!home){
      const a=numericHandicap(away.handicap);
      home=active.find(v=>(v.selection_outcome==='home'||v.selection_side==='home')&&sameAbs(numericHandicap(v.handicap),a))
        || active.find(v=>v.selection_outcome==='home'||v.selection_side==='home');
    }

    if(!home||!away){
      const numeric=primary
        .map(v=>({n:numericHandicap(v.handicap),outcome:v.selection_outcome,value:v.value}))
        .filter(x=>Number.isFinite(x.n));

      if(numeric.length===2){
        const [x,y]=numeric;
        if(Math.abs(x.n+y.n)<1e-9){
          return {
            valid:true,status:'complementary_unlabeled',
            warnings:['AH_PAIR_SIDE_LABEL_NOT_EXPLICIT'],
            trusted:false,validator:'ASIAN_HANDICAP'
          };
        }
        if(sameAbs(x.n,y.n)&&Math.sign(x.n)===Math.sign(y.n)&&x.n!==0){
          return {
            valid:false,status:'same_sign_pair_unlabeled',
            warnings:[`AH_IMPOSSIBLE_PAIR ${x.n} / ${y.n}`],
            trusted:false,validator:'ASIAN_HANDICAP'
          };
        }
      }

      return {
        valid:true,status:'unpaired',
        warnings:['AH_PAIR_NOT_EXPLICIT'],
        trusted:false,validator:'ASIAN_HANDICAP'
      };
    }

    const h=numericHandicap(home.handicap),a=numericHandicap(away.handicap);
    if(h===null||a===null){
      return {
        valid:false,status:'missing_line',
        warnings:['AH_HANDICAP_MISSING'],
        trusted:false,validator:'ASIAN_HANDICAP'
      };
    }

    if(Math.abs(h+a)<1e-9){
      return {valid:true,status:'complementary',warnings, trusted:true,validator:'ASIAN_HANDICAP'};
    }

    if(sameAbs(h,a)&&Math.sign(h)===Math.sign(a)&&h!==0){
      warnings.push(`AH_IMPOSSIBLE_PAIR home ${h} / away ${a}`);
      return {
        valid:false,status:'same_sign_pair',
        warnings,trusted:false,validator:'ASIAN_HANDICAP'
      };
    }

    warnings.push(`AH_NON_COMPLEMENTARY home ${h} / away ${a}`);
    return {
      valid:false,status:'non_complementary',
      warnings,trusted:false,validator:'ASIAN_HANDICAP'
    };
  }

  // Validator #2: HANDICAP RESULT / EUROPEAN HANDICAP
  // Usually a 3-way result market: Home / Draw / Away. The same handicap may
  // legitimately appear on all three selections. Therefore NO complementary
  // sign rule and NO AH_IMPOSSIBLE_PAIR warning is allowed here.
  function handicapResultIntegrity(values,category,ctx={}){
    if(!HANDICAP_RESULT_CATEGORIES.has(category)){
      return {valid:true,status:'not_applicable',warnings:[],trusted:true,validator:'HANDICAP_RESULT'};
    }

    const active=(values||[]).filter(v=>!v.suspended);
    if(!active.length){
      return {
        valid:false,status:'no_active_values',
        warnings:['HR_NO_ACTIVE_VALUES'],
        trusted:false,validator:'HANDICAP_RESULT'
      };
    }

    const outcomes=new Set(active.map(v=>v.selection_outcome).filter(Boolean));
    const numericLines=active.map(v=>numericHandicap(v.handicap)).filter(Number.isFinite);

    // A normal Handicap Result is 3-way. If labels are not explicit, keep it
    // usable only as unverified rather than pretending it is Asian Handicap.
    if(outcomes.has('home')&&outcomes.has('draw')&&outcomes.has('away')){
      return {
        valid:true,status:'three_way_result',
        warnings:[],trusted:true,validator:'HANDICAP_RESULT'
      };
    }

    if(active.length>=3){
      return {
        valid:true,status:'three_way_unlabeled',
        warnings:['HR_SELECTION_LABELS_NOT_EXPLICIT'],
        trusted:false,validator:'HANDICAP_RESULT'
      };
    }

    // Two-way/incomplete feed: do not apply Asian sign logic. Mark as
    // incomplete/untrusted and exclude from main executable lines.
    return {
      valid:false,status:'incomplete_result_market',
      warnings:[`HR_SELECTIONS_INCOMPLETE n=${active.length}`],
      trusted:false,validator:'HANDICAP_RESULT'
    };
  }

  function marketIntegrity(values,category,ctx={}){
    if(ASIAN_HANDICAP_CATEGORIES.has(category))return asianHandicapIntegrity(values,category,ctx);
    if(HANDICAP_RESULT_CATEGORIES.has(category))return handicapResultIntegrity(values,category,ctx);
    return {valid:true,status:'not_applicable',warnings:[],trusted:true,validator:'NONE'};
  }

  function compactOddsValues(values,isLive=false,category=null,ctx={}){
    const src=(values||[]).map(v=>{
      const value=v?.value??v?.name??v?.label??'';
      const raw=v?.handicap??null;
      const parsed=numericHandicap(raw)??(ALL_HANDICAP_CATEGORIES.has(category)?handicapFromLabel(value):null);
      return {
        value,
        odd:v?.odd??v?.price??null,
        handicap:parsed,
        raw_handicap:raw,
        selection_outcome:ALL_HANDICAP_CATEGORIES.has(category)?selectionOutcome(value,ctx):null,
        selection_side:ASIAN_HANDICAP_CATEGORIES.has(category)?selectionSide(value,ctx):null,
        main:v?.main??null,
        suspended:!!v?.suspended
      };
    });

    let picked;
    if(!isLive){
      picked=src.slice(0,10);
    }else{
      const mains=src.filter(v=>v.main===true);
      if(mains.length){
        if(ASIAN_HANDICAP_CATEGORIES.has(category)){
          const absLines=new Set(mains.map(v=>numericHandicap(v.handicap)).filter(Number.isFinite).map(Math.abs));
          picked=src.filter(v=>v.main===true||absLines.has(Math.abs(numericHandicap(v.handicap)))).slice(0,10);
        }else if(HANDICAP_RESULT_CATEGORIES.has(category)){
          const lineSet=new Set(mains.map(v=>String(v.handicap??'')));
          picked=src.filter(v=>v.main===true||lineSet.has(String(v.handicap??''))).slice(0,10);
        }else{
          const hs=new Set(mains.map(v=>String(v.handicap??'')));
          picked=src.filter(v=>v.main===true||hs.has(String(v.handicap??''))).slice(0,10);
        }
      }else if(ALL_HANDICAP_CATEGORIES.has(category)){
        picked=src.slice(0,8);
      }else{
        const firstH=src.find(v=>v.handicap!=null)?.handicap;
        if(firstH!=null){
          const group=src.filter(v=>String(v.handicap)===String(firstH));
          picked=group.length?group.slice(0,8):src.slice(0,8);
        }else picked=src.slice(0,8);
      }
    }
    return picked;
  }

  function marketContextFromResponse(r,fallback={}){
    return {
      homeName:r?.teams?.home?.name||r?.fixture?.teams?.home?.name||fallback.homeName||null,
      awayName:r?.teams?.away?.name||r?.fixture?.teams?.away?.name||fallback.awayName||null
    };
  }

  function normalizePrematchMarkets(resp,ctx={}){
    const out=[];
    (resp||[]).forEach(r=>{
      const rctx=marketContextFromResponse(r,ctx);
      (r.bookmakers||[]).slice(0,4).forEach(b=>{
        (b.bets||[]).forEach(bet=>{
          const ident=marketIdentity(bet.name,bet.id,'prematch',ctx.betRefs?.prematch);
          const category=ident.category;
          if(!category)return;
          const values=compactOddsValues(bet.values,false,category,rctx);
          const integrity=marketIntegrity(values,category,rctx);
          out.push({
            source:'prematch',bookmaker:b.name||null,update:r.update??null,
            bet_id:bet.id??null,bet:ident.canonical_name||bet.name,feed_bet_name:bet.name||null,
            bet_reference:{mapped_by:ident.mapped_by,canonical_name:ident.canonical_name,reference_source:ident.reference_source},
            category,integrity,values
          });
        });
      });
    });
    return out.sort((a,b)=>MARKET_PRIORITY.indexOf(a.category)-MARKET_PRIORITY.indexOf(b.category)).slice(0,24);
  }

  function normalizeLiveMarkets(resp,ctx={}){
    const out=[];
    (resp||[]).forEach(r=>{
      const rctx=marketContextFromResponse(r,ctx);
      const status={
        stopped:!!r.status?.stopped,
        blocked:!!r.status?.blocked,
        finished:!!r.status?.finished
      };
      const bets=Array.isArray(r.odds)?r.odds:[];
      bets.forEach(bet=>{
        const ident=marketIdentity(bet.name,bet.id,'live',ctx.betRefs?.live);
        const category=ident.category;
        if(!category)return;
        const values=compactOddsValues(bet.values,true,category,rctx);
        const integrity=marketIntegrity(values,category,rctx);
        const usable=integrity.valid?values.filter(v=>!v.suspended):[];
        const mainV=usable.find(v=>v.main===true)||usable[0]||null;
        out.push({
          source:'live',fixture_id:r.fixture?.id??null,fixture_status:r.fixture?.status??null,
          feed_status:status,update:r.update??null,bet_id:bet.id??null,
          bet:ident.canonical_name||bet.name,feed_bet_name:bet.name||null,
          bet_reference:{mapped_by:ident.mapped_by,canonical_name:ident.canonical_name,reference_source:ident.reference_source},
          category,integrity,main_line:mainV?.handicap??mainV?.value??null,values
        });
      });
    });
    return out.sort((a,b)=>MARKET_PRIORITY.indexOf(a.category)-MARKET_PRIORITY.indexOf(b.category)).slice(0,24);
  }

  function oddsCompact(resp,live=false,ctx={}){
    const markets=live?normalizeLiveMarkets(resp,ctx):normalizePrematchMarkets(resp,ctx);
    return markets.map(m=>({
      bookmaker:m.bookmaker||'LIVE_FEED',
      market:m.bet,
      category:m.category,
      main_line:m.main_line??null,
      status:m.feed_status??null,
      update:m.update??null,
      integrity:m.integrity??null,
      bet_id:m.bet_id??null,
      bet_reference:m.bet_reference??null,
      values:m.values
    })).slice(0,60);
  }

  function mainLines(markets){
    const o={};
    for(const m of (markets||[])){
      if(o[m.category]||m.integrity?.valid===false)continue;
      const vals=(m.values||[]).filter(v=>!v.suspended);
      if(!vals.length)continue;
      o[m.category]={
        bet:m.bet,bookmaker:m.bookmaker||null,
        line:m.main_line??vals[0]?.handicap??vals[0]?.value??null,
        values:vals.slice(0,6),status:m.feed_status||null,update:m.update||null,
        integrity:m.integrity||null
      };
    }
    return o;
  }
  function recentCompact(fs){return (fs||[]).slice(0,8).map(f=>({date:f.fixture?.date,status:f.fixture?.status?.short,league:f.league?.name,home:f.teams?.home?.name,away:f.teams?.away?.name,goals:f.goals,home_id:f.teams?.home?.id,away_id:f.teams?.away?.id}))}
  function lineupPlayer(p){const x=p?.player||p||{};return {id:x.id??null,name:x.name??null,number:x.number??null,pos:x.pos??null,grid:x.grid??null}}
  function lineupsCompact(x){return (x||[]).map(t=>({team:t.team?.name,team_id:t.team?.id,formation:t.formation,coach:t.coach?{id:t.coach.id,name:t.coach.name}:null,startXI:(t.startXI||[]).map(lineupPlayer).slice(0,11),subs:(t.substitutes||[]).map(lineupPlayer).slice(0,15)}))}
  function injuriesCompact(x){return (x||[]).slice(0,40).map(i=>({team:i.team?.name,team_id:i.team?.id,player:i.player?.name,player_id:i.player?.id,type:i.player?.type??i.type??null,reason:i.player?.reason??i.reason??null,fixture_id:i.fixture?.id??null}))}
  function standingsCompact(x){const league=x?.[0]?.league;const arr=league?.standings?.flat?.()||[];return arr.slice(0,30).map(s=>({rank:s.rank,team:s.team?.name,team_id:s.team?.id,points:s.points,goalsDiff:s.goalsDiff,form:s.form,group:s.group,all:s.all,home:s.home,away:s.away}))}
  function teamStatsCompact(x){
    if(!x||Array.isArray(x))return null;return {form:x.form||null,fixtures:x.fixtures||null,goals:x.goals?{for:{total:x.goals.for?.total,average:x.goals.for?.average},against:{total:x.goals.against?.total,average:x.goals.against?.average}}:null,biggest:x.biggest||null,clean_sheet:x.clean_sheet||null,failed_to_score:x.failed_to_score||null,lineups:(x.lineups||[]).slice(0,5),cards:x.cards||null}
  }
  function playersMatchCompact(resp){
    return (resp||[]).map(team=>({team:team.team?.name,team_id:team.team?.id,players:(team.players||[]).map(p=>{const s=p.statistics?.[0]||{},g=s.games||{};return {id:p.player?.id,name:p.player?.name,minutes:g.minutes??null,rating:g.rating??null,position:g.position??null,captain:!!g.captain,substitute:!!g.substitute,shots:s.shots||null,goals:s.goals||null,passes:s.passes?{total:s.passes.total,key:s.passes.key,accuracy:s.passes.accuracy}:null,tackles:s.tackles||null,duels:s.duels?{total:s.duels.total,won:s.duels.won}:null,dribbles:s.dribbles?{attempts:s.dribbles.attempts,success:s.dribbles.success}:null,fouls:s.fouls||null,cards:s.cards||null,penalty:s.penalty||null}}).filter(p=>(Number(p.minutes)||0)>0||p.rating||p.substitute).sort((a,b)=>(Number(b.minutes)||0)-(Number(a.minutes)||0)).slice(0,18)}))
  }
  function predictionCompact(resp){
    const r=resp?.[0];if(!r)return null;const p=r.predictions||r;return {winner:p.winner||null,win_or_draw:p.win_or_draw??null,under_over:p.under_over??null,goals:{home:p.goals?.home??null,away:p.goals?.away??null},advice:p.advice??null,percent:p.percent??null,comparison:r.comparison||null}
  }
  function sourceFlag(data){return data!=null&&(!(Array.isArray(data))||data.length>0)}
  function snapshotFixtureMeta(s,f,mode,requestedMode){const x=s||f;return {mode,requested_mode:requestedMode,timezone:TZ,fixture_id:x.fixture?.id||f.fixture?.id,kickoff_vn:x.fixture?.timestamp?fmtDateTime(x.fixture.timestamp):null,league:x.league||f.league,fixture:x.fixture||f.fixture,teams:x.teams||f.teams,goals:x.goals||f.goals,score:x.score||f.score,referee:x.fixture?.referee??null,venue:x.fixture?.venue??null}}

  async function getDeepBundle(f,requestedMode){
    const id=f.fixture.id,home=f.teams.home.id,away=f.teams.away.id,league=f.league.id,season=f.league.season;

    // A) Deep fixture snapshot first.
    const fixtureResp=await football('/fixtures',{id,timezone:TZ},true);
    const snap=fixtureResp?.[0]||null;
    const current=snap||f,liveNow=isLive(current),actualMode=liveNow?autoModeForFixture(current):'PRE';

    // B) Bootstrap references once per league/season + separate PRE/LIVE bet ID maps.
    const [apiCoverage,preBetRef,liveBetRef]=await Promise.all([
      getLeagueCoverage(league,season),
      getBetReference('prematch'),
      liveNow?getBetReference('live'):Promise.resolve({source:'live',count:0,byId:{}})
    ]);
    const betRefs={prematch:preBetRef,live:liveBetRef};

    const nested={events:snap?.events,lineups:snap?.lineups,statistics:snap?.statistics,players:snap?.players};
    const skips=coverageSkipList(apiCoverage,[
      'fixtures.events','fixtures.lineups','fixtures.statistics_fixtures','fixtures.statistics_players',
      'standings','injuries','predictions','odds'
    ]);

    // C) Only call an endpoint when: nested snapshot does not already contain it AND league coverage does not explicitly say false.
    const jobs={
      half_statistics:liveNow&&coverageAllows(apiCoverage,'fixtures.statistics_fixtures')
        ?football('/fixtures/statistics',{fixture:id,half:true},true):Promise.resolve(null),
      events:sourceFlag(nested.events)
        ?Promise.resolve(nested.events)
        :(liveNow&&coverageAllows(apiCoverage,'fixtures.events')?football('/fixtures/events',{fixture:id},true):Promise.resolve(null)),
      lineups:sourceFlag(nested.lineups)
        ?Promise.resolve(nested.lineups)
        :(coverageAllows(apiCoverage,'fixtures.lineups')?footballCached('/fixtures/lineups',{fixture:id},CACHE_TTL.lineups,true):Promise.resolve(null)),
      players_match:sourceFlag(nested.players)
        ?Promise.resolve(nested.players)
        :(liveNow&&coverageAllows(apiCoverage,'fixtures.statistics_players')?football('/fixtures/players',{fixture:id},true):Promise.resolve(null)),
      injuries:coverageAllows(apiCoverage,'injuries')
        ?footballCached('/injuries',{fixture:id},CACHE_TTL.injuries,true):Promise.resolve(null),
      odds:coverageAllows(apiCoverage,'odds')
        ?footballCached('/odds',{fixture:id},CACHE_TTL.prematch_odds,true):Promise.resolve(null),
      live_odds:liveNow&&coverageAllows(apiCoverage,'odds')
        ?football('/odds/live',{fixture:id},true):Promise.resolve(null),
      h2h:footballCached('/fixtures/headtohead',{h2h:`${home}-${away}`,last:7},CACHE_TTL.h2h,true),
      home_recent:footballCached('/fixtures',{team:home,last:8},CACHE_TTL.recent,true),
      away_recent:footballCached('/fixtures',{team:away,last:8},CACHE_TTL.recent,true),
      standings:league&&season&&coverageAllows(apiCoverage,'standings')
        ?footballCached('/standings',{league,season},CACHE_TTL.standings,true):Promise.resolve(null),
      home_team_stats:league&&season
        ?footballCached('/teams/statistics',{league,season,team:home},CACHE_TTL.team_stats,true):Promise.resolve(null),
      away_team_stats:league&&season
        ?footballCached('/teams/statistics',{league,season,team:away},CACHE_TTL.team_stats,true):Promise.resolve(null),
      prediction:coverageAllows(apiCoverage,'predictions')
        ?footballCached('/predictions',{fixture:id},CACHE_TTL.prediction,true):Promise.resolve(null)
    };
    const keys=Object.keys(jobs),vals=await Promise.all(keys.map(k=>jobs[k]));
    const sr={};keys.forEach((k,i)=>sr[k]=vals[i]);
    const cacheStatus=cacheRuntimeSummary({
      lineups:['/fixtures/lineups',{fixture:id}],injuries:['/injuries',{fixture:id}],
      prematch_odds:['/odds',{fixture:id}],h2h:['/fixtures/headtohead',{h2h:`${home}-${away}`,last:7}],
      home_recent:['/fixtures',{team:home,last:8}],away_recent:['/fixtures',{team:away,last:8}],
      standings:['/standings',{league,season}],home_team_stats:['/teams/statistics',{league,season,team:home}],
      away_team_stats:['/teams/statistics',{league,season,team:away}],prediction:['/predictions',{fixture:id}]
    });

    const fullFallback=sourceFlag(nested.statistics)?nested.statistics:sr.half_statistics;
    const liveStats=liveNow?normalizeHalfStatistics(sr.half_statistics,fullFallback):{full:{},first_half:{},second_half:{},second_half_derived:false};
    const marketCtx={
      homeName:current.teams?.home?.name||f.teams.home.name,
      awayName:current.teams?.away?.name||f.teams.away.name,
      betRefs
    };
    const preMarkets=normalizePrematchMarkets(sr.odds,marketCtx);
    const liveMarkets=normalizeLiveMarkets(sr.live_odds,marketCtx);

    // D) Capture local live market history every time LIVE odds are actually fetched.
    const history=liveNow?saveLiveOddsSnapshot(id,{
      fixture:current.fixture,goals:current.goals
    },liveMarkets):{snapshot_count:0,status:'NOT_LIVE',window_minutes:0,categories:{},timeline:[]};

    const allStandings=standingsCompact(sr.standings);
    const bundle={
      meta:snapshotFixtureMeta(snap,f,actualMode,requestedMode),
      normalized:{
        cache_status:cacheStatus,
        api_coverage:{...apiCoverage,skipped_endpoints:skips},
        bet_reference:{
          prematch:{count:preBetRef.count,source:preBetRef.source},
          live:{count:liveBetRef.count,source:liveBetRef.source}
        },
        live_statistics:liveStats,
        events:eventsCompact(sr.events),
        lineups:lineupsCompact(sr.lineups),
        player_match_stats:playersMatchCompact(sr.players_match),
        injuries:injuriesCompact(sr.injuries),
        h2h:recentCompact(sr.h2h),
        home_recent:recentCompact(sr.home_recent),
        away_recent:recentCompact(sr.away_recent),
        recent_sample:{
          home:recentCompact(sr.home_recent).slice(0,5).length,
          away:recentCompact(sr.away_recent).slice(0,5).length,
          requested:8
        },
        standings:standingsForTeams(allStandings,current.teams?.home?.name||f.teams.home.name,current.teams?.away?.name||f.teams.away.name),
        home_team_stats:teamStatsCompact(sr.home_team_stats),
        away_team_stats:teamStatsCompact(sr.away_team_stats),
        api_prediction:predictionCompact(sr.prediction),
        market:{
          prematch:preMarkets,
          live:liveMarkets,
          main_lines:{prematch:mainLines(preMarkets),live:mainLines(liveMarkets)},
          live_history:history
        }
      },
      data_sources:{
        league_coverage:apiCoverage.known,
        bet_reference_prematch:preBetRef.count>0,
        bet_reference_live:liveNow?liveBetRef.count>0:null,
        fixture_deep:sourceFlag(fixtureResp),
        statistics_half:sourceFlag(sr.half_statistics),
        events:sourceFlag(sr.events),
        lineups:sourceFlag(sr.lineups),
        players_match:sourceFlag(sr.players_match),
        injuries:sourceFlag(sr.injuries),
        prematch_odds:sourceFlag(sr.odds),
        live_odds:sourceFlag(sr.live_odds),
        live_odds_history:history.snapshot_count>0,
        h2h:sourceFlag(sr.h2h),
        recent:sourceFlag(sr.home_recent)&&sourceFlag(sr.away_recent),
        standings:sourceFlag(sr.standings),
        team_stats:sourceFlag(sr.home_team_stats)&&sourceFlag(sr.away_team_stats),
        api_prediction:sourceFlag(sr.prediction)
      },
      api_usage:apiUsageSnapshot()
    };
    bundle.coverage=coverageScore(bundle);
    const staleSources=Object.entries(cacheStatus).filter(([,x])=>x?.status==='CACHE_STALE').map(([k,x])=>`${k} ${x.age_sec}s`);
    if(staleSources.length)bundle.coverage.warnings=[...new Set([...(bundle.coverage.warnings||[]),`CACHE_STALE ${staleSources.join(', ')}`])].slice(0,12);
    return bundle
  }

  function marketIntegrityScore(markets){
    const warnings=[];let score=100,checked=0,invalid=0;
    for(const m of (markets||[])){
      if(m.integrity){checked++;if(m.integrity.valid===false){invalid++;score-=45;(m.integrity.warnings||[]).forEach(w=>warnings.push(`${m.category||m.market||'market'}: ${w}`))}}
      for(const v of (m.values||[])){
        const odd=Number(v.odd);if(v.odd!=null&&(!Number.isFinite(odd)||odd<=1)){score-=12;warnings.push(`${m.category||m.market||'market'}: ODD_INVALID ${v.odd}`)}
      }
    }
    return {score:Math.max(0,Math.min(100,score)),warnings,checked,invalid};
  }
  function parseUpdateMs(v){if(v===null||v===undefined||v==='')return null;if(typeof v==='number'){const t=v<1e12?v*1000:v;return Number.isFinite(t)?t:null}const n=Number(v);if(Number.isFinite(n)&&String(v).trim()!=='')return n<1e12?n*1000:n;const t=Date.parse(v);return Number.isFinite(t)?t:null}
  function marketFreshness(markets,live){
    const rows=(markets||[]);

    // No market exists at all: this is a COVERAGE issue, not a freshness issue.
    // Do NOT emit NO_MARKET_TIMESTAMP and do NOT manufacture a freshness score.
    if(!rows.length){
      return {
        score:null,
        applicable:false,
        age_min:null,
        note:null,
        status:'NO_MARKET_DATA'
      };
    }

    const times=rows.map(m=>parseUpdateMs(m.update)).filter(Number.isFinite);
    let note=null;
    let score;
    let age=null;

    // Market exists but the feed did not provide an update timestamp.
    if(!times.length){
      score=live?65:75;
      note='NO_MARKET_TIMESTAMP';
    }else{
      age=Math.max(0,(Date.now()-Math.max(...times))/60000);
      if(live)score=age<=2?100:age<=5?90:age<=10?75:age<=20?50:25;
      else score=age<=360?100:age<=1440?85:age<=2880?65:40;
    }

    if(live){
      const feedUnavailable=rows.every(m=>m.status?.blocked||m.status?.stopped||m.status?.finished);
      const allSuspended=rows.every(m=>(m.values||[]).length>0&&(m.values||[]).every(v=>v.suspended));

      if(feedUnavailable){
        score=Math.min(score,35);
        note=note?note+'; LIVE_MARKET_BLOCKED_OR_STOPPED':'LIVE_MARKET_BLOCKED_OR_STOPPED';
      }
      if(allSuspended){
        score=Math.min(score,30);
        note=note?note+'; LIVE_MARKET_ALL_SUSPENDED':'LIVE_MARKET_ALL_SUSPENDED';
      }
    }

    return {
      score,
      applicable:true,
      age_min:age==null?null:Math.round(age*10)/10,
      note,
      status:'MARKET_PRESENT'
    };
  }

  function dataQuality(mode,n,coverage,meta){
    const live=mode!=='PRE';
    const markets=live?(n.market?.live||n.live_odds||[]):(n.market?.prematch||n.odds||[]);
    const mi=marketIntegrityScore(markets);

    let integrity=mi.score;
    const warnings=[...mi.warnings];

    const hn=(n.home_recent||[]).slice(0,5).length;
    const an=(n.away_recent||[]).slice(0,5).length;
    const minN=Math.min(hn||0,an||0);

    if(minN>0&&minN<3){
      integrity=Math.max(0,integrity-(live?5:10));
      warnings.push(`RECENT_SAMPLE_LOW H=${hn} A=${an}`);
    }

    const fr=marketFreshness(markets,live);
    if(fr.note)warnings.push(fr.note);

    // Coverage owns "market missing". Freshness only evaluates a market that exists.
    const parts=[
      {score:coverage,weight:45},
      {score:integrity,weight:40}
    ];
    if(fr.applicable&&Number.isFinite(fr.score)){
      parts.push({score:fr.score,weight:15});
    }

    const weightSum=parts.reduce((s,p)=>s+p.weight,0);
    const overall=Math.round(parts.reduce((s,p)=>s+p.score*p.weight,0)/Math.max(1,weightSum));

    return {
      score:overall,
      coverage_score:coverage,
      integrity_score:Math.round(integrity),
      freshness_score:fr.applicable?Math.round(fr.score):null,
      freshness_applicable:fr.applicable,
      freshness_status:fr.status,
      freshness_age_min:fr.age_min,
      sample_sizes:{home_recent:hn,away_recent:an},
      market_integrity:{
        applicable:markets.length>0,
        checked:mi.checked,
        invalid:mi.invalid
      },
      warnings:[...new Set(warnings)].slice(0,12)
    };
  }

  function coverageScore(b){
    const n=b.normalized||{},ls=n.live_statistics||{},live=b.meta.mode!=='PRE';
    const checks={fixture:!!b.meta?.fixture_id,stats_full:Object.keys(ls.full||{}).length>0,stats_h1:Object.keys(ls.first_half||{}).length>0,stats_h2:Object.keys(ls.second_half||{}).length>0,events:(n.events||[]).length>0,lineups:(n.lineups||[]).length>0,players_match:(n.player_match_stats||[]).some(t=>(t.players||[]).length),injuries:(n.injuries||[]).length>0,prematch_odds:(n.market?.prematch||[]).length>0,live_odds:(n.market?.live||[]).length>0,h2h:(n.h2h||[]).length>0,recent:(n.home_recent||[]).length>0&&(n.away_recent||[]).length>0,standings:(n.standings||[]).length>0,team_stats:!!n.home_team_stats&&!!n.away_team_stats,prediction:!!n.api_prediction};
    const weights=live?{fixture:8,stats_full:13,stats_h1:8,stats_h2:8,events:8,lineups:5,players_match:8,injuries:4,prematch_odds:5,live_odds:12,h2h:4,recent:5,standings:3,team_stats:4,prediction:5}:{fixture:10,lineups:8,injuries:8,prematch_odds:13,h2h:8,recent:14,standings:8,team_stats:15,prediction:16};
    let got=0,total=0;Object.entries(weights).forEach(([k,w])=>{total+=w;if(checks[k])got+=w});const cov=Math.round(got/Math.max(1,total)*100);return {...dataQuality(b.meta.mode,n,cov,b.meta),checks}
  }
  function renderCoverage(c){els.coverage.classList.remove('hidden');const chips=Object.entries(c.checks).map(([k,v])=>`<span class="chip ${v?'y':'n'}">${v?'✓':'×'} ${esc(k)}</span>`).join('\n\n');const warn=(c.warnings||[]).length?`<div style="margin-top:8px;color:#f7c96a;font-size:12px">⚠ ${esc(c.warnings.join(' • '))}</div>`:'';const fresh=c.freshness_applicable?`${c.freshness_score}%`:'N/A';els.coverage.innerHTML=`<div class="status"><b>DQ ${c.score}%</b> • Coverage ${c.coverage_score}% • Integrity ${c.integrity_score}% • Freshness ${fresh}<div class="datachips" style="margin-top:7px">${chips}</div>${warn}</div>`}


  function autoModeForFixture(f){
    const st=f?.fixture?.status?.short||'';
    if(!isLive(f))return 'PRE';
    return st==='1H'?'H1':'FT';
  }
  function compactFixtureMeta(f,mode){
    return {
      mode,
      fixture_id:f.fixture?.id,
      league:{id:f.league?.id,name:f.league?.name,country:f.league?.country,season:f.league?.season,round:f.league?.round},
      fixture:{date:f.fixture?.date,timestamp:f.fixture?.timestamp,status:f.fixture?.status,venue:f.fixture?.venue},
      teams:{home:{id:f.teams?.home?.id,name:f.teams?.home?.name},away:{id:f.teams?.away?.id,name:f.teams?.away?.name}},
      goals:f.goals,score:f.score
    };
  }
  function groupCoverageScore(mode,n){
    let checks,weights;
    if(mode==='PRE'){
      checks={fixture:true,recent:(n.home_recent||[]).length>0&&(n.away_recent||[]).length>0,odds:(n.odds||[]).length>0,standings:(n.standings||[]).length>0,team_stats:!!n.home_team_stats&&!!n.away_team_stats};
      weights={fixture:15,recent:30,odds:25,standings:15,team_stats:15};
    }else{
      checks={fixture:true,statistics:Object.keys(n.live_statistics||{}).length>0,events:(n.events||[]).length>0,live_odds:(n.live_odds||[]).length>0,recent:(n.home_recent||[]).length>0&&(n.away_recent||[]).length>0,odds:(n.odds||[]).length>0,standings:(n.standings||[]).length>0};
      weights={fixture:10,statistics:25,events:15,live_odds:22,recent:15,odds:5,standings:8};
    }
    let got=0,total=0;Object.keys(weights).forEach(k=>{total+=weights[k];if(checks[k])got+=weights[k]});const cov=Math.round(got/Math.max(1,total)*100);return {...dataQuality(mode,n,cov,null),checks};
  }
  function standingsForTeams(rows,homeName,awayName){const wanted=new Set([homeName,awayName].filter(Boolean));const picked=(rows||[]).filter(x=>wanted.has(x.team));return picked.length?picked:(rows||[]).slice(0,8)}
  async function getGroupBundle(f){
    const mode=autoModeForFixture(f),id=f.fixture.id,home=f.teams.home.id,away=f.teams.away.id,league=f.league.id,season=f.league.season;

    // One coverage request per unique league-season (cached + in-flight dedupe), plus cached PRE/LIVE bet references.
    const [apiCoverage,preBetRef,liveBetRef]=await Promise.all([
      getLeagueCoverage(league,season),
      getBetReference('prematch'),
      mode!=='PRE'?getBetReference('live'):Promise.resolve({source:'live',count:0,byId:{}})
    ]);
    const betRefs={prematch:preBetRef,live:liveBetRef};

    const baseJobs={
      odds:coverageAllows(apiCoverage,'odds')
        ?footballCached('/odds',{fixture:id},CACHE_TTL.prematch_odds,true):Promise.resolve(null),
      home_recent:footballCached('/fixtures',{team:home,last:6},CACHE_TTL.recent,true),
      away_recent:footballCached('/fixtures',{team:away,last:6},CACHE_TTL.recent,true),
      standings:league&&season&&coverageAllows(apiCoverage,'standings')
        ?footballCached('/standings',{league,season},CACHE_TTL.standings,true):Promise.resolve(null)
    };

    // ULTRA MODE: enrich the screening layer instead of cache-peeking only.
    // footballCached + in-flight dedupe prevents duplicate team calls across fixtures.
    baseJobs.home_team_stats=league&&season
      ?footballCached('/teams/statistics',{league,season,team:home},CACHE_TTL.team_stats,true):Promise.resolve(null);
    baseJobs.away_team_stats=league&&season
      ?footballCached('/teams/statistics',{league,season,team:away},CACHE_TTL.team_stats,true):Promise.resolve(null);

    if(mode!=='PRE'){
      baseJobs.statistics=coverageAllows(apiCoverage,'fixtures.statistics_fixtures')
        ?football('/fixtures/statistics',{fixture:id},true):Promise.resolve(null);
      baseJobs.events=coverageAllows(apiCoverage,'fixtures.events')
        ?football('/fixtures/events',{fixture:id},true):Promise.resolve(null);
      baseJobs.live_odds=coverageAllows(apiCoverage,'odds')
        ?football('/odds/live',{fixture:id},true):Promise.resolve(null);
    }

    const keys=Object.keys(baseJobs),vals=await Promise.all(keys.map(k=>baseJobs[k]));
    const sr={};keys.forEach((k,i)=>sr[k]=vals[i]);
    const cacheStatus=cacheRuntimeSummary({
      prematch_odds:['/odds',{fixture:id}],home_recent:['/fixtures',{team:home,last:6}],
      away_recent:['/fixtures',{team:away,last:6}],standings:['/standings',{league,season}]
    });

    const marketCtx={homeName:f.teams.home.name,awayName:f.teams.away.name,betRefs};
    const preOdds=oddsCompact(sr.odds,false,marketCtx).slice(0,12);
    const liveOdds=oddsCompact(sr.live_odds,true,marketCtx).slice(0,12);

    const history=mode!=='PRE'?saveLiveOddsSnapshot(id,{fixture:f.fixture,goals:f.goals},liveOdds):null;
    const allStandings=standingsCompact(sr.standings);
    const n={
      api_coverage:{...apiCoverage,skipped_endpoints:coverageSkipList(apiCoverage,['fixtures.events','fixtures.statistics_fixtures','standings','odds'])},
      cache_status:cacheStatus,
      live_statistics:statMap(sr.statistics),
      events:eventsCompact(sr.events).slice(-24),
      odds:preOdds,
      live_odds:liveOdds,
      live_market_movement:history,
      home_recent:recentCompact(sr.home_recent).slice(0,6),
      away_recent:recentCompact(sr.away_recent).slice(0,6),
      standings:standingsForTeams(allStandings,f.teams.home.name,f.teams.away.name),
      home_team_stats:teamStatsCompact(sr.home_team_stats),
      away_team_stats:teamStatsCompact(sr.away_team_stats)
    };
    const coverage=groupCoverageScore(mode,n),staleSources=Object.entries(cacheStatus).filter(([,x])=>x?.status==='CACHE_STALE').map(([k,x])=>`${k} ${x.age_sec}s`);
    if(staleSources.length)coverage.warnings=[...new Set([...(coverage.warnings||[]),`CACHE_STALE ${staleSources.join(', ')}`])].slice(0,12);
    return {meta:compactFixtureMeta(f,mode),coverage,data:n};
  }

  async function mapLimit(items,limit,worker,onProgress){
    const out=new Array(items.length);let next=0,done=0;
    async function runner(){
      while(true){const i=next++;if(i>=items.length)return;try{out[i]=await worker(items[i],i)}catch(e){out[i]={error:e.message,meta:compactFixtureMeta(items[i],autoModeForFixture(items[i])),coverage:{score:0,checks:{}}};log('Group fixture error',{fixture:items[i]?.fixture?.id,error:e.message})}done++;if(onProgress)onProgress(done,items.length,items[i]);}
    }
    await Promise.all(Array.from({length:Math.min(limit,items.length)},runner));return out;
  }
  function compactNum(v){
    if(v===null||v===undefined||v==='')return null;
    if(typeof v==='number')return Number.isInteger(v)?String(v):String(Math.round(v*100)/100);
    return String(v).replace(/\s+/g,' ').trim();
  }
  function getAnyStat(side,names){
    const s=side?.stats||{};const keys=Object.keys(s);
    for(const name of names){
      const hit=keys.find(k=>String(k).toLowerCase()===String(name).toLowerCase())||keys.find(k=>String(k).toLowerCase().includes(String(name).toLowerCase()));
      if(hit!=null&&s[hit]!=null)return compactNum(s[hit]);
    }
    return null;
  }
  function pairStat(n,meta,names){
    const h=n.live_statistics?.[meta.teams?.home?.id],a=n.live_statistics?.[meta.teams?.away?.id];
    const hv=getAnyStat(h,names),av=getAnyStat(a,names);
    return hv!=null||av!=null?`${hv??'-'}-${av??'-'}`:null;
  }
  function recentSummary(rows,teamName){
    const r=(rows||[]).slice(0,5);if(!r.length)return null;
    let w=0,d=0,l=0,gf=0,ga=0;const seq=[];
    r.forEach(x=>{
      const home=x.home===teamName,forG=Number(home?x.goals?.home:x.goals?.away),againstG=Number(home?x.goals?.away:x.goals?.home);
      if(Number.isFinite(forG))gf+=forG;if(Number.isFinite(againstG))ga+=againstG;
      if(!Number.isFinite(forG)||!Number.isFinite(againstG)){seq.push('?');return}
      if(forG>againstG){w++;seq.push('W')}else if(forG===againstG){d++;seq.push('D')}else{l++;seq.push('L')}
    });
    return {n:r.length,text:`${seq.join('')} | W${w} D${d} L${l} | GF${gf} GA${ga}`};
  }
  function standingSummary(rows,teamName){
    const x=(rows||[]).find(r=>r.team===teamName);if(!x)return null;
    return `#${x.rank??'-'} ${x.points??'-'}đ GD${x.goalsDiff!=null?(Number(x.goalsDiff)>=0?'+':'')+x.goalsDiff:'-'}${x.form?' form '+x.form:''}`;
  }
  function deepVal(o,path){
    try{return path.split('.').reduce((a,k)=>a==null?undefined:a[k],o)}catch{return undefined}
  }
  function seasonSummary(s){
    if(!s||Array.isArray(s)||typeof s!=='object')return null;
    const parts=[];if(s.form)parts.push(`form ${String(s.form).slice(-8)}`);
    const gf=deepVal(s,'goals.for.average.total'),ga=deepVal(s,'goals.against.average.total');
    if(gf!=null||ga!=null)parts.push(`GFavg ${gf??'-'} GAavg ${ga??'-'}`);
    const wins=deepVal(s,'fixtures.wins.total'),draws=deepVal(s,'fixtures.draws.total'),loses=deepVal(s,'fixtures.loses.total');
    if(wins!=null||draws!=null||loses!=null)parts.push(`W/D/L ${wins??'-'}/${draws??'-'}/${loses??'-'}`);
    return parts.length?parts.join(' | '):null;
  }
  function injurySummary(rows,teamName){
    const arr=(rows||[]).filter(x=>x.team===teamName);if(!arr.length)return null;
    const names=arr.slice(0,3).map(x=>x.player).filter(Boolean);
    return `${arr.length}${names.length?' ('+names.join(', ')+(arr.length>3?', …':'')+')':''}`;
  }
  function formatMarketValue(v){
    if(v==null)return '';if(typeof v==='string'||typeof v==='number')return String(v);
    let label=String(v.value??v.name??v.label??'').trim();const odd=v.odd??v.price??'';
    if(v.handicap!=null&&HANDICAP_CATEGORIES){const rawTail=handicapFromLabel(label);if(rawTail!=null)label=label.replace(/\s*[+-]?\d+(?:[.,]\d+)?\s*$/,'').trim();label=`${label}${label?' ':''}${Number(v.handicap)>0?'+':''}${v.handicap}`}
    return `${label}${odd!==''?'@'+odd:''}`;
  }
  function marketSummary(rows,maxMarkets=3){
    const out=[];const seen=new Set();
    for(const r of (rows||[])){
      const market=String(r.market||'').trim();
      if(!market||seen.has(market.toLowerCase()))continue;

      if(r.integrity?.valid===false){
        const why=(r.integrity?.warnings||[r.integrity?.status||'MARKET_INTEGRITY_FAIL']).join(' | ');
        out.push(`${market}: INVALID / KHÔNG DÙNG (${why})`);
        seen.add(market.toLowerCase());
        if(out.length>=maxMarkets)break;
        continue;
      }

      const vals=(r.values||[]).filter(v=>!v.suspended).slice(0,5).map(formatMarketValue).filter(Boolean);
      if(vals.length){
        const trust=r.integrity?.trusted===false?' [UNVERIFIED_SIDE]':'';
        out.push(`${market}${trust}: ${vals.join(', ')}`);
        seen.add(market.toLowerCase());
      }
      if(out.length>=maxMarkets)break;
    }
    return out;
  }
  function liveSummary(meta,n){
    const pairs=[
      ['SOT',['Shots on Goal','Shots on Target']],['Shots',['Total Shots']],['InBox',['Shots insidebox','Shots inside box']],
      ['Corners',['Corner Kicks','Corners']],['Poss',['Ball Possession','Possession']],['xG',['expected_goals','Expected Goals']],
      ['YC',['Yellow Cards']],['RC',['Red Cards']]
    ];
    const parts=[];pairs.forEach(([label,names])=>{const v=pairStat(n,meta,names);if(v!=null)parts.push(`${label} ${v}`)});
    return parts.length?parts.join(' | '):null;
  }
  function eventsSummary(events){
    const ev=(events||[]).filter(e=>/Goal|Card|subst/i.test(`${e.type||''} ${e.detail||''}`)).slice(-5);
    if(!ev.length)return null;
    return ev.map(e=>`${e.time??'?'}' ${e.team||''} ${e.type||''}${e.detail?' '+e.detail:''}`.replace(/\s+/g,' ').trim()).join(' ; ');
  }
  function dataFlags(c){
    const map={statistics:'ST',events:'EV',live_odds:'LO',odds:'OD',recent:'FM',standings:'TB',team_stats:'TS'};
    const checks=c?.checks||{};return Object.entries(map).filter(([k])=>k in checks).map(([k,v])=>`${v}${checks[k]?'✓':'×'}`).join(' ');
  }
  function compactScreeningBlock(b,index,level,total){
    const m=b.meta||{},n=b.data||{},h=m.teams?.home?.name||'Home',a=m.teams?.away?.name||'Away',st=m.fixture?.status||{};
    const kick=m.fixture?.timestamp?fmtDateTime(m.fixture.timestamp):'-';const minute=st.elapsed!=null?`${st.elapsed}'`:'';
    const score=m.goals?.home!=null||m.goals?.away!=null?`${m.goals?.home??0}-${m.goals?.away??0}`:'NS';
    const q=b.coverage||{};const head=`#${String(index+1).padStart(2,'0')} | FX ${m.fixture_id||'-'} | ${m.mode||'PRE'} | ${kick} | ${m.league?.name||'-'} | ${h} vs ${a} | ${minute||st.short||'NS'} ${score} | DQ ${q.score||0}% [C${q.coverage_score??'-'} I${q.integrity_score??'-'} F${q.freshness_score??'-'}] ${dataFlags(q)}`;
    if(b.error)return `${head}\nERROR: ${b.error}`;
    const lines=[head];
    const hr=recentSummary(n.home_recent,h),ar=recentSummary(n.away_recent,a);if(hr||ar)lines.push(`Recent (max5): H [n=${hr?.n??0}] ${hr?.text||'-'} | A [n=${ar?.n??0}] ${ar?.text||'-'}`);
    if((q.warnings||[]).length)lines.push(`QualityWarn: ${(q.warnings||[]).slice(0,3).join(' ; ')}`);
    const ht=standingSummary(n.standings,h),at=standingSummary(n.standings,a);if(ht||at)lines.push(`Table: H ${ht||'-'} | A ${at||'-'}`);
    if(m.mode==='PRE'){
      if(level>=1){const hs=seasonSummary(n.home_team_stats),as=seasonSummary(n.away_team_stats);if(hs||as)lines.push(`Season: H ${hs||'-'} | A ${as||'-'}`)}
      const mk=marketSummary(n.odds,level>=2?3:2);if(mk.length)lines.push(`Market: ${mk.join(' || ')}`);
    }else{
      const live=liveSummary(m,n);if(live)lines.push(`Live: ${live}`);
      const lm=marketSummary(n.live_odds,level>=2?3:2),pm=marketSummary(n.odds,1);if(lm.length)lines.push(`LiveMarket: ${lm.join(' || ')}`);else if(pm.length)lines.push(`PreMarket: ${pm.join(' || ')}`);
      const mv=movementCompactText(n.live_market_movement);if(mv)lines.push(`MarketMove(local): ${mv}`);
      if(level>=2){const ev=eventsSummary(n.events);if(ev)lines.push(`KeyEvents: ${ev}`)}
    }
    return lines.join('\n');
  }

  const XIEN_ALLOWED_PRE=new Set(['asian_handicap','over_under','match_winner','h1_handicap','h1_total','team_total']);
  const XIEN_ALLOWED_LIVE=new Set(['asian_handicap','over_under','match_winner','h1_handicap','h1_total','h2_handicap','h2_total','team_total','corners']);

  function xienMarketText(rows,liveMode,maxMarkets=4){
    const allowed=liveMode?XIEN_ALLOWED_LIVE:XIEN_ALLOWED_PRE;
    const out=[];
    for(const r of (rows||[])){
      if(!allowed.has(r.category))continue;
      if(r.integrity?.valid===false)continue;
      if(r.status?.blocked||r.status?.stopped||r.status?.finished)continue;

      const vals=(r.values||[]).filter(v=>!v.suspended);
      if(!vals.length)continue;

      const mainVals=vals.some(v=>v.main===true)?vals.filter(v=>v.main===true):vals;
      const picked=(mainVals.length?mainVals:vals).slice(0,4);
      const txt=picked.map(v=>{
        const side=v.selection_outcome||v.selection_side||v.value||'';
        const line=v.handicap!==null&&v.handicap!==undefined?` ${Number(v.handicap)>0?'+':''}${v.handicap}`:'';
        const odd=v.odd!==null&&v.odd!==undefined?` @${v.odd}`:'';
        return `${side}${line}${odd}`.trim();
      }).join(', ');
      if(txt)out.push(`${r.category}: ${txt}${r.integrity?.trusted===false?' [UNVERIFIED_SIDE]':''}`);
      if(out.length>=maxMarkets)break;
    }
    return out;
  }

  function xienFixtureBlock(b,index,purpose){
    const m=b.meta||{},n=b.data||{},q=b.coverage||{};
    const h=m.teams?.home?.name||'Home',a=m.teams?.away?.name||'Away';
    const st=m.fixture?.status||{},liveMode=purpose==='xien_live';
    const kickoff=m.fixture?.timestamp?fmtDateTime(m.fixture.timestamp):'-';
    const score=(m.goals?.home!=null||m.goals?.away!=null)?`${m.goals?.home??0}-${m.goals?.away??0}`:'-';
    const lines=[
      `#${String(index+1).padStart(2,'0')} | FIXTURE_ID: ${m.fixture_id||'-'}`,
      `GIỜ VN: ${kickoff}`,
      `GIẢI: ${m.league?.name||'-'}${m.league?.country?' | '+m.league.country:''}`,
      `TRẬN: ${h} vs ${a}`,
      liveMode
        ?`LIVE: ${st.elapsed!=null?st.elapsed+"'":st.short||'LIVE'} | TỶ SỐ ${score}`
        :`TRẠNG THÁI: PRE | ${st.short||'NS'}`,
      `DQ: ${q.score??0}% [C${q.coverage_score??'-'} I${q.integrity_score??'-'} F${q.freshness_applicable===false?'N/A':(q.freshness_score??'-')}]`
    ];

    if(b.error){lines.push(`ERROR: ${b.error}`);return lines.join('\n')}

    const hr=recentSummary(n.home_recent,h),ar=recentSummary(n.away_recent,a);
    if(hr||ar)lines.push(`RECENT: H [n=${hr?.n??0}] ${hr?.text||'-'} | A [n=${ar?.n??0}] ${ar?.text||'-'}`);

    const ht=standingSummary(n.standings,h),at=standingSummary(n.standings,a);
    if(ht||at)lines.push(`BXH: H ${ht||'-'} | A ${at||'-'}`);

    if(liveMode){
      const live=liveSummary(m,n);if(live)lines.push(`LIVE STATS: ${live}`);
      const ev=eventsSummary(n.events);if(ev)lines.push(`EVENTS: ${ev}`);
      const markets=xienMarketText(n.live_odds,true,4);
      if(markets.length)lines.push(`LIVE MARKET: ${markets.join(' || ')}`);
      else{
        const pre=xienMarketText(n.odds,false,2);
        if(pre.length)lines.push(`PRE MARKET REF: ${pre.join(' || ')}`);
      }
      const mv=movementCompactText(n.live_market_movement);
      if(mv)lines.push(`MARKET MOVE: ${mv}`);
    }else{
      const hs=seasonSummary(n.home_team_stats),as=seasonSummary(n.away_team_stats);
      if(hs||as)lines.push(`SEASON: H ${hs||'-'} | A ${as||'-'}`);
      const markets=xienMarketText(n.odds,false,4);
      if(markets.length)lines.push(`PRE MARKET: ${markets.join(' || ')}`);
    }

    if((q.warnings||[]).length)lines.push(`QUALITY WARN: ${(q.warnings||[]).slice(0,3).join(' ; ')}`);
    return lines.join('\n');
  }

  function makeXienTag(purpose){
    const d=new Date();
    const stamp=new Intl.DateTimeFormat('en-CA',{timeZone:TZ,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false})
      .format(d).replace(/[^0-9]/g,'');
    return `FE-XIEN5-${purpose==='xien_live'?'LIVE':'PRE'}-${stamp}`;
  }

  function buildXienPacket(bundles,purpose){
    const liveMode=purpose==='xien_live';
    const tag=makeXienTag(purpose);
    const good=bundles.filter(x=>!x.error);
    const avg=good.length?Math.round(good.reduce((s,b)=>s+(b.coverage?.score||0),0)/good.length):0;
    const blocks=bundles.map((b,i)=>xienFixtureBlock(b,i,purpose)).join('\n\n');
    const usage=apiUsageSnapshot();

    return `[FOOTBALL_EDGE_XIEN5_SCAN]
TAG: ${tag}
MODE: ${liveMode?'XIEN_5_LIVE':'XIEN_5_PRE'}
SCAN: ${state.scanLabel}
TARGET_LEGS: 5
TOTAL_CANDIDATES: ${bundles.length}
AVERAGE_DQ: ${avg}%
QUALITY_SCHEMA: COVERAGE_INTEGRITY_FRESHNESS_V4
API_CALLS_LOCAL_TODAY: ${usage.network_calls||0}

MỤC TIÊU:
So sánh chéo toàn bộ ứng viên bên dưới để xây 01 bộ XIÊN 5 ${liveMode?'LIVE':'PRE'} có chất lượng đồng đều.
KHÔNG được lấy một chân yếu chỉ để đủ số lượng. Nếu không đủ 5 chân đạt chuẩn thì kết luận KHÔNG ĐỦ ĐIỀU KIỆN XIÊN 5.

QUY TẮC BẮT BUỘC:
1. Chỉ chọn đúng 5 chân từ 5 FIXTURE_ID KHÁC NHAU. Tối đa 1 chân / 1 trận.
2. Ưu tiên market đã có line/price thực tế trong packet và qua Integrity Guard.
3. Không dùng market INVALID, suspended, blocked, stopped hoặc dữ liệu có cảnh báo integrity nghiêm trọng.
4. Tránh 5 chân cùng phụ thuộc một kiểu kịch bản; đánh giá CORRELATION của cả bộ.
5. ${liveMode
  ?'LIVE: game-state + phút/tỷ số + live stats + events + market movement có trọng số cao nhất. Không dùng dữ liệu lịch sử để phủ nhận diễn biến đang xảy ra.'
  :'PRE: ưu tiên sức mạnh nền, recent sample size, BXH/season context và market PRE. Nếu lineup/chấn thương sâu chưa có thì ghi rõ cần DEEP kiểm tra.'}
6. Odds trong packet chỉ là MARKET REFERENCE. Khi người dùng tra app cược, line/giá thực tế mới là giá thực thi.
7. Không bịa line/giá không có trong packet. Nếu một chân tốt nhưng market/price chưa xác định thì trạng thái phải là CHỜ GIÁ.
8. Nếu có dưới 5 fixture thực sự đạt chuẩn: trả KHÔNG ĐỦ ĐIỀU KIỆN XIÊN 5, không bù chân yếu.

FORMAT TRẢ VỀ — PHẢI ĐẶT NGAY ĐẦU:
XIÊN 5 ${liveMode?'LIVE':'PRE'} — KHUNG ${state.scanLabel}

| LEG | GIỜ VN | GIẢI | TRẬN | ${liveMode?'LIVE / TỶ SỐ | ':''}KÈO | LINE/GIÁ | TRẠNG THÁI |
|---|---|---|---|${liveMode?'---|':''}---|---|---|
| 1 | ... | ... | ... | ${liveMode?'... | ':''}... | ... | GIỮ/CHỜ/LOẠI |
...
| 5 | ... | ... | ... | ${liveMode?'... | ':''}... | ... | GIỮ/CHỜ/LOẠI |

Sau bảng:
- LEG 1→5: mỗi chân giải thích tối đa 2–3 ý.
- QUALITY từng chân: DQ / Integrity / Freshness.
- CORRELATION TOÀN BỘ: THẤP / TRUNG BÌNH / CAO + lý do.
- DEEP PRIORITY: chân nào cần chạy DEEP trước khi xác nhận.
- Không được trả một danh sách chỉ có tên kèo mà thiếu GIỜ VN / GIẢI / TRẬN.

=== XIEN 5 CANDIDATES ===
${blocks}

=== END XIEN 5 SCAN ===`;
  }

  function renderXienPacket(bundles,purpose){
    const packet=buildXienPacket(bundles,purpose);
    const tag=packet.match(/TAG: ([^\n]+)/)?.[1]||'FE-XIEN5';
    const good=bundles.filter(x=>!x.error);
    const avg=good.length?Math.round(good.reduce((s,b)=>s+(b.coverage?.score||0),0)/good.length):0;

    state.lastPacket=packet;
    state.lastPacketKind=purpose==='xien_live'?'xien5_live':'xien5_pre';
    els.packetText.value=packet;
    els.packetMeta.textContent=`TAG ${tag} • ${purpose==='xien_live'?'XIÊN 5 LIVE':'XIÊN 5 PRE'} • ${bundles.length} trận • ${packet.length.toLocaleString('vi-VN')} ký tự • DQ TB ${avg}%`;
    els.packetBox.classList.remove('hidden');
    els.coverage.classList.add('hidden');
    els.result.classList.remove('hidden');
    els.result.innerHTML=`<div class="status ok"><b>Đã tạo gói ${purpose==='xien_live'?'XIÊN 5 LIVE':'XIÊN 5 PRE'}.</b><br>GPT bắt buộc trả đủ GIỜ VN • GIẢI • TRẬN • ${purpose==='xien_live'?'PHÚT/TỶ SỐ • ':''}KÈO • LINE/GIÁ cho từng LEG.</div>`;
    els.packetBox.scrollIntoView({behavior:'smooth',block:'start'});
  }

  function makeGroupTag(){
    const d=new Date(),stamp=new Intl.DateTimeFormat('en-CA',{timeZone:TZ,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(d).replace(/[^0-9]/g,'');
    return `FE-SCAN-${stamp}-${String(state.scanLabel||'RANGE').replace(/[^A-Za-z0-9+_-]/g,'')}`;
  }
  function buildGroupPacket(bundles){
    const tag=makeGroupTag(),good=bundles.filter(x=>!x.error),avg=good.length?Math.round(good.reduce((a,b)=>a+(b.coverage?.score||0),0)/good.length):0;
    const total=bundles.length,level=total<=10?2:(total<=22?1:0),blocks=bundles.map((b,i)=>compactScreeningBlock(b,i,level,total)).join('\n\n'),usage=apiUsageSnapshot();
    return `[FOOTBALL_EDGE_GROUP_SCAN]
TAG: ${tag}
SCAN: ${state.scanLabel}
PACKET_MODE: COMPACT_SCREENING
QUALITY_SCHEMA: COVERAGE_INTEGRITY_FRESHNESS_V4
TOTAL_MATCHES: ${total}
AVERAGE_SCREENING_DQ: ${avg}%
DETAIL_LEVEL: ${level}
API_CALLS_LOCAL_TODAY: ${usage.network_calls||0}

MỤC TIÊU DUY NHẤT CỦA BƯỚC 1:
Đây là GROUP SCAN để chọn TRẬN đáng đi sâu, KHÔNG phải quyết định cược cuối.

QUY TRÌNH BẮT BUỘC:
1. So sánh chéo toàn bộ ${total} trận theo sức mạnh nền, Recent form kèm sample size thực tế (n=x/5; không mặc định đủ 5 trận), BXH/season nếu có, game-state LIVE, live stats, events, market reference và Data Quality.
2. Shortlist tối đa 2–4 trận có tín hiệu tốt nhất.
3. Chọn đúng 01 TOP 1 TARGET (ghi rõ FIXTURE_ID) để người dùng quay lại app chạy DEEP ANALYSIS. Nếu cả khung không đủ edge hoặc dữ liệu quá yếu thì BỎ CẢ KHUNG.
4. LIVE phải ưu tiên game-state + live statistics + live market hơn lịch sử. PRE ưu tiên sức mạnh nền + context + market reference.
5. Data Quality gồm Coverage / Integrity / Freshness và KHÔNG phải ngưỡng loại cứng. api_coverage cho biết endpoint nào league-season hỗ trợ; market bet ID ưu tiên mapping qua bảng reference PRE/LIVE riêng. Market integrity lỗi phải được xem là cảnh báo nghiêm trọng. Không bịa dữ liệu thiếu.
6. Odds API chỉ là market reference, chưa phải giá thực thi. Không được chốt FINAL VÀO ở bước này.
7. Nếu thấy market thiếu/stale, chỉ ghi chú cần kiểm tra ở DEEP/MARKET CONFIRM.

FORMAT TRẢ VỀ:
- SHORTLIST #1–#4: giờ VN • giải • trận • FIXTURE_ID • mode • lý do ngắn.
- TOP 1 TARGET: đúng 01 trận + FIXTURE_ID + vì sao đáng đi sâu nhất.
- BACKUP: tối đa 1–2 trận, chỉ dùng nếu TOP 1 bị loại ở DEEP.
- Hoặc BỎ CẢ KHUNG.
- Không đưa FINAL BET ở GROUP SCAN.

=== MATCHES • COMPACT SCREENING ===
${blocks}

=== END GROUP SCAN ===`;
  }
  function renderGroupPacket(bundles){
    const packet=buildGroupPacket(bundles),tag=packet.match(/TAG: ([^\n]+)/)?.[1]||'FE-SCAN';
    const good=bundles.filter(x=>!x.error),avg=good.length?Math.round(good.reduce((a,b)=>a+(b.coverage?.score||0),0)/good.length):0;
    state.lastPacket=packet;state.lastPacketKind='group';els.packetText.value=packet;
    els.packetMeta.textContent=`TAG ${tag} • COMPACT • ${bundles.length} trận • ${packet.length.toLocaleString('vi-VN')} ký tự • DQ TB ${avg}%`;
    els.packetBox.classList.remove('hidden');els.coverage.classList.add('hidden');els.result.classList.remove('hidden');
    els.result.innerHTML=`<div class="status ok"><b>Đã tạo gói COMPACT ${bundles.length} trận.</b><br>Đã lược bỏ raw JSON/dữ liệu dư. GPT sẽ shortlist 2–4 và chọn 01 TOP 1 TARGET để chạy DEEP; không đủ edge sẽ BỎ CẢ KHUNG.</div>`;
    els.packetBox.scrollIntoView({behavior:'smooth',block:'start'});
  }

  function makeTag(bundle){
    const m=bundle.meta||{},fx=m.fixture_id||'NA',mode=String(m.mode||'PRE').replace(/\s+/g,'');
    const minute=m.fixture?.status?.elapsed;
    return `FE-${mode}-${fx}${minute!=null?'-M'+minute:''}`;
  }
  function compactSnapshot(bundle){return {meta:bundle.meta,data_quality:bundle.coverage,coverage:bundle.coverage,data_sources:bundle.data_sources,api_usage:bundle.api_usage,data:bundle.normalized}}
  function buildPacket(bundle){
    const m=bundle.meta||{},tag=makeTag(bundle),f=m.fixture||{},teams=m.teams||{},goals=m.goals||{};
    const modeName=m.mode==='PRE'?'PRE-MATCH':m.mode==='H1'?'LIVE H1':'LIVE FT',score=(goals.home!=null||goals.away!=null)?`${goals.home??0}-${goals.away??0}`:'chưa bắt đầu',snapshot=JSON.stringify(compactSnapshot(bundle));
    return `[FOOTBALL_EDGE_ANALYSIS]
TAG: ${tag}
STAGE: DEEP_ANALYSIS
MODE: ${modeName}
FIXTURE_ID: ${m.fixture_id}
TRẬN: ${teams.home?.name||'Home'} vs ${teams.away?.name||'Away'}
GIẢI: ${m.league?.name||''} | ${m.league?.country||''}
GIỜ ĐÁ VN: ${m.kickoff_vn||'-'}
TRẠNG THÁI: ${f.status?.short||''}${f.status?.elapsed!=null?' | phút '+f.status.elapsed:''}
TỶ SỐ: ${score}
DATA_QUALITY_APP: ${bundle.coverage?.score??0}%
QUALITY_SCHEMA: COVERAGE_INTEGRITY_FRESHNESS_V4
COVERAGE: ${bundle.coverage?.coverage_score??'-'}%
INTEGRITY: ${bundle.coverage?.integrity_score??'-'}%
FRESHNESS: ${bundle.coverage?.freshness_score??'-'}%

YÊU CẦU DEEP ANALYSIS – CHƯA FINAL:
1. Phân tích độc lập dữ liệu API bên dưới. API-Football là xương sống nhưng không phải nguồn chân lý duy nhất.
2. CHỦ ĐỘNG WEB RESEARCH từ nhiều nguồn uy tín: đội hình/chấn thương/treo giò, phong độ/bối cảnh, lịch nghỉ/rotation, động lực, tactical matchup, tin CLB/giải và thị trường nếu tìm được.
3. Đối chiếu rõ API ↔ WEB: điểm đồng thuận, mâu thuẫn và dữ liệu nào đáng tin hơn.
4. API_MODEL / api_prediction chỉ là MODEL VOTE, tuyệt đối không coi là FINAL PICK.
5. LIVE: ưu tiên game-state + FULL/H1/H2 statistics + momentum + events + live market. So H2 với H1 để nhận diện thế trận đổi chiều hay tăng/giảm áp lực. Nếu market.live_history có >=2 snapshot, dùng nó để đọc line/price movement; đây là lịch sử cục bộ do app tự ghi mỗi lần quét/DEEP, không phải historical feed từ API.
6. Player match stats dùng để kiểm tra key players đang chơi, rating/performance, phút thi đấu và tác động thay người nếu dữ liệu có.
7. Odds API chỉ là MARKET REFERENCE. Ảnh app cược của người dùng ở BƯỚC 3 mới là line/giá thực thi cuối.
8. Không dùng Data Quality làm ngưỡng cứng. Không bịa dữ liệu thiếu. Nếu api_coverage xác nhận endpoint=false thì coi là nguồn không được giải hỗ trợ, không coi là lỗi request. Nếu market thiếu/stale: CHỜ GIÁ/KÈO CẬP NHẬT.

KẾT QUẢ BƯỚC 2 PHẢI TRẢ:
- DEEP STATUS: CANDIDATE / WATCH / REJECT.
- Kèo ưu tiên nếu có: market + hướng cược.
- Vùng line hợp lý.
- Vùng giá chấp nhận sơ bộ.
- Entry window / điều kiện chờ.
- Điều kiện hủy nhận định.
- Confidence 0–100 và Data Quality 0–100; nêu riêng Coverage / Integrity / Freshness nếu có cảnh báo.
- API ↔ WEB cross-check ngắn gọn.
- Rủi ro chính.
- Cuối cùng yêu cầu người dùng gửi SCREENSHOT bookmaker hiện tại để MARKET CONFIRM.

CẤM: Không được ghi FINAL VÀO ở bước DEEP nếu chưa có ảnh line/giá thực tế từ app cược.

=== DEEP MATCH SNAPSHOT JSON ===
${snapshot}`;
  }
  function renderPacket(bundle){
    const packet=buildPacket(bundle);state.lastPacket=packet;state.lastPacketKind='single';els.packetText.value=packet;els.packetMeta.textContent=`TAG ${makeTag(bundle)} • ${packet.length.toLocaleString('vi-VN')} ký tự • DQ ${bundle.coverage.score}% [C${bundle.coverage.coverage_score??'-'} I${bundle.coverage.integrity_score??'-'} F${bundle.coverage.freshness_score??'-'}]`;els.packetBox.classList.remove('hidden');
    els.result.classList.remove('hidden');els.result.innerHTML=`<div class="status ok"><b>DEEP DATA đã gom xong.</b><br>Copy sang Project để GPT web research + cross-check. Chưa FINAL cho tới khi anh gửi ảnh market thực tế.</div>`;
    els.packetBox.scrollIntoView({behavior:'smooth',block:'start'});
  }
  let toastTimer=null;
  function showToast(type='ok',title='Đã copy gói phân tích',sub='Có thể mở Project và dán vào ô chat.') {
    const t=$('toast'),icon=$('toastIcon'),tt=$('toastTitle'),ts=$('toastSub');
    if(!t)return;
    clearTimeout(toastTimer);
    t.classList.remove('show','err','busy');
    if(type==='err')t.classList.add('err');
    if(type==='busy')t.classList.add('busy');
    icon.textContent=type==='err'?'!':type==='busy'?'↻':'✓';
    tt.textContent=title;
    ts.textContent=sub;
    requestAnimationFrame(()=>t.classList.add('show'));
    if(navigator.vibrate) try{navigator.vibrate(type==='err'?[60,45,60]:type==='busy'?20:35)}catch{}
    toastTimer=setTimeout(()=>t.classList.remove('show'),2600);
  }
  function flashCopyButton(btn){
    if(!btn)return;
    const old=btn.innerHTML;
    btn.classList.add('copy-flash');
    btn.innerHTML='✓ ĐÃ COPY';
    setTimeout(()=>{btn.innerHTML=old;btn.classList.remove('copy-flash')},1400);
  }

  async function copyPacket(){
    if(!state.lastPacket)throw new Error('Chưa có gói phân tích. Hãy bấm TẠO GÓI PHÂN TÍCH trước.');
    try{await navigator.clipboard.writeText(state.lastPacket)}catch(e){els.packetText.focus();els.packetText.select();const ok=document.execCommand('copy');if(!ok)throw e}
  }
  function openProject(){
    const url=els.projectUrl.value.trim();
    if(!url){status(els.conn,'Chưa lưu link ChatGPT Project. Hãy mở Project của anh, copy link và dán vào ô Link Project ở phần 1.','err');els.projectUrl.scrollIntoView({behavior:'smooth',block:'center'});return false}
    try{const u=new URL(url);if(!/^https?:$/.test(u.protocol))throw new Error();window.open(u.href,'_blank','noopener,noreferrer');return true}catch{status(els.conn,'Link Project không hợp lệ. Hãy dán URL đầy đủ bắt đầu bằng https://','err');return false}
  }



  $('prepareXienBtn').addEventListener('click',async()=>{
    const purpose=state.scanPurpose;
    if(!['xien_pre','xien_live'].includes(purpose)){
      status(els.scanStatus,'Hãy chọn XIÊN 5 PRE hoặc XIÊN 5 LIVE trước.','err');
      return;
    }

    const fixtures=xienEligibleFixtures(state.fixtures,purpose);
    if(fixtures.length<5){
      status(els.scanStatus,`${scanPurposeLabel(purpose)} cần tối thiểu 5 trận phù hợp. Hiện chỉ có ${fixtures.length}.`,'err');
      return;
    }

    saveConfig(true);
    const total=fixtures.length;
    if(total>30){
      const ok=confirm(`${scanPurposeLabel(purpose)} có ${total} trận. App sẽ screening toàn bộ và dùng nhiều lượt Football API. Tiếp tục?`);
      if(!ok)return;
    }

    els.packetBox.classList.add('hidden');
    els.coverage.classList.add('hidden');
    els.result.classList.add('hidden');
    els.groupProgress.textContent=`Đang gom ${total} trận cho ${scanPurposeLabel(purpose)}...`;
    loading(true,`Đang chuẩn bị ${scanPurposeLabel(purpose)}`,`0/${total} trận`);

    try{
      const bundles=await mapLimit(fixtures,2,getGroupBundle,(done,n,f)=>{
        const name=`${f?.teams?.home?.name||''} vs ${f?.teams?.away?.name||''}`;
        els.loadingText.textContent=`${done}/${n} • ${name}`;
        els.groupProgress.textContent=`${scanPurposeLabel(purpose)}: ${done}/${n} trận`;
      });

      const failed=bundles.filter(x=>x.error).length;
      els.groupProgress.textContent=`Đã gom ${total-failed}/${total} trận • đang tạo packet ${scanPurposeLabel(purpose)}.`;
      renderXienPacket(bundles,purpose);
      showToast('ok',`Đã tạo ${scanPurposeLabel(purpose)}`,`Copy sang Project để GPT chọn đúng 5 chân hoặc báo không đủ điều kiện.`);
      log('Xien5 bundle',{purpose,total,failed,scan:state.scanLabel});
    }catch(e){
      els.groupProgress.textContent='Không tạo được gói XIÊN 5: '+e.message;
      els.result.classList.remove('hidden');
      els.result.innerHTML=`<div class="status err"><b>Không tạo được gói XIÊN 5.</b><br>${esc(e.message)}</div>`;
      log('Xien5 fatal',e.message);
    }finally{
      loading(false);
    }
  });

  $('prepareAllBtn').addEventListener('click',async()=>{
    if(!state.fixtures.length){status(els.scanStatus,'Chưa có danh sách trận. Hãy quét LIVE hoặc một khung giờ trước.','err');return}
    saveConfig(true);const total=state.fixtures.length;
    if(total>30){const ok=confirm(`Khung này có ${total} trận. App sẽ gom dữ liệu cho toàn bộ nên có thể mất vài phút và dùng nhiều lượt Football API. Tiếp tục?`);if(!ok)return}
    els.packetBox.classList.add('hidden');els.coverage.classList.add('hidden');els.result.classList.add('hidden');
    els.groupProgress.textContent=`Đang chuẩn bị gom ${total} trận...`;
    loading(true,'Đang gom cả khung',`0/${total} trận • app tự nhận diện PRE / H1 / FT`);
    try{
      const bundles=await mapLimit(state.fixtures,2,getGroupBundle,(done,n,f)=>{
        const name=`${f?.teams?.home?.name||''} vs ${f?.teams?.away?.name||''}`;
        els.loadingText.textContent=`${done}/${n} trận • ${name}`;
        els.groupProgress.textContent=`Đang gom dữ liệu: ${done}/${n} trận`;
      });
      const failed=bundles.filter(x=>x.error).length;
      els.groupProgress.textContent=`Đã gom ${total-failed}/${total} trận${failed?` • ${failed} trận thiếu dữ liệu`:''} • đang nén thành gói COMPACT.`;
      renderGroupPacket(bundles);
      showToast('ok',`Đã tạo gói COMPACT ${total} trận`,'Gói đã rút gọn để GPT đọc ổn định hơn. Copy và gửi vào Project.');
      log('Group scan bundle',{total,failed,scan:state.scanLabel});
    }catch(e){els.groupProgress.textContent='Không tạo được gói tổng: '+e.message;els.result.classList.remove('hidden');els.result.innerHTML=`<div class="status err"><b>Không tạo được gói tổng.</b><br>${esc(e.message)}</div>`;log('Group scan fatal',e.message)}finally{loading(false)}
  });


  /* ===== V1.18.3 SINGLE MATCH ANALYZER =====
     APP-ONLY orchestrator.
     Reuses stable PRE data, RUNG H1/FT, Handicap, Market-Time, Robustness
     and Final Model Decision without changing their formulas.

     Output:
       - exactly one MODEL CHOICE, or PASS NOW
       - cross-market ranking
       - explicit WHY / MAIN RISK
       - optional Background FOCUS registration

     No bankroll sizing / auto execution. */

  const SMA_VERSION='V1.18.3';
  const SMA_MIN_PRE_ACTION=78;
  const SMA_MIN_PRE_WATCH=65;

  function smaClamp(v,a,b){const n=Number(v);return Number.isFinite(n)?Math.max(a,Math.min(b,n)):a}
  function smaRound(v,d=2){const n=Number(v);if(!Number.isFinite(n))return null;const p=10**d;return Math.round(n*p)/p}
  function smaNum(v,fallback=null){const n=Number(v);return Number.isFinite(n)?n:fallback}
  function smaPct(v){if(v==null)return null;const n=parseFloat(String(v).replace('%',''));return Number.isFinite(n)?n:null}
  function smaMedian(arr){const a=(arr||[]).map(Number).filter(Number.isFinite).sort((x,y)=>x-y);if(!a.length)return null;const m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2}
  function smaFmtOdd(v){const n=Number(v);return Number.isFinite(n)?n.toFixed(3).replace(/0+$/,'').replace(/\.$/,''):'-'}
  function smaFmtLine(v){const n=Number(v);return Number.isFinite(n)?`${n>0?'+':''}${Math.round(n*100)/100}`:'-'}
  function smaModeLabel(mode){return mode==='PRE'?'PRE-MATCH':mode==='H1'?'LIVE H1':'LIVE FT'}

  function smaFixtureFromBundle(bundle,fallback){
    const m=bundle?.meta||{},fx=m.fixture||fallback?.fixture||{},teams=m.teams||fallback?.teams||{},league=m.league||fallback?.league||{},goals=m.goals||fallback?.goals||{};
    return {
      ...(fallback||{}),
      fixture:{...(fallback?.fixture||{}),...fx,id:m.fixture_id||fx.id||fallback?.fixture?.id},
      teams:{...(fallback?.teams||{}),...teams},
      league:{...(fallback?.league||{}),...league},
      goals:{...(fallback?.goals||{}),...goals},
      score:m.score||fallback?.score||null
    }
  }

  function smaRecentTeam(rows,teamId){
    const valid=(rows||[]).filter(x=>['FT','AET','PEN'].includes(String(x.status||''))).slice(0,5);
    let pts=0,gf=0,ga=0,n=0;
    for(const r of valid){
      const home=Number(r.home_id)===Number(teamId),away=Number(r.away_id)===Number(teamId);
      if(!home&&!away)continue;
      const a=Number(r.goals?.home),b=Number(r.goals?.away);if(!Number.isFinite(a)||!Number.isFinite(b))continue;
      const f=home?a:b,g=home?b:a;gf+=f;ga+=g;n++;pts+=f>g?3:f===g?1:0
    }
    return {n,pts,ppg:n?pts/n:null,gf:n?gf/n:null,ga:n?ga/n:null}
  }

  function smaStatAvg(teamStats,side,venue){
    const x=teamStats?.goals?.[side]?.average;
    if(x==null)return null;
    if(typeof x==='object'){
      const v=smaNum(x?.[venue],null);if(v!=null)return v;
      return smaNum(x?.total,null)
    }
    return smaNum(x,null)
  }

  function smaGoalRangeMid(v){
    if(v==null)return null;
    if(typeof v==='number')return Number.isFinite(v)?v:null;
    const nums=String(v).match(/\d+(?:\.\d+)?/g)?.map(Number).filter(Number.isFinite)||[];
    if(!nums.length)return null;
    if(nums.length===1)return nums[0];
    return (nums[0]+nums[1])/2
  }

  function smaPreSideEvidence(bundle){
    const n=bundle?.normalized||{},m=bundle?.meta||{},hid=m.teams?.home?.id,aid=m.teams?.away?.id,
          hr=smaRecentTeam(n.home_recent,hid),ar=smaRecentTeam(n.away_recent,aid),
          homeName=m.teams?.home?.name,awayName=m.teams?.away?.name,
          hs=(n.standings||[]).find(x=>x.team===homeName||Number(x.team_id)===Number(hid)),
          as=(n.standings||[]).find(x=>x.team===awayName||Number(x.team_id)===Number(aid)),
          p=n.api_prediction?.percent||{},ph=smaPct(p.home),pa=smaPct(p.away),
          hgf=smaStatAvg(n.home_team_stats,'for','home'),hga=smaStatAvg(n.home_team_stats,'against','home'),
          agf=smaStatAvg(n.away_team_stats,'for','away'),aga=smaStatAvg(n.away_team_stats,'against','away'),
          inj=n.injuries||[],hi=inj.filter(x=>Number(x.team_id)===Number(hid)).length,ai=inj.filter(x=>Number(x.team_id)===Number(aid)).length;
    let edge=2.0,sources=1;const why=[];

    if(hr.ppg!=null&&ar.ppg!=null){const c=smaClamp((hr.ppg-ar.ppg)*3.6,-9,9);edge+=c;sources++;why.push(`Form5 ${hr.ppg.toFixed(2)} vs ${ar.ppg.toFixed(2)} PPG`)}
    if(Number.isFinite(Number(hs?.rank))&&Number.isFinite(Number(as?.rank))){const c=smaClamp((Number(as.rank)-Number(hs.rank))*.75,-8,8);edge+=c;sources++;why.push(`BXH #${hs.rank} vs #${as.rank}`)}
    if([hgf,hga,agf,aga].every(x=>x!=null)){const hnet=hgf-hga,anet=agf-aga,c=smaClamp((hnet-anet)*4,-8,8);edge+=c;sources++;why.push(`Season net ${smaRound(hnet,2)} vs ${smaRound(anet,2)}`)}
    if(ph!=null&&pa!=null){const c=smaClamp((ph-pa)*.18,-10,10);edge+=c;sources++;why.push(`API model vote ${ph}% vs ${pa}%`)}
    if(hi||ai){const c=smaClamp((ai-hi)*1.2,-5,5);edge+=c;sources++;why.push(`Injuries ${hi}-${ai}`)}
    edge=smaClamp(edge,-35,35);
    const direction=Math.abs(edge)<5?'BALANCED':edge>0?'HOME':'AWAY';
    return {edge:smaRound(edge,1),direction,sources,source_quality:smaClamp(sources/5,0,1),home_recent:hr,away_recent:ar,why:why.slice(0,5)}
  }

  function smaRecentTotalAvg(rows){
    const vals=(rows||[]).filter(x=>['FT','AET','PEN'].includes(String(x.status||''))).slice(0,5)
      .map(x=>Number(x.goals?.home)+Number(x.goals?.away)).filter(Number.isFinite);
    return vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:null
  }

  function smaPreGoalEnvironment(bundle){
    const n=bundle?.normalized||{},parts=[],why=[];
    const hRec=smaRecentTotalAvg(n.home_recent),aRec=smaRecentTotalAvg(n.away_recent);
    if(hRec!=null&&aRec!=null){const x=(hRec+aRec)/2;parts.push(x);why.push(`Recent total BQ ${x.toFixed(2)}`)}
    const hgf=smaStatAvg(n.home_team_stats,'for','home'),hga=smaStatAvg(n.home_team_stats,'against','home'),
          agf=smaStatAvg(n.away_team_stats,'for','away'),aga=smaStatAvg(n.away_team_stats,'against','away');
    if([hgf,hga,agf,aga].every(x=>x!=null)){
      const x=((hgf+aga)/2)+((agf+hga)/2);parts.push(x);why.push(`Season goal environment ${x.toFixed(2)}`)
    }
    const pg=n.api_prediction?.goals||{},ph=smaGoalRangeMid(pg.home),pa=smaGoalRangeMid(pg.away);
    if(ph!=null&&pa!=null){const x=ph+pa;parts.push(x);why.push(`API goal model ${x.toFixed(2)}`)}
    const expected=parts.length?parts.reduce((a,b)=>a+b,0)/parts.length:null;
    return {expected:expected==null?null:smaRound(expected,2),sources:parts.length,why}
  }

  function smaOuParseValue(v){
    const label=String(v?.value||'').trim(),low=label.toLowerCase();
    const side=/\bover\b/.test(low)?'OVER':/\bunder\b/.test(low)?'UNDER':null;
    let line=smaNum(v?.handicap,null);
    if(line==null){const nums=label.match(/[+-]?\d+(?:[.,]\d+)?/g);if(nums?.length)line=smaNum(nums[nums.length-1].replace(',','.'),null)}
    const odd=smaNum(v?.odd,null);
    return side&&line!=null&&odd>1?{side,line,odd}:null
  }

  function smaOuConsensus(markets,category='over_under'){
    const rows=[];
    for(const m of (markets||[])){
      if(m.category!==category||m.integrity?.valid===false)continue;
      const vals=(m.values||[]).filter(v=>!v.suspended).map(smaOuParseValue).filter(Boolean);
      const lines=[...new Set(vals.map(x=>x.line))];
      for(const line of lines){
        const over=vals.find(x=>x.line===line&&x.side==='OVER'),under=vals.find(x=>x.line===line&&x.side==='UNDER');
        if(over&&under)rows.push({book:m.bookmaker||'MARKET',line,over:over.odd,under:under.odd})
      }
    }
    if(!rows.length)return null;
    const groups=new Map();
    for(const r of rows){const k=String(r.line);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r)}
    const ranked=[...groups.entries()].map(([k,a])=>({
      line:Number(k),books:a.length,over:smaMedian(a.map(x=>x.over)),under:smaMedian(a.map(x=>x.under)),rows:a
    })).sort((a,b)=>b.books-a.books||Math.abs(a.over-a.under)-Math.abs(b.over-b.under));
    return ranked[0]||null
  }

  function smaMatchWinnerChoice(markets,direction){
    if(!['HOME','AWAY'].includes(direction))return null;
    for(const m of (markets||[])){
      if(m.category!=='match_winner'||m.integrity?.valid===false)continue;
      const vals=(m.values||[]).filter(v=>!v.suspended);
      const v=vals.find(x=>x.selection_outcome===direction.toLowerCase());
      const odd=smaNum(v?.odd,null);
      if(v&&odd>1)return {market:m,odd,value:v.value}
    }
    return null
  }

  function smaPreCandidates(bundle){
    const n=bundle?.normalized||{},dq=Number(bundle?.coverage?.score||0),side=smaPreSideEvidence(bundle),goal=smaPreGoalEnvironment(bundle),
          markets=n.market?.prematch||[],out=[],home=bundle?.meta?.teams?.home?.name||'HOME',away=bundle?.meta?.teams?.away?.name||'AWAY';

    // Asian Handicap candidate.
    const ah=hcMarketFromRows(markets,home,away);
    if(ah?.valid&&['HOME','AWAY'].includes(side.direction)){
      const line=side.direction==='HOME'?Number(ah.line):-Number(ah.line),
            odd=side.direction==='HOME'?Number(ah.homeOdd):Number(ah.awayOdd),
            burden=line<0?Math.min(11,Math.abs(line)*6):Math.max(-4,-Math.abs(line)*2),
            score=smaClamp(58+Math.abs(side.edge)*.82-burden+(dq>=70?5:dq>=50?2:-5)+(ah.bookmakerCount>=3?4:0),0,100);
      out.push({
        id:'PRE_AH',market:'ASIAN HANDICAP',selection:side.direction,line,odd:Number.isFinite(odd)?odd:null,
        display:`${side.direction==='HOME'?home:away} ${smaFmtLine(line)}${Number.isFinite(odd)?' @'+smaFmtOdd(odd):''}`,
        score:Math.round(score),actionable:score>=SMA_MIN_PRE_ACTION&&side.source_quality>=.55&&dq>=50,
        state:score>=SMA_MIN_PRE_ACTION?'MODEL CANDIDATE':score>=SMA_MIN_PRE_WATCH?'WATCH':'NO EDGE',
        why:[`PRE side edge ${side.edge>0?'+':''}${side.edge}`, ...side.why.slice(0,3)],
        risk:[line<-.75?'Line favorite khá sâu':null,side.sources<3?'PRE evidence ít nguồn':null].filter(Boolean),
        source:'PRE_SIDE_MODEL'
      })
    }

    // Match Total candidate.
    const ou=smaOuConsensus(markets,'over_under');
    if(ou&&goal.expected!=null){
      const gap=goal.expected-ou.line,dir=Math.abs(gap)<.25?null:gap>0?'OVER':'UNDER',
            odd=dir==='OVER'?ou.over:dir==='UNDER'?ou.under:null,
            score=dir?smaClamp(58+Math.abs(gap)*22+(dq>=70?5:dq>=50?2:-5)+(ou.books>=2?3:0),0,100):50;
      if(dir)out.push({
        id:'PRE_TOTAL',market:'MATCH TOTAL',selection:dir,line:ou.line,odd,
        display:`${dir} ${smaFmtLine(ou.line)} @${smaFmtOdd(odd)}`,
        score:Math.round(score),actionable:score>=SMA_MIN_PRE_ACTION&&goal.sources>=2&&dq>=50,
        state:score>=SMA_MIN_PRE_ACTION?'MODEL CANDIDATE':score>=SMA_MIN_PRE_WATCH?'WATCH':'NO EDGE',
        why:[`Goal environment ${goal.expected} vs line ${ou.line}`,...goal.why.slice(0,3)],
        risk:[goal.sources<2?'Goal environment ít nguồn':null,ou.books<2?'Market breadth thấp':null].filter(Boolean),
        source:'PRE_TOTAL_MODEL'
      })
    }

    // Match Winner as fallback side market.
    const ml=smaMatchWinnerChoice(markets,side.direction);
    if(ml&&Math.abs(side.edge)>=10){
      const score=smaClamp(54+Math.abs(side.edge)*.75+(dq>=70?5:dq>=50?2:-5),0,100);
      out.push({
        id:'PRE_ML',market:'MATCH WINNER',selection:side.direction,line:null,odd:ml.odd,
        display:`${side.direction==='HOME'?home:away} WIN @${smaFmtOdd(ml.odd)}`,
        score:Math.round(score),actionable:score>=82&&side.source_quality>=.65&&dq>=55,
        state:score>=82?'MODEL CANDIDATE':score>=SMA_MIN_PRE_WATCH?'WATCH':'NO EDGE',
        why:[`PRE side edge ${side.edge>0?'+':''}${side.edge}`,...side.why.slice(0,2)],
        risk:['1X2 chịu rủi ro hòa'],
        source:'PRE_SIDE_MODEL'
      })
    }
    return {candidates:out,side,goal}
  }

  async function smaBackgroundRows(fixtureId,limit=100){
    try{
      const db=await bgIDBOpen();if(!db)return [];
      return await new Promise(resolve=>{
        const tx=db.transaction(BG_DB_STORE,'readonly'),idx=tx.objectStore(BG_DB_STORE).index('fixture_id'),out=[],
              req=idx.openCursor(IDBKeyRange.only(Number(fixtureId)),'prev');
        req.onsuccess=e=>{const c=e.target.result;if(c&&out.length<limit){out.push(c.value);c.continue()}else resolve(out.reverse())};
        req.onerror=()=>resolve([])
      })
    }catch{return []}
  }

  function smaMergeTimeline(...sets){
    const map=new Map();
    for(const rows of sets)for(const x of (rows||[]))if(Number(x?.captured_at))map.set(String(x.captured_at),x);
    return [...map.values()].sort((a,b)=>Number(a.captured_at)-Number(b.captured_at))
  }

  function smaBgWatchHistory(bgRows,mode){
    const out=[];
    for(const r of (bgRows||[])){
      if(!r?.stats_raw?.length)continue;
      const min=Number(r.fixture?.fixture?.status?.elapsed||0);
      if(mode==='H1'&&min>45)continue;
      if(mode==='FT'&&min<44)continue;
      try{const s=bgToWatchSnapshot(r,mode);if(s)out.push(s)}catch{}
    }
    return out
  }

  function smaHcPreBaseline(bundle){
    const p=bundle?.normalized?.api_prediction?.percent||{},h=smaPct(p.home),a=smaPct(p.away);
    if(h!=null&&a!=null){
      const adv=watchClamp((h-a)/Math.max(50,h+a)*16,-10,10);
      return {adv:smaRound(adv,1),source:'DEEP_PREDICTION',home:h,away:a}
    }
    const side=smaPreSideEvidence(bundle);
    return {adv:smaClamp(side.edge*.22,-8,8),source:'PRE_EVIDENCE',home:null,away:null}
  }

  function smaBgHandicapHistory(bgRows,fixture){
    const meta=compactFixtureMeta(fixture,autoModeForFixture(fixture)),history=[],marketHistory=[],home=fixture.teams?.home?.name||'',away=fixture.teams?.away?.name||'';
    for(const r of (bgRows||[])){
      if(!r?.stats_raw?.length)continue;
      try{
        const sm=statMap(r.stats_raw),metrics=handicapAggregate(sm,meta),f=r.fixture||fixture,rows=r.odds_raw?.length?oddsCompact(r.odds_raw,true,{homeName:home,awayName:away}):[],
              market=hcMarketFromRows(rows,home,away),captured=Number(r.captured_at||Date.now());
        history.push({
          captured_at:captured,fresh_at:captured,minute:Number(f.fixture?.status?.elapsed||0),status:f.fixture?.status?.short||'',
          goals:{home:Number(f.goals?.home||0),away:Number(f.goals?.away||0)},metrics,market,fixture:f,events:eventsCompact(r.events_raw||[]),source:'BACKGROUND_WORKER'
        });
        if(market?.valid)marketHistory.push({captured_at:captured,minute:Number(f.fixture?.status?.elapsed||0),score:`${Number(f.goals?.home||0)}-${Number(f.goals?.away||0)}`,line:Number(market.line),homeOdd:market.homeOdd,awayOdd:market.awayOdd})
      }catch{}
    }
    return {history,marketHistory}
  }

  async function smaLiveTotalEngine(bundle,fixture,bgRows){
    const mode=bundle.meta.mode==='H1'?'H1':'FT',id=Number(bundle.meta.fixture_id),
          local=mode==='H1'?h1WatchReadHistory(id):watchReadHistory(id),
          bg=smaBgWatchHistory(bgRows,mode),
          item={
            id,home:bundle.meta.teams?.home?.name||'',away:bundle.meta.teams?.away?.name||'',
            league:`${bundle.meta.league?.name||''}${bundle.meta.league?.country?' | '+bundle.meta.league.country:''}`,
            initialDQ:Number(bundle.coverage?.score||0),initialIntegrity:bundle.coverage?.integrity_score??100,
            apiCoverage:bundle.normalized?.api_coverage||null,
            history:smaMergeTimeline(local,bg).slice(mode==='H1'?-90:-80),state:'LOW',reason:'',dataMissStreak:0,peak:0
          };
    const s=mode==='H1'?await fetchH1WatchSnapshot(item,true,fixture):await fetchWatchSnapshot(item,true,fixture);
    if(s?.ended)return {mode,item,s:null,ended:true};
    item.history=smaMergeTimeline(item.history,[s]).slice(mode==='H1'?-90:-80);
    item.latest=s;
    item.eval=mode==='H1'?h1WatchEvaluate(item,s):watchEvaluate(item,s);
    item.peak=item.eval.score;
    if(mode==='H1')h1WatchApplyState(item,s,null);else watchApplyState(item,s,null);

    s.goal_potential=await gpBuildShadow(item,s,item.eval,mode);
    s.live_vs_market=await lvmBuildShadow(item,s.goal_potential,s.market_expectation,mode);
    s.line_price_value=await lpvBuildShadow(item,s.market_time,s.goal_potential,s.market_expectation,s.live_vs_market,mode);
    s.robustness=await rbBuildShadow(item,s.goal_potential,s.market_expectation,s.live_vs_market,s.line_price_value,mode);
    s.final_model_decision=await fmdBuildShadow(item,s,mode);
    return {mode,item,s,ended:false,history_count:item.history.length}
  }

  async function smaLiveHandicapEngine(bundle,fixture,bgRows){
    const id=Number(bundle.meta.fixture_id),n=bundle.normalized||{},meta=bundle.meta,home=meta.teams?.home?.name||'',away=meta.teams?.away?.name||'',
          full=n.live_statistics?.full||{},metrics=handicapAggregate(full,meta),
          market=hcMarketFromRows(n.market?.live||[],home,away),
          bg=smaBgHandicapHistory(bgRows,fixture),
          local=hcReadHistory(id),
          current={
            captured_at:Date.now(),fresh_at:Date.now(),minute:Number(meta.fixture?.status?.elapsed||0),status:meta.fixture?.status?.short||'',
            goals:{home:Number(meta.goals?.home||0),away:Number(meta.goals?.away||0)},metrics,market,fixture,events:n.events||[],source:'DEEP_SINGLE'
          },
          item={
            id,home,away,league:`${meta.league?.name||''}${meta.league?.country?' | '+meta.league.country:''}`,
            preBaseline:smaHcPreBaseline(bundle),history:smaMergeTimeline(local,bg.history).slice(-140),
            marketHistory:(bg.marketHistory||[]).slice(-60),latest:current,resetAt:null,cooldownUntil:0,activeSignal:null
          };
    if(market?.valid)hcMarketHistory(item,market,current);
    item.history=smaMergeTimeline(item.history,[current]).slice(-140);
    item.eval=hcEvaluate(item,current);
    const q=qsigAssessHC(item,current);
    return {item,s:current,q,history_count:item.history.length,bg_history_count:bg.history.length}
  }

  function smaLiveTotalCandidate(x){
    if(!x?.s)return null;
    const d=x.s.final_model_decision,lpv=x.s.line_price_value,gp=x.s.goal_potential,lvm=x.s.live_vs_market,rb=x.s.robustness,
          best=d?.selected||lpv?.best;
    if(!best)return null;
    const buy=d?.verdict==='BUY_CANDIDATE',watch=!buy&&['POSITIVE','STRONG_POSITIVE'].includes(String(best?.grade?.key||''))&&Number(gp?.band?.rank||0)>=3,
          score=buy?(d.path==='STANDARD'?93:89):watch?68:52,
          market=x.mode==='H1'?'H1 TOTAL':'MATCH TOTAL';
    return {
      id:x.mode==='H1'?'LIVE_H1_TOTAL':'LIVE_FT_TOTAL',market,selection:'OVER',line:Number(best.line),odd:Number(best.over_odd),
      display:`OVER ${smaFmtLine(best.line)} @${smaFmtOdd(best.over_odd)}`,score,actionable:buy,
      state:buy?(score>=92?'STRONG MODEL CANDIDATE':'MODEL CANDIDATE'):watch?'WATCH':'NO EDGE',
      why:[
        `RUNG ${x.item.state} ${x.item.eval?.score??'-'}/100`,
        `Goal Potential ${gp?.band?.label||'N/A'} ${gp?.trend?.arrow||''}`.trim(),
        lvm?.classification?.label||'LIVE/MARKET N/A',
        `Line Value ${best?.grade?.label||best?.grade?.key||'N/A'}`,
        `Robustness ${rb?.label||rb?.key||'N/A'}`
      ],
      risk:[d?.main_risk||null,x.history_count<2?'Recent history còn mỏng':null].filter(Boolean),
      source:'LIVE_TOTAL_FMD',detail:{decision:d,rung:x.item.state,gp,lvm,rb,lpv}
    }
  }

  function smaLiveHcCandidate(hc){
    const e=hc?.item?.eval,s=hc?.s;if(!e||!s?.market?.valid||!['HOME','AWAY'].includes(e.states?.direction))return null;
    const dir=e.states.direction,line=dir==='HOME'?Number(s.market.line):-Number(s.market.line),
          odd=dir==='HOME'?Number(s.market.homeOdd):Number(s.market.awayOdd),
          strong=['HOME_STRONG','AWAY_STRONG'].includes(e.state),
          lean=['HOME_LEAN','AWAY_LEAN'].includes(e.state),
          qualified=!!hc.q?.qualified,
          score=strong?(qualified?94:88):lean?72:e.state==='DIVERGENCE'?42:58;
    return {
      id:'LIVE_AH',market:'ASIAN HANDICAP',selection:dir,line,odd:Number.isFinite(odd)?odd:null,
      display:`${dir==='HOME'?hc.item.home:hc.item.away} ${smaFmtLine(line)}${Number.isFinite(odd)?' @'+smaFmtOdd(odd):''}`,
      score,actionable:strong,
      state:strong?(qualified?'STRONG MODEL CANDIDATE':'MODEL CANDIDATE'):lean?'WATCH':e.state==='DIVERGENCE'?'CONTRADICTION':'NO EDGE',
      why:[
        `LIVE GAP ${e.states.liveGap>0?'+':''}${e.states.liveGap}`,
        `Football Core ${e.core?.footballCount??0}/3 • Total ${e.core?.count??0}/4`,
        `Momentum ${dir==='HOME'?e.homeTrend?.trend:e.awayTrend?.trend}`,
        `Market ${e.marketFit?.level||'N/A'}`,
        qualified?'QSIG QUALIFIED':'QSIG chưa qualified'
      ],
      risk:[e.evidenceThin?'Evidence còn mỏng':null,e.dataTier!=='FULL'?`Data ${e.dataTier}`:null,!Number.isFinite(odd)?'Thiếu current price':null].filter(Boolean),
      source:'LIVE_HANDICAP',detail:{eval:e,qsig:hc.q,history_count:hc.history_count,bg_history_count:hc.bg_history_count}
    }
  }

  function smaDecide(candidates,mode,dq){
    const ranked=(candidates||[]).filter(Boolean).sort((a,b)=>Number(b.score||0)-Number(a.score||0));
    const actionable=ranked.filter(x=>x.actionable);
    if(actionable.length){
      const top=actionable[0],label=top.score>=92?'STRONG MODEL CANDIDATE':'MODEL CANDIDATE';
      return {verdict:'MODEL_CHOICE',label,top,ranked,mode,dq}
    }
    return {verdict:'PASS_NOW',label:'PASS NOW',top:ranked[0]||null,ranked,mode,dq}
  }

  function smaMainRisk(decision,bundle){
    const t=decision?.top,dq=Number(bundle?.coverage?.score||0);
    if(dq<50)return 'Data Quality thấp; kết luận dễ thay đổi khi dữ liệu đầy đủ hơn.';
    if(t?.risk?.length)return t.risk[0];
    if(decision.mode!=='PRE'){
      const min=Number(bundle?.meta?.fixture?.status?.elapsed||0);
      if(min>=82)return 'Quỹ thời gian ngắn; state có thể thay đổi nhanh.';
    }
    return 'Rủi ro kết quả vẫn tồn tại dù model choice đạt điều kiện.'
  }

  function smaWhyText(decision){
    if(decision?.verdict==='MODEL_CHOICE')return 'Model đã so các market khả dụng và chọn đúng lựa chọn có state + market fit tốt nhất tại snapshot hiện tại.';
    if(decision?.top?.state==='WATCH')return 'Có market đáng theo dõi nhưng chưa đủ điều kiện để nâng thành Model Choice ở snapshot hiện tại.';
    return 'Không có market nào đồng thời đạt state, dữ liệu và mức phù hợp cần thiết; model chủ động PASS.'
  }

  function smaCandidateClass(x){
    if(x?.actionable)return x.score>=92?'strong':'candidate';
    if(x?.state==='WATCH')return 'watch';
    if(x?.state==='CONTRADICTION')return 'danger';
    return 'neutral'
  }

  function smaRender(result){
    const el=els.smaResult;if(!el)return;
    const d=result.decision,b=result.bundle,m=b.meta||{},top=d.top,mode=smaModeLabel(m.mode),
          score=`${Number(m.goals?.home||0)}-${Number(m.goals?.away||0)}`,
          title=d.verdict==='MODEL_CHOICE'?(top?.display||'MODEL CHOICE'):'NO ACCEPTED MARKET',
          pre=result.pre,live=result.live,total=live?.total,hc=live?.handicap;
    const rows=(d.ranked||[]).map((x,i)=>`
      <div class="sma-rank-row ${smaCandidateClass(x)}">
        <div class="sma-rank-no">#${i+1}</div>
        <div class="sma-rank-main"><span>${esc(x.market)}</span><b>${esc(x.display)}</b><small>${esc(x.state)} • ${esc(x.source)}</small></div>
        <div class="sma-rank-score"><span>MODEL RANK</span><b>${Math.round(Number(x.score||0))}</b></div>
      </div>`).join('')||'<div class="sma-empty">Không có market hợp lệ để xếp hạng tại snapshot này.</div>';

    const engineCards=m.mode==='PRE'?`
      <div class="sma-engine-card"><span>PRE SIDE EDGE</span><b>${pre?.side?.direction||'N/A'} ${pre?.side?.edge!=null?`(${pre.side.edge>0?'+':''}${pre.side.edge})`:''}</b><small>${pre?.side?.sources||0} nguồn nền</small></div>
      <div class="sma-engine-card"><span>GOAL ENVIRONMENT</span><b>${pre?.goal?.expected??'N/A'}</b><small>${pre?.goal?.sources||0} nguồn goal proxy</small></div>
      <div class="sma-engine-card"><span>DATA QUALITY</span><b>${b.coverage?.score??0}%</b><small>Coverage / Integrity / Freshness</small></div>
      <div class="sma-engine-card"><span>MODE</span><b>PRE-MATCH</b><small>Market + nền trước trận</small></div>`:`
      <div class="sma-engine-card live"><span>RUNG ${esc(total?.mode||m.mode)}</span><b>${esc(total?.item?.state||'N/A')} ${total?.item?.eval?.score??'—'}/100</b><small>CORE ${total?.item?.eval?.core?.strongCount??'—'}/3</small></div>
      <div class="sma-engine-card goal"><span>GOAL POTENTIAL</span><b>${esc(total?.s?.goal_potential?.band?.label||'N/A')} ${esc(total?.s?.goal_potential?.trend?.arrow||'')}</b><small>${total?.s?.goal_potential?.index??'—'}/100</small></div>
      <div class="sma-engine-card market"><span>LIVE VS MARKET</span><b>${esc(total?.s?.live_vs_market?.classification?.label||'N/A')}</b><small>Gap ${total?.s?.live_vs_market?.gap??'—'}</small></div>
      <div class="sma-engine-card handicap"><span>HANDICAP STATE</span><b>${esc(hc?.item?.eval?.state||'N/A')}</b><small>LIVE GAP ${hc?.item?.eval?.states?.liveGap??'—'} • CORE ${hc?.item?.eval?.core?.count??'—'}/4</small></div>`;

    el.innerHTML=`
      <section class="sma-shell ${d.verdict==='MODEL_CHOICE'?'has-choice':'pass'}">
        <div class="sma-topline"><span>SINGLE MATCH ANALYZER</span><b>${esc(mode)} • DQ ${b.coverage?.score??0}%</b></div>
        <div class="sma-fixture-line"><b>${esc(m.teams?.home?.name||'HOME')} vs ${esc(m.teams?.away?.name||'AWAY')}</b><span>${m.mode==='PRE'?esc(m.kickoff_vn||''):`${esc(m.fixture?.status?.elapsed??'—')}' • ${esc(score)}`}</span></div>

        <div class="sma-final ${d.verdict==='MODEL_CHOICE'?'choice':'pass'}">
          <div>
            <span>FINAL MODEL CHOICE</span>
            <strong>${esc(d.label)}</strong>
            <small>${esc(smaWhyText(d))}</small>
          </div>
          <div class="sma-pick"><b>${esc(title)}</b><em>${top?esc(top.market):'PASS'}</em></div>
        </div>

        <div class="sma-engine-grid">${engineCards}</div>

        <div class="sma-section-title"><span>CROSS-MARKET RANKING</span><small>Model Rank là điểm xếp hạng nội bộ, không phải xác suất.</small></div>
        <div class="sma-ranking">${rows}</div>

        <div class="sma-why-risk">
          <div><span>WHY</span><b>${esc(top?.why?.slice(0,3).join(' • ')||smaWhyText(d))}</b></div>
          <div class="risk"><span>MAIN RISK</span><b>${esc(smaMainRisk(d,b))}</b></div>
        </div>

        <div class="sma-actions">
          <button class="primary" id="smaReanalyzeBtn" type="button">↻ PHÂN TÍCH LẠI</button>
          <button id="smaFollowBtn" type="button">◎ THEO DÕI TRẬN NÀY</button>
          <button id="smaRecordFinalBtn" type="button">✓ GHI NHẬN MODEL CHOICE</button>
        </div>
        <div class="sma-footnote">MODEL CHOICE là kết luận analytics tại T0 hiện tại; không phải đảm bảo kết quả. Khi LIVE thay đổi hoặc market đổi line/giá, cần Analyze lại.</div>
      </section>`;
    el.classList.remove('hidden');
    el.scrollIntoView({behavior:'smooth',block:'start'})
  }

  async function smaAnalyzeSelected(){
    if(state.singleAnalyzer.running){showToast('busy','SINGLE MATCH ANALYZER đang chạy','Chờ lượt phân tích hiện tại hoàn tất.');return}
    if(!state.selected){status(els.selected,'Hãy chọn 1 trận trước.','err');return}
    if(!els.fkey.value.trim()){showToast('err','Chưa có Football API Key','Lưu API key trước khi phân tích.');return}

    state.singleAnalyzer.running=true;
    const initial=state.selected,requested=autoModeForFixture(initial);
    saveConfig(true);
    loading(true,'SINGLE MATCH ANALYZER','Đang lấy DEEP data • xác định PRE/LIVE • so market • chốt Model Choice');
    els.smaResult?.classList.add('hidden');
    try{
      const bundle=await getDeepBundle(initial,requested),fixture=smaFixtureFromBundle(bundle,initial),mode=bundle.meta.mode;
      state.selected=fixture;state.mode=mode;setMode(mode);
      if(els.smaAutoMode)els.smaAutoMode.textContent=smaModeLabel(mode);
      state.lastBundle=bundle;renderCoverage(bundle.coverage);

      let pre=null,live=null,candidates=[];
      if(mode==='PRE'){
        pre=smaPreCandidates(bundle);candidates=pre.candidates
      }else{
        const bgRows=await smaBackgroundRows(bundle.meta.fixture_id,120);
        const total=await smaLiveTotalEngine(bundle,fixture,bgRows);
        const handicap=await smaLiveHandicapEngine(bundle,fixture,bgRows);
        const tc=smaLiveTotalCandidate(total),hc=smaLiveHcCandidate(handicap);
        live={total,handicap,bg_rows:bgRows.length};
        candidates=[tc,hc].filter(Boolean)
      }

      const decision=smaDecide(candidates,mode,bundle.coverage?.score||0),result={
        version:SMA_VERSION,captured_at:Date.now(),bundle,fixture,pre,live,candidates,decision
      };
      state.singleAnalyzer.last=result;smaRender(result);
      log('Single Match Analyzer',{fixture_id:bundle.meta.fixture_id,mode,decision:decision.label,choice:decision.top?.display||null,rank:decision.top?.score||null});
      if(decision.verdict==='MODEL_CHOICE')showToast('ok',decision.label,decision.top?.display||'Model Choice đã sẵn sàng.');
      else showToast('busy','PASS NOW',decision.top?.state==='WATCH'?'Có WATCH nhưng chưa đủ điều kiện Model Choice.':'Không có market đạt điều kiện hiện tại.')
    }catch(e){
      els.smaResult?.classList.remove('hidden');
      if(els.smaResult)els.smaResult.innerHTML=`<div class="status err"><b>SINGLE MATCH ANALYZER chưa hoàn tất.</b><br>${esc(e.message)}</div>`;
      log('Single Match Analyzer error',e.message);showToast('err','Phân tích lỗi',e.message)
    }finally{
      state.singleAnalyzer.running=false;loading(false)
    }
  }

  async function smaFollowSelected(){
    const f=state.singleAnalyzer.last?.fixture||state.selected;
    if(!f){showToast('err','Chưa có trận','Chọn và phân tích một trận trước.');return}
    if(!bgEnabled()){
      showToast('err','Background Watch chưa bật','Vào Cài đặt → Nâng cao → bật Background Watch trước.');
      return
    }
    const r=await bgRegisterFixtures([f],'focus','SINGLE_MATCH',false);
    if(!r?.error)showToast('ok','ĐÃ THEO DÕI NỀN',`${f.teams?.home?.name||''} vs ${f.teams?.away?.name||''} đã được nâng lên FOCUS.`)
  }

  $('singleAnalyzeBtn')?.addEventListener('click',smaAnalyzeSelected);
  els.smaResult?.addEventListener('click',e=>{
    if(e.target?.id==='smaReanalyzeBtn')smaAnalyzeSelected();
    if(e.target?.id==='smaFollowBtn')smaFollowSelected();
    if(e.target?.id==='smaRecordFinalBtn'){setBetTab('active');$('betTrackerCard')?.scrollIntoView({behavior:'smooth',block:'start'});setTimeout(()=>openBetForm({fromFinal:true}),220)}
  });


  $('prepareBtn').addEventListener('click',async()=>{
    if(!state.selected){status(els.selected,'Hãy chọn một trận trước khi tạo gói.','err');return}
    const liveNow=isLive(state.selected);if(state.mode!=='PRE'&&!liveNow){status(els.selected,'Trận chưa LIVE. Hãy dùng PRE-MATCH hoặc chờ trận bắt đầu.','err');return}
    if(state.mode==='H1'&&liveNow&&!['1H','HT'].includes(state.selected.fixture.status.short)){status(els.selected,'Trận không còn ở hiệp 1. Hãy chọn LIVE FT.','err');return}
    saveConfig(true);loading(true,'Đang lấy DEEP snapshot','Fixture • H1/H2 Stats • Players • Prediction • Market • Context');els.result.classList.add('hidden');els.packetBox.classList.add('hidden');
    try{const bundle=await getDeepBundle(state.selected,state.mode);state.lastBundle=bundle;renderCoverage(bundle.coverage);log('Bundle coverage',bundle.coverage);renderPacket(bundle)}catch(e){log('Tạo gói lỗi',e.message);els.result.classList.remove('hidden');els.result.innerHTML=`<div class="status err"><b>Không tạo được gói.</b><br>${esc(e.message)}</div>`}finally{loading(false)}
  });
  $('copyBtn').addEventListener('click',async()=>{try{await copyPacket();flashCopyButton($('copyBtn'));const isXien=String(state.lastPacketKind).startsWith('xien5_');showToast('ok',isXien?'Đã copy gói XIÊN 5':state.lastPacketKind==='group'?'Đã copy gói cả khung':'Đã copy gói phân tích',isXien?'Dán vào Project để GPT chọn 5 LEG và ghi đủ giờ/giải/trận/kèo.':state.lastPacketKind==='group'?'Dán vào Project để GPT chọn TOP 1 trận để đi sâu.':'Gói đã nằm trong bộ nhớ tạm. Có thể mở Project và dán vào chat.');status(els.conn,'Đã COPY gói phân tích. Mở Project và dán vào chat.','ok')}catch(e){showToast('err','Copy chưa thành công','Hãy giữ tay trên ô dữ liệu và chọn Sao chép.');status(els.conn,'Không copy tự động được: '+e.message+' — hãy giữ tay trên ô dữ liệu và chọn Sao chép.','err')}});
  $('openProjectBtn').addEventListener('click',()=>{saveConfig(true);openProject()});
  $('copyOpenBtn').addEventListener('click',async()=>{
    if(!state.lastPacket){status(els.conn,'Chưa có gói phân tích. Hãy bấm TẠO GÓI PHÂN TÍCH trước.','err');return}
    const url=els.projectUrl.value.trim();let popup=null;
    try{const u=new URL(url);if(!/^https?:$/.test(u.protocol))throw new Error();popup=window.open(u.href,'_blank','noopener,noreferrer')}catch{status(els.conn,'Link Project chưa hợp lệ. Hãy dán URL đầy đủ bắt đầu bằng https://','err');return}
    try{await copyPacket();flashCopyButton($('copyOpenBtn'));{const isXien=String(state.lastPacketKind).startsWith('xien5_');showToast('ok',isXien?'Đã copy XIÊN 5 & mở Project':state.lastPacketKind==='group'?'Đã copy cả khung & mở Project':'Đã copy & mở Project',isXien?'Dán gói để GPT chọn 5 LEG và trả GIỜ VN • GIẢI • TRẬN • KÈO • LINE/GIÁ.':state.lastPacketKind==='group'?'Dán gói vào chat để GPT shortlist và chọn TOP 1 TARGET.':'Gói đã được copy. Sang ChatGPT, dán vào ô chat rồi gửi.');}saveConfig(true);status(els.conn,'Đã COPY gói và mở ChatGPT Project. Dán vào ô chat rồi gửi.','ok')}catch(e){showToast('err','Mở Project được nhưng copy lỗi','Quay lại app và sao chép gói thủ công.');status(els.conn,'Project đã mở nhưng app không copy tự động được. Hãy quay lại app, giữ tay trên ô dữ liệu và chọn Sao chép.','err')}
  });






  /* ===== V1.8.1 CALIBRATION / RUNG TAI SIGNAL ENGINE ===== */

  /* ===== V1.16.3 ULTRA DATA ORCHESTRATOR =====
     One shared acquisition layer for H1 / FT / HANDICAP.
     The scoring engines remain unchanged; this layer improves recency,
     breadth, dedupe, event/half/personnel context and market consensus. */
  const ULTRA_HUB={
    entries:new Map(),
    inflight:new Map(),
    heartbeat:{at:0,rows:[],map:new Map()},
    metrics:{heartbeat:0,stats:0,events:0,market:0,half:0,players:0,lineups:0,reuse:0,persist:0},
    cleanupAt:0
  };
  const ULTRA_HUB_POLICY={
    HOT:{stats:8000,events:8000,market:10000,half:45000,players:180000,lineups:600000},
    ACTIVE:{stats:12000,events:15000,market:15000,half:60000,players:240000,lineups:900000},
    BACKGROUND:{stats:18000,events:25000,market:25000,half:90000,players:300000,lineups:1200000}
  };
  function ultraTierFor(engine,item){
    const state=String(item?.state||item?.eval?.state||'');
    if(item?.qsig?.high||item?.qsig?.qualified||/STRONG|READY|DIVERGENCE/.test(state))return 'HOT';
    if(/CANDIDATE|WATCH|LEAN|BIAS/.test(state)||Number(item?.eval?.score||0)>=60||Number(item?.eval?.footballWatch||0)>0)return 'ACTIVE';
    return 'BACKGROUND'
  }
  function ultraPolicy(engine,item){return ULTRA_HUB_POLICY[ultraTierFor(engine,item)]||ULTRA_HUB_POLICY.BACKGROUND}
  function ultraEntry(id){
    const k=String(id);if(!ULTRA_HUB.entries.has(k))ULTRA_HUB.entries.set(k,{id:Number(id),created_at:Date.now(),fields:{},changed:{},lastPersistAt:0,lastPersistSig:null});
    return ULTRA_HUB.entries.get(k)
  }
  function ultraSig(x){
    try{
      if(x==null)return 'null';
      const s=JSON.stringify(x);let h=2166136261;
      for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
      return String(h>>>0)
    }catch{return String(Date.now())}
  }
  async function ultraInflight(key,fn){
    if(ULTRA_HUB.inflight.has(key)){ULTRA_HUB.metrics.reuse++;return ULTRA_HUB.inflight.get(key)}
    const p=(async()=>{try{return await fn()}finally{ULTRA_HUB.inflight.delete(key)}})();
    ULTRA_HUB.inflight.set(key,p);return p
  }
  async function ultraHeartbeat(force=false){
    const now=Date.now();
    if(!force&&ULTRA_HUB.heartbeat.at&&now-ULTRA_HUB.heartbeat.at<8000){ULTRA_HUB.metrics.reuse++;return ULTRA_HUB.heartbeat}
    return ultraInflight('heartbeat',async()=>{
      const again=Date.now();
      if(!force&&ULTRA_HUB.heartbeat.at&&again-ULTRA_HUB.heartbeat.at<8000)return ULTRA_HUB.heartbeat;
      const rows=await football('/fixtures',{live:'all',timezone:TZ},true)||[];
      ULTRA_HUB.metrics.heartbeat++;
      ULTRA_HUB.heartbeat={at:Date.now(),rows,map:new Map(rows.map(f=>[String(f.fixture?.id),f]))};
      return ULTRA_HUB.heartbeat
    })
  }
  function ultraAcceptField(entry,key,data,at=Date.now()){
    if(data===null||data===undefined)return entry.fields[key]?.data??null;
    const sig=ultraSig(data),prev=entry.fields[key],changed=!prev||prev.sig!==sig;
    entry.fields[key]={data,sig,at,changed_at:changed?at:(prev?.changed_at||at)};
    if(changed)entry.changed[key]=at;
    return data
  }
  async function ultraField(entry,key,ttl,loader,force=false){
    const now=Date.now(),cur=entry.fields[key];
    if(!force&&cur&&now-Number(cur.at||0)<ttl){ULTRA_HUB.metrics.reuse++;return cur.data}
    return ultraInflight(`${entry.id}:${key}`,async()=>{
      const current=entry.fields[key],t=Date.now();
      if(!force&&current&&t-Number(current.at||0)<ttl)return current.data;
      const data=await loader();
      if(key in ULTRA_HUB.metrics)ULTRA_HUB.metrics[key]++;
      if(data===null||data===undefined){
        if(current){current.at=t;return current.data}
        return data
      }
      return ultraAcceptField(entry,key,data,t)
    })
  }
  function ultraAge(entry,key,kind='request'){
    const x=entry?.fields?.[key];if(!x)return null;
    const ts=kind==='content'?x.changed_at:x.at;
    return ts?Math.max(0,Math.round((Date.now()-Number(ts))/1000)):null
  }
  function ultraPersonnelContext(eventsRaw,playersRaw,homeId,awayId){
    const events=eventsCompact(eventsRaw||[]),subs=events.filter(e=>/subst/i.test(String(e.type||'')+' '+String(e.detail||''))).slice(-8),
          reds=events.filter(e=>/card/i.test(String(e.type||''))&&/red|second yellow/i.test(String(e.detail||''))).slice(-4),
          pc=playersMatchCompact(playersRaw||[]);
    const top=(teamId)=>{
      const team=pc.find(x=>Number(x.team_id)===Number(teamId));if(!team)return [];
      return (team.players||[]).filter(p=>Number.isFinite(parseFloat(p.rating))).sort((a,b)=>parseFloat(b.rating)-parseFloat(a.rating)).slice(0,3)
        .map(p=>({name:p.name,rating:parseFloat(p.rating),minutes:p.minutes,position:p.position}))
    };
    return {
      last_sub_minute:subs.length?Number(subs[subs.length-1].time):null,
      substitutions:subs.map(e=>({minute:e.time,team:e.team,team_id:e.team_id,out:e.player,in:e.assist})),
      red_events:reds.map(e=>({minute:e.time,team:e.team,player:e.player,detail:e.detail})),
      home_top:top(homeId),away_top:top(awayId)
    }
  }
  function ultraContentFreshness(entry){
    return {
      stats_request_age:ultraAge(entry,'stats','request'),stats_content_age:ultraAge(entry,'stats','content'),
      events_request_age:ultraAge(entry,'events','request'),events_content_age:ultraAge(entry,'events','content'),
      market_request_age:ultraAge(entry,'market','request'),market_content_age:ultraAge(entry,'market','content'),
      half_request_age:ultraAge(entry,'half','request'),half_content_age:ultraAge(entry,'half','content'),
      players_request_age:ultraAge(entry,'players','request'),players_content_age:ultraAge(entry,'players','content')
    }
  }

  const ULTRA_IDB={dbp:null};
  function ultraIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(ULTRA_IDB.dbp)return ULTRA_IDB.dbp;
    ULTRA_IDB.dbp=new Promise(resolve=>{
      try{
        const req=indexedDB.open('FOOTBALL_EDGE_ULTRA_V1',1);
        req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('snapshots')){const s=db.createObjectStore('snapshots',{keyPath:'id'});s.createIndex('captured_at','captured_at',{unique:false});s.createIndex('fixture_id','fixture_id',{unique:false})}};
        req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null)
      }catch{resolve(null)}
    });return ULTRA_IDB.dbp
  }
  async function ultraPersistSnapshot(row){
    try{
      const db=await ultraIDBOpen();if(!db)return;
      await new Promise(resolve=>{const tx=db.transaction('snapshots','readwrite');tx.objectStore('snapshots').put(row);tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()});
      ULTRA_HUB.metrics.persist++;
      if(Date.now()-ULTRA_HUB.cleanupAt>10*60000){ULTRA_HUB.cleanupAt=Date.now();ultraCleanupSnapshots()}
    }catch{}
  }
  async function ultraCleanupSnapshots(){
    try{
      const db=await ultraIDBOpen();if(!db)return;const cutoff=Date.now()-12*3600000;
      const tx=db.transaction('snapshots','readwrite'),store=tx.objectStore('snapshots'),idx=store.index('captured_at'),range=IDBKeyRange.upperBound(cutoff);
      idx.openCursor(range).onsuccess=e=>{const c=e.target.result;if(c){c.delete();c.continue()}}
    }catch{}
  }
  function ultraHubSummary(){
    const m=ULTRA_HUB.metrics;return `HUB reuse ${m.reuse} • stats ${m.stats} • events ${m.events} • market ${m.market} • half ${m.half} • players ${m.players}`
  }
  async function ultraLiveRaw(f,item,engine='HC',forceMarket=false){
    if(!f)return {ended:true};
    const id=f.fixture?.id||item?.id,entry=ultraEntry(id),tier=ultraTierFor(engine,item),p=ULTRA_HUB_POLICY[tier],now=Date.now();
    ultraAcceptField(entry,'fixture',f,ULTRA_HUB.heartbeat.at||now);
    const nestedStats=Array.isArray(f.statistics)&&f.statistics.length?f.statistics:null,
          nestedEvents=Array.isArray(f.events)&&f.events.length?f.events:null;
    if(nestedStats)ultraAcceptField(entry,'stats',nestedStats,ULTRA_HUB.heartbeat.at||now);
    if(nestedEvents)ultraAcceptField(entry,'events',nestedEvents,ULTRA_HUB.heartbeat.at||now);
    const st=f.fixture?.status?.short||'',needHalf=['2H','HT','ET','BT'].includes(st),m=Number(f.fixture?.status?.elapsed||0),
          needPlayers=(tier==='HOT'||tier==='ACTIVE')&&m>=25&&item?.history?.length>1,
          needLineups=tier==='HOT'&&m>=25&&item?.history?.length>1;
    const jobs=[
      ultraField(entry,'stats',p.stats,()=>football('/fixtures/statistics',{fixture:id},true),false),
      ultraField(entry,'events',p.events,()=>football('/fixtures/events',{fixture:id},true),false),
      ultraField(entry,'market',p.market,()=>football('/odds/live',{fixture:id},true),forceMarket)
    ];
    if(needHalf)jobs.push(ultraField(entry,'half',p.half,()=>football('/fixtures/statistics',{fixture:id,half:true},true),false));
    if(needPlayers)jobs.push(ultraField(entry,'players',p.players,()=>football('/fixtures/players',{fixture:id},true),false));
    if(needLineups)jobs.push(ultraField(entry,'lineups',p.lineups,()=>footballCached('/fixtures/lineups',{fixture:id},CACHE_TTL.lineups,true),false));
    await Promise.all(jobs);
    const liveRef=await getBetReference('live'),rawOdds=entry.fields.market?.data||[],
          liveOdds=oddsCompact(rawOdds||[],true,{homeName:f.teams?.home?.name,awayName:f.teams?.away?.name,betRefs:{live:liveRef,prematch:{byId:{}}}}),
          eventsRaw=entry.fields.events?.data||[],statsRaw=entry.fields.stats?.data||[],halfRaw=entry.fields.half?.data||null,playersRaw=entry.fields.players?.data||null,lineupsRaw=entry.fields.lineups?.data||null,
          personnel=ultraPersonnelContext(eventsRaw,playersRaw,f.teams?.home?.id,f.teams?.away?.id),freshness=ultraContentFreshness(entry),
          persistSig=[entry.fields.stats?.sig,entry.fields.events?.sig,entry.fields.market?.sig,entry.fields.half?.sig,entry.fields.players?.sig].join('|');
    if(entry.lastPersistSig!==persistSig||now-entry.lastPersistAt>=60000){
      entry.lastPersistSig=persistSig;entry.lastPersistAt=now;
      ultraPersistSnapshot({id:`${id}:${now}`,fixture_id:Number(id),captured_at:now,minute:m,status:st,goals:f.goals||null,tier,content_freshness:freshness,events:eventsCompact(eventsRaw).slice(-20),personnel,market_rows:liveOdds.slice(0,40),players:playersRaw?playersMatchCompact(playersRaw):null})
    }
    return {f,entry,tier,statsRaw,eventsRaw,rawOdds,liveOdds,halfRaw,playersRaw,lineupsRaw,personnel,freshness,statsAt:entry.fields.stats?.at||now,marketAt:entry.fields.market?.at||null}
  }


  /* ===== V1.17.0 MARKET-TIME DATA FOUNDATION — SHADOW ONLY =====
     Purpose:
     - Capture the live Total ladder at the exact minute / score state.
     - Pair Over/Under prices by line.
     - Normalize two-way price share (de-vig input), market margin, breadth.
     - Track line / price movement only within the same score state.
     - Persist shadow snapshots separately in IndexedDB.
     IMPORTANT: This layer DOES NOT modify RUNG H1/FT score, CORE, thresholds,
     QSIG, state transitions or Final Signal. */
  const MT_SHADOW_VERSION='V1.17.0';
  const MT_DB_NAME='FOOTBALL_EDGE_MARKET_TIME_V1';
  const MT_DB_STORE='market_time';
  const MT_DB_MAX_AGE=12*60*60*1000;
  const MT_MEMORY_MAX=80;
  const MT_STATE={dbp:null,cleanupAt:0,persisted:0};

  function mtCategory(mode){return mode==='H1'?'h1_total':'over_under'}
  function mtMedian(nums){
    const a=(nums||[]).map(Number).filter(Number.isFinite).sort((x,y)=>x-y);
    if(!a.length)return null;
    const m=Math.floor(a.length/2);
    return a.length%2?a[m]:(a[m-1]+a[m])/2
  }
  function mtRound(v,d=3){
    const n=Number(v);if(!Number.isFinite(n))return null;
    const p=10**d;return Math.round(n*p)/p
  }
  function mtSide(label){
    const s=String(label??'').toLowerCase().replace(/\s+/g,' ').trim();
    if(/\bover\b|\btài\b|\btai\b/.test(s))return 'over';
    if(/\bunder\b|\bxỉu\b|\bxiu\b/.test(s))return 'under';
    return null
  }
  function mtLine(value,handicap=null){
    const direct=numericHandicap(handicap);
    if(Number.isFinite(direct))return Number(direct);
    const s=String(value??'').replace(',','.').trim();
    const m=s.match(/(?:over|under|tài|tai|xỉu|xiu)\s*[\(\[]?\s*([+-]?\d+(?:\.\d+)?)/i)
      ||s.match(/([+-]?\d+(?:\.\d+)?)/);
    if(!m)return null;
    const n=Number(m[1]);return Number.isFinite(n)?n:null
  }
  function mtOdd(v){
    const n=Number(v);return Number.isFinite(n)&&n>1&&n<100?n:null
  }
  function mtUpdateTs(v){
    if(v==null)return null;
    if(Number.isFinite(Number(v))){
      const n=Number(v);return n>1e12?n:n>1e9?n*1000:null
    }
    const d=Date.parse(String(v));return Number.isFinite(d)?d:null
  }
  function mtTimeContext(f,mode){
    const status=String(f?.fixture?.status?.short||''),minute=Number(f?.fixture?.status?.elapsed||0);
    const end=mode==='H1'?45:(['ET','BT','P'].includes(status)||minute>90?120:90);
    return {
      mode,minute:Number.isFinite(minute)?minute:null,status,
      nominal_end:end,
      nominal_remaining:Number.isFinite(minute)?Math.max(0,end-minute):null,
      added_time_unknown:true,
      score:{home:Number(f?.goals?.home??0),away:Number(f?.goals?.away??0)}
    }
  }
  function mtSameScore(a,b){
    return Number(a?.score?.home)===Number(b?.score?.home)&&Number(a?.score?.away)===Number(b?.score?.away)
  }
  function mtPairMetrics(overOdd,underOdd){
    const o=mtOdd(overOdd),u=mtOdd(underOdd);
    if(o==null||u==null)return {complete:false,over_raw:null,under_raw:null,over_share:null,under_share:null,margin:null};
    const qo=1/o,qu=1/u,sum=qo+qu;
    return {
      complete:true,
      over_raw:mtRound(qo,4),under_raw:mtRound(qu,4),
      over_share:sum>0?mtRound(qo/sum,4):null,
      under_share:sum>0?mtRound(qu/sum,4):null,
      margin:mtRound(sum-1,4)
    }
  }
  function mtExtractRawPairs(resp,mode,ctx={}){
    const wanted=mtCategory(mode),out=[];
    for(const r of (Array.isArray(resp)?resp:[])){
      const status={stopped:!!r?.status?.stopped,blocked:!!r?.status?.blocked,finished:!!r?.status?.finished};
      if(status.stopped||status.blocked||status.finished)continue;
      const book=String(r?.bookmaker?.name||r?.bookmaker||r?.name||r?.provider||'LIVE_FEED');
      const rctx=marketContextFromResponse(r,ctx);
      for(const bet of (Array.isArray(r?.odds)?r.odds:[])){
        const ident=marketIdentity(bet?.name,bet?.id,'live',ctx?.betRefs?.live);
        if(ident?.category!==wanted)continue;
        const groups=new Map();
        for(const v of (Array.isArray(bet?.values)?bet.values:[])){
          if(v?.suspended)continue;
          const side=mtSide(v?.value??v?.name??v?.label),line=mtLine(v?.value??v?.name??v?.label,v?.handicap);
          const odd=mtOdd(v?.odd??v?.price);
          if(!side||line==null||odd==null)continue;
          const k=String(line);
          if(!groups.has(k))groups.set(k,{line:Number(line),over:null,under:null,main_votes:0,raw:[]});
          const g=groups.get(k);
          g[side]=odd;
          if(v?.main===true)g.main_votes++;
          g.raw.push({side,odd,main:v?.main===true,value:v?.value??null,handicap:v?.handicap??null})
        }
        for(const g of groups.values()){
          const pm=mtPairMetrics(g.over,g.under);
          out.push({
            category:wanted,bookmaker:book,bet_id:bet?.id??null,bet:ident?.canonical_name||bet?.name||null,
            update:r?.update??bet?.update??null,update_ts:mtUpdateTs(r?.update??bet?.update),
            line:g.line,over_odd:g.over,under_odd:g.under,main_votes:g.main_votes,
            complete:pm.complete,over_share:pm.over_share,under_share:pm.under_share,margin:pm.margin,
            raw:g.raw
          })
        }
      }
    }
    return out.sort((a,b)=>a.line-b.line||String(a.bookmaker).localeCompare(String(b.bookmaker)))
  }
  function mtConsensusLadder(pairs){
    const byLine=new Map();
    for(const p of (pairs||[])){
      if(p?.line==null)continue;
      const k=String(Number(p.line));
      if(!byLine.has(k))byLine.set(k,[]);
      byLine.get(k).push(p)
    }
    const out=[];
    for(const rows of byLine.values()){
      const complete=rows.filter(x=>x.complete),src=complete.length?complete:rows;
      const oo=mtMedian(src.map(x=>x.over_odd)),uo=mtMedian(src.map(x=>x.under_odd)),
            sh=mtMedian(src.map(x=>x.over_share)),marg=mtMedian(src.map(x=>x.margin)),
            mainVotes=rows.reduce((a,x)=>a+Number(x.main_votes||0),0),
            updates=rows.map(x=>x.update_ts).filter(Number.isFinite);
      const books=[...new Set(rows.map(x=>x.bookmaker))];
      out.push({
        line:Number(rows[0].line),over_odd:mtRound(oo,3),under_odd:mtRound(uo,3),
        over_share:mtRound(sh,4),under_share:sh==null?null:mtRound(1-sh,4),
        margin:mtRound(marg,4),book_count:books.length,books,
        complete_books:complete.length,total_quotes:rows.length,main_votes:mainVotes,
        latest_update_ts:updates.length?Math.max(...updates):null,
        over_price_min:complete.length?mtRound(Math.min(...complete.map(x=>x.over_odd)),3):null,
        over_price_max:complete.length?mtRound(Math.max(...complete.map(x=>x.over_odd)),3):null,
        under_price_min:complete.length?mtRound(Math.min(...complete.map(x=>x.under_odd)),3):null,
        under_price_max:complete.length?mtRound(Math.max(...complete.map(x=>x.under_odd)),3):null
      })
    }
    return out.sort((a,b)=>a.line-b.line)
  }
  function mtSelectReference(ladder){
    const rows=(ladder||[]).filter(x=>x.over_odd!=null&&x.under_odd!=null);
    if(!rows.length)return null;
    const explicit=rows.filter(x=>Number(x.main_votes||0)>0);
    if(explicit.length){
      return [...explicit].sort((a,b)=>Number(b.main_votes)-Number(a.main_votes)||Number(b.book_count)-Number(a.book_count)||Math.abs(a.over_odd-a.under_odd)-Math.abs(b.over_odd-b.under_odd))[0]
    }
    // Shadow-only fallback: infer the most balanced quoted line. Do not call it "fair".
    return [...rows].sort((a,b)=>Math.abs(a.over_odd-a.under_odd)-Math.abs(b.over_odd-b.under_odd)||Number(b.book_count)-Number(a.book_count))[0]
  }
  function mtSnapshotSig(x){
    try{return JSON.stringify({
      score:x?.time?.score,reference:x?.reference?{line:x.reference.line,over:x.reference.over_odd,under:x.reference.under_odd}:null,
      ladder:(x?.ladder||[]).map(r=>[r.line,r.over_odd,r.under_odd,r.book_count,r.main_votes])
    })}catch{return ''}
  }
  function mtMovement(prev,cur){
    if(!prev||!cur)return {status:'BASELINE',same_score:true,line_delta:null,over_price_delta:null,under_price_delta:null,window_seconds:null};
    if(!mtSameScore(prev?.time,cur?.time))return {status:'SCORE_RESET',same_score:false,line_delta:null,over_price_delta:null,under_price_delta:null,window_seconds:Math.max(0,Math.round((cur.captured_at-prev.captured_at)/1000))};
    const a=prev.reference,b=cur.reference,window=Math.max(0,Math.round((cur.captured_at-prev.captured_at)/1000));
    if(!a||!b)return {status:'NO_REFERENCE',same_score:true,line_delta:null,over_price_delta:null,under_price_delta:null,window_seconds:window};
    const ld=mtRound(Number(b.line)-Number(a.line),2),
          od=mtRound(Number(b.over_odd)-Number(a.over_odd),3),
          ud=mtRound(Number(b.under_odd)-Number(a.under_odd),3);
    let status='FLAT';
    if(ld>0)status='LINE_UP';
    else if(ld<0)status='LINE_DOWN';
    else if(od!=null&&od<=-.03)status='OVER_PRICE_SHORTENING';
    else if(od!=null&&od>=.03)status='OVER_PRICE_DRIFTING';
    return {status,same_score:true,line_delta:ld,over_price_delta:od,under_price_delta:ud,window_seconds:window,
            from_line:a.line,to_line:b.line,from_over:a.over_odd,to_over:b.over_odd,from_under:a.under_odd,to_under:b.under_odd}
  }

  function mtIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(MT_STATE.dbp)return MT_STATE.dbp;
    MT_STATE.dbp=new Promise(resolve=>{
      try{
        const req=indexedDB.open(MT_DB_NAME,1);
        req.onupgradeneeded=()=>{
          const db=req.result;
          if(!db.objectStoreNames.contains(MT_DB_STORE)){
            const s=db.createObjectStore(MT_DB_STORE,{keyPath:'id'});
            s.createIndex('captured_at','captured_at',{unique:false});
            s.createIndex('fixture_id','fixture_id',{unique:false});
            s.createIndex('fixture_mode','fixture_mode',{unique:false})
          }
        };
        req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null)
      }catch{resolve(null)}
    });
    return MT_STATE.dbp
  }
  async function mtLoadRecent(fixtureId,mode,limit=30){
    try{
      const db=await mtIDBOpen();if(!db)return [];
      return await new Promise(resolve=>{
        const tx=db.transaction(MT_DB_STORE,'readonly'),store=tx.objectStore(MT_DB_STORE),idx=store.index('fixture_mode'),
              key=`${fixtureId}:${mode}`,rows=[],req=idx.openCursor(IDBKeyRange.only(key),'prev');
        req.onsuccess=e=>{const c=e.target.result;if(c&&rows.length<limit){rows.push(c.value);c.continue()}else resolve(rows.reverse())};
        req.onerror=()=>resolve([])
      })
    }catch{return []}
  }
  async function mtPersist(x){
    try{
      const db=await mtIDBOpen();if(!db)return;
      await new Promise(resolve=>{
        const tx=db.transaction(MT_DB_STORE,'readwrite');
        tx.objectStore(MT_DB_STORE).put(x);tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()
      });
      MT_STATE.persisted++;
      if(Date.now()-MT_STATE.cleanupAt>10*60*1000){MT_STATE.cleanupAt=Date.now();mtCleanup()}
    }catch{}
  }
  async function mtCleanup(){
    try{
      const db=await mtIDBOpen();if(!db)return;
      const cutoff=Date.now()-MT_DB_MAX_AGE,tx=db.transaction(MT_DB_STORE,'readwrite'),
            idx=tx.objectStore(MT_DB_STORE).index('captured_at');
      idx.openCursor(IDBKeyRange.upperBound(cutoff)).onsuccess=e=>{const c=e.target.result;if(c){c.delete();c.continue()}}
    }catch{}
  }
  async function mtHydrate(item,mode){
    if(item.marketTimeHydrated)return;
    item.marketTimeHydrated=true;
    const old=await mtLoadRecent(item.id,mode,30);
    item.marketTimeHistory=old.slice(-MT_MEMORY_MAX);
    const last=old[old.length-1];
    if(last){item.marketTimeLastSig=mtSnapshotSig(last);item.marketTimeLastPersistAt=Number(last.captured_at||0)}
  }
  async function mtBuildShadow(item,f,rawOdds,mode,marketContentAge=null){
    await mtHydrate(item,mode);
    const liveRef=await getBetReference('live'),
          pairs=mtExtractRawPairs(rawOdds,mode,{homeName:f?.teams?.home?.name,awayName:f?.teams?.away?.name,betRefs:{live:liveRef}}),
          ladder=mtConsensusLadder(pairs),reference=mtSelectReference(ladder),time=mtTimeContext(f,mode),
          now=Date.now(),prev=(item.marketTimeHistory||[]).slice(-1)[0]||null,
          latestUpdate=ladder.map(x=>x.latest_update_ts).filter(Number.isFinite),
          shadow={
            id:`${item.id}:${mode}:${now}`,fixture_id:Number(item.id),fixture_mode:`${item.id}:${mode}`,
            version:MT_SHADOW_VERSION,mode,captured_at:now,time,
            market_content_age:marketContentAge,
            quote_update_age:latestUpdate.length?Math.max(0,Math.round((now-Math.max(...latestUpdate))/1000)):null,
            raw_pair_count:pairs.length,complete_pair_count:pairs.filter(x=>x.complete).length,
            ladder,reference,reference_source:reference?(Number(reference.main_votes||0)>0?'EXPLICIT_MAIN':'INFERRED_BALANCE'):'N/A',
            movement:null,
            note:'SHADOW DATA ONLY — không tác động RUNG Score / CORE / Final Signal'
          };
    shadow.movement=mtMovement(prev,shadow);
    const sig=mtSnapshotSig(shadow),elapsed=now-Number(item.marketTimeLastPersistAt||0);
    item.marketTimeHistory=(item.marketTimeHistory||[]).concat([shadow]).slice(-MT_MEMORY_MAX);
    if(sig!==item.marketTimeLastSig||elapsed>=60000){
      item.marketTimeLastSig=sig;item.marketTimeLastPersistAt=now;mtPersist(shadow)
    }
    return shadow
  }

  function mtFmtOdd(v){return Number.isFinite(Number(v))?Number(v).toFixed(2):'—'}
  function mtFmtLine(v){const n=Number(v);return Number.isFinite(n)?String(Math.round(n*100)/100):'—'}
  function mtLadderText(mt,limit=5){
    if(!mt?.ladder?.length)return 'No valid Total ladder';
    const ref=mt.reference?.line;
    const sorted=[...mt.ladder].sort((a,b)=>{
      if(ref==null)return a.line-b.line;
      return Math.abs(a.line-ref)-Math.abs(b.line-ref)||a.line-b.line
    }).slice(0,limit).sort((a,b)=>a.line-b.line);
    return sorted.map(x=>`O${mtFmtLine(x.line)} @${mtFmtOdd(x.over_odd)} / U @${mtFmtOdd(x.under_odd)}`).join('  •  ')
  }
  function mtMovementText(mt){
    const m=mt?.movement;if(!m)return 'Baseline';
    if(m.status==='SCORE_RESET')return 'Score changed → market baseline reset';
    if(m.status==='BASELINE')return 'Baseline snapshot';
    const bits=[m.status];
    if(m.line_delta!=null&&m.line_delta!==0)bits.push(`line ${m.line_delta>0?'+':''}${m.line_delta}`);
    if(m.over_price_delta!=null&&m.over_price_delta!==0)bits.push(`Over price ${m.over_price_delta>0?'+':''}${m.over_price_delta}`);
    if(m.window_seconds!=null)bits.push(`${m.window_seconds}s`);
    return bits.join(' • ')
  }
  function mtPacketText(mt){
    if(!mt)return 'N/A';
    const r=mt.reference,t=mt.time;
    return `TIME ${t?.nominal_remaining??'N/A'}m + added unknown | REF ${r?`O${mtFmtLine(r.line)} @${mtFmtOdd(r.over_odd)} / U @${mtFmtOdd(r.under_odd)}`:'N/A'} | SOURCE ${mt.reference_source} | LADDER ${mt.ladder?.length||0} lines | PAIRS ${mt.complete_pair_count||0}/${mt.raw_pair_count||0} | MARKET_CONTENT_AGE ${mt.market_content_age??'N/A'}s | MOVE ${mtMovementText(mt)}`
  }
  function mtShadowHTML(mt,mode){
    if(!mt)return `<div class="mt-shadow waiting"><div class="mt-shadow-head"><span>MARKET-TIME SHADOW</span><b>WAIT DATA</b></div><small>Đang chờ snapshot Total line đầu tiên • chưa tác động RUNG.</small></div>`;
    const r=mt.reference,t=mt.time,age=mt.market_content_age??mt.quote_update_age;
    return `<div class="mt-shadow">
      <div class="mt-shadow-head"><span>MARKET-TIME SHADOW</span><b>DATA ONLY</b></div>
      <div class="mt-shadow-grid">
        <div><span>TIME REMAINING</span><strong>${esc(t?.nominal_remaining??'—')}'</strong><small>+ added time unknown</small></div>
        <div><span>MARKET REFERENCE</span><strong>${r?`O${esc(mtFmtLine(r.line))} @${esc(mtFmtOdd(r.over_odd))}`:'N/A'}</strong><small>${esc(mt.reference_source||'N/A')}</small></div>
        <div><span>MARKET AGE</span><strong>${age==null?'N/A':esc(age)+'s'}</strong><small>content / quote age</small></div>
        <div><span>TOTAL LADDER</span><strong>${esc(mt.ladder?.length||0)} lines</strong><small>${esc(mt.complete_pair_count||0)}/${esc(mt.raw_pair_count||0)} paired</small></div>
      </div>
      <div class="mt-shadow-ladder">${esc(mtLadderText(mt,5))}</div>
      <div class="mt-shadow-move"><b>MOVEMENT:</b> ${esc(mtMovementText(mt))}</div>
      <div class="mt-shadow-note">Chỉ thu thập line/giá theo đúng phút và tỷ số để làm nền cho Market-Time Model. Chưa cộng/trừ điểm RUNG và chưa kết luận line có lợi thế.</div>
    </div>`
  }


  /* ===== V1.17.1 GOAL POTENTIAL SHADOW =====
     This layer estimates a RELATIVE remaining-goal potential band from:
       LIVE football intensity + time remaining + game state + current-half trend
       + evidence freshness / reliability.
     It intentionally DOES NOT use live market prices to produce the band.
     Market-Time remains a separate comparison layer for V1.17.2+.
     IMPORTANT: no path into RUNG score / CORE / thresholds / QSIG / Final Signal. */
  const GP_SHADOW_VERSION='V1.17.1';
  const GP_DB_NAME='FOOTBALL_EDGE_GOAL_POTENTIAL_V1';
  const GP_DB_STORE='goal_potential';
  const GP_DB_MAX_AGE=12*60*60*1000;
  const GP_MEMORY_MAX=100;
  const GP_STATE={dbp:null,cleanupAt:0,persisted:0};

  function gpClamp(v,a=0,b=1){const n=Number(v);return Number.isFinite(n)?Math.max(a,Math.min(b,n)):a}
  function gpRound(v,d=2){const n=Number(v);if(!Number.isFinite(n))return null;const p=10**d;return Math.round(n*p)/p}
  function gpAvailable(values){return (values||[]).filter(x=>Number.isFinite(Number(x)))}
  function gpWeighted(parts){
    const usable=(parts||[]).filter(x=>Number.isFinite(Number(x?.value))&&Number(x?.weight)>0);
    const den=usable.reduce((a,x)=>a+Number(x.weight),0);
    if(!den)return null;
    return usable.reduce((a,x)=>a+Number(x.value)*Number(x.weight),0)/den
  }

  function gpModeConfig(mode){
    return mode==='H1'
      ?{maxPressure:22,maxChance:20,maxMomentum:18,windowSpan:25,nominalEnd:45}
      :{maxPressure:20,maxChance:20,maxMomentum:15,windowSpan:45,nominalEnd:90}
  }
  function gpTimeState(s,mode){
    const cfg=gpModeConfig(mode),minute=Number(s?.minute||0),
          status=String(s?.status||s?.fixture?.fixture?.status?.short||''),
          end=mode==='H1'?45:((['ET','BT','P'].includes(status)||minute>90)?120:90),
          remaining=Math.max(0,end-minute),
          span=mode==='H1'?Math.min(cfg.windowSpan,Math.max(1,end-20)):Math.min(cfg.windowSpan,Math.max(1,end-45)),
          fraction=gpClamp(remaining/span,0,1);
    // Time opportunity is deliberately non-linear: late minutes retain some hazard,
    // but a hot signal at 88' must not be treated like the same signal at 60'.
    const opportunity=gpClamp(Math.pow(fraction,.52),0,1);
    return {minute,end,remaining,fraction:gpRound(fraction,3),opportunity:gpRound(opportunity,3),added_time_unknown:true}
  }

  function gpLiveIntensity(e,mode){
    const cfg=gpModeConfig(mode),
          p=Number.isFinite(Number(e?.pressure))?gpClamp(Number(e.pressure)/cfg.maxPressure):null,
          c=Number.isFinite(Number(e?.chance))?gpClamp(Number(e.chance)/cfg.maxChance):null,
          m=Number.isFinite(Number(e?.momentum))?gpClamp(Number(e.momentum)/cfg.maxMomentum):null,
          core=gpWeighted([{value:p,weight:.38},{value:c,weight:.34},{value:m,weight:.28}]);
    if(core==null)return {value:null,pressure:p,chance:c,momentum:m,accel:0};
    const accel=Number(e?.accel||0),accelAdj=accel>=.70?.08:accel>=.35?.05:accel<=-.55?-.07:accel<=-.35?-.04:0,
          value=gpClamp(core+accelAdj,0,1);
    return {value:gpRound(value,3),pressure:p==null?null:gpRound(p,3),chance:c==null?null:gpRound(c,3),momentum:m==null?null:gpRound(m,3),accel:gpRound(accel,2)}
  }

  function gpRecentPulse(e,mode){
    const r5=e?.recent5?.delta||e?.pressure5?.delta||{},r10=e?.recent10?.delta||e?.pressure10?.delta||{},
          w5=Number(e?.recent5?.window_min||e?.pressure5?.window_min||5)||5,
          w10=Number(e?.recent10?.window_min||e?.pressure10?.window_min||10)||10,
          s5=5/Math.max(1,w5),s10=10/Math.max(2,w10);
    let x=0,available=0;
    const add=(v,weight)=>{if(Number.isFinite(Number(v))){x+=gpClamp(Number(v),0,1)*weight;available+=weight}};
    add((Number(r5.sot||0)*s5)/2.0,.28);
    add((Number(r5.inbox||0)*s5)/4.0,.18);
    add((Number(r5.shots||0)*s5)/5.0,.12);
    if(Number(r5.xg||0)>0)add((Number(r5.xg||0)*s5)/.40,.17);
    add((Number(r10.sot||0)*s10)/3.2,.10);
    if(Number(r10.xg||0)>0)add((Number(r10.xg||0)*s10)/.55,.15);
    if(!available)return {value:null};
    return {value:gpRound(gpClamp(x/available),3),sot5:Number(r5.sot||0),inbox5:Number(r5.inbox||0),xg5:gpRound(Number(r5.xg||0),2),sot10:Number(r10.sot||0),xg10:gpRound(Number(r10.xg||0),2)}
  }

  function gpHalfTrend(s,mode){
    if(mode==='H1')return {multiplier:1,label:'CURRENT_HALF'};
    const h1=s?.h1?.total||{},h2=s?.h2?.total||{},m=Math.max(1,Number(s?.minute||45)-45);
    const has=(Number(h1.sot||0)+Number(h1.inbox||0)+Number(h2.sot||0)+Number(h2.inbox||0))>0;
    if(!has)return {multiplier:1,label:'NO_HALF_SPLIT'};
    const h1Rate=(Number(h1.sot||0)*2+Number(h1.inbox||0)*.55+Number(h1.xg||0)*4)/45,
          h2Rate=(Number(h2.sot||0)*2+Number(h2.inbox||0)*.55+Number(h2.xg||0)*4)/m,
          ratio=h1Rate>0?h2Rate/h1Rate:(h2Rate>0?1.5:1);
    if(ratio>=1.45)return {multiplier:1.10,label:'H2_ACCELERATING',ratio:gpRound(ratio,2)};
    if(ratio>=1.15)return {multiplier:1.05,label:'H2_STRONGER',ratio:gpRound(ratio,2)};
    if(ratio<=.60)return {multiplier:.90,label:'H2_DECAYING',ratio:gpRound(ratio,2)};
    if(ratio<=.82)return {multiplier:.95,label:'H2_WEAKER',ratio:gpRound(ratio,2)};
    return {multiplier:1,label:'H2_STABLE',ratio:gpRound(ratio,2)}
  }

  function gpGameState(s){
    const h=Number(s?.goals?.home||0),a=Number(s?.goals?.away||0),gap=Math.abs(h-a),total=h+a;
    let multiplier=1,label='LEVEL';
    if(gap===1){multiplier=1.06;label='ONE_GOAL_GAME'}
    else if(gap===0){multiplier=1.02;label='LEVEL_GAME'}
    else if(gap===2){multiplier=.96;label='TWO_GOAL_GAP'}
    else if(gap>=3){multiplier=.90;label='WIDE_GAP'}
    if(total>=4)multiplier*=1.03;
    return {multiplier:gpRound(multiplier,3),label,gap,total}
  }

  function gpReliability(item,s,e,mode){
    let r=1;
    const reasons=[];
    if(e?.scoreMode==='PARTIAL_STATS'){r*=.72;reasons.push('PARTIAL_STATS')}
    else if(e?.scoreMode==='BASELINE'){r*=.55;reasons.push('BASELINE_BUILDING')}
    else if(e?.scoreMode==='DATA_INCOMPLETE'){r*=.32;reasons.push('DATA_INCOMPLETE')}
    if(e?.hardVeto){r*=.45;reasons.push('HARD_DATA_VETO')}
    const cf=s?.content_freshness||{},
          statsAge=Number(cf.stats_content_age),
          eventsAge=Number(cf.events_content_age);
    if(Number.isFinite(statsAge)){
      if(statsAge>180){r*=.55;reasons.push('STATS_CONTENT_OLD')}
      else if(statsAge>90){r*=.75;reasons.push('STATS_CONTENT_AGING')}
      else if(statsAge>45){r*=.90}
    }
    if(Number.isFinite(eventsAge)&&eventsAge>180){r*=.90;reasons.push('EVENTS_OLD')}
    const requestAge=(Date.now()-Number(s?.fresh_at||Date.now()))/1000;
    if(requestAge>(mode==='H1'?55:60)){r*=.45;reasons.push('REQUEST_STALE')}
    const baselineAge=Number(e?.baselineAge||0);
    if(baselineAge>0&&baselineAge<2){r*=.65;reasons.push('SHORT_BASELINE')}
    const dataHealth=String(s?.data_health?.level||'');
    if(dataHealth==='NO_STATS'){r*=.35;reasons.push('NO_STATS')}
    else if(dataHealth==='PARTIAL'){r*=.80;reasons.push('PARTIAL_HEALTH')}
    return {value:gpRound(gpClamp(r,.15,1),3),reasons:[...new Set(reasons)]}
  }

  function gpRawHazardRatio(intensity,recent,half,game){
    if(intensity?.value==null)return 1;
    const live=Number(intensity.value),
          pulse=recent?.value==null?live:Number(recent.value),
          blend=gpClamp(live*.78+pulse*.22),
          base=.62+1.48*blend,
          halfM=Number(half?.multiplier||1),gameM=Number(game?.multiplier||1);
    return gpClamp(base*halfM*gameM,.45,2.35)
  }
  function gpReliabilityShrink(rawRatio,reliability){
    const rel=gpClamp(reliability,.15,1);
    return gpClamp(1+(Number(rawRatio)-1)*rel,.55,2.20)
  }

  function gpPotentialIndex(time,ratio,reliability){
    // Relative remaining-goal opportunity, not probability.
    // The coefficient keeps strong minute-80 states capable of HIGH,
    // while very-late states are naturally reduced by time opportunity.
    const base=88*Number(time?.opportunity||0),
          idx=base*Number(ratio||1),
          relFloor=.72+.28*gpClamp(reliability,.15,1);
    return gpClamp(idx*relFloor,0,100)
  }
  function gpBand(index){
    const x=Number(index||0);
    if(x>=82)return {key:'VERY_HIGH',label:'VERY HIGH',rank:5};
    if(x>=66)return {key:'HIGH',label:'HIGH',rank:4};
    if(x>=50)return {key:'ELEVATED',label:'ELEVATED',rank:3};
    if(x>=34)return {key:'MODERATE',label:'MODERATE',rank:2};
    return {key:'LOW',label:'LOW',rank:1}
  }
  function gpTrend(prev,cur,e){
    if(prev&&Number.isFinite(Number(prev.index))){
      const d=Number(cur.index)-Number(prev.index);
      if(d>=8)return {key:'ACCELERATING',arrow:'↑',delta:gpRound(d,1)};
      if(d>=3)return {key:'RISING',arrow:'↑',delta:gpRound(d,1)};
      if(d<=-8)return {key:'DECAYING',arrow:'↓',delta:gpRound(d,1)};
      if(d<=-3)return {key:'FALLING',arrow:'↓',delta:gpRound(d,1)};
    }
    const a=Number(e?.accel||0);
    if(a>=.35)return {key:'RISING',arrow:'↑',delta:null};
    if(a<=-.35)return {key:'FALLING',arrow:'↓',delta:null};
    return {key:'STABLE',arrow:'→',delta:null}
  }

  function gpIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(GP_STATE.dbp)return GP_STATE.dbp;
    GP_STATE.dbp=new Promise(resolve=>{
      try{
        const req=indexedDB.open(GP_DB_NAME,1);
        req.onupgradeneeded=()=>{
          const db=req.result;
          if(!db.objectStoreNames.contains(GP_DB_STORE)){
            const st=db.createObjectStore(GP_DB_STORE,{keyPath:'id'});
            st.createIndex('captured_at','captured_at',{unique:false});
            st.createIndex('fixture_id','fixture_id',{unique:false});
            st.createIndex('fixture_mode','fixture_mode',{unique:false})
          }
        };
        req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null)
      }catch{resolve(null)}
    });
    return GP_STATE.dbp
  }
  async function gpLoadRecent(fixtureId,mode,limit=30){
    try{
      const db=await gpIDBOpen();if(!db)return [];
      return await new Promise(resolve=>{
        const tx=db.transaction(GP_DB_STORE,'readonly'),st=tx.objectStore(GP_DB_STORE),idx=st.index('fixture_mode'),
              key=`${fixtureId}:${mode}`,rows=[],req=idx.openCursor(IDBKeyRange.only(key),'prev');
        req.onsuccess=e=>{const c=e.target.result;if(c&&rows.length<limit){rows.push(c.value);c.continue()}else resolve(rows.reverse())};
        req.onerror=()=>resolve([])
      })
    }catch{return []}
  }
  async function gpPersist(row){
    try{
      const db=await gpIDBOpen();if(!db)return;
      await new Promise(resolve=>{
        const tx=db.transaction(GP_DB_STORE,'readwrite');tx.objectStore(GP_DB_STORE).put(row);
        tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()
      });
      GP_STATE.persisted++;
      if(Date.now()-GP_STATE.cleanupAt>10*60*1000){GP_STATE.cleanupAt=Date.now();gpCleanup()}
    }catch{}
  }
  async function gpCleanup(){
    try{
      const db=await gpIDBOpen();if(!db)return;
      const cutoff=Date.now()-GP_DB_MAX_AGE,tx=db.transaction(GP_DB_STORE,'readwrite'),
            idx=tx.objectStore(GP_DB_STORE).index('captured_at');
      idx.openCursor(IDBKeyRange.upperBound(cutoff)).onsuccess=e=>{const c=e.target.result;if(c){c.delete();c.continue()}}
    }catch{}
  }
  async function gpHydrate(item,mode){
    if(item.goalPotentialHydrated)return;
    item.goalPotentialHydrated=true;
    const rows=await gpLoadRecent(item.id,mode,30);
    item.goalPotentialHistory=rows.slice(-GP_MEMORY_MAX);
    const last=rows[rows.length-1];
    if(last){item.goalPotentialLastSig=JSON.stringify([last.band?.key,last.index,last.hazard_ratio,last.time?.remaining,last.score]);item.goalPotentialLastPersistAt=Number(last.captured_at||0)}
  }

  async function gpBuildShadow(item,s,e,mode){
    await gpHydrate(item,mode);
    const time=gpTimeState(s,mode),intensity=gpLiveIntensity(e,mode),recent=gpRecentPulse(e,mode),
          half=gpHalfTrend(s,mode),game=gpGameState(s),reliability=gpReliability(item,s,e,mode),
          rawRatio=gpRawHazardRatio(intensity,recent,half,game),
          adjustedRatio=gpReliabilityShrink(rawRatio,reliability.value),
          index=gpRound(gpPotentialIndex(time,adjustedRatio,reliability.value),1),
          band=gpBand(index),now=Date.now(),
          prev=(item.goalPotentialHistory||[]).slice(-1)[0]||null,
          row={
            id:`${item.id}:${mode}:${now}`,fixture_id:Number(item.id),fixture_mode:`${item.id}:${mode}`,
            version:GP_SHADOW_VERSION,mode,captured_at:now,
            minute:Number(s?.minute||0),score:{home:Number(s?.goals?.home||0),away:Number(s?.goals?.away||0)},
            time,intensity,recent,current_half:half,game_state:game,reliability,
            raw_hazard_ratio:gpRound(rawRatio,2),hazard_ratio:gpRound(adjustedRatio,2),
            index,band,trend:null,
            rung_state:String(item?.state||''),rung_score:Number.isFinite(Number(e?.score))?Number(e.score):null,
            rung_score_mode:e?.scoreMode||null,core:e?.core||null,
            note:'SHADOW ONLY — relative potential, not goal probability; does not modify RUNG / QSIG / Final Signal'
          };
    row.trend=gpTrend(prev,row,e);
    const sig=JSON.stringify([row.band?.key,row.index,row.hazard_ratio,row.time?.remaining,row.score,row.trend?.key]),
          elapsed=now-Number(item.goalPotentialLastPersistAt||0);
    item.goalPotentialHistory=(item.goalPotentialHistory||[]).concat([row]).slice(-GP_MEMORY_MAX);
    if(sig!==item.goalPotentialLastSig||elapsed>=60000){
      item.goalPotentialLastSig=sig;item.goalPotentialLastPersistAt=now;gpPersist(row)
    }
    return row
  }

  function gpBandClass(gp){return String(gp?.band?.key||'LOW').toLowerCase().replace('_','-')}
  function gpReliabilityLabel(v){
    const x=Number(v||0);return x>=.85?'HIGH':x>=.65?'GOOD':x>=.45?'LIMITED':'LOW'
  }
  function gpVietnameseRead(gp){
    const k=gp?.band?.key,trend=gp?.trend?.key;
    let s=k==='VERY_HIGH'?'Cường độ LIVE và quỹ thời gian hiện tạo mức tiềm năng bàn thắng rất cao so với nền của thời điểm này.'
      :k==='HIGH'?'Dữ liệu LIVE hiện đang tạo tiềm năng bàn thắng cao khi xét cùng quỹ thời gian còn lại.'
      :k==='ELEVATED'?'Tiềm năng bàn thắng đang cao hơn trạng thái nền, nhưng chưa ở mức mạnh nhất.'
      :k==='MODERATE'?'Có tín hiệu tạo bàn nhưng mức độ hiện chỉ ở vùng trung bình sau khi điều chỉnh theo thời gian.'
      :'Dữ liệu hiện tại và quỹ thời gian chưa tạo ra tiềm năng bàn thắng cao.';
    if(trend==='ACCELERATING'||trend==='RISING')s+=' Xu hướng đang tăng.';
    else if(trend==='DECAYING'||trend==='FALLING')s+=' Xu hướng đang giảm.';
    return s
  }
  function gpShadowHTML(gp,mode){
    if(!gp)return `<section class="gp-shadow waiting"><div class="gp-head"><span>GOAL POTENTIAL SHADOW</span><b>WAIT DATA</b></div><small>Đang chờ đủ LIVE evidence để đánh giá cùng quỹ thời gian còn lại.</small></section>`;
    const cls=gpBandClass(gp),rel=gpReliabilityLabel(gp.reliability?.value),ratio=Number(gp.hazard_ratio||1).toFixed(2);
    return `<section class="gp-shadow ${cls}">
      <div class="gp-head">
        <span>GOAL POTENTIAL</span>
        <b>SHADOW ONLY</b>
      </div>
      <div class="gp-main">
        <div>
          <strong>${esc(gp.band?.label||'LOW')} <i>${esc(gp.trend?.arrow||'→')}</i></strong>
          <small>${esc(gpVietnameseRead(gp))}</small>
        </div>
        <div class="gp-index">${esc(gp.index??'—')}<em>/100</em></div>
      </div>
      <div class="gp-grid">
        <div class="live"><span>LIVE INTENSITY</span><b>${gp.intensity?.value==null?'N/A':esc(Math.round(gp.intensity.value*100))}</b><small>Pressure + Chance + Momentum</small></div>
        <div class="time"><span>TIME REMAINING</span><b>${esc(gp.time?.remaining??'—')}'</b><small>+ added time unknown</small></div>
        <div class="hazard"><span>LIVE HAZARD RATIO</span><b>${esc(ratio)}x</b><small>So với trạng thái nền, không phải xác suất</small></div>
        <div class="reliability"><span>RELIABILITY</span><b>${esc(rel)}</b><small>${esc(Math.round(Number(gp.reliability?.value||0)*100))}% evidence weight</small></div>
      </div>
      <div class="gp-context">
        <span>CURRENT HALF: <b>${esc(gp.current_half?.label||'N/A')}</b></span>
        <span>GAME STATE: <b>${esc(gp.game_state?.label||'N/A')}</b></span>
        <span>TREND: <b>${esc(gp.trend?.key||'STABLE')}</b></span>
      </div>
      <div class="gp-note">Lớp này chỉ đánh giá tiềm năng bàn thắng tương đối từ dữ liệu bóng đá LIVE + thời gian còn lại. Chưa dùng market để quyết định và chưa tác động tín hiệu RUNG.</div>
    </section>`
  }
  function gpPacketText(gp){
    if(!gp)return 'N/A';
    return `${gp.band?.label||'N/A'} ${gp.trend?.arrow||''} | INDEX ${gp.index??'N/A'}/100 | LIVE_INTENSITY ${gp.intensity?.value==null?'N/A':Math.round(gp.intensity.value*100)} | TIME ${gp.time?.remaining??'N/A'}m + added unknown | HAZARD_RATIO ${gp.hazard_ratio??'N/A'}x | RELIABILITY ${gp.reliability?.value??'N/A'} | HALF ${gp.current_half?.label||'N/A'} | GAME ${gp.game_state?.label||'N/A'}`
  }


  /* ===== V1.17.2 MARKET EXPECTATION SHADOW =====
     Goal:
       Translate the live Asian Total ladder + paired O/U price into an
       implied remaining-goal expectation representation.
     Method:
       1) use paired O/U prices from V1.17.0;
       2) remove two-way price imbalance through normalized over_share;
       3) fit a Poisson remaining-goals lambda to each Asian Total line,
          respecting integer / half / quarter settlement;
       4) aggregate across valid ladder lines and books.
     IMPORTANT:
       - This is MARKET EXPECTATION, not football truth.
       - It does not consume Goal Potential or RUNG score.
       - It does not compare LIVE vs Market yet.
       - It does not alter RUNG / QSIG / Final Signal. */
  const ME_SHADOW_VERSION='V1.17.2';
  const ME_DB_NAME='FOOTBALL_EDGE_MARKET_EXPECTATION_V1';
  const ME_DB_STORE='market_expectation';
  const ME_DB_MAX_AGE=12*60*60*1000;
  const ME_MEMORY_MAX=100;
  const ME_STATE={dbp:null,cleanupAt:0,persisted:0};

  function meClamp(v,a=0,b=1){const n=Number(v);return Number.isFinite(n)?Math.max(a,Math.min(b,n)):a}
  function meRound(v,d=3){const n=Number(v);if(!Number.isFinite(n))return null;const p=10**d;return Math.round(n*p)/p}
  function mePoissonPmf(k,lambda){
    const l=Math.max(0,Number(lambda)||0),n=Math.max(0,Math.floor(Number(k)||0));
    let p=Math.exp(-l);
    for(let i=1;i<=n;i++)p*=l/i;
    return p
  }
  function mePoissonCdf(k,lambda){
    const n=Math.floor(Number(k));
    if(n<0)return 0;
    let sum=0;
    for(let i=0;i<=n;i++)sum+=mePoissonPmf(i,lambda);
    return meClamp(sum,0,1)
  }
  function meSplitLine(line){
    const x=Math.max(0,Number(line)||0),q=Math.round(x*4)/4,
          frac=Math.round((q-Math.floor(q))*100)/100,n=Math.floor(q);
    if(Math.abs(frac-.25)<.001)return [n,n+.5];
    if(Math.abs(frac-.75)<.001)return [n+.5,n+1];
    return [q]
  }
  function meLegSettlement(goals,line,side){
    const g=Number(goals),l=Number(line),s=side==='under'?'under':'over';
    if(s==='over'){
      if(g>l)return 1;
      if(g===l)return 0;
      return -1
    }
    if(g<l)return 1;
    if(g===l)return 0;
    return -1
  }
  function meSettlement(goals,line,side){
    const legs=meSplitLine(line);
    return legs.reduce((a,l)=>a+meLegSettlement(goals,l,side),0)/legs.length
  }
  function meExpectedUnits(lambda,line,side){
    // Expected settlement units before applying price. Useful for diagnostics only.
    const maxK=Math.max(12,Math.ceil(Number(lambda)*5+10));
    let ev=0;
    for(let g=0;g<=maxK;g++)ev+=mePoissonPmf(g,lambda)*meSettlement(g,line,side);
    return ev
  }
  function meWinPushLose(lambda,line,side){
    // At Asian quarter lines, half-win/half-loss are represented through
    // settlement components. We compute the fair decimal odd by EV directly.
    const legs=meSplitLine(line),maxK=Math.max(12,Math.ceil(Number(lambda)*5+10));
    let winStake=0,loseStake=0,pushStake=0;
    for(let g=0;g<=maxK;g++){
      const p=mePoissonPmf(g,lambda);
      for(const leg of legs){
        const r=meLegSettlement(g,leg,side),w=1/legs.length;
        if(r>0)winStake+=p*w;
        else if(r<0)loseStake+=p*w;
        else pushStake+=p*w
      }
    }
    const total=winStake+loseStake+pushStake;
    if(total>0&&Math.abs(total-1)>.0001){winStake/=total;loseStake/=total;pushStake/=total}
    return {win:winStake,lose:loseStake,push:pushStake}
  }
  function meFairOdd(lambda,line,side){
    const x=meWinPushLose(lambda,line,side);
    if(x.win<=1e-9)return 99;
    return 1+x.lose/x.win
  }
  function meModelOverShare(lambda,line){
    const o=meFairOdd(lambda,line,'over'),u=meFairOdd(lambda,line,'under');
    const qo=1/o,qu=1/u,sum=qo+qu;
    return sum>0?qo/sum:null
  }
  function meSolveLambda(line,targetOverShare){
    const target=meClamp(targetOverShare,.001,.999);
    let lo=.005,hi=8;
    const flo=meModelOverShare(lo,line),fhi=meModelOverShare(hi,line);
    if(target<=flo)return lo;
    if(target>=fhi)return hi;
    for(let i=0;i<55;i++){
      const mid=(lo+hi)/2,f=meModelOverShare(mid,line);
      if(f<target)lo=mid;else hi=mid
    }
    return (lo+hi)/2
  }
  function meLineEstimate(row){
    const line=Number(row?.line),share=Number(row?.over_share);
    if(!Number.isFinite(line)||!Number.isFinite(share)||share<=0||share>=1)return null;
    const lambda=meSolveLambda(line,share),
          overFair=meFairOdd(lambda,line,'over'),
          underFair=meFairOdd(lambda,line,'under'),
          p1=1-Math.exp(-lambda);
    return {
      line,lambda:meRound(lambda,3),one_plus_proxy:meRound(p1,4),
      over_share:meRound(share,4),
      over_fair_model:meRound(overFair,3),under_fair_model:meRound(underFair,3),
      over_odd:row.over_odd,under_odd:row.under_odd,
      book_count:Number(row.book_count||0),complete_books:Number(row.complete_books||0),
      main_votes:Number(row.main_votes||0),margin:row.margin,
      latest_update_ts:row.latest_update_ts??null
    }
  }
  function meWeightedMedian(rows,valueKey,weightKey){
    const a=(rows||[]).filter(x=>Number.isFinite(Number(x?.[valueKey]))).map(x=>({...x,_v:Number(x[valueKey]),_w:Math.max(.1,Number(x?.[weightKey]||1))})).sort((x,y)=>x._v-y._v);
    if(!a.length)return null;
    const total=a.reduce((s,x)=>s+x._w,0),half=total/2;
    let c=0;for(const x of a){c+=x._w;if(c>=half)return x._v}
    return a[a.length-1]._v
  }
  function meDispersion(vals,center){
    const a=(vals||[]).map(Number).filter(Number.isFinite);
    if(!a.length||!Number.isFinite(Number(center)))return null;
    const dev=a.map(x=>Math.abs(x-Number(center))).sort((x,y)=>x-y);
    const m=Math.floor(dev.length/2);
    return meRound(dev.length%2?dev[m]:(dev[m-1]+dev[m])/2,3)
  }
  function meReliability(mt,ests,lambda,dispersion){
    let r=1;const reasons=[];
    const complete=(ests||[]).length,books=Math.max(0,...(ests||[]).map(x=>Number(x.book_count||0)));
    if(complete<=1){r*=.58;reasons.push('ONE_LINE_ONLY')}
    else if(complete===2){r*=.78;reasons.push('TWO_LINES')}
    if(books<2){r*=.78;reasons.push('LOW_BOOK_BREADTH')}
    else if(books>=4)r*=1.03;
    if(Number.isFinite(Number(dispersion))){
      if(dispersion>.45){r*=.58;reasons.push('HIGH_LAMBDA_DISPERSION')}
      else if(dispersion>.25){r*=.76;reasons.push('LAMBDA_DISPERSION')}
      else if(dispersion<.12)r*=1.03
    }
    const age=Number(mt?.market_content_age??mt?.quote_update_age);
    if(Number.isFinite(age)){
      if(age>120){r*=.58;reasons.push('MARKET_OLD')}
      else if(age>60){r*=.78;reasons.push('MARKET_AGING')}
      else if(age<=20)r*=1.02
    }
    if(mt?.reference_source==='INFERRED_BALANCE'){r*=.94;reasons.push('INFERRED_REFERENCE')}
    return {value:meRound(meClamp(r,.2,1),3),reasons:[...new Set(reasons)],line_count:complete,max_books:books}
  }
  function meBand(lambda){
    const l=Number(lambda||0),p=1-Math.exp(-l);
    if(p>=.76)return {key:'VERY_HIGH',label:'VERY HIGH',rank:5};
    if(p>=.61)return {key:'HIGH',label:'HIGH',rank:4};
    if(p>=.46)return {key:'ELEVATED',label:'ELEVATED',rank:3};
    if(p>=.30)return {key:'MODERATE',label:'MODERATE',rank:2};
    return {key:'LOW',label:'LOW',rank:1}
  }
  function meTrend(prev,cur){
    if(!prev||!Number.isFinite(Number(prev.lambda))||!Number.isFinite(Number(cur.lambda)))return {key:'BASELINE',arrow:'→',delta:null};
    if(Number(prev?.score?.home)!==Number(cur?.score?.home)||Number(prev?.score?.away)!==Number(cur?.score?.away))return {key:'SCORE_RESET',arrow:'↺',delta:null};
    const d=Number(cur.lambda)-Number(prev.lambda);
    if(d>=.18)return {key:'RISING_FAST',arrow:'↑',delta:meRound(d,2)};
    if(d>=.07)return {key:'RISING',arrow:'↑',delta:meRound(d,2)};
    if(d<=-.18)return {key:'FALLING_FAST',arrow:'↓',delta:meRound(d,2)};
    if(d<=-.07)return {key:'FALLING',arrow:'↓',delta:meRound(d,2)};
    return {key:'STABLE',arrow:'→',delta:meRound(d,2)}
  }

  function meIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(ME_STATE.dbp)return ME_STATE.dbp;
    ME_STATE.dbp=new Promise(resolve=>{
      try{
        const req=indexedDB.open(ME_DB_NAME,1);
        req.onupgradeneeded=()=>{
          const db=req.result;
          if(!db.objectStoreNames.contains(ME_DB_STORE)){
            const st=db.createObjectStore(ME_DB_STORE,{keyPath:'id'});
            st.createIndex('captured_at','captured_at',{unique:false});
            st.createIndex('fixture_id','fixture_id',{unique:false});
            st.createIndex('fixture_mode','fixture_mode',{unique:false})
          }
        };
        req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null)
      }catch{resolve(null)}
    });
    return ME_STATE.dbp
  }
  async function meLoadRecent(fixtureId,mode,limit=30){
    try{
      const db=await meIDBOpen();if(!db)return [];
      return await new Promise(resolve=>{
        const tx=db.transaction(ME_DB_STORE,'readonly'),st=tx.objectStore(ME_DB_STORE),idx=st.index('fixture_mode'),
              key=`${fixtureId}:${mode}`,rows=[],req=idx.openCursor(IDBKeyRange.only(key),'prev');
        req.onsuccess=e=>{const c=e.target.result;if(c&&rows.length<limit){rows.push(c.value);c.continue()}else resolve(rows.reverse())};
        req.onerror=()=>resolve([])
      })
    }catch{return []}
  }
  async function mePersist(row){
    try{
      const db=await meIDBOpen();if(!db)return;
      await new Promise(resolve=>{
        const tx=db.transaction(ME_DB_STORE,'readwrite');tx.objectStore(ME_DB_STORE).put(row);
        tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()
      });
      ME_STATE.persisted++;
      if(Date.now()-ME_STATE.cleanupAt>10*60*1000){ME_STATE.cleanupAt=Date.now();meCleanup()}
    }catch{}
  }
  async function meCleanup(){
    try{
      const db=await meIDBOpen();if(!db)return;
      const cutoff=Date.now()-ME_DB_MAX_AGE,tx=db.transaction(ME_DB_STORE,'readwrite'),
            idx=tx.objectStore(ME_DB_STORE).index('captured_at');
      idx.openCursor(IDBKeyRange.upperBound(cutoff)).onsuccess=e=>{const c=e.target.result;if(c){c.delete();c.continue()}}
    }catch{}
  }
  async function meHydrate(item,mode){
    if(item.marketExpectationHydrated)return;
    item.marketExpectationHydrated=true;
    const rows=await meLoadRecent(item.id,mode,30);
    item.marketExpectationHistory=rows.slice(-ME_MEMORY_MAX);
    const last=rows[rows.length-1];
    if(last){item.marketExpectationLastSig=JSON.stringify([last.band?.key,last.lambda,last.reference?.line,last.reference?.over_odd,last.score]);item.marketExpectationLastPersistAt=Number(last.captured_at||0)}
  }
  async function meBuildShadow(item,mt,mode){
    await meHydrate(item,mode);
    const now=Date.now(),time=mt?.time||null,score=time?.score||{home:0,away:0},
          estimates=(mt?.ladder||[]).map(meLineEstimate).filter(Boolean),
          lambda=meWeightedMedian(estimates,'lambda','book_count'),
          disp=meDispersion(estimates.map(x=>x.lambda),lambda),
          rel=meReliability(mt,estimates,lambda,disp),
          band=lambda==null?{key:'NO_DATA',label:'NO DATA',rank:0}:meBand(lambda),
          ref=mt?.reference?{
            line:mt.reference.line,over_odd:mt.reference.over_odd,under_odd:mt.reference.under_odd,
            over_share:mt.reference.over_share,book_count:mt.reference.book_count
          }:null,
          row={
            id:`${item.id}:${mode}:${now}`,fixture_id:Number(item.id),fixture_mode:`${item.id}:${mode}`,
            version:ME_SHADOW_VERSION,mode,captured_at:now,
            minute:Number(time?.minute||0),score:{home:Number(score?.home||0),away:Number(score?.away||0)},
            time_remaining:time?.nominal_remaining??null,
            lambda:lambda==null?null:meRound(lambda,3),
            one_plus_goal_proxy:lambda==null?null:meRound(1-Math.exp(-lambda),4),
            band,trend:null,reliability:rel,dispersion:disp,
            reference:ref,reference_source:mt?.reference_source||'N/A',
            line_estimates:estimates,
            market_content_age:mt?.market_content_age??null,
            quote_update_age:mt?.quote_update_age??null,
            note:'MARKET SHADOW ONLY — Poisson proxy from live Asian Total ladder; not football truth; no RUNG/Final Signal effect'
          },
          prev=(item.marketExpectationHistory||[]).slice(-1)[0]||null;
    row.trend=meTrend(prev,row);
    const sig=JSON.stringify([row.band?.key,row.lambda,row.reference?.line,row.reference?.over_odd,row.reference?.under_odd,row.score,row.trend?.key]),
          elapsed=now-Number(item.marketExpectationLastPersistAt||0);
    item.marketExpectationHistory=(item.marketExpectationHistory||[]).concat([row]).slice(-ME_MEMORY_MAX);
    if(sig!==item.marketExpectationLastSig||elapsed>=60000){
      item.marketExpectationLastSig=sig;item.marketExpectationLastPersistAt=now;mePersist(row)
    }
    return row
  }

  function meBandClass(me){return String(me?.band?.key||'NO_DATA').toLowerCase().replace('_','-')}
  function meReliabilityLabel(v){
    const x=Number(v||0);return x>=.85?'HIGH':x>=.65?'GOOD':x>=.45?'LIMITED':'LOW'
  }
  function meVietnameseRead(me){
    if(!me||me.lambda==null)return 'Chưa có đủ Total line và giá hai đầu để suy ra kỳ vọng thị trường.';
    const k=me.band?.key;
    let s=k==='VERY_HIGH'?'Thị trường hiện đang định giá mức kỳ vọng bàn còn lại rất cao cho quãng thời gian còn lại.'
      :k==='HIGH'?'Thị trường hiện đang định giá kỳ vọng có thêm bàn ở mức cao.'
      :k==='ELEVATED'?'Thị trường đang định giá khả năng có thêm bàn cao hơn vùng trung bình.'
      :k==='MODERATE'?'Kỳ vọng bàn còn lại từ thị trường đang ở mức trung bình.'
      :'Thị trường hiện đang định giá kỳ vọng bàn còn lại ở mức thấp.';
    if(me.trend?.key==='RISING'||me.trend?.key==='RISING_FAST')s+=' Kỳ vọng thị trường đang tăng.';
    else if(me.trend?.key==='FALLING'||me.trend?.key==='FALLING_FAST')s+=' Kỳ vọng thị trường đang giảm.';
    return s
  }
  function meShadowHTML(me){
    if(!me)return `<section class="me-shadow waiting"><div class="me-head"><span>MARKET EXPECTATION</span><b>WAIT DATA</b></div><small>Đang chờ Total ladder đủ dữ liệu để suy ra kỳ vọng thị trường.</small></section>`;
    const cls=meBandClass(me),r=me.reference,rel=meReliabilityLabel(me.reliability?.value),
          p=me.one_plus_goal_proxy==null?'N/A':`${Math.round(me.one_plus_goal_proxy*100)}%`;
    return `<section class="me-shadow ${cls}">
      <div class="me-head">
        <span>MARKET EXPECTATION</span>
        <b>SHADOW ONLY</b>
      </div>
      <div class="me-main">
        <div>
          <strong>${esc(me.band?.label||'NO DATA')} <i>${esc(me.trend?.arrow||'→')}</i></strong>
          <small>${esc(meVietnameseRead(me))}</small>
        </div>
        <div class="me-lambda">${me.lambda==null?'—':esc(Number(me.lambda).toFixed(2))}<em> λ</em></div>
      </div>
      <div class="me-grid">
        <div class="reference"><span>MARKET REFERENCE</span><b>${r?`O${esc(mtFmtLine(r.line))} @${esc(mtFmtOdd(r.over_odd))}`:'N/A'}</b><small>${r?`U @${esc(mtFmtOdd(r.under_odd))}`:'No paired quote'}</small></div>
        <div class="remaining"><span>IMPLIED REMAINING GOALS</span><b>${me.lambda==null?'N/A':esc(Number(me.lambda).toFixed(2))}</b><small>Poisson λ proxy</small></div>
        <div class="proxy"><span>1+ GOAL PROXY</span><b>${esc(p)}</b><small>Model proxy, không phải xác suất thực</small></div>
        <div class="reliability"><span>RELIABILITY</span><b>${esc(rel)}</b><small>${esc(Math.round(Number(me.reliability?.value||0)*100))}% market evidence</small></div>
      </div>
      <div class="me-context">
        <span>LINES: <b>${esc(me.line_estimates?.length||0)}</b></span>
        <span>DISPERSION: <b>${me.dispersion==null?'N/A':esc(me.dispersion)}</b></span>
        <span>TREND: <b>${esc(me.trend?.key||'BASELINE')}</b></span>
        <span>TIME: <b>${esc(me.time_remaining??'—')}'</b></span>
      </div>
      <div class="me-note">Đây là cách thị trường đang định giá số bàn còn lại từ Total line + giá hai đầu. Không dùng dữ liệu RUNG để tính và chưa so sánh với LIVE EXPECTATION.</div>
    </section>`
  }
  function mePacketText(me){
    if(!me)return 'N/A';
    const r=me.reference;
    return `${me.band?.label||'N/A'} ${me.trend?.arrow||''} | LAMBDA ${me.lambda??'N/A'} | 1+PROXY ${me.one_plus_goal_proxy==null?'N/A':Math.round(me.one_plus_goal_proxy*100)+'%'} | REF ${r?`O${mtFmtLine(r.line)} @${mtFmtOdd(r.over_odd)} / U @${mtFmtOdd(r.under_odd)}`:'N/A'} | LINES ${me.line_estimates?.length||0} | DISP ${me.dispersion??'N/A'} | REL ${me.reliability?.value??'N/A'}`
  }


  /* ===== V1.17.3 LIVE VS MARKET SHADOW =====
     Compares two INDEPENDENT layers already built:
       LIVE side   = V1.17.1 Goal Potential
       MARKET side = V1.17.2 Market Expectation
     It classifies alignment / divergence but does not decide market value.
     IMPORTANT:
       - no line selection
       - no fair price
       - no betting-value grade
       - no RUNG / QSIG / Final Signal effect */
  const LVM_SHADOW_VERSION='V1.17.3';
  const LVM_DB_NAME='FOOTBALL_EDGE_LIVE_VS_MARKET_V1';
  const LVM_DB_STORE='live_vs_market';
  const LVM_DB_MAX_AGE=12*60*60*1000;
  const LVM_MEMORY_MAX=100;
  const LVM_STATE={dbp:null,cleanupAt:0,persisted:0};

  function lvmClamp(v,a=0,b=100){const n=Number(v);return Number.isFinite(n)?Math.max(a,Math.min(b,n)):a}
  function lvmRound(v,d=1){const n=Number(v);if(!Number.isFinite(n))return null;const p=10**d;return Math.round(n*p)/p}

  function lvmMarketIndex(me){
    // Map Market Expectation's 1+ goal Poisson proxy onto the SAME band boundaries
    // used by Goal Potential: 34 / 50 / 66 / 82.
    // This is a synthetic comparison index, not probability and not fair value.
    const p=Number(me?.one_plus_goal_proxy);
    if(!Number.isFinite(p))return null;
    const pts=[
      [0.00,0],
      [0.30,34],
      [0.46,50],
      [0.61,66],
      [0.76,82],
      [0.90,100],
      [1.00,100]
    ];
    const x=Math.max(0,Math.min(1,p));
    for(let i=1;i<pts.length;i++){
      if(x<=pts[i][0]){
        const [x0,y0]=pts[i-1],[x1,y1]=pts[i],r=(x-x0)/Math.max(.000001,x1-x0);
        return lvmRound(y0+r*(y1-y0),1)
      }
    }
    return 100
  }

  function lvmJointReliability(gp,me){
    const a=Number(gp?.reliability?.value),b=Number(me?.reliability?.value);
    if(!Number.isFinite(a)||!Number.isFinite(b))return 0;
    return lvmRound(Math.sqrt(Math.max(.01,a)*Math.max(.01,b)),3)
  }
  function lvmTrendUp(key){return ['RISING','ACCELERATING','RISING_FAST'].includes(String(key||''))}
  function lvmTrendDown(key){return ['FALLING','DECAYING','FALLING_FAST'].includes(String(key||''))}
  function lvmTrendFlat(key){return ['STABLE','BASELINE'].includes(String(key||''))}

  function lvmClassify(gp,me,liveIndex,marketIndex,jointRel){
    if(gp?.band?.rank==null||me?.band?.rank==null||liveIndex==null||marketIndex==null){
      return {key:'WAIT_DATA',label:'WAIT DATA',className:'wait',priority:0}
    }
    const rawGap=Number(liveIndex)-Number(marketIndex),
          adjustedGap=rawGap*(.55+.45*Math.max(.2,Number(jointRel||0))),
          liveRank=Number(gp.band.rank||0),marketRank=Number(me.band.rank||0),
          liveUp=lvmTrendUp(gp?.trend?.key),marketUp=lvmTrendUp(me?.trend?.key),
          marketDown=lvmTrendDown(me?.trend?.key),liveDown=lvmTrendDown(gp?.trend?.key);

    // Special PRESENT-FIRST state: LIVE accelerates before market follows.
    if(liveUp&&!marketUp&&Number(gp?.index||0)>=50&&adjustedGap>=-4&&Number(gp?.reliability?.value||0)>=.60){
      return {key:'EARLY_DIVERGENCE',label:'EARLY DIVERGENCE',className:'early',priority:5,rawGap,adjustedGap}
    }

    if(adjustedGap>=10||liveRank>=marketRank+1){
      return {key:'LIVE_ABOVE_MARKET',label:'LIVE ABOVE MARKET',className:'above',priority:4,rawGap,adjustedGap}
    }

    if(adjustedGap<=-15||marketRank>=liveRank+2||(adjustedGap<=-10&&liveDown)){
      return {key:'LIVE_BELOW_MARKET',label:'LIVE BELOW MARKET',className:'below',priority:1,rawGap,adjustedGap}
    }

    if(adjustedGap<=-7||marketRank>=liveRank+1){
      return {key:'MARKET_AHEAD_OF_LIVE',label:'MARKET AHEAD OF LIVE',className:'ahead',priority:2,rawGap,adjustedGap}
    }

    return {key:'ALIGNED_WITH_MARKET',label:'ALIGNED WITH MARKET',className:'aligned',priority:3,rawGap,adjustedGap}
  }

  function lvmConfidence(gp,me,classification,jointRel){
    let c=Number(jointRel||0),reasons=[];
    const gap=Math.abs(Number(classification?.adjustedGap||0));
    if(gap>=18)c*=1.04;
    else if(gap<5)c*=.88;
    if(gp?.trend?.key==='BASELINE')c*=.90;
    if(me?.trend?.key==='BASELINE')c*=.92;
    if(me?.dispersion!=null&&Number(me.dispersion)>.30){c*=.82;reasons.push('MARKET_DISPERSION')}
    if(Number(me?.line_estimates?.length||0)<2){c*=.82;reasons.push('THIN_MARKET_LADDER')}
    if(Number(gp?.reliability?.value||0)<.55)reasons.push('LIVE_RELIABILITY_LIMITED');
    if(Number(me?.reliability?.value||0)<.55)reasons.push('MARKET_RELIABILITY_LIMITED');
    c=Math.max(.2,Math.min(1,c));
    return {value:lvmRound(c,3),reasons}
  }

  function lvmVietnameseRead(row){
    const k=row?.classification?.key;
    if(k==='EARLY_DIVERGENCE')return 'Dữ liệu LIVE đang tăng nhanh trong khi thị trường chưa phản ứng tương ứng. Đây là lệch kỳ vọng sớm, chưa phải kết luận line có lợi thế.';
    if(k==='LIVE_ABOVE_MARKET')return 'Trạng thái bóng đá LIVE hiện mạnh hơn mức kỳ vọng mà thị trường đang phản ánh.';
    if(k==='ALIGNED_WITH_MARKET')return 'Dữ liệu LIVE và kỳ vọng thị trường hiện đang ở vùng tương đối đồng thuận.';
    if(k==='MARKET_AHEAD_OF_LIVE')return 'Thị trường đang định giá kỳ vọng cao hơn dữ liệu LIVE hiện tại, nhưng mức lệch chưa đủ mạnh để xem là đối nghịch rõ.';
    if(k==='LIVE_BELOW_MARKET')return 'Dữ liệu LIVE hiện yếu đáng kể so với mức kỳ vọng thị trường đang định giá.';
    return 'Chưa đủ dữ liệu tin cậy để so sánh LIVE với thị trường.'
  }

  function lvmWhy(row){
    const out=[],gp=row?.live,me=row?.market;
    if(gp?.trend)out.push(`LIVE ${gp.trend}`);
    if(me?.trend)out.push(`MARKET ${me.trend}`);
    if(row?.gap!=null)out.push(`GAP ${row.gap>0?'+':''}${row.gap}`);
    if(row?.confidence?.value!=null)out.push(`CONF ${Math.round(row.confidence.value*100)}%`);
    return out
  }

  function lvmIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(LVM_STATE.dbp)return LVM_STATE.dbp;
    LVM_STATE.dbp=new Promise(resolve=>{
      try{
        const req=indexedDB.open(LVM_DB_NAME,1);
        req.onupgradeneeded=()=>{
          const db=req.result;
          if(!db.objectStoreNames.contains(LVM_DB_STORE)){
            const st=db.createObjectStore(LVM_DB_STORE,{keyPath:'id'});
            st.createIndex('captured_at','captured_at',{unique:false});
            st.createIndex('fixture_id','fixture_id',{unique:false});
            st.createIndex('fixture_mode','fixture_mode',{unique:false})
          }
        };
        req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null)
      }catch{resolve(null)}
    });
    return LVM_STATE.dbp
  }
  async function lvmLoadRecent(fixtureId,mode,limit=30){
    try{
      const db=await lvmIDBOpen();if(!db)return [];
      return await new Promise(resolve=>{
        const tx=db.transaction(LVM_DB_STORE,'readonly'),st=tx.objectStore(LVM_DB_STORE),idx=st.index('fixture_mode'),
              key=`${fixtureId}:${mode}`,rows=[],req=idx.openCursor(IDBKeyRange.only(key),'prev');
        req.onsuccess=e=>{const c=e.target.result;if(c&&rows.length<limit){rows.push(c.value);c.continue()}else resolve(rows.reverse())};
        req.onerror=()=>resolve([])
      })
    }catch{return []}
  }
  async function lvmPersist(row){
    try{
      const db=await lvmIDBOpen();if(!db)return;
      await new Promise(resolve=>{
        const tx=db.transaction(LVM_DB_STORE,'readwrite');tx.objectStore(LVM_DB_STORE).put(row);
        tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()
      });
      LVM_STATE.persisted++;
      if(Date.now()-LVM_STATE.cleanupAt>10*60*1000){LVM_STATE.cleanupAt=Date.now();lvmCleanup()}
    }catch{}
  }
  async function lvmCleanup(){
    try{
      const db=await lvmIDBOpen();if(!db)return;
      const cutoff=Date.now()-LVM_DB_MAX_AGE,tx=db.transaction(LVM_DB_STORE,'readwrite'),
            idx=tx.objectStore(LVM_DB_STORE).index('captured_at');
      idx.openCursor(IDBKeyRange.upperBound(cutoff)).onsuccess=e=>{const c=e.target.result;if(c){c.delete();c.continue()}}
    }catch{}
  }
  async function lvmHydrate(item,mode){
    if(item.liveVsMarketHydrated)return;
    item.liveVsMarketHydrated=true;
    const rows=await lvmLoadRecent(item.id,mode,30);
    item.liveVsMarketHistory=rows.slice(-LVM_MEMORY_MAX);
    const last=rows[rows.length-1];
    if(last){item.liveVsMarketLastSig=JSON.stringify([last.classification?.key,last.gap,last.score]);item.liveVsMarketLastPersistAt=Number(last.captured_at||0)}
  }

  async function lvmBuildShadow(item,gp,me,mode){
    await lvmHydrate(item,mode);
    const now=Date.now(),
          liveIndex=Number.isFinite(Number(gp?.index))?lvmRound(gp.index,1):null,
          marketIndex=lvmMarketIndex(me),
          jointRel=lvmJointReliability(gp,me),
          classification=lvmClassify(gp,me,liveIndex,marketIndex,jointRel),
          confidence=lvmConfidence(gp,me,classification,jointRel),
          score=gp?.score||me?.score||{home:0,away:0},
          row={
            id:`${item.id}:${mode}:${now}`,fixture_id:Number(item.id),fixture_mode:`${item.id}:${mode}`,
            version:LVM_SHADOW_VERSION,mode,captured_at:now,
            minute:Number(gp?.minute??me?.minute??0),
            score:{home:Number(score?.home||0),away:Number(score?.away||0)},
            live:{
              index:liveIndex,band:gp?.band?.label||'N/A',rank:gp?.band?.rank??null,
              trend:gp?.trend?.key||'N/A',reliability:gp?.reliability?.value??null,
              hazard_ratio:gp?.hazard_ratio??null
            },
            market:{
              index:marketIndex,band:me?.band?.label||'N/A',rank:me?.band?.rank??null,
              trend:me?.trend?.key||'N/A',reliability:me?.reliability?.value??null,
              lambda:me?.lambda??null,reference:me?.reference||null
            },
            raw_gap:(liveIndex==null||marketIndex==null)?null:lvmRound(liveIndex-marketIndex,1),
            gap:(classification?.adjustedGap==null)?null:lvmRound(classification.adjustedGap,1),
            classification,confidence,joint_reliability:jointRel,
            note:'SHADOW COMPARISON ONLY — does not determine line value, fair price, RUNG or Final Signal'
          },
          prev=(item.liveVsMarketHistory||[]).slice(-1)[0]||null;

    if(prev&&Number(prev?.score?.home)!==Number(row.score.home)||prev&&Number(prev?.score?.away)!==Number(row.score.away)){
      row.classification={key:'WAIT_DATA',label:'SCORE RESET',className:'wait',priority:0,rawGap:null,adjustedGap:null};
      row.gap=null;
      row.note='Score changed → comparison baseline reset; wait for post-goal LIVE and market rebaseline'
    }

    const sig=JSON.stringify([row.classification?.key,row.gap,row.live?.index,row.market?.index,row.score]),
          elapsed=now-Number(item.liveVsMarketLastPersistAt||0);
    item.liveVsMarketHistory=(item.liveVsMarketHistory||[]).concat([row]).slice(-LVM_MEMORY_MAX);
    if(sig!==item.liveVsMarketLastSig||elapsed>=60000){
      item.liveVsMarketLastSig=sig;item.liveVsMarketLastPersistAt=now;lvmPersist(row)
    }
    return row
  }

  function lvmConfidenceLabel(v){
    const x=Number(v||0);return x>=.82?'HIGH':x>=.64?'GOOD':x>=.45?'LIMITED':'LOW'
  }
  function lvmShadowHTML(row){
    if(!row)return `<section class="lvm-shadow wait"><div class="lvm-head"><span>LIVE VS MARKET</span><b>WAIT DATA</b></div><small>Đang chờ cả LIVE EXPECTATION và MARKET EXPECTATION.</small></section>`;
    const c=row.classification||{label:'WAIT DATA',className:'wait'},
          conf=lvmConfidenceLabel(row.confidence?.value),why=lvmWhy(row);
    return `<section class="lvm-shadow ${esc(c.className||'wait')}">
      <div class="lvm-head">
        <span>LIVE VS MARKET</span>
        <b>SHADOW ONLY</b>
      </div>
      <div class="lvm-main">
        <div>
          <strong>${esc(c.label||'WAIT DATA')}</strong>
          <small>${esc(lvmVietnameseRead(row))}</small>
        </div>
        <div class="lvm-gap">${row.gap==null?'—':`${row.gap>0?'+':''}${esc(row.gap)}`}<em> GAP</em></div>
      </div>
      <div class="lvm-grid">
        <div class="live"><span>LIVE INDEX</span><b>${row.live?.index??'N/A'}</b><small>${esc(row.live?.band||'N/A')} • ${esc(row.live?.trend||'N/A')}</small></div>
        <div class="market"><span>MARKET INDEX</span><b>${row.market?.index??'N/A'}</b><small>${esc(row.market?.band||'N/A')} • ${esc(row.market?.trend||'N/A')}</small></div>
        <div class="gap"><span>EXPECTATION GAP</span><b>${row.gap==null?'N/A':`${row.gap>0?'+':''}${esc(row.gap)}`}</b><small>synthetic comparison index</small></div>
        <div class="confidence"><span>COMPARISON CONFIDENCE</span><b>${esc(conf)}</b><small>${esc(Math.round(Number(row.confidence?.value||0)*100))}% evidence agreement</small></div>
      </div>
      <div class="lvm-why">${why.map(x=>`<span>${esc(x)}</span>`).join('')}</div>
      <div class="lvm-note">Khung này chỉ so LIVE với kỳ vọng thị trường. Chưa đánh giá line/giá nào có lợi thế và chưa tác động tín hiệu RUNG.</div>
    </section>`
  }
  function lvmPacketText(row){
    if(!row)return 'N/A';
    return `${row.classification?.label||'N/A'} | LIVE_INDEX ${row.live?.index??'N/A'} | MARKET_INDEX ${row.market?.index??'N/A'} | GAP ${row.gap??'N/A'} | LIVE ${row.live?.band||'N/A'} ${row.live?.trend||''} | MARKET ${row.market?.band||'N/A'} ${row.market?.trend||''} | CONF ${row.confidence?.value??'N/A'}`
  }


  /* ===== V1.17.4 LINE / PRICE VALUE SHADOW =====
     Market-anchored research model. It evaluates every available Over Total
     line separately using:
       Market implied lambda + independent LIVE-vs-market gap + reliability.
     This produces MODEL PRICE PROXY / expected-return proxy, NOT a calibrated
     fair price and NOT an execution instruction.
     No effect on RUNG / QSIG / Final Signal. */
  const LPV_SHADOW_VERSION='V1.17.4';
  const LPV_DB_NAME='FOOTBALL_EDGE_LINE_PRICE_VALUE_V1';
  const LPV_DB_STORE='line_price_value';
  const LPV_MEMORY_MAX=100;
  const LPV_STATE={dbp:null,persisted:0,cleanupAt:0};

  function lpvClamp(v,a,b){const n=Number(v);return Number.isFinite(n)?Math.max(a,Math.min(b,n)):a}
  function lpvRound(v,d=3){const n=Number(v);if(!Number.isFinite(n))return null;const p=10**d;return Math.round(n*p)/p}
  function lpvLambdaFactor(lvm){
    const gap=Number(lvm?.gap);
    if(!Number.isFinite(gap))return 1;
    const rel=Number(lvm?.confidence?.value||.4);
    const raw=Math.exp(gap/115);
    return lpvClamp(1+(raw-1)*lpvClamp(rel,.2,1),.68,1.48)
  }
  function lpvLiveAdjustedLambda(me,lvm){
    const l=Number(me?.lambda);
    if(!Number.isFinite(l))return null;
    return lpvRound(l*lpvLambdaFactor(lvm),3)
  }
  function lpvExpectedReturn(lambda,line,odd,side='over'){
    const o=Number(odd);if(!Number.isFinite(o)||o<=1||!Number.isFinite(Number(lambda)))return null;
    const x=meWinPushLose(lambda,line,side);
    return lpvRound(x.win*(o-1)-x.lose,4)
  }
  function lpvGrade(ev){
    const x=Number(ev);
    if(!Number.isFinite(x))return {key:'NO_DATA',label:'NO DATA',rank:0};
    if(x>=.08)return {key:'STRONG_POSITIVE',label:'STRONG POSITIVE',rank:5};
    if(x>=.04)return {key:'POSITIVE',label:'POSITIVE',rank:4};
    if(x>=.015)return {key:'MARGINAL_POSITIVE',label:'MARGINAL +',rank:3};
    if(x>-.02)return {key:'NEUTRAL',label:'NEUTRAL',rank:2};
    if(x>-.06)return {key:'POOR_PRICE',label:'POOR PRICE',rank:1};
    return {key:'NEGATIVE',label:'NEGATIVE',rank:0}
  }
  function lpvStatePriceFit(gp,best){
    const rank=Number(gp?.band?.rank||0),g=best?.grade?.key;
    if(rank>=4&&['STRONG_POSITIVE','POSITIVE'].includes(g))return {key:'GOOD_STATE_GOOD_PRICE',label:'GOOD STATE / GOOD PRICE'};
    if(rank>=4&&['POOR_PRICE','NEGATIVE'].includes(g))return {key:'GOOD_STATE_POOR_PRICE',label:'GOOD STATE / POOR PRICE'};
    if(rank<=2&&['STRONG_POSITIVE','POSITIVE'].includes(g))return {key:'WEAK_STATE_HIGH_PRICE',label:'WEAK STATE / HIGH PRICE'};
    if(g==='MARGINAL_POSITIVE')return {key:'MARGINAL_VALUE',label:'MARGINAL VALUE'};
    if(g==='NEUTRAL')return {key:'NO_CLEAR_VALUE',label:'NO CLEAR VALUE'};
    if(['POOR_PRICE','NEGATIVE'].includes(g))return {key:'PRICE_NOT_SUPPORTIVE',label:'PRICE NOT SUPPORTIVE'};
    return {key:'WAIT_DATA',label:'WAIT DATA'}
  }
  function lpvRows(mt,me,lvm){
    const lambda=lpvLiveAdjustedLambda(me,lvm);
    if(lambda==null)return [];
    return (mt?.ladder||[]).filter(r=>r.over_odd!=null).map(r=>{
      const overModel=meFairOdd(lambda,r.line,'over'),underModel=meFairOdd(lambda,r.line,'under'),
            overEv=lpvExpectedReturn(lambda,r.line,r.over_odd,'over'),
            underEv=r.under_odd==null?null:lpvExpectedReturn(lambda,r.line,r.under_odd,'under'),
            grade=lpvGrade(overEv);
      return {
        line:Number(r.line),over_odd:r.over_odd,under_odd:r.under_odd,
        model_over_price:lpvRound(overModel,3),model_under_price:lpvRound(underModel,3),
        over_ev:overEv,under_ev:underEv,grade,
        book_count:Number(r.book_count||0),margin:r.margin,main_votes:Number(r.main_votes||0)
      }
    }).sort((a,b)=>Number(b.over_ev??-99)-Number(a.over_ev??-99))
  }
  function lpvReliability(gp,me,lvm,rows){
    const a=Number(gp?.reliability?.value||0),b=Number(me?.reliability?.value||0),c=Number(lvm?.confidence?.value||0);
    let r=Math.pow(Math.max(.05,a*b*c),1/3),reasons=[];
    if((rows||[]).length<2){r*=.78;reasons.push('THIN_LADDER')}
    const best=rows?.[0];
    if(best&&Number(best.book_count||0)<2){r*=.82;reasons.push('LOW_BOOK_BREADTH')}
    if(Number(me?.dispersion||0)>.30){r*=.82;reasons.push('MARKET_DISPERSION')}
    return {value:lpvRound(lpvClamp(r,.2,1),3),reasons}
  }

  function lpvIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(LPV_STATE.dbp)return LPV_STATE.dbp;
    LPV_STATE.dbp=new Promise(resolve=>{
      try{
        const req=indexedDB.open(LPV_DB_NAME,1);
        req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(LPV_DB_STORE)){const st=db.createObjectStore(LPV_DB_STORE,{keyPath:'id'});st.createIndex('captured_at','captured_at',{unique:false});st.createIndex('fixture_mode','fixture_mode',{unique:false})}};
        req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null)
      }catch{resolve(null)}
    });return LPV_STATE.dbp
  }
  async function lpvLoadRecent(id,mode,limit=30){
    try{
      const db=await lpvIDBOpen();if(!db)return [];
      return await new Promise(resolve=>{const tx=db.transaction(LPV_DB_STORE,'readonly'),idx=tx.objectStore(LPV_DB_STORE).index('fixture_mode'),rows=[],req=idx.openCursor(IDBKeyRange.only(`${id}:${mode}`),'prev');req.onsuccess=e=>{const c=e.target.result;if(c&&rows.length<limit){rows.push(c.value);c.continue()}else resolve(rows.reverse())};req.onerror=()=>resolve([])})
    }catch{return []}
  }
  async function lpvPersist(row){
    try{
      const db=await lpvIDBOpen();if(!db)return;
      await new Promise(resolve=>{const tx=db.transaction(LPV_DB_STORE,'readwrite');tx.objectStore(LPV_DB_STORE).put(row);tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()});
      LPV_STATE.persisted++
    }catch{}
  }
  async function lpvHydrate(item,mode){
    if(item.lpvHydrated)return;item.lpvHydrated=true;
    const rows=await lpvLoadRecent(item.id,mode);item.lpvHistory=rows.slice(-LPV_MEMORY_MAX);
    const last=rows[rows.length-1];if(last){item.lpvLastSig=JSON.stringify([last.best?.line,last.best?.grade?.key,last.fit?.key,last.score]);item.lpvLastPersistAt=Number(last.captured_at||0)}
  }
  async function lpvBuildShadow(item,mt,gp,me,lvm,mode){
    await lpvHydrate(item,mode);
    const now=Date.now(),rows=lpvRows(mt,me,lvm),best=rows[0]||null,lambda=lpvLiveAdjustedLambda(me,lvm),
          reliability=lpvReliability(gp,me,lvm,rows),fit=lpvStatePriceFit(gp,best),score=gp?.score||me?.score||{home:0,away:0},
          row={
            id:`${item.id}:${mode}:${now}`,fixture_mode:`${item.id}:${mode}`,fixture_id:Number(item.id),version:LPV_SHADOW_VERSION,
            captured_at:now,mode,minute:Number(gp?.minute??me?.minute??0),score:{home:Number(score.home||0),away:Number(score.away||0)},
            market_lambda:me?.lambda??null,live_adjusted_lambda:lambda,lambda_factor:lpvRound(lpvLambdaFactor(lvm),3),
            rows,best,fit,reliability,
            note:'SHADOW MODEL VALUE ONLY — market-anchored proxy; not calibrated fair value; no Final Signal effect'
          };
    const prev=(item.lpvHistory||[]).slice(-1)[0];
    if(prev&&(Number(prev.score?.home)!==row.score.home||Number(prev.score?.away)!==row.score.away)){row.best=null;row.fit={key:'SCORE_RESET',label:'SCORE RESET'};row.note='Score changed → wait for post-goal rebaseline'}
    const sig=JSON.stringify([row.best?.line,row.best?.grade?.key,row.fit?.key,row.live_adjusted_lambda,row.score]),elapsed=now-Number(item.lpvLastPersistAt||0);
    item.lpvHistory=(item.lpvHistory||[]).concat([row]).slice(-LPV_MEMORY_MAX);
    if(sig!==item.lpvLastSig||elapsed>=60000){item.lpvLastSig=sig;item.lpvLastPersistAt=now;lpvPersist(row)}
    return row
  }
  function lpvColorClass(row){
    const k=row?.best?.grade?.key||row?.fit?.key||'NO_DATA';
    if(['STRONG_POSITIVE','POSITIVE','GOOD_STATE_GOOD_PRICE'].includes(k))return 'positive';
    if(['MARGINAL_POSITIVE','MARGINAL_VALUE'].includes(k))return 'marginal';
    if(['POOR_PRICE','NEGATIVE','GOOD_STATE_POOR_PRICE','PRICE_NOT_SUPPORTIVE'].includes(k))return 'poor';
    return 'neutral'
  }
  function lpvVietnameseRead(row){
    const f=row?.fit?.key;
    if(f==='GOOD_STATE_GOOD_PRICE')return 'Trạng thái LIVE đang tốt và giá Over tốt nhất trong ladder vẫn còn khoảng chênh dương theo mô hình shadow.';
    if(f==='GOOD_STATE_POOR_PRICE')return 'Trạng thái LIVE tốt nhưng market đã ép giá; trạng thái trận tốt không đồng nghĩa giá hiện tại còn hấp dẫn.';
    if(f==='WEAK_STATE_HIGH_PRICE')return 'Giá nhìn cao nhưng dữ liệu LIVE chưa đủ mạnh; không nên nhầm giá cao với trạng thái trận tốt.';
    if(f==='MARGINAL_VALUE')return 'Có chênh lệch dương nhỏ, nhưng chưa đủ rộng để xem là bền vững.';
    if(f==='PRICE_NOT_SUPPORTIVE')return 'Line/giá hiện tại không hỗ trợ kỳ vọng LIVE theo mô hình shadow.';
    if(f==='SCORE_RESET')return 'Tỷ số vừa thay đổi; chờ market và LIVE tái baseline trước khi so lại line/giá.';
    return 'Chưa có chênh lệch đủ rõ giữa trạng thái LIVE và line/giá hiện tại.'
  }
  function lpvShadowHTML(row){
    const best=row?.best,cls=lpvColorClass(row);
    return `<section class="lpv-shadow ${cls}">
      <div class="lpv-head"><span>LINE / PRICE VALUE</span><b>SHADOW ONLY</b></div>
      <div class="lpv-main">
        <div><strong>${esc(row?.fit?.label||'WAIT DATA')}</strong><small>${esc(lpvVietnameseRead(row))}</small></div>
        <div class="lpv-best">${best?`O${esc(mtFmtLine(best.line))} @${esc(mtFmtOdd(best.over_odd))}`:'—'}<em> BEST FIT</em></div>
      </div>
      <div class="lpv-grid">
        <div><span>LIVE-ADJUSTED λ</span><b>${row?.live_adjusted_lambda??'N/A'}</b><small>market-anchored research proxy</small></div>
        <div><span>MODEL PRICE PROXY</span><b>${best?esc(mtFmtOdd(best.model_over_price)):'N/A'}</b><small>not calibrated fair price</small></div>
        <div><span>OVER VALUE GAP</span><b>${best?.over_ev==null?'N/A':`${best.over_ev>=0?'+':''}${Math.round(best.over_ev*1000)/10}%`}</b><small>expected-return proxy</small></div>
        <div><span>RELIABILITY</span><b>${row?.reliability?.value==null?'N/A':Math.round(row.reliability.value*100)+'%'}</b><small>combined evidence quality</small></div>
      </div>
      <div class="lpv-ladder">${(row?.rows||[]).slice(0,5).map(x=>`<span class="${esc(lpvGrade(x.over_ev).key.toLowerCase())}">O${esc(mtFmtLine(x.line))} @${esc(mtFmtOdd(x.over_odd))} • ${esc(x.grade.label)} • ${x.over_ev==null?'N/A':`${x.over_ev>=0?'+':''}${Math.round(x.over_ev*1000)/10}%`}</span>`).join('')}</div>
      <div class="lpv-note">Đánh giá từng line riêng biệt. GOAL POTENTIAL cao không có nghĩa mọi line Over đều có giá trị.</div>
    </section>`
  }
  function lpvPacketText(row){
    const b=row?.best;
    return `${row?.fit?.label||'N/A'} | BEST ${b?`O${mtFmtLine(b.line)} @${mtFmtOdd(b.over_odd)}`:'N/A'} | MODEL_PRICE ${b?.model_over_price??'N/A'} | EV_PROXY ${b?.over_ev??'N/A'} | LIVE_ADJ_LAMBDA ${row?.live_adjusted_lambda??'N/A'} | REL ${row?.reliability?.value??'N/A'}`
  }

  /* ===== V1.17.5 ROBUSTNESS + CONSOLIDATED UI =====
     Tests whether the Line/Price shadow conclusion survives a reasonable
     uncertainty range around the LIVE-adjusted lambda.
     Still research-only. */
  const RB_SHADOW_VERSION='V1.17.5';
  const RB_DB_NAME='FOOTBALL_EDGE_ROBUSTNESS_V1';
  const RB_DB_STORE='robustness';
  const RB_STATE={dbp:null};

  function rbClamp(v,a,b){const n=Number(v);return Number.isFinite(n)?Math.max(a,Math.min(b,n)):a}
  function rbRound(v,d=3){const n=Number(v);if(!Number.isFinite(n))return null;const p=10**d;return Math.round(n*p)/p}
  function rbUncertainty(gp,me,lvm,lpv){
    const rel=Math.pow(Math.max(.01,Number(gp?.reliability?.value||.2)*Number(me?.reliability?.value||.2)*Number(lvm?.confidence?.value||.2)*Number(lpv?.reliability?.value||.2)),.25);
    const lambda=Math.max(.15,Number(lpv?.live_adjusted_lambda||me?.lambda||.5)),disp=Number(me?.dispersion||0),
          dispPct=disp>0?Math.min(.28,disp/lambda*.45):.04,
          u=rbClamp(.10+(1-rel)*.34+dispPct,.10,.48);
    return {fraction:rbRound(u,3),combined_reliability:rbRound(rel,3),dispersion_component:rbRound(dispPct,3)}
  }
  function rbBuild(gp,me,lvm,lpv){
    const best=lpv?.best,lambda=Number(lpv?.live_adjusted_lambda);
    if(!best||!Number.isFinite(lambda))return {key:'WAIT_DATA',label:'WAIT DATA',className:'neutral',uncertainty:null};
    const u=rbUncertainty(gp,me,lvm,lpv),low=Math.max(.01,lambda*(1-u.fraction)),high=lambda*(1+u.fraction),
          evLow=lpvExpectedReturn(low,best.line,best.over_odd,'over'),
          evBase=lpvExpectedReturn(lambda,best.line,best.over_odd,'over'),
          evHigh=lpvExpectedReturn(high,best.line,best.over_odd,'over');
    let key='UNCERTAIN',label='UNCERTAIN',className='neutral';
    if(evLow!=null&&evLow>=.015){key='ROBUST_POSITIVE';label='ROBUST POSITIVE';className='positive'}
    else if(evBase!=null&&evBase>=.015&&evLow<.015){key='SENSITIVE_POSITIVE';label='POSITIVE / SENSITIVE';className='marginal'}
    else if(evHigh!=null&&evHigh<=-.015){key='ROBUST_POOR';label='ROBUST POOR PRICE';className='poor'}
    else if(evBase!=null&&evBase<-.015){key='POOR_BUT_SENSITIVE';label='POOR / SENSITIVE';className='poor'}
    return {key,label,className,uncertainty:u,lambda_low:rbRound(low,3),lambda_base:rbRound(lambda,3),lambda_high:rbRound(high,3),ev_low:evLow,ev_base:evBase,ev_high:evHigh}
  }
  function rbIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(RB_STATE.dbp)return RB_STATE.dbp;
    RB_STATE.dbp=new Promise(resolve=>{try{const r=indexedDB.open(RB_DB_NAME,1);r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains(RB_DB_STORE)){const s=db.createObjectStore(RB_DB_STORE,{keyPath:'id'});s.createIndex('fixture_mode','fixture_mode',{unique:false})}};r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null)}catch{resolve(null)}});return RB_STATE.dbp
  }
  async function rbPersist(row){
    try{const db=await rbIDBOpen();if(!db)return;await new Promise(resolve=>{const tx=db.transaction(RB_DB_STORE,'readwrite');tx.objectStore(RB_DB_STORE).put(row);tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()})}catch{}
  }
  async function rbBuildShadow(item,gp,me,lvm,lpv,mode){
    const now=Date.now(),x=rbBuild(gp,me,lvm,lpv),score=gp?.score||me?.score||{home:0,away:0},
          row={id:`${item.id}:${mode}:${now}`,fixture_mode:`${item.id}:${mode}`,fixture_id:Number(item.id),version:RB_SHADOW_VERSION,captured_at:now,mode,minute:Number(gp?.minute??me?.minute??0),score:{home:Number(score.home||0),away:Number(score.away||0)},...x,note:'SHADOW ROBUSTNESS ONLY — no RUNG/Final Signal effect'};
    const sig=JSON.stringify([row.key,row.lambda_low,row.lambda_high,row.score]),last=item.rbLastSig,elapsed=now-Number(item.rbLastAt||0);
    item.robustnessHistory=(item.robustnessHistory||[]).concat([row]).slice(-100);
    if(sig!==last||elapsed>=60000){item.rbLastSig=sig;item.rbLastAt=now;rbPersist(row)}
    return row
  }
  function rbVietnamese(row){
    if(row?.key==='ROBUST_POSITIVE')return 'Chênh lệch dương vẫn còn ngay cả khi giảm giả định LIVE trong biên bất định.';
    if(row?.key==='SENSITIVE_POSITIVE')return 'Kết luận dương ở ước lượng trung tâm nhưng có thể mất nếu LIVE yếu hơn giả định.';
    if(row?.key==='ROBUST_POOR')return 'Ngay cả giả định LIVE cao hơn, giá hiện tại vẫn chưa tạo khoảng chênh tích cực.';
    if(row?.key==='POOR_BUT_SENSITIVE')return 'Ước lượng trung tâm không thuận lợi nhưng kết luận còn nhạy với bất định.';
    return 'Biên bất định hiện còn lớn; chưa nên xem kết luận line/giá là bền vững.'
  }
  function rbPacketText(row){
    return row?`${row.label} | LAMBDA ${row.lambda_low??'N/A'}..${row.lambda_high??'N/A'} | EV ${row.ev_low??'N/A'} / ${row.ev_base??'N/A'} / ${row.ev_high??'N/A'} | U ${row.uncertainty?.fraction??'N/A'}`:'N/A'
  }
  function mtIntelClass(s){
    return s?.robustness?.className||s?.line_price_value?.best?.grade?.key==='POSITIVE'?'positive':s?.live_vs_market?.classification?.className||'neutral'
  }
  function mtIntelHTML(s,mode){
    const gp=s?.goal_potential,me=s?.market_expectation,lvm=s?.live_vs_market,lpv=s?.line_price_value,rb=s?.robustness,b=lpv?.best,
          cls=rb?.className||lvm?.classification?.className||'neutral';
    return `<section class="mt-intel ${esc(cls)}">
      <div class="mti-head"><span>MARKET-TIME INTELLIGENCE</span><b>RESEARCH LAYER</b></div>
      <div class="mti-hero">
        <div><strong>${esc(lvm?.classification?.label||'WAIT DATA')}</strong><small>${esc(lvmVietnameseRead(lvm))}</small></div>
        <div class="mti-line">${b?`O${esc(mtFmtLine(b.line))} @${esc(mtFmtOdd(b.over_odd))}`:'—'}<em> BEST FIT SHADOW</em></div>
      </div>
      <div class="mti-grid">
        <div class="live"><span>GOAL POTENTIAL</span><b>${esc(gp?.band?.label||'N/A')} ${esc(gp?.trend?.arrow||'')}</b><small>${gp?.index??'—'}/100</small></div>
        <div class="market"><span>MARKET EXPECTATION</span><b>${esc(me?.band?.label||'N/A')}</b><small>λ ${me?.lambda??'—'}</small></div>
        <div class="value"><span>LINE / PRICE FIT</span><b>${esc(lpv?.fit?.label||'N/A')}</b><small>${b?.over_ev==null?'N/A':`${b.over_ev>=0?'+':''}${Math.round(b.over_ev*1000)/10}% proxy`}</small></div>
        <div class="robust"><span>ROBUSTNESS</span><b>${esc(rb?.label||'N/A')}</b><small>${rb?.uncertainty?.fraction==null?'N/A':'±'+Math.round(rb.uncertainty.fraction*100)+'% λ range'}</small></div>
        <div class="time"><span>TIME REMAINING</span><b>${gp?.time?.remaining??me?.time_remaining??'—'}'</b><small>+ added time unknown</small></div>
        <div class="confidence"><span>COMPARISON CONF.</span><b>${lvm?.confidence?.value==null?'N/A':Math.round(lvm.confidence.value*100)+'%'}</b><small>LIVE + market evidence</small></div>
      </div>
      <div class="mti-read">${esc(rbVietnamese(rb))}</div>
      <div class="mti-warning">Các chỉ số này vẫn ở SHADOW/RESEARCH MODE; chưa thay đổi RUNG, QSIG hoặc Final Signal.</div>${valStatusHTML(s?.validation)}${evidenceHTML()}
    </section>`
  }

  /* ===== V1.17.6 VALIDATION LAB =====
     Immutable T0 research ledger for Market-Time layers.
     One wave = one sample. No retroactive threshold edits. */
  const VAL_VERSION='V1.17.6';
  const VAL_DB_NAME='FOOTBALL_EDGE_MARKET_TIME_VALIDATION_V1';
  const VAL_DB_STORE='samples';
  const VAL_STATE={dbp:null,started:0,updated:0};

  function valEligibility(s,mode){
    const gp=s?.goal_potential,lvm=s?.live_vs_market,lpv=s?.line_price_value,rb=s?.robustness,
          remain=Number(gp?.time?.remaining??s?.market_expectation?.time_remaining);
    if(!gp||!lvm||!lpv||!rb||!Number.isFinite(remain))return {ok:false,reason:'WAIT_DATA'};
    if(remain<(mode==='H1'?1:2))return {ok:false,reason:'TOO_LATE'};
    if(['SCORE_RESET','WAIT_DATA'].includes(String(lvm?.classification?.key||''))||String(lpv?.fit?.key||'')==='SCORE_RESET')return {ok:false,reason:'RESET'};
    const gpOn=Number(gp?.band?.rank||0)>=3,
          gapOn=Math.abs(Number(lvm?.gap||0))>=7,
          valueOn=Number(lpv?.best?.grade?.rank||0)>=3;
    return {ok:gpOn||gapOn||valueOn,reason:gpOn?'GOAL_POTENTIAL':gapOn?'EXPECTATION_GAP':valueOn?'LINE_VALUE':'BELOW_RESEARCH_GATE'}
  }
  function valT0(item,s,mode,now=Date.now()){
    const gp=s.goal_potential,me=s.market_expectation,lvm=s.live_vs_market,lpv=s.line_price_value,rb=s.robustness,b=lpv?.best;
    return {
      id:`${item.id}:${mode}:${now}`,fixture_id:Number(item.id),fixture_mode:`${item.id}:${mode}`,version:VAL_VERSION,
      t0:now,captured_at:now,mode,minute:Number(s.minute||gp?.minute||0),score0:{home:Number(s.goals?.home||0),away:Number(s.goals?.away||0)},
      rung:{state:String(item.state||''),score:Number(item.eval?.score??NaN),core:item.eval?.core||null,score_mode:item.eval?.scoreMode||null},
      goal_potential:{band:gp?.band?.key,index:gp?.index,hazard_ratio:gp?.hazard_ratio,trend:gp?.trend?.key,reliability:gp?.reliability?.value,time_remaining:gp?.time?.remaining},
      market_expectation:{band:me?.band?.key,lambda:me?.lambda,proxy:me?.one_plus_goal_proxy,trend:me?.trend?.key,reliability:me?.reliability?.value,reference:me?.reference||null},
      live_vs_market:{state:lvm?.classification?.key,gap:lvm?.gap,confidence:lvm?.confidence?.value},
      line_price:{fit:lpv?.fit?.key,best:b?{line:b.line,over_odd:b.over_odd,model_price:b.model_over_price,ev_proxy:b.over_ev,grade:b.grade?.key}:null,live_adjusted_lambda:lpv?.live_adjusted_lambda,reliability:lpv?.reliability?.value},
      robustness:{key:rb?.key,lambda_low:rb?.lambda_low,lambda_high:rb?.lambda_high,ev_low:rb?.ev_low,ev_base:rb?.ev_base,ev_high:rb?.ev_high},
      horizons:{
        goal_3m:{resolved:false,hit:null},goal_5m:{resolved:false,hit:null},goal_10m:{resolved:false,hit:null},goal_15m:{resolved:false,hit:null},
        before_period_end:{resolved:false,hit:null}
      },
      market_follow:{
        s30:{resolved:false,data:null},s60:{resolved:false,data:null},s120:{resolved:false,data:null}
      },
      first_goal_at:null,closed:false,close_reason:null,last_update:now,
      note:'IMMUTABLE T0 research sample. One wave = one sample.'
    }
  }
  function valScoreChanged(sample,s){
    return Number(s?.goals?.home||0)!==Number(sample?.score0?.home||0)||Number(s?.goals?.away||0)!==Number(sample?.score0?.away||0)
  }
  function valMarketFollowData(s){
    const me=s?.market_expectation,r=me?.reference,lvm=s?.live_vs_market;
    return {minute:Number(s?.minute||0),lambda:me?.lambda??null,line:r?.line??null,over_odd:r?.over_odd??null,under_odd:r?.under_odd??null,lvm:lvm?.classification?.key||null,gap:lvm?.gap??null}
  }
  function valResolveSample(sample,s,now=Date.now(),periodEnded=false){
    const elapsed=(now-Number(sample.t0))/1000,goal=valScoreChanged(sample,s);
    if(goal&&sample.first_goal_at==null)sample.first_goal_at=now;
    for(const m of [3,5,10,15]){
      const k=`goal_${m}m`,h=sample.horizons[k];
      if(!h.resolved&&(goal||elapsed>=m*60)){h.resolved=true;h.hit=goal&&elapsed<=m*60;h.resolved_at=now}
    }
    for(const sec of [30,60,120]){
      const k=`s${sec}`,h=sample.market_follow[k];
      if(!h.resolved&&elapsed>=sec){h.resolved=true;h.data=valMarketFollowData(s);h.resolved_at=now}
    }
    if(periodEnded&&!sample.horizons.before_period_end.resolved){
      sample.horizons.before_period_end={resolved:true,hit:sample.first_goal_at!=null,resolved_at:now}
    }
    if(goal){
      sample.horizons.before_period_end={resolved:true,hit:true,resolved_at:now};
      sample.closed=true;sample.close_reason='GOAL'
    }else if(periodEnded){
      sample.closed=true;sample.close_reason='PERIOD_END'
    }else if(sample.horizons.goal_15m.resolved){
      sample.closed=true;sample.close_reason='HORIZON_15M'
    }
    sample.last_update=now;return sample
  }

  function valIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(VAL_STATE.dbp)return VAL_STATE.dbp;
    VAL_STATE.dbp=new Promise(resolve=>{try{const r=indexedDB.open(VAL_DB_NAME,1);r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains(VAL_DB_STORE)){const st=db.createObjectStore(VAL_DB_STORE,{keyPath:'id'});st.createIndex('t0','t0',{unique:false});st.createIndex('fixture_mode','fixture_mode',{unique:false});st.createIndex('closed','closed',{unique:false})}};r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null)}catch{resolve(null)}});return VAL_STATE.dbp
  }
  async function valPersist(sample){
    try{const db=await valIDBOpen();if(!db)return;await new Promise(resolve=>{const tx=db.transaction(VAL_DB_STORE,'readwrite');tx.objectStore(VAL_DB_STORE).put(sample);tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()});VAL_STATE.updated++}catch{}
  }
  async function valUpdate(item,s,mode){
    const now=Date.now(),eligible=valEligibility(s,mode),status=String(s?.status||''),minute=Number(s?.minute||0),
          periodEnded=mode==='H1'?(!['1H','LIVE'].includes(status)||minute>45):(!isLive(s?.fixture));
    if(item.validationArmed===undefined)item.validationArmed=true;
    if(!eligible.ok){
      item.validationBelowSince=item.validationBelowSince||now;
      if(now-Number(item.validationBelowSince)>=120000&&!item.validationActive)item.validationArmed=true
    }else item.validationBelowSince=null;

    if(item.validationActive){
      valResolveSample(item.validationActive,s,now,periodEnded);
      await valPersist(item.validationActive);
      if(item.validationActive.closed){
        item.validationLastClosed=item.validationActive;
        item.validationActive=null;
        item.validationArmed=false;
        item.validationBelowSince=eligible.ok?null:now
      }
    }
    if(!item.validationActive&&item.validationArmed&&eligible.ok&&!periodEnded){
      item.validationActive=valT0(item,s,mode,now);
      item.validationActive.trigger=eligible.reason;
      item.validationArmed=false;VAL_STATE.started++;
      await valPersist(item.validationActive)
    }
    return {
      active:item.validationActive?{id:item.validationActive.id,t0:item.validationActive.t0,trigger:item.validationActive.trigger,minute:item.validationActive.minute}:null,
      last:item.validationLastClosed?{id:item.validationLastClosed.id,reason:item.validationLastClosed.close_reason,goal_5m:item.validationLastClosed.horizons?.goal_5m?.hit,goal_10m:item.validationLastClosed.horizons?.goal_10m?.hit}:null,
      armed:!!item.validationArmed,eligible
    }
  }
  function valStatusHTML(v){
    if(v?.active)return `<div class="val-status active"><span>VALIDATION LAB</span><b>T0 ACTIVE</b><small>${esc(v.active.trigger)} • sample ${esc(v.active.id.split(':').slice(-1)[0])}</small></div>`;
    if(v?.last)return `<div class="val-status closed"><span>VALIDATION LAB</span><b>${esc(v.last.reason||'CLOSED')}</b><small>5m ${v.last.goal_5m===null?'N/A':v.last.goal_5m?'HIT':'NO'} • 10m ${v.last.goal_10m===null?'N/A':v.last.goal_10m?'HIT':'NO'} • ${v.armed?'ARMED':'WAIT RE-ARM'}</small></div>`;
    return `<div class="val-status"><span>VALIDATION LAB</span><b>${v?.armed?'ARMED':'WAIT'}</b><small>${esc(v?.eligible?.reason||'Waiting for research state')}</small></div>`
  }
  function valPacketText(v){return v?.active?`T0_ACTIVE ${v.active.id} | trigger ${v.active.trigger}`:v?.last?`LAST ${v.last.id} | ${v.last.reason} | 5m ${v.last.goal_5m} | 10m ${v.last.goal_10m}`:'N/A'}

  /* ===== V1.18.0 EVIDENCE-GATED INTEGRATED RESEARCH BUILD =====
     V1.18 does NOT auto-promote Market-Time research layers into the main
     RUNG / QSIG / Final Signal. It evaluates whether collected validation
     evidence is mature enough to become a PROMOTION CANDIDATE for a later,
     deliberate release review. */
  const EVIDENCE_VERSION='V1.18.0';
  const EVIDENCE_STATE={summary:null,lastAt:0,refreshing:false};

  function evRate(rows,fn){
    const a=(rows||[]).filter(fn),r=a.filter(x=>x?.horizons?.goal_10m?.resolved);
    if(!r.length)return {n:0,hits:0,rate:null};
    const hits=r.filter(x=>x.horizons.goal_10m.hit===true).length;
    return {n:r.length,hits,rate:hits/r.length}
  }
  function evBandRank(s){
    const k=String(s?.goal_potential?.band||'');
    return k==='VERY_HIGH'?5:k==='HIGH'?4:k==='ELEVATED'?3:k==='MODERATE'?2:k==='LOW'?1:0
  }
  function evFollowPositive(s){
    const f=s?.market_follow?.s120;
    if(!f?.resolved||!f.data)return null;
    const t=s?.market_expectation||{},d=f.data;
    const l0=Number(t.lambda),l1=Number(d.lambda),line0=Number(t.reference?.line),line1=Number(d.line),o0=Number(t.reference?.over_odd),o1=Number(d.over_odd);
    if(Number.isFinite(l0)&&Number.isFinite(l1)&&l1>=l0+.05)return true;
    if(Number.isFinite(line0)&&Number.isFinite(line1)&&line1>line0)return true;
    if(Number.isFinite(line0)&&Number.isFinite(line1)&&line1===line0&&Number.isFinite(o0)&&Number.isFinite(o1)&&o1<=o0-.03)return true;
    return false
  }
  function evCheckMonotonic(rows){
    const g3=evRate(rows,x=>evBandRank(x)===3),g4=evRate(rows,x=>evBandRank(x)===4),g5=evRate(rows,x=>evBandRank(x)===5),
          available=[g3,g4,g5].filter(x=>x.n>=20);
    if(available.length<2)return {status:'UNKNOWN',pass:false,detail:'Need >=20 samples in at least two Goal Potential bands',groups:{elevated:g3,high:g4,very_high:g5}};
    let pass=true;
    if(g3.n>=20&&g4.n>=20&&g4.rate+0.03<g3.rate)pass=false;
    if(g4.n>=20&&g5.n>=20&&g5.rate+0.03<g4.rate)pass=false;
    return {status:pass?'PASS':'FAIL',pass,groups:{elevated:g3,high:g4,very_high:g5}}
  }
  function evCheckSeparation(rows){
    const pos=evRate(rows,x=>['LIVE_ABOVE_MARKET','EARLY_DIVERGENCE'].includes(String(x?.live_vs_market?.state||''))),
          neg=evRate(rows,x=>['LIVE_BELOW_MARKET','MARKET_AHEAD_OF_LIVE'].includes(String(x?.live_vs_market?.state||'')));
    if(pos.n<30||neg.n<30)return {status:'UNKNOWN',pass:false,pos,neg,detail:'Need >=30 positive and >=30 negative comparison samples'};
    const pass=Number(pos.rate)-Number(neg.rate)>=.05;
    return {status:pass?'PASS':'FAIL',pass,pos,neg,diff:pos.rate-neg.rate}
  }
  function evCheckFollow(rows){
    const cohort=(rows||[]).filter(x=>String(x?.robustness?.key||'')==='ROBUST_POSITIVE'),
          resolved=cohort.map(x=>({x,v:evFollowPositive(x)})).filter(z=>z.v!==null);
    if(resolved.length<30)return {status:'UNKNOWN',pass:false,n:resolved.length,rate:null,detail:'Need >=30 ROBUST_POSITIVE samples with 120s market follow-through'};
    const hits=resolved.filter(z=>z.v===true).length,rate=hits/resolved.length,pass=rate>=.55;
    return {status:pass?'PASS':'FAIL',pass,n:resolved.length,hits,rate}
  }
  function evChronologicalSplit(rows){
    const a=[...(rows||[])].sort((x,y)=>Number(x.t0)-Number(y.t0)),cut=Math.max(1,Math.floor(a.length*.70));
    return {train:a.slice(0,cut),holdout:a.slice(cut)}
  }
  function evSummaryFromRows(allRows){
    const closed=(allRows||[]).filter(x=>x?.closed&&x?.horizons?.goal_10m?.resolved),
          split=evChronologicalSplit(closed),
          trainChecks={monotonic:evCheckMonotonic(split.train),separation:evCheckSeparation(split.train),follow:evCheckFollow(split.train)},
          holdChecks={monotonic:evCheckMonotonic(split.holdout),separation:evCheckSeparation(split.holdout),follow:evCheckFollow(split.holdout)};
    let key='LOCKED',label='EVIDENCE LOCKED',className='locked',reason='Insufficient real validation samples';
    if(closed.length>=200&&split.holdout.length>=60){
      const trainPass=Object.values(trainChecks).every(x=>x.pass),holdKnown=Object.values(holdChecks).filter(x=>x.status!=='UNKNOWN'),
            holdPass=holdKnown.length>=2&&holdKnown.every(x=>x.pass);
      if(trainPass&&holdPass){key='PROMOTION_CANDIDATE';label='PROMOTION CANDIDATE';className='candidate';reason='Evidence checks passed train + holdout; manual release review still required'}
      else {key='REVIEW_REQUIRED';label='REVIEW REQUIRED';className='review';reason='Sample size sufficient but one or more evidence checks are not yet robust'}
    }
    return {
      version:EVIDENCE_VERSION,key,label,className,reason,total:closed.length,train_n:split.train.length,holdout_n:split.holdout.length,
      train:trainChecks,holdout:holdChecks,
      constitution:'NO AUTO PROMOTION • NO AUTO THRESHOLD EDIT'
    }
  }

  async function evReadAll(){
    try{
      const db=await valIDBOpen();if(!db)return [];
      return await new Promise(resolve=>{const tx=db.transaction(VAL_DB_STORE,'readonly'),st=tx.objectStore(VAL_DB_STORE),rows=[],req=st.openCursor();req.onsuccess=e=>{const c=e.target.result;if(c){rows.push(c.value);c.continue()}else resolve(rows)};req.onerror=()=>resolve([])})
    }catch{return []}
  }
  async function evidenceRefresh(force=false){
    const now=Date.now();
    if(EVIDENCE_STATE.refreshing)return EVIDENCE_STATE.summary;
    if(!force&&EVIDENCE_STATE.lastAt&&now-EVIDENCE_STATE.lastAt<60000)return EVIDENCE_STATE.summary;
    EVIDENCE_STATE.refreshing=true;
    try{const rows=await evReadAll();EVIDENCE_STATE.summary=evSummaryFromRows(rows);EVIDENCE_STATE.lastAt=Date.now();return EVIDENCE_STATE.summary}
    finally{EVIDENCE_STATE.refreshing=false}
  }
  function evidenceMaybeRefresh(){evidenceRefresh(false).catch(()=>{})}
  function evPct(x){return x==null?'N/A':`${(Number(x)*100).toFixed(1)}%`}
  function evidenceHTML(){
    const e=EVIDENCE_STATE.summary;
    if(!e)return `<div class="evidence-gate locked"><span>EVIDENCE GATE</span><b>LOADING</b><small>Đang đọc Validation Lab.</small></div>`;
    const m=e.holdout?.monotonic,s=e.holdout?.separation,f=e.holdout?.follow;
    return `<div class="evidence-gate ${esc(e.className)}">
      <div class="ev-head"><span>EVIDENCE GATE</span><b>${esc(e.label)}</b></div>
      <div class="ev-grid">
        <div><span>SAMPLES</span><b>${esc(e.total)}</b><small>train ${esc(e.train_n)} • holdout ${esc(e.holdout_n)}</small></div>
        <div><span>MONOTONICITY</span><b>${esc(m?.status||'UNKNOWN')}</b><small>Goal Potential bands</small></div>
        <div><span>LIVE/MARKET SEP.</span><b>${esc(s?.status||'UNKNOWN')}</b><small>${s?.diff==null?'N/A':'gap '+evPct(s.diff)}</small></div>
        <div><span>MARKET FOLLOW</span><b>${esc(f?.status||'UNKNOWN')}</b><small>${f?.rate==null?'N/A':evPct(f.rate)} • n=${esc(f?.n||0)}</small></div>
      </div>
      <small class="ev-read">${esc(e.reason)}. Không tự động sửa threshold hoặc đưa Shadow vào Final Signal.</small>
    </div>`
  }
  function evidencePacketText(){
    const e=EVIDENCE_STATE.summary;
    return e?`${e.label} | n=${e.total} train=${e.train_n} holdout=${e.holdout_n} | train M/S/F ${e.train.monotonic.status}/${e.train.separation.status}/${e.train.follow.status} | holdout ${e.holdout.monotonic.status}/${e.holdout.separation.status}/${e.holdout.follow.status}`:'LOADING'
  }

  /* ===== V1.18.1 FINAL MODEL DECISION — PAPER / RESEARCH =====
     Purpose:
       Turn the complete research stack into one explicit paper verdict:
         BUY CANDIDATE
         PASS NOW
     while preserving the stable RUNG / QSIG / Final Signal.

     Two BUY paths:
       STANDARD
       EARLY_EDGE

     This layer also maintains a paper Decision Journal until period end so
     the exact T0 line/price can be settled correctly over long samples.

     IMPORTANT:
       - PAPER / RESEARCH verdict only.
       - no bookmaker execution CTA.
       - no bankroll / stake sizing.
       - no changes to stable RUNG / CORE / thresholds / QSIG / Final Signal. */
  const FMD_VERSION='V1.18.1';
  const FMD_DB_NAME='FOOTBALL_EDGE_FINAL_MODEL_DECISION_V1';
  const FMD_DB_STORE='decisions';
  const FMD_STATE={dbp:null,benchmark:null,benchmarkAt:0,refreshing:false};

  function fmdClamp(v,a,b){const n=Number(v);return Number.isFinite(n)?Math.max(a,Math.min(b,n)):a}
  function fmdRound(v,d=3){const n=Number(v);if(!Number.isFinite(n))return null;const p=10**d;return Math.round(n*p)/p}
  function fmdRungLevel(state){
    const s=String(state||'');
    if(s==='STRONG')return 4;
    if(s==='READY')return 3;
    if(['CANDIDATE','PARTIAL_CANDIDATE'].includes(s))return 2;
    if(['WATCH','PARTIAL_WATCH'].includes(s))return 1;
    return 0
  }
  function fmdTrendUp(gp){return ['RISING','ACCELERATING'].includes(String(gp?.trend?.key||''))}
  function fmdPairedLine(me,best){
    if(!best||best.under_odd==null)return false;
    return !!(me?.line_estimates||[]).find(x=>Math.abs(Number(x.line)-Number(best.line))<.001&&x.over_odd!=null&&x.under_odd!=null)
  }
  function fmdPriceThreshold(lambda,line,targetEv=.04){
    if(!Number.isFinite(Number(lambda))||!Number.isFinite(Number(line)))return null;
    const x=meWinPushLose(Number(lambda),Number(line),'over');
    if(!x||x.win<=1e-9)return null;
    return fmdRound(1+(x.lose+Number(targetEv||0))/x.win,3)
  }
  function fmdPriceThresholds(lpv,rb){
    const b=lpv?.best;
    if(!b)return {base:null,robust:null};
    return {
      base:fmdPriceThreshold(lpv?.live_adjusted_lambda,b.line,.04),
      robust:fmdPriceThreshold(rb?.lambda_low,b.line,.015)
    }
  }
  function fmdHardVeto(item,s,mode){
    const reasons=[],now=Date.now(),gp=s?.goal_potential,mt=s?.market_time,me=s?.market_expectation,
          lvm=s?.live_vs_market,lpv=s?.line_price_value,b=lpv?.best,
          minute=Number(s?.minute),gh=Number(s?.goals?.home),ga=Number(s?.goals?.away),
          fresh=(now-Number(s?.fresh_at||now))/1000,
          remain=Number(gp?.time?.remaining??me?.time_remaining),
          resetAge=item?.resetAt?Math.max(0,(now-Number(item.resetAt))/1000):99999,
          marketAge=Number(mt?.market_content_age??mt?.quote_update_age);

    if(!Number.isFinite(minute)||!Number.isFinite(gh)||!Number.isFinite(ga))reasons.push('INVALID_SCORE_OR_MINUTE');
    if(['ENDED','CANCELLED'].includes(String(item?.state||'')))reasons.push('MATCH_NOT_LIVE');
    if(['COOLDOWN','STALE'].includes(String(item?.state||'')))reasons.push(String(item.state));
    if(item?.cooldownUntil&&Number(item.cooldownUntil)>now)reasons.push('RESET_COOLDOWN');
    if(item?.eval?.hardVeto)reasons.push('ENGINE_HARD_VETO');
    if(fresh>(mode==='H1'?55:60))reasons.push('LIVE_DATA_STALE');
    if(resetAge<(mode==='H1'?120:180))reasons.push('RECENT_EVENT_NOT_REBASELINED');
    if(!Number.isFinite(remain)||remain<(mode==='H1'?2:3))reasons.push('INSUFFICIENT_TIME_HORIZON');
    if(!b||!Number.isFinite(Number(b.line))||!Number.isFinite(Number(b.over_odd))||Number(b.over_odd)<=1)reasons.push('NO_VALID_CURRENT_LINE_PRICE');
    if(b&&!fmdPairedLine(me,b))reasons.push('UNPAIRED_TOTAL_QUOTE');
    if(['SCORE_RESET','WAIT_DATA'].includes(String(lvm?.classification?.key||''))||String(lpv?.fit?.key||'')==='SCORE_RESET')reasons.push('SCORE_RESET');
    if(Number.isFinite(marketAge)&&marketAge>180)reasons.push('MARKET_SEVERELY_STALE');

    return {veto:reasons.length>0,reasons:[...new Set(reasons)],fresh,marketAge,remain,resetAge}
  }
  function fmdReliability(gp,me,lvm,lpv){
    return {
      live:Number(gp?.reliability?.value||0),
      market:Number(me?.reliability?.value||0),
      comparison:Number(lvm?.confidence?.value||0),
      value:Number(lpv?.reliability?.value||0)
    }
  }
  function fmdBuildRisks(item,s,mode){
    const gp=s?.goal_potential,me=s?.market_expectation,lvm=s?.live_vs_market,lpv=s?.line_price_value,rb=s?.robustness,
          mt=s?.market_time,b=lpv?.best,risks=[],remain=Number(gp?.time?.remaining??me?.time_remaining),
          marketAge=Number(mt?.market_content_age??mt?.quote_update_age);

    if(Number.isFinite(remain)&&remain<=(mode==='H1'?4:6))risks.push(`TIME_SHORT_${remain}M`);
    if(rb?.key==='SENSITIVE_POSITIVE')risks.push('ROBUSTNESS_SENSITIVE');
    if(Number(me?.dispersion||0)>.25)risks.push('MARKET_DISPERSION');
    if(Number(lvm?.confidence?.value||0)<.70)risks.push('COMPARISON_CONFIDENCE_NOT_HIGH');
    if(Number(gp?.reliability?.value||0)<.80)risks.push('LIVE_RELIABILITY_BELOW_HIGH');
    if(Number.isFinite(marketAge)&&marketAge>60)risks.push('MARKET_CONTENT_AGING');
    if(Number(b?.book_count||0)<3)risks.push('LOW_BOOK_BREADTH');
    if(fmdRungLevel(item?.state)<3)risks.push('RUNG_BELOW_READY');
    return [...new Set(risks)]
  }
  function fmdEvaluate(item,s,mode){
    const gp=s?.goal_potential,me=s?.market_expectation,lvm=s?.live_vs_market,lpv=s?.line_price_value,rb=s?.robustness,
          best=lpv?.best,hard=fmdHardVeto(item,s,mode),rel=fmdReliability(gp,me,lvm,lpv),
          rungLevel=fmdRungLevel(item?.state),gpRank=Number(gp?.band?.rank||0),
          grade=String(best?.grade?.key||'NO_DATA'),rbKey=String(rb?.key||'WAIT_DATA'),
          lvmKey=String(lvm?.classification?.key||'WAIT_DATA'),
          thresholds=fmdPriceThresholds(lpv,rb),price=Number(best?.over_odd),
          priceOk=Number.isFinite(price)&&Number.isFinite(Number(thresholds.base))&&price+1e-9>=Number(thresholds.base),
          positiveGrade=['POSITIVE','STRONG_POSITIVE'].includes(grade),
          standardLvm=['LIVE_ABOVE_MARKET','ALIGNED_WITH_MARKET'].includes(lvmKey),
          standardReliability=rel.live>=.65&&rel.market>=.55&&rel.comparison>=.55&&rel.value>=.55,
          earlyReliability=rel.live>=.72&&rel.market>=.50&&rel.comparison>=.60&&rel.value>=.60,
          standard=!hard.veto&&gpRank>=4&&rungLevel>=3&&standardLvm&&positiveGrade&&rbKey==='ROBUST_POSITIVE'&&standardReliability&&priceOk,
          early=!hard.veto&&gpRank>=4&&rungLevel>=2&&fmdTrendUp(gp)&&lvmKey==='EARLY_DIVERGENCE'&&positiveGrade&&
                ['ROBUST_POSITIVE','SENSITIVE_POSITIVE'].includes(rbKey)&&earlyReliability&&priceOk;

    let verdict='PASS_NOW',label='PASS NOW',path=hard.veto?'HARD_VETO':'NO_EDGE',className='pass';
    if(standard){verdict='BUY_CANDIDATE';label='BUY CANDIDATE';path='STANDARD';className='buy'}
    else if(early){verdict='BUY_CANDIDATE';label='BUY CANDIDATE';path='EARLY_EDGE';className='early'}

    const reasons=[],failures=[];
    if(verdict==='BUY_CANDIDATE'){
      reasons.push(`GOAL POTENTIAL ${gp?.band?.label||'N/A'} ${gp?.trend?.arrow||''}`.trim());
      reasons.push(`RUNG ${item?.state||'N/A'}`);
      reasons.push(lvm?.classification?.label||'LIVE/MARKET N/A');
      reasons.push(`LINE VALUE ${best?.grade?.label||grade}`);
      reasons.push(`ROBUSTNESS ${rb?.label||rbKey}`);
    }else if(hard.veto){
      failures.push(...hard.reasons)
    }else{
      if(gpRank<4)failures.push(`GOAL POTENTIAL ${gp?.band?.label||'N/A'} < HIGH`);
      if(path!=='EARLY_EDGE'&&rungLevel<3)failures.push(`RUNG ${item?.state||'N/A'} < READY`);
      if(!['LIVE_ABOVE_MARKET','ALIGNED_WITH_MARKET','EARLY_DIVERGENCE'].includes(lvmKey))failures.push(lvm?.classification?.label||'LIVE/MARKET NOT SUPPORTIVE');
      if(!positiveGrade)failures.push(`LINE VALUE ${best?.grade?.label||grade}`);
      if(!['ROBUST_POSITIVE','SENSITIVE_POSITIVE'].includes(rbKey))failures.push(`ROBUSTNESS ${rb?.label||rbKey}`);
      if(rbKey==='SENSITIVE_POSITIVE'&&lvmKey!=='EARLY_DIVERGENCE')failures.push('SENSITIVE VALUE NEEDS EARLY DIVERGENCE');
      if(!priceOk&&Number.isFinite(Number(thresholds.base)))failures.push(`PRICE ${mtFmtOdd(price)} < PAPER ACCEPT ${mtFmtOdd(thresholds.base)}`);
      if(rel.live<.65||rel.market<.50||rel.comparison<.55||rel.value<.55)failures.push('EVIDENCE RELIABILITY TOO LOW');
    }

    const risks=fmdBuildRisks(item,s,mode),selected=best?{
      line:Number(best.line),over_odd:Number(best.over_odd),under_odd:best.under_odd==null?null:Number(best.under_odd),
      model_price:best.model_over_price??null,ev_proxy:best.over_ev??null,grade:best.grade?.key||null,book_count:Number(best.book_count||0)
    }:null;

    return {
      version:FMD_VERSION,verdict,label,path,className,paper_only:true,
      minute:Number(s?.minute||0),score:{home:Number(s?.goals?.home||0),away:Number(s?.goals?.away||0)},
      selected,price_threshold:thresholds.base,robust_price_threshold:thresholds.robust,
      price_gap:(Number.isFinite(price)&&Number.isFinite(Number(thresholds.base)))?fmdRound(price-Number(thresholds.base),3):null,
      hard_veto:hard,reliability:rel,reasons,failures:[...new Set(failures)].slice(0,7),risks,
      main_risk:risks[0]||null,
      snapshot:{
        rung_state:item?.state||null,rung_score:Number.isFinite(Number(item?.eval?.score))?Number(item.eval.score):null,
        goal_potential:gp?.band?.key||null,goal_index:gp?.index??null,goal_trend:gp?.trend?.key||null,
        live_vs_market:lvmKey,expectation_gap:lvm?.gap??null,
        robustness:rbKey
      },
      note:'PAPER / RESEARCH MODEL VERDICT — no stake sizing, no automatic execution, no stable Final Signal effect'
    }
  }

  function fmdIDBOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(FMD_STATE.dbp)return FMD_STATE.dbp;
    FMD_STATE.dbp=new Promise(resolve=>{
      try{
        const r=indexedDB.open(FMD_DB_NAME,1);
        r.onupgradeneeded=()=>{
          const db=r.result;
          if(!db.objectStoreNames.contains(FMD_DB_STORE)){
            const st=db.createObjectStore(FMD_DB_STORE,{keyPath:'id'});
            st.createIndex('fixture_mode','fixture_mode',{unique:false});
            st.createIndex('opened_at','opened_at',{unique:false});
            st.createIndex('closed','closed',{unique:false});
            st.createIndex('path','path',{unique:false})
          }
        };
        r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null)
      }catch{resolve(null)}
    });
    return FMD_STATE.dbp
  }
  async function fmdPersist(row){
    try{
      const db=await fmdIDBOpen();if(!db)return;
      await new Promise(resolve=>{const tx=db.transaction(FMD_DB_STORE,'readwrite');tx.objectStore(FMD_DB_STORE).put(row);tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()})
    }catch{}
  }
  async function fmdLoadFixture(id,mode){
    try{
      const db=await fmdIDBOpen();if(!db)return [];
      return await new Promise(resolve=>{
        const tx=db.transaction(FMD_DB_STORE,'readonly'),idx=tx.objectStore(FMD_DB_STORE).index('fixture_mode'),rows=[],
              req=idx.openCursor(IDBKeyRange.only(`${id}:${mode}`));
        req.onsuccess=e=>{const c=e.target.result;if(c){rows.push(c.value);c.continue()}else resolve(rows)};
        req.onerror=()=>resolve([])
      })
    }catch{return []}
  }
  async function fmdLoadAll(){
    try{
      const db=await fmdIDBOpen();if(!db)return [];
      return await new Promise(resolve=>{
        const tx=db.transaction(FMD_DB_STORE,'readonly'),st=tx.objectStore(FMD_DB_STORE),rows=[],req=st.openCursor();
        req.onsuccess=e=>{const c=e.target.result;if(c){rows.push(c.value);c.continue()}else resolve(rows)};
        req.onerror=()=>resolve([])
      })
    }catch{return []}
  }
  async function fmdJournalHydrate(item,mode){
    if(item.fmdJournalHydrated)return;
    item.fmdJournalHydrated=true;
    const rows=await fmdLoadFixture(item.id,mode);
    item.fmdOpenDecisions=rows.filter(x=>!x.closed);
    item.fmdDecisionArmed=true;
    item.fmdDecisionBelowSince=null
  }
  function fmdSettlementLabel(x){
    const n=Number(x);
    if(n>=.99)return 'WIN';
    if(n>=.49)return 'HALF_WIN';
    if(n<=-.99)return 'LOSS';
    if(n<=-.49)return 'HALF_LOSS';
    return 'PUSH'
  }
  function fmdPaperReturn(settlement,odd){
    const s=Number(settlement),o=Number(odd);
    if(!Number.isFinite(s)||!Number.isFinite(o))return null;
    return fmdRound(s>0?s*(o-1):s,4)
  }
  function fmdDecisionSample(item,s,d,mode,now=Date.now()){
    const sel=d?.selected;
    return {
      id:`${item.id}:${mode}:${now}`,fixture_id:Number(item.id),fixture_mode:`${item.id}:${mode}`,
      version:FMD_VERSION,opened_at:now,t0:now,mode,path:d.path,decision:d.verdict,
      minute:Number(s?.minute||0),score0:{home:Number(s?.goals?.home||0),away:Number(s?.goals?.away||0)},
      selected:sel?{...sel}:null,price_threshold:d.price_threshold,robust_price_threshold:d.robust_price_threshold,
      snapshot:{...d.snapshot},risks:[...(d.risks||[])],main_risk:d.main_risk||null,
      latest_score:{home:Number(s?.goals?.home||0),away:Number(s?.goals?.away||0)},
      first_goal_at:null,goal_5m:null,goal_10m:null,additional_goals:null,
      settlement:null,settlement_label:null,paper_return_units:null,final_score:null,
      closed:false,closed_at:null,last_update:now,
      note:'PAPER BUY CANDIDATE journal. Settlement tracked to H1/FT period end.'
    }
  }
  function fmdUpdateOpenSample(row,s,now,periodEnded){
    const h=Number(s?.goals?.home||0),a=Number(s?.goals?.away||0),
          base=Number(row?.score0?.home||0)+Number(row?.score0?.away||0),cur=h+a,add=Math.max(0,cur-base),
          elapsed=(now-Number(row.t0))/1000;
    row.latest_score={home:h,away:a};row.additional_goals=add;row.last_update=now;
    if(add>0&&row.first_goal_at==null)row.first_goal_at=now;
    if(row.first_goal_at!=null){
      const gsec=(Number(row.first_goal_at)-Number(row.t0))/1000;
      if(row.goal_5m===null)row.goal_5m=gsec<=300;
      if(row.goal_10m===null)row.goal_10m=gsec<=600
    }else{
      if(row.goal_5m===null&&elapsed>=300)row.goal_5m=false;
      if(row.goal_10m===null&&elapsed>=600)row.goal_10m=false
    }
    if(periodEnded&&!row.closed){
      const line=Number(row?.selected?.line),odd=Number(row?.selected?.over_odd),sett=meSettlement(add,line,'over');
      row.settlement=fmdRound(sett,2);row.settlement_label=fmdSettlementLabel(sett);row.paper_return_units=fmdPaperReturn(sett,odd);
      row.final_score={home:h,away:a};row.closed=true;row.closed_at=now
    }
    return row
  }
  async function fmdJournalUpdate(item,s,d,mode){
    await fmdJournalHydrate(item,mode);
    const now=Date.now(),status=String(s?.status||''),minute=Number(s?.minute||0),
          periodEnded=mode==='H1'?(!['1H','LIVE'].includes(status)||minute>45):(!isLive(s?.fixture));

    for(const row of (item.fmdOpenDecisions||[])){
      fmdUpdateOpenSample(row,s,now,periodEnded);
      await fmdPersist(row)
    }
    item.fmdOpenDecisions=(item.fmdOpenDecisions||[]).filter(x=>!x.closed);

    if(d?.verdict!=='BUY_CANDIDATE'){
      item.fmdDecisionBelowSince=item.fmdDecisionBelowSince||now;
      if(now-Number(item.fmdDecisionBelowSince)>=120000)item.fmdDecisionArmed=true
    }else item.fmdDecisionBelowSince=null;

    let opened=null;
    if(!periodEnded&&d?.verdict==='BUY_CANDIDATE'&&item.fmdDecisionArmed){
      opened=fmdDecisionSample(item,s,d,mode,now);
      item.fmdOpenDecisions.push(opened);item.fmdDecisionArmed=false;
      await fmdPersist(opened)
    }
    return {opened:opened?opened.id:null,open_count:item.fmdOpenDecisions.length,armed:!!item.fmdDecisionArmed}
  }

  async function fmdAttachValidationT0(item,s){
    const active=item?.validationActive,d=s?.final_model_decision;
    if(!active||!d||active.final_model_decision)return;
    if(Math.abs(Date.now()-Number(active.t0||0))>5000)return;
    active.final_model_decision={
      verdict:d.verdict,path:d.path,selected:d.selected?{...d.selected}:null,
      price_threshold:d.price_threshold,robust_price_threshold:d.robust_price_threshold,
      reasons:[...(d.reasons||[])],failures:[...(d.failures||[])],risks:[...(d.risks||[])],
      snapshot:{...d.snapshot}
    };
    await valPersist(active)
  }

  function fmdAverage(rows,key='paper_return_units'){
    const a=(rows||[]).map(x=>Number(x?.[key])).filter(Number.isFinite);
    return a.length?a.reduce((s,x)=>s+x,0)/a.length:null
  }
  function fmdSettleCounts(rows){
    const out={WIN:0,HALF_WIN:0,PUSH:0,HALF_LOSS:0,LOSS:0};
    for(const r of (rows||[]))if(out[r?.settlement_label]!==undefined)out[r.settlement_label]++;
    return out
  }
  function fmdBenchmarkSummary(rows){
    const closed=(rows||[]).filter(x=>x.closed&&Number.isFinite(Number(x.paper_return_units))).sort((a,b)=>Number(a.opened_at)-Number(b.opened_at)),
          cut=Math.max(1,Math.floor(closed.length*.70)),train=closed.slice(0,cut),holdout=closed.slice(cut),
          standard=closed.filter(x=>x.path==='STANDARD'),early=closed.filter(x=>x.path==='EARLY_EDGE'),
          counts=fmdSettleCounts(closed),avg=fmdAverage(closed),trainAvg=fmdAverage(train),holdAvg=fmdAverage(holdout);
    let gate='LOCKED',label='DECISION EVIDENCE LOCKED',className='locked';
    if(closed.length>=200&&holdout.length>=60){
      if(Number(trainAvg)>0&&Number(holdAvg)>0){gate='CANDIDATE';label='DECISION REVIEW CANDIDATE';className='candidate'}
      else {gate='REVIEW';label='DECISION REVIEW REQUIRED';className='review'}
    }
    return {
      n:closed.length,avg_return:avg,train_n:train.length,holdout_n:holdout.length,train_avg:trainAvg,holdout_avg:holdAvg,
      standard_n:standard.length,standard_avg:fmdAverage(standard),early_n:early.length,early_avg:fmdAverage(early),
      counts,gate,label,className,
      note:'Paper settlement only; real execution may differ due to market availability, latency and slippage.'
    }
  }
  async function fmdBenchmarkRefresh(force=false){
    const now=Date.now();
    if(FMD_STATE.refreshing)return FMD_STATE.benchmark;
    if(!force&&FMD_STATE.benchmark&&now-FMD_STATE.benchmarkAt<60000)return FMD_STATE.benchmark;
    FMD_STATE.refreshing=true;
    try{FMD_STATE.benchmark=fmdBenchmarkSummary(await fmdLoadAll());FMD_STATE.benchmarkAt=Date.now();return FMD_STATE.benchmark}
    finally{FMD_STATE.refreshing=false}
  }
  function fmdReturnText(x){return x==null?'N/A':`${x>=0?'+':''}${(Number(x)*100).toFixed(1)}% / unit`}
  function fmdBenchmarkHTML(){
    const b=FMD_STATE.benchmark;
    if(!b)return `<div class="fmd-bench locked"><span>DECISION JOURNAL</span><b>LOADING</b><small>Đang đọc paper settlement history.</small></div>`;
    return `<div class="fmd-bench ${esc(b.className)}">
      <div class="fmdb-head"><span>DECISION JOURNAL</span><b>${esc(b.label)}</b></div>
      <div class="fmdb-grid">
        <div><span>CLOSED BUY</span><b>${esc(b.n)}</b><small>paper samples</small></div>
        <div><span>PAPER RETURN</span><b>${esc(fmdReturnText(b.avg_return))}</b><small>average / 1 unit</small></div>
        <div><span>STANDARD</span><b>${esc(b.standard_n)}</b><small>${esc(fmdReturnText(b.standard_avg))}</small></div>
        <div><span>EARLY EDGE</span><b>${esc(b.early_n)}</b><small>${esc(fmdReturnText(b.early_avg))}</small></div>
      </div>
      <small class="fmdb-note">W ${esc(b.counts.WIN)} • HW ${esc(b.counts.HALF_WIN)} • P ${esc(b.counts.PUSH)} • HL ${esc(b.counts.HALF_LOSS)} • L ${esc(b.counts.LOSS)}. ${esc(b.note)}</small>
    </div>`
  }

  async function fmdBuildShadow(item,s,mode){
    const now=Date.now(),x=fmdEvaluate(item,s,mode),
          row={id:`${item.id}:${mode}:shadow:${now}`,captured_at:now,fixture_id:Number(item.id),fixture_mode:`${item.id}:${mode}`,...x};
    item.fmdLatest=row;return row
  }
  function fmdReasonVietnamese(d){
    if(!d)return 'Chưa có đủ dữ liệu để ra verdict.';
    if(d.verdict==='BUY_CANDIDATE'&&d.path==='STANDARD')return 'Model chấp nhận line/giá hiện tại theo đường STANDARD: trạng thái LIVE đủ mạnh, line/price còn khoảng chênh và kết luận vượt qua robustness.';
    if(d.verdict==='BUY_CANDIDATE'&&d.path==='EARLY_EDGE')return 'Model chấp nhận line/giá hiện tại theo đường EARLY EDGE: LIVE đang tăng trước market và price vẫn còn dương theo shadow model.';
    if(d.path==='HARD_VETO')return 'Model PASS vì trạng thái hiện tại không đủ điều kiện hợp lệ để định giá một quyết định mới.';
    if(d.failures?.some(x=>String(x).startsWith('PRICE ')))return 'Trạng thái trận có thể tốt nhưng giá hiện tại chưa đạt ngưỡng PAPER ACCEPT của model.';
    return 'Model PASS vì tổng hợp state, market, line/price hoặc robustness chưa đạt ngưỡng quyết định cuối.'
  }
  function fmdHTML(d){
    if(!d)return `<section class="fmd-card pass"><div class="fmd-head"><span>FINAL MODEL DECISION</span><b>PAPER / RESEARCH</b></div><div class="fmd-hero"><strong>WAIT DATA</strong></div></section>`;
    const sel=d.selected,price=sel?.over_odd,accept=d.price_threshold,robust=d.robust_price_threshold;
    return `<section class="fmd-card ${esc(d.className||'pass')}">
      <div class="fmd-head"><span>FINAL MODEL DECISION</span><b>PAPER / RESEARCH</b></div>
      <div class="fmd-hero">
        <div>
          <strong>${esc(d.label)}</strong>
          <small>${esc(fmdReasonVietnamese(d))}</small>
        </div>
        <div class="fmd-selection">${sel?`O${esc(mtFmtLine(sel.line))} @${esc(mtFmtOdd(sel.over_odd))}`:'NO ACCEPTED LINE'}<em>${esc(d.path)}</em></div>
      </div>
      <div class="fmd-pricebar">
        <div><span>CURRENT PRICE</span><b>${price==null?'N/A':esc(mtFmtOdd(price))}</b></div>
        <div><span>PAPER ACCEPT ≥</span><b>${accept==null?'N/A':esc(mtFmtOdd(accept))}</b></div>
        <div><span>ROBUST ACCEPT ≥</span><b>${robust==null?'N/A':esc(mtFmtOdd(robust))}</b></div>
        <div><span>PRICE GAP</span><b>${d.price_gap==null?'N/A':`${d.price_gap>=0?'+':''}${esc(d.price_gap.toFixed(3))}`}</b></div>
      </div>
      ${d.reasons?.length?`<div class="fmd-why"><b>WHY BUY</b>${d.reasons.map(x=>`<span>${esc(x)}</span>`).join('')}</div>`:''}
      ${d.failures?.length?`<div class="fmd-why fail"><b>WHY PASS</b>${d.failures.map(x=>`<span>${esc(x)}</span>`).join('')}</div>`:''}
      <div class="fmd-risk"><b>MAIN RISK:</b> ${esc(d.main_risk||'Không có risk flag nổi bật ngoài rủi ro kết quả vốn có.')}</div>
      <div class="fmd-note">Đây là verdict của model để paper benchmark dài hạn. Không thay Stable Final Signal và không tự động thực hiện giao dịch.</div>
      ${fmdBenchmarkHTML()}
    </section>`
  }
  function fmdPacketText(d){
    if(!d)return 'N/A';
    const s=d.selected;
    return `${d.label} | PATH ${d.path} | ${s?`O${mtFmtLine(s.line)} @${mtFmtOdd(s.over_odd)}`:'NO LINE'} | PAPER_ACCEPT ${d.price_threshold??'N/A'} | ROBUST_ACCEPT ${d.robust_price_threshold??'N/A'} | FAIL ${d.failures?.join('; ')||'-'} | RISK ${d.main_risk||'-'}`
  }
  const WATCH_HISTORY_PREFIX='FE_LIVE_WATCH_V181_';
  const WATCH_CAL_KEY='FE_LIVE_WATCH_CAL_V181';
  const WATCH_MAX_ITEMS=5, WATCH_PREFILTER_MAX=40, WATCH_CAL_MAX=5000;
  const watchState={active:false,refreshing:false,items:[],timer:null,ticker:null,nextAt:0,cycle:0,audio:null,lastPacket:'',calibration:null};

  function watchNum(v){const n=Number(String(v??'').replace('%','').trim());return Number.isFinite(n)?n:null}
  function watchClamp(n,a,b){return Math.max(a,Math.min(b,n))}
  function watchLiveEligible(f){const st=f?.fixture?.status?.short||'',m=Number(f?.fixture?.status?.elapsed);return feLiveSourceValid(f)&&['2H','HT','ET','BT','LIVE','INT'].includes(st)&&Number.isFinite(m)&&m>=45&&m<=89}
  function cheapWatchRank(f){
    const m=Number(f?.fixture?.status?.elapsed||0),h=Number(f?.goals?.home||0),a=Number(f?.goals?.away||0),gap=Math.abs(h-a),tg=h+a;
    let s=0;s+=m>=55&&m<=82?25:m>=45&&m<=88?18:8;s+=gap===1?25:gap===0?22:gap===2?10:2;s+=tg<=3?15:tg<=5?8:3;s+=f?.fixture?.status?.short==='2H'?10:4;return s;
  }
  function watchPrefilterCap(){return WATCH_PREFILTER_MAX}
  function watchSideMetrics(statSide){
    const get=(names)=>{const v=getAnyStat(statSide,names);const n=watchNum(v);return n==null?0:n};
    return {shots:get(['Total Shots']),sot:get(['Shots on Goal','Shots on Target']),inbox:get(['Shots insidebox','Shots inside box']),corners:get(['Corner Kicks','Corners']),xg:get(['expected_goals','Expected Goals']),red:get(['Red Cards'])};
  }
  function watchAggregate(statMapObj,meta){
    const h=watchSideMetrics(statMapObj?.[meta?.teams?.home?.id]),a=watchSideMetrics(statMapObj?.[meta?.teams?.away?.id]);
    const t={};['shots','sot','inbox','corners','xg','red'].forEach(k=>t[k]=(Number(h[k])||0)+(Number(a[k])||0));
    return {home:h,away:a,total:t};
  }

  // DATA GUARD V1.11.1: field presence, not numeric value.
  function watchStatsPresence(statMapObj,meta){
    const ids=[meta?.teams?.home?.id,meta?.teams?.away?.id].filter(x=>x!=null),keys=[];
    let sideCount=0;
    for(const id of ids){const side=statMapObj?.[id],obj=side?.stats||side||{};const sk=Object.keys(obj);if(sk.length)sideCount++;keys.push(...sk.map(k=>String(k).toLowerCase().replace(/[_-]+/g,' ')))}
    const has=(rx)=>keys.some(k=>rx.test(k));
    const shots=has(/total shots|shots total/),sot=has(/shots on goal|shots on target/),inbox=has(/shots inside ?box|shots insidebox/),corners=has(/corner kicks|corners?/),xg=has(/expected goals|expectedgoals/);
    const pressure=shots||sot||inbox||corners||xg,chance=sot||inbox||xg,coverage=[shots,sot,inbox,corners,xg].filter(Boolean).length;
    return {shots,sot,inbox,corners,xg,pressure,chance,momentum:pressure,core:sideCount>=2&&pressure&&chance,coverage,source_keys:keys.length,side_count:sideCount};
  }

  // V1.11.5 PRO THEMES SCREENING
  // HEALTHY is the only class allowed to outrank another HEALTHY candidate.
  // PARTIAL is backup only. NO_STATS is excluded from TOP watchlists.
  function watchDataHealth(presence,apiCoverage=null){
    const p=presence||{},supported=coverageValue(apiCoverage,'fixtures.statistics_fixtures');
    if(p.core===true)return {level:'HEALTHY',priority:2,reason:'STATS OK',retryable:false};
    if(p.pressure===true)return {level:'PARTIAL',priority:1,reason:`PARTIAL • ${p.side_count<2?'thiếu 1 phía stats':'thiếu SOT/InBox/xG'}`,retryable:false};
    if(supported===false)return {level:'NO_STATS',priority:0,reason:'COVERAGE UNSUPPORTED',retryable:false};
    return {level:'NO_STATS',priority:0,reason:'API EMPTY / NO STATS',retryable:true};
  }
  function watchBundleHealth(b){
    const source=b?.data?.live_statistics||{},presence=watchStatsPresence(source,b?.meta||{});
    return {...watchDataHealth(presence,b?.data?.api_coverage||null),presence};
  }
  async function watchRetryBundleStats(entry){
    if(!entry?.b||!entry?.f||entry.health?.retryable!==true)return false;
    const id=entry.b.meta?.fixture_id;if(!id)return false;
    for(let attempt=1;attempt<=2;attempt++){
      const rows=await football('/fixtures/statistics',{fixture:id},true);
      if(Array.isArray(rows)&&rows.length){
        entry.b.data.live_statistics=statMap(rows);
        entry.b.coverage=groupCoverageScore(entry.b.meta?.mode||autoModeForFixture(entry.f),entry.b.data||{});
        entry.health=watchBundleHealth(entry.b);
        return entry.health.level!=='NO_STATS';
      }
      if(attempt<2)await new Promise(resolve=>setTimeout(resolve,250));
    }
    return false;
  }
  function watchHealthCounts(entries){
    const c={healthy:0,partial:0,no_stats:0};
    for(const x of (entries||[])){if(x.health?.level==='HEALTHY')c.healthy++;else if(x.health?.level==='PARTIAL')c.partial++;else c.no_stats++}
    return c;
  }
  async function watchSelectUsableBundles(bundles,pref,mode,maxItems,scoreFn,progressPrefix='STATS'){
    const map=new Map((pref||[]).map(f=>[Number(f.fixture?.id),f]));
    let entries=(bundles||[]).filter(b=>!b?.error&&(mode==='H1'?b.meta?.mode==='H1':b.meta?.mode!=='PRE')).map(b=>{
      const f=map.get(Number(b.meta?.fixture_id));return {b,f,e:scoreFn(b,f),health:watchBundleHealth(b),retried:false};
    });
    entries.sort((a,b)=>Number(b.e?.rank||0)-Number(a.e?.rank||0));
    let counts=watchHealthCounts(entries),retried=0,recovered=0;
    if(counts.healthy<maxItems){
      const need=Math.max(1,maxItems-counts.healthy),retryPool=entries.filter(x=>x.health?.level==='NO_STATS'&&x.health?.retryable).slice(0,Math.min(5,need+2));
      for(let i=0;i<retryPool.length;i++){
        const x=retryPool[i];retried++;x.retried=true;
        if(els.loadingText)els.loadingText.textContent=`${progressPrefix} retry ${i+1}/${retryPool.length} • ${x.f?.teams?.home?.name||''} vs ${x.f?.teams?.away?.name||''}`;
        if(await watchRetryBundleStats(x)){recovered++;x.e=scoreFn(x.b,x.f)}
      }
    }
    // Refresh health after retry. Sorting is health-first, score-second.
    entries.forEach(x=>{x.health=watchBundleHealth(x.b)});
    entries.sort((a,b)=>(Number(b.health?.priority||0)-Number(a.health?.priority||0))||(Number(b.e?.rank||0)-Number(a.e?.rank||0)));
    counts=watchHealthCounts(entries);
    const selected=entries.filter(x=>x.health?.level!=='NO_STATS').slice(0,maxItems);
    return {selected,all:entries,summary:{...counts,retried,recovered,usable:selected.length,excluded_no_stats:counts.no_stats}};
  }
  function watchHealthLabel(h){return h?.reason||h?.level||'UNKNOWN'}
  function watchHistoryAge(item,cur){
    const rows=(item.history||[]).filter(s=>Number(s.captured_at)<=Number(cur.captured_at)&&(!item.resetAt||Number(s.captured_at)>=Number(item.resetAt)));
    if(rows.length<2)return 0;const first=rows.reduce((a,b)=>Number(a.captured_at)<=Number(b.captured_at)?a:b);
    return Math.max(0,Math.round(((Number(cur.captured_at)-Number(first.captured_at))/60000)*10)/10);
  }
  function watchBestOver(overMarkets){
    const rows=[];
    for(const m of (overMarkets||[]))for(const v of (m.values||[])){
      if(v.suspended)continue;const raw=String(v.value||'');if(!/\bover\b|\btài\b|\btai\b/i.test(raw))continue;
      const odd=Number(v.odd),line=numericHandicap(v.handicap)??betTrackerLineFromValue?.(v,'over_under');
      if(Number.isFinite(odd)&&odd>1)rows.push({line:Number.isFinite(Number(line))?Number(line):null,odd,main:v.main===true,label:raw});
    }
    rows.sort((a,b)=>Number(b.main)-Number(a.main)||Math.abs((a.odd||2)-1.9)-Math.abs((b.odd||2)-1.9));return rows[0]||null;
  }
  function watchOverPriceFromMap(o){for(const [k,v] of Object.entries(o||{})){if(/over|tài|tai/i.test(k)&&Number.isFinite(Number(v)))return Number(v)}return null}
  function watchMarketInfo(markets,history=null){
    const raw=(markets||[]),valid=raw.filter(r=>r.integrity?.valid!==false&&!r.status?.blocked&&!r.status?.stopped&&!r.status?.finished&&(r.values||[]).some(v=>!v.suspended));
    const over=valid.filter(r=>r.category==='over_under'||/over.?under|total goals|goals over/i.test(String(r.market||r.bet||'')));
    const ah=valid.filter(r=>r.category==='asian_handicap'),txt=xienMarketText(valid,true,2),best=watchBestOver(over);
    const move=history?.categories?.over_under||null,fp=move?watchOverPriceFromMap(move.from_prices):null,tp=move?watchOverPriceFromMap(move.to_prices):null;
    return {raw_count:raw.length,valid_count:valid.length,invalid_count:Math.max(0,raw.length-valid.length),over_count:over.length,ah_count:ah.length,has_over:over.length>0,best_over:best,history,move:{line_delta:move?.line_delta??null,from_line:move?.from_line??null,to_line:move?.to_line??null,over_price_delta:fp!=null&&tp!=null?Math.round((tp-fp)*1000)/1000:null,from_over_price:fp,to_over_price:tp},text:txt.join(' || ')||'Chưa có live main line hợp lệ',movement_text:movementCompactText(history)||''};
  }
  function watchSnapshotFromBundle(b,f){
    const m=b.meta,n=b.data||{},source=n.live_statistics||{},metrics=watchAggregate(source,m),stats_presence=watchStatsPresence(source,m),market=watchMarketInfo(n.live_odds||[],n.live_market_movement||null),now=Date.now();
    return {captured_at:now,minute:Number(m.fixture?.status?.elapsed||0),status:m.fixture?.status?.short||'',goals:{home:Number(m.goals?.home||0),away:Number(m.goals?.away||0)},metrics,stats_presence,data_health:watchDataHealth(stats_presence,n.api_coverage||null),h1:null,h2:null,market,market_rows:n.live_odds||[],dq:b.coverage?.score||0,integrity:b.coverage?.integrity_score??null,events:n.events||[],fresh_at:now};
  }
  function watchHistoryKey(id){return WATCH_HISTORY_PREFIX+id}
  function watchReadHistory(id){try{const x=JSON.parse(localStorage.getItem(watchHistoryKey(id))||'[]');const cutoff=Date.now()-30*60*1000;return (Array.isArray(x)?x:[]).filter(s=>Number(s.captured_at)>=cutoff).slice(-80)}catch{return []}}
  function watchWriteHistory(item){try{localStorage.setItem(watchHistoryKey(item.id),JSON.stringify((item.history||[]).slice(-80)))}catch{}}
  function watchMetricAvailable(s,k){
    if(k==='red')return true;
    return s?.stats_presence?.[k]===true;
  }
  function watchMetricDelta(cur,old){
    const out={};
    ['shots','sot','inbox','corners','xg','red'].forEach(k=>{
      if(k!=='red'&&(!watchMetricAvailable(cur,k)||!watchMetricAvailable(old,k))){out[k]=null;return}
      out[k]=Math.max(0,(Number(cur?.metrics?.total?.[k])||0)-(Number(old?.metrics?.total?.[k])||0));
    });
    return out;
  }
  function watchDeltaText(d,k,label,decimals=0){
    const v=d?.[k];
    if(v==null)return `${label} N/A`;
    const n=Number(v);if(!Number.isFinite(n))return `${label} N/A`;
    const val=decimals?Math.round(n*Math.pow(10,decimals))/Math.pow(10,decimals):Math.round(n);
    return `${label} +${val}`;
  }
  function watchFindBaseline(item,cur,minutes){
    const rows=(item.history||[]).filter(s=>Number(s.captured_at)<Number(cur.captured_at)&&(!item.resetAt||s.captured_at>=item.resetAt));if(!rows.length)return null;
    const target=cur.captured_at-minutes*60000;let pick=rows[0],best=Infinity;for(const r of rows){const diff=Math.abs(Number(r.captured_at)-target);if(diff<best){pick=r;best=diff}}return pick;
  }
  function watchWindow(item,cur,minutes){const base=watchFindBaseline(item,cur,minutes);if(!base)return {mature:false,window_min:0,delta:{shots:0,sot:0,inbox:0,corners:0,xg:0,red:0},base:null};const win=Math.max(.1,(cur.captured_at-base.captured_at)/60000);return {mature:win>=Math.min(1,minutes*.4),window_min:Math.round(win*10)/10,delta:watchMetricDelta(cur,base),base}}

  function watchGameStateScore(s){
    const m=Number(s.minute||0),h=Number(s.goals?.home||0),a=Number(s.goals?.away||0),gap=Math.abs(h-a),tg=h+a;let x=0;
    x+=m>=55&&m<=82?6:m>=48&&m<=87?4:2;x+=gap===1?5:gap===0?4:gap===2?2:0;x+=tg<=3?3:tg<=5?2:1;x+=s.status==='2H'?1:0;return watchClamp(Math.round(x),0,15);
  }
  function watchPressureScore(item,s){
    const w5=watchWindow(item,s,5),w10=watchWindow(item,s,10),m=Math.max(45,Number(s.minute||60)),t=s.metrics?.total||{};let x=0;
    const d=w5.mature?w5.delta:w10.delta,win=Math.max(1,w5.mature?w5.window_min:w10.window_min||5),scale=5/win;
    if(w5.mature||w10.mature){x+=watchClamp(d.shots*scale/4*5,0,5);x+=watchClamp(d.sot*scale/1.6*6,0,6);x+=watchClamp(d.inbox*scale/3*4,0,4);x+=watchClamp(d.corners*scale/1.5*2,0,2);if(Number(t.xg)>0)x+=watchClamp(d.xg*scale/.30*3,0,3)}
    else{const p=90/m;x+=watchClamp((Number(t.shots)||0)*p/18*4,0,4);x+=watchClamp((Number(t.sot)||0)*p/7*5,0,5);x+=watchClamp((Number(t.inbox)||0)*p/11*3,0,3);x+=watchClamp((Number(t.corners)||0)*p/8*2,0,2);if(Number(t.xg)>0)x+=watchClamp((Number(t.xg)||0)*p/2*2,0,2)}
    if(s.h1&&s.h2){const h1=Number(s.h1.total?.sot||0)/45,h2m=Math.max(1,m-45),h2=Number(s.h2.total?.sot||0)/h2m;if(h2>h1*1.15)x+=2;else if(h1>0&&h2<h1*.65)x-=2}
    return {score:watchClamp(Math.round(x),0,20),w5,w10};
  }
  function watchChanceScore(item,s,p){
    const t=s.metrics?.total||{},shots=Math.max(1,Number(t.shots)||0),sot=Number(t.sot)||0,inbox=Number(t.inbox)||0,xg=Number(t.xg)||0,w=p?.w5?.mature?p.w5:p?.w10,d=w?.delta||{};let x=0;
    x+=watchClamp((sot/shots)/.42*4,0,4);x+=watchClamp((inbox/shots)/.62*3,0,3);if(xg>0)x+=watchClamp((xg/shots)/.12*4,0,4);
    if(w?.mature){const scale=5/Math.max(1,w.window_min);x+=watchClamp((Number(d.sot)||0)*scale/1.5*3,0,3);x+=watchClamp((Number(d.inbox)||0)*scale/3*2,0,2);if(xg>0)x+=watchClamp((Number(d.xg)||0)*scale/.30*4,0,4)}else{x+=watchClamp(sot/6*2,0,2)}
    return watchClamp(Math.round(x),0,20);
  }
  function watchMomentum(item,s){
    const w3=watchWindow(item,s,3),w6=watchWindow(item,s,6);if(!w3.mature)return {score:4,mature:false,window_min:w3.window_min,delta:w3.delta,accel:0};
    const d=w3.delta,scale=3/Math.max(.5,w3.window_min);let x=0;x+=watchClamp(d.shots*scale/3*4,0,4);x+=watchClamp(d.sot*scale/1.2*5,0,5);x+=watchClamp((Number(d.inbox)||0)*scale/2.2*2,0,2);x+=watchClamp((Number(d.corners)||0)*scale/1.3*2,0,2);if(s.stats_presence?.xg===true)x+=watchClamp((Number(d.xg)||0)*scale/.22*2,0,2);
    let accel=0;if(w6.mature&&w6.base&&w3.base){const prev=watchMetricDelta(w3.base,w6.base),rw=Math.max(.5,(w3.base.captured_at-w6.base.captured_at)/60000),recentRate=((Number(d.sot)||0)*2+(Number(d.shots)||0)*.35+(Number(d.corners)||0)*.45+(Number(d.xg)||0)*5)/Math.max(.5,w3.window_min),prevRate=((Number(prev.sot)||0)*2+(Number(prev.shots)||0)*.35+(Number(prev.corners)||0)*.45+(Number(prev.xg)||0)*5)/rw;accel=prevRate>0?(recentRate-prevRate)/prevRate:(recentRate>0?1:0);if(accel>.35)x+=2;else if(accel<-.4)x-=2}
    return {score:watchClamp(Math.round(x),0,15),mature:w3.window_min>=1.0,window_min:w3.window_min,delta:d,accel:Math.round(accel*100)/100};
  }
  function watchMarketScore(s){
    const m=s.market||{},mv=m.move||{};let x=0;if(m.has_over)x+=5;else if(m.valid_count)x+=2;if(m.valid_count>=2)x+=1;
    const bo=m.best_over;if(bo&&bo.odd>=1.45&&bo.odd<=2.35)x+=2;else if(bo&&bo.odd>=1.30&&bo.odd<=2.55)x+=1;
    if(Number(mv.line_delta)>0)x+=4;else if(Number(mv.over_price_delta)<=-.05)x+=4;else if(Number(mv.over_price_delta)<=-.02)x+=2;else if(m.history?.snapshot_count>=2)x+=1;
    return {score:watchClamp(Math.round(x),0,15),available:m.valid_count>0,over_available:m.has_over,best_over:bo,movement:mv};
  }
  function watchContextScore(s){
    const m=Number(s.minute||0),gap=Math.abs(Number(s.goals?.home||0)-Number(s.goals?.away||0));let x=0;x+=gap===1?4:gap===0?3:gap===2?1:0;x+=m>=55&&m<=80?3:m<=86?2:1;
    const h2=s.h2?.total||{},h1=s.h1?.total||{};if(Number(h2.sot||0)>=Number(h1.sot||0))x+=2;if(Number(h2.inbox||0)>=Number(h1.inbox||0))x+=1;return watchClamp(x,0,10);
  }
  function watchQualityScore(item,s){
    const dq=Number(item.initialDQ||s.dq||60),integ=Number(s.integrity??item.initialIntegrity??100);let x=watchClamp(Math.round(dq/25),0,4);if(integ>=85)x+=1;x=watchClamp(x,0,5);
    const p=s.stats_presence,age=(Date.now()-Number(s.fresh_at||Date.now()))/1000;if(p&&p.core===false)x=Math.min(x,p.pressure?2:1);else if(p&&p.coverage<3)x=Math.min(x,3);if(age>60)x=Math.min(x,1);return watchClamp(x,0,5)
  }
  function watchCore(e){
    const dims=[
      {name:'PRESS',value:e.pressure,strong:12,weak:6},
      {name:'CHANCE',value:e.chance,strong:12,weak:6},
      {name:'MOM',value:e.momentum,strong:9,weak:4}
    ],available=dims.filter(x=>x.value!=null);
    if(available.length<2)return {available:false,complete:false,availableCount:available.length,strongCount:available.length?0:null,weakCount:available.length?0:null,pass:false,partialPass:false};
    const strongCount=available.filter(x=>Number(x.value)>=x.strong).length,weakCount=available.filter(x=>Number(x.value)<x.weak).length,complete=available.length===3;
    return {available:true,complete,availableCount:available.length,strongCount,weakCount,pass:complete&&strongCount>=2&&weakCount===0,partialPass:!complete&&strongCount>=2&&weakCount===0};
  }


  // ===== V1.15 QUALIFIED SIGNAL BASELINE =====
  // Fixed research thresholds. These are signal-strength gates, NOT probabilities.
  // They stay fixed for the benchmark even if legacy READY/STRONG display thresholds later learn from old calibration.
  const QSIG_MAX=5000;
  const QSIG_KEYS={
    FT:'FE_QSIG_FT_V115',
    H1:'FE_QSIG_H1_V115',
    HC:'FE_QSIG_HC_V115'
  };
  const QSIG_THRESHOLDS={
    H1:{min:20,max:42,score:72,highScore:79,fresh:20,evidence:120,highEvidence:90},
    FT:{min:46,max:80,score:73,highScore:80,fresh:20,evidence:180,highEvidence:90},
    HC:{min:30,max:80,liveGap:22,highLiveGap:30,fresh:20,evidence:180,highEvidence:90}
  };
  // FE_EVIDENCE_SYNC_REPAIR_START
  const FE_QSIG_MEMORY=new Map(),FE_QSIG_DIRTY=new Set();let feQsigValidationTimer=null,feQsigStorageWarned=false;
  // Independent source capture only. No signal gate, score or outcome changes.
  const FE_EVIDENCE_ACK=new Map();let feEvidenceBusy=false,feEvidenceWarned=false,feEvidenceTarget='';
  async function feEvidenceRegisterPending(){
    if(feEvidenceBusy||!bgEnabled())return;
    feEvidenceBusy=true;
    try{
      if(feEvidenceTarget!==bgBase()){FE_EVIDENCE_ACK.clear();feEvidenceTarget=bgBase()}
      const now=Date.now();
      for(const [key,until] of FE_EVIDENCE_ACK)if(until<=now)FE_EVIDENCE_ACK.delete(key);
      const signals=['FT','H1','HC'].flatMap(engine=>qsigRead(engine).map(r=>({id:r.id,fixture_id:r.fixture_id,t0:r.t0,engine})))
        .filter(r=>Number(r.t0)<=now&&Number(r.t0)+10800000>now&&!FE_EVIDENCE_ACK.has(`${r.engine}:${r.id}`))
        .sort((a,b)=>Number(a.t0)-Number(b.t0)).slice(0,20);
      if(!signals.length)return;
      const result=await bgRequest('/api/watch/evidence-register',{method:'POST',body:{signals}});
      if(!result.ok||!Array.isArray(result.accepted))throw new Error(result.error||'Worker chưa hỗ trợ theo dõi QSIG độc lập');
      for(const key of result.accepted){const row=signals.find(r=>`${r.engine}:${r.id}`===key);if(row)FE_EVIDENCE_ACK.set(key,Number(row.t0)+10800000)}
      if(result.rejected?.length)throw new Error(`Chưa đăng ký được ${result.rejected.length} QSIG: ${result.rejected[0].reason}`);
      feEvidenceWarned=false;
    }catch(e){
      log('QSIG background evidence pending',e.message);
      if(!feEvidenceWarned){feEvidenceWarned=true;showToast('err','QSIG chưa được server xác nhận theo dõi',`${e.message}. App sẽ thử lại; chưa bảo đảm thu dữ liệu khi đóng app.`)}
    }finally{feEvidenceBusy=false}
  }
  setInterval(()=>{feEvidenceRegisterPending().catch(e=>log('QSIG evidence registration error',e.message))},60000);
  setTimeout(()=>{feEvidenceRegisterPending().catch(e=>log('QSIG evidence registration error',e.message))},5000);
  function feQsigPublish(engine,row){
    feDbQueueQsigResult(engine,row).catch(e=>log('QSIG D1 queue error',e.message));
    feEvidenceRegisterPending().catch(e=>log('QSIG evidence registration error',e.message));
    FE_QSIG_DIRTY.add(`QSIG-${engine}-${row.id}`);
    if(feQsigValidationTimer)return;
    feQsigValidationTimer=setTimeout(()=>{
      feQsigValidationTimer=null;const ids=new Set(FE_QSIG_DIRTY);FE_QSIG_DIRTY.clear();
      try{const rows=validationSyncSources();feDbQueueValidationBatch(rows.filter(r=>ids.has(r.id))).catch(e=>{for(const id of ids)FE_QSIG_DIRTY.add(id);log('QSIG validation queue error',e.message)})}
      catch(e){for(const id of ids)FE_QSIG_DIRTY.add(id);log('QSIG validation projection error',e.message)}
    },100);
  }
  // FE_EVIDENCE_SYNC_REPAIR_END
  function qsigRead(engine){
    if(FE_QSIG_MEMORY.has(engine))return JSON.parse(JSON.stringify(FE_QSIG_MEMORY.get(engine)));
    try{const x=JSON.parse(localStorage.getItem(QSIG_KEYS[engine])||'[]');return Array.isArray(x)?x.slice(-QSIG_MAX):[]}catch{return []}
  }
  function qsigWrite(engine,rows){
    const snapshot=JSON.parse(JSON.stringify((rows||[]).slice(-QSIG_MAX)));FE_QSIG_MEMORY.set(engine,snapshot);
    try{localStorage.setItem(QSIG_KEYS[engine],JSON.stringify(snapshot));return true}
    catch(e){log('QSIG local storage error',{engine,error:e.message});if(!feQsigStorageWarned){feQsigStorageWarned=true;showToast('err','QSIG chưa lưu được trên máy','Dữ liệu đang giữ trong phiên này; kiểm tra đồng bộ D1 trước khi đóng app.')}return false}
  }
  function qsigUpdateRow(engine,id,fn){const rows=qsigRead(engine),i=rows.findIndex(x=>x.id===id);if(i<0)return null;fn(rows[i]);qsigWrite(engine,rows);feQsigPublish(engine,rows[i]);return rows[i]}
  function qsigOpen(engine,fixtureId){const rows=qsigRead(engine);return [...rows].reverse().find(x=>Number(x.fixture_id)===Number(fixtureId)&&x.wave_open===true)||null}
  function qsigFreshAge(s){return Math.max(0,(Date.now()-Number(s?.fresh_at||s?.captured_at||Date.now()))/1000)}
  function qsigEvidenceAge(item,s){
    const rows=(item.history||[]).filter(x=>Number(x.captured_at||x.fresh_at||0)<=Number(s.captured_at||s.fresh_at||Date.now())).slice(-90);
    if(rows.length<2)return null;
    for(let i=rows.length-1;i>0;i--){
      const a=rows[i-1]?.metrics?.total||{},b=rows[i]?.metrics?.total||{};
      let changed=false;
      for(const k of ['shots','sot','inbox','xg']){
        const av=Number(a[k]),bv=Number(b[k]);
        if(Number.isFinite(av)&&Number.isFinite(bv)&&bv>av+.0001){changed=true;break}
      }
      if(changed){
        const ts=Number(rows[i].captured_at||rows[i].fresh_at||Date.now());
        return Math.max(0,Math.round((Number(s.captured_at||s.fresh_at||Date.now())-ts)/1000));
      }
    }
    return null
  }
  function qsigGoalTimes(events){return (events||[]).filter(e=>/goal/i.test(String(e.type||''))&&!/missed|disallow/i.test(String(e.detail||''))).map(e=>Number(e.time)+(Number(e.extra)||0)/60).filter(Number.isFinite).sort((a,b)=>a-b)}
  function qsigRecentChance(e){
    const d=e?.recent5?.delta||e?.pressure5?.delta||e?.delta||{};
    return Number(d.sot||0)>=1||Number(d.inbox||0)>=2||Number(d.xg||0)>=.12;
  }
  function qsigTrend(e){
    const d5=e?.recent5?.delta||e?.pressure5?.delta||{},d10=e?.recent10?.delta||e?.pressure10?.delta||{};
    const active5=Number(d5.sot||0)>=1||Number(d5.inbox||0)>=2||Number(d5.xg||0)>=.12||Number(d5.shots||0)>=3;
    const active10=Number(d10.sot||0)>=1||Number(d10.inbox||0)>=2||Number(d10.xg||0)>=.15||Number(d10.shots||0)>=4;
    if(Number(e?.accel||0)>=.35&&active5)return 'ACCELERATING';
    if(active5&&active10)return 'SUSTAINED';
    return active5?'ACTIVE':'QUIET';
  }
  function qsigAssessFT(item,s){
    const e=item.eval||{},th=QSIG_THRESHOLDS.FT,m=Number(s?.minute||0),fresh=qsigFreshAge(s),evAge=qsigEvidenceAge(item,s),trend=qsigTrend(e),chance=qsigRecentChance(e);
    const resetAge=item.resetAt?Math.max(0,(Date.now()-Number(item.resetAt))/1000):9999;
    const base=e.scoreMode==='FULL'&&m>=th.min&&m<=th.max&&Number(e.score)>=th.score&&Number(e.quality)>=4&&fresh<=th.fresh&&evAge!=null&&evAge<=th.evidence&&e.core?.strongCount>=2&&chance&&['SUSTAINED','ACCELERATING'].includes(trend)&&resetAge>=180&&!e.hardVeto&&!['COOLDOWN','STALE','ENDED','CANCELLED','BASELINE'].includes(item.state);
    const high=base&&Number(e.score)>=th.highScore&&e.core?.strongCount>=3&&evAge<=th.highEvidence&&!!e.market_available;
    return {qualified:base,high,label:high?'HIGH CONFIRMATION':base?'QUALIFIED':'—',fresh,evidenceAge:evAge,trend,chance};
  }
  function qsigAssessH1(item,s){
    const e=item.eval||{},th=QSIG_THRESHOLDS.H1,m=Number(s?.minute||0),fresh=qsigFreshAge(s),evAge=qsigEvidenceAge(item,s),trend=qsigTrend(e),chance=qsigRecentChance(e);
    const resetAge=item.resetAt?Math.max(0,(Date.now()-Number(item.resetAt))/1000):9999;
    const base=e.scoreMode==='FULL'&&m>=th.min&&m<=th.max&&Number(e.score)>=th.score&&Number(e.quality)>=4&&fresh<=th.fresh&&evAge!=null&&evAge<=th.evidence&&e.core?.strongCount>=2&&chance&&['SUSTAINED','ACCELERATING'].includes(trend)&&resetAge>=180&&!e.hardVeto&&!['COOLDOWN','STALE','ENDED','CANCELLED','BASELINE'].includes(item.state);
    const high=base&&Number(e.score)>=th.highScore&&e.core?.strongCount>=3&&evAge<=th.highEvidence&&!!e.market_available;
    return {qualified:base,high,label:high?'HIGH CONFIRMATION':base?'QUALIFIED':'—',fresh,evidenceAge:evAge,trend,chance};
  }
  function qsigAssessHC(item,s){
    const e=item.eval||{},th=QSIG_THRESHOLDS.HC,m=Number(s?.minute||0),fresh=qsigFreshAge(s),dir=e.states?.direction,
          trend=dir==='HOME'?e.homeTrend?.trend:dir==='AWAY'?e.awayTrend?.trend:'QUIET',evAge=e.evidenceAge?.direction,
          marketOk=['SOFT_AGREEMENT','HARD_AGREEMENT'].includes(e.marketFit?.level),liveGap=Math.abs(Number(e.states?.liveGap||0));
    const base=e.dataTier==='FULL'&&m>=th.min&&m<=th.max&&liveGap>=th.liveGap&&Number(e.dq)>=4&&fresh<=th.fresh&&
          evAge!=null&&evAge<=th.evidence&&Number(e.core?.count||0)>=3&&Number(e.core?.footballCount||0)>=2&&
          !!e.core?.tests?.superiority&&marketOk&&trend!=='ISOLATED'&&
          !['COOLDOWN','STALE','ENDED','DATA_INCOMPLETE','MARKET_WATCH'].includes(e.state);
    const high=base&&liveGap>=th.highLiveGap&&Number(e.core?.count||0)>=4&&Number(e.core?.footballCount||0)>=3&&
          !!e.core?.tests?.chance&&!!e.core?.tests?.momentum&&evAge<=th.highEvidence&&e.marketFit?.level==='HARD_AGREEMENT';
    return {qualified:base,high,label:high?'HIGH CONFIRMATION':base?'QUALIFIED':'—',fresh,evidenceAge:evAge,trend,
            chance:!!e.core?.tests?.chance,momentum:!!e.core?.tests?.momentum,liveGap}
  }
  function qsigBadgeHTML(a){
    if(!a?.qualified)return '';
    return `<div class="qsig-band ${a.high?'high':'qualified'}"><b>${a.high?'◆ HIGH CONFIRMATION':'● QUALIFIED SIGNAL'}</b><span>T0 benchmark V1.16.2 • ngưỡng cố định • không phải xác suất</span></div>`;
  }
  function qsigStart(engine,item,s,a,extra={}){
    if(!a?.qualified)return null;
    const existing=qsigOpen(engine,item.id);
    if(existing){item.qualifiedWave=existing;return existing}
    const e=item.eval||{},num=v=>{const n=Number(v);return Number.isFinite(n)?n:null},appDQ=num(item.initialDQ??s?.dq),
          liveQ=num(engine==='HC'?e.dq:e.quality),coverage=num(item.apiCoverage?.coverage_score??item.apiCoverage?.coverage),
          integrity=num(s?.integrity??item.initialIntegrity),cacheSource=s?.cache_status||s?.source||null;
    const t0Snapshot=engine==='HC'?{
      current_state:e.states?.direction??null,pre_adv:e.states?.preAdv??null,live_adv:e.states?.liveAdv??null,
      live_gap:e.states?.liveGap??null,total_gap:e.states?.gap??null,regime:e.regime??null,evidence_age:e.evidenceAge?.direction??null,
      core:e.core?.count??null,football_core:e.core?.footballCount??null,core_tests:e.core?.tests??null,
      momentum_trend:a.trend??null,market_level:e.marketFit?.level??null,line_move:e.marketFit?.lineMove??null,
      price_move:e.marketFit?.priceMove??null,velocity:e.marketFit?.velocity??null,line:s?.market?.line??null,
      home_odd:s?.market?.homeOdd??null,away_odd:s?.market?.awayOdd??null
    }:{
      score:e.score??null,pressure:e.pressure??null,chance:e.chance??null,momentum:e.momentum??null,
      core:e.core?.strongCount??null,core_complete:e.core?.complete??null,evidence_age:a.evidenceAge??null,
      momentum_trend:a.trend??null,recent3:e.recent3?.delta??null,recent5:e.recent5?.delta??null,recent10:e.recent10?.delta??null,
      market_available:!!e.market_available,market_movement:e.market_movement??null,best_over:e.best_over??null
    };
    const row={
      id:`${engine}-${item.id}-${Number(s.captured_at||s.fresh_at||Date.now())}`,
      schema:'FOOTBALL_EDGE_QSIG_V1.16.2',benchmark_version:'V1.16.2_FIXED',app_version:APP_VERSION,
      engine,fixture_id:item.id,league:item.league,home:item.home,away:item.away,
      t0:Number(s.captured_at||s.fresh_at||Date.now()),minute:Number(s.minute||0),
      start_home:Number(s.goals?.home||0),start_away:Number(s.goals?.away||0),
      score:Number(item.eval?.score??0),level:a.high?'HIGH_CONFIRMATION':'QUALIFIED',
      evidence_age:a.evidenceAge,trend:a.trend,fresh:a.fresh,wave_open:true,
      peak_level:a.high?'HIGH_CONFIRMATION':'QUALIFIED',resolved:false,release_reason:null,
      app_dq_100:appDQ!=null&&appDQ>5?appDQ:null,live_quality_5:liveQ,coverage,integrity,
      freshness_age_sec:a.fresh,data_tier:engine==='HC'?e.dataTier:e.scoreMode,cache_source:cacheSource,
      t0_snapshot:t0Snapshot,...extra
    };
    const rows=qsigRead(engine);rows.push(row);qsigWrite(engine,rows);feQsigPublish(engine,row);item.qualifiedWave=row;item.qsigBelowSince=null;return row
  }
  function qsigClose(engine,item,reason,s){
    const a=item.qualifiedWave||qsigOpen(engine,item.id);if(!a)return;
    qsigUpdateRow(engine,a.id,r=>{r.wave_open=false;r.release_reason=reason;r.closed_at=Number(s?.captured_at||s?.fresh_at||Date.now());});
    item.qualifiedWave=null;item.qsigBelowSince=null
  }
  function qsigSetGoalOutcomes(engine,item,s,windows){
    const a=item.qualifiedWave||qsigOpen(engine,item.id);if(!a)return;
    const nowMin=Number(s?.minute||a.minute),gNow=Number(s?.goals?.home||0)+Number(s?.goals?.away||0),g0=Number(a.start_home||0)+Number(a.start_away||0),goalTimes=qsigGoalTimes(s?.events||[]);
    let first=goalTimes.find(x=>x>Number(a.minute));
    if(first==null&&gNow>g0)first=nowMin+.01;
    qsigUpdateRow(engine,a.id,r=>{
      if(first!=null)r.first_goal_min=r.first_goal_min??first;
      for(const w of windows){
        const k=`goal_${w}m`;
        if(r[k]===undefined)r[k]=null;
        if(first!=null&&r[k]==null)r[k]=(first-Number(r.minute))<=w;
        else if(r[k]==null&&nowMin>=Number(r.minute)+w)r[k]=false;
      }
    })
  }
  function qsigUpdateFT(item,s,ev=null,ended=false){
    const assess=qsigAssessFT(item,s);item.qsig=assess;
    const open=item.qualifiedWave||qsigOpen('FT',item.id);if(open)item.qualifiedWave=open;
    if(open)qsigSetGoalOutcomes('FT',item,s,[5,10,15]);
    if(ev==='RED_CARD'){qsigClose('FT',item,'RED_CARD',s);return}
    if(ev==='GOAL'){if(open)qsigUpdateRow('FT',open.id,r=>{r.goal_ft=true;r.resolved=true;r.resolved_at=Number(s.captured_at||s.fresh_at||Date.now())});qsigClose('FT',item,'GOAL',s);return}
    if(ended){qsigUpdateRow('FT',open?.id||'',r=>{r.goal_ft=(Number(s.goals?.home||0)+Number(s.goals?.away||0))>(Number(r.start_home||0)+Number(r.start_away||0));r.resolved=true});qsigClose('FT',item,'FT',s);return}
    if(!open&&assess.qualified){qsigStart('FT',item,s,assess,{core:item.eval?.core?.strongCount??0,dq:item.eval?.quality??null,market_available:!!item.eval?.market_available,over_line:s.market?.best_over?.line??null,over_odd:s.market?.best_over?.odd??null});return}
    if(open){
      if(assess.high)qsigUpdateRow('FT',open.id,r=>r.peak_level='HIGH_CONFIRMATION');
      if(!assess.qualified){
        item.qsigBelowSince=item.qsigBelowSince||Date.now();
        if(Date.now()-item.qsigBelowSince>=120000)qsigClose('FT',item,'PRESSURE_DECAY_120S',s)
      }else item.qsigBelowSince=null
    }
  }
  function qsigUpdateH1(item,s,ev=null,ended=false){
    const assess=qsigAssessH1(item,s);item.qsig=assess;
    const open=item.qualifiedWave||qsigOpen('H1',item.id);if(open)item.qualifiedWave=open;
    if(open)qsigSetGoalOutcomes('H1',item,s,[3,5,10]);
    if(ev==='RED_CARD'){qsigClose('H1',item,'RED_CARD',s);return}
    if(ev==='GOAL'){if(open)qsigUpdateRow('H1',open.id,r=>{r.goal_before_ht=true;r.resolved=true;r.resolved_at=Number(s.captured_at||s.fresh_at||Date.now())});qsigClose('H1',item,'GOAL',s);return}
    if(ended){if(open)qsigUpdateRow('H1',open.id,r=>{if(r.goal_before_ht==null)r.goal_before_ht=(Number(s.goals?.home||0)+Number(s.goals?.away||0))>(Number(r.start_home||0)+Number(r.start_away||0));r.resolved=true});qsigClose('H1',item,'HT',s);return}
    if(!open&&assess.qualified){qsigStart('H1',item,s,assess,{core:item.eval?.core?.strongCount??0,dq:item.eval?.quality??null,market_available:!!item.eval?.market_available,h1_over_line:s.market?.best_over?.line??null,h1_over_odd:s.market?.best_over?.odd??null});return}
    if(open){
      if(assess.high)qsigUpdateRow('H1',open.id,r=>r.peak_level='HIGH_CONFIRMATION');
      if(!assess.qualified){
        item.qsigBelowSince=item.qsigBelowSince||Date.now();
        if(Date.now()-item.qsigBelowSince>=120000)qsigClose('H1',item,'PRESSURE_DECAY_120S',s)
      }else item.qsigBelowSince=null
    }
  }
  function qsigUpdateHC(item,s,ev=null,ended=false){
    const assess=qsigAssessHC(item,s);item.qsig=assess;
    const e=item.eval||{},open=item.qualifiedWave||qsigOpen('HC',item.id);if(open)item.qualifiedWave=open;
    if(open){
      const elapsed=(Number(s.captured_at||Date.now())-Number(open.t0))/60000,liveGap=Number(e.states?.liveGap||0),
            liveDir=Math.abs(liveGap)<10?'BALANCED':liveGap>0?'HOME':'AWAY',signalDir=open.direction;
      qsigUpdateRow('HC',open.id,r=>{
        for(const w of [5,10,15]){
          const k=`state_${w}m`;
          if(r[k]===undefined)r[k]=null;
          if(r[k]==null&&elapsed>=w){
            r[k]=liveDir===signalDir&&Math.abs(liveGap)>=10?'MAINTAINED':
                 (liveDir==='BALANCED'||liveDir===signalDir)?'DECAYED':'REVERSED';
            r[`live_gap_${w}m`]=liveGap;
          }
        }
        r.last_direction=liveDir;r.last_live_gap=liveGap;r.last_market_level=e.marketFit?.level;
        if(r.state_15m!=null){r.resolved=true;r.resolved_at=Number(s.captured_at||Date.now())}
      });
    }
    if(ev==='RED_CARD'){
      if(open)qsigUpdateRow('HC',open.id,r=>{r.void_reason='RED_CARD';r.resolved=true;r.resolved_at=Number(s.captured_at||Date.now())});
      qsigClose('HC',item,'RED_CARD',s);return
    }
    if(ev==='GOAL'){
      if(open){
        const dh=Number(s.goals?.home||0)-Number(open.start_home||0),da=Number(s.goals?.away||0)-Number(open.start_away||0),
              forDir=open.direction==='HOME'?dh>da:open.direction==='AWAY'?da>dh:null;
        qsigUpdateRow('HC',open.id,r=>{r.goal_event=true;r.goal_for_direction=forDir;r.goal_delta={home:dh,away:da};
          if(r.state_15m==null)r.void_reason='GOAL_REBASELINE';r.resolved=true;r.resolved_at=Number(s.captured_at||Date.now())})
      }
      qsigClose('HC',item,'GOAL_REBASELINE',s);return
    }
    if(ended){
      if(open)qsigUpdateRow('HC',open.id,r=>{if(r.state_15m==null)r.void_reason='ENDED_BEFORE_15M';r.resolved=true;r.resolved_at=Number(s.captured_at||Date.now())});
      qsigClose('HC',item,'ENDED',s);return
    }
    if(!open&&assess.qualified){
      qsigStart('HC',item,s,assess,{
        direction:e.states?.direction,live_gap:e.states?.liveGap,total_gap:e.states?.gap,
        core:e.core?.count??0,football_core:e.core?.footballCount??0,
        market_level:e.marketFit?.level,line_move:e.marketFit?.lineMove,price_move:e.marketFit?.priceMove,
        velocity:e.marketFit?.velocity,line:s.market?.line??null,home_odd:s.market?.homeOdd??null,away_odd:s.market?.awayOdd??null
      });return
    }
    if(open){
      if(assess.high)qsigUpdateRow('HC',open.id,r=>r.peak_level='HIGH_CONFIRMATION');
      if(!assess.qualified){
        item.qsigBelowSince=item.qsigBelowSince||Date.now();
        if(Date.now()-item.qsigBelowSince>=120000)qsigClose('HC',item,'SIGNAL_DECAY_120S',s)
      }else item.qsigBelowSince=null
    }
  }
  function qsigStats(engine){
    const rows=qsigRead(engine),q=rows.filter(x=>x.level==='QUALIFIED').length,h=rows.filter(x=>x.level==='HIGH_CONFIRMATION'||x.peak_level==='HIGH_CONFIRMATION').length;
    return {n:rows.length,qualified:q,high:h,open:rows.filter(x=>x.wave_open).length}
  }

  /* ===== V1.18.9 GOAL RADAR OVERLAY =====
     Presentation/calibration layer only. Stable H1/FT scoring is untouched.
     Probability is NOT the engine score. It is a smoothed empirical estimate
     when resolved calibration exists, otherwise a clearly labelled model estimate. */
  function grClamp(v,a=0,b=100){return Math.max(a,Math.min(b,Number(v)||0))}
  function grFallback(score,engine){
    const x=Number(score||0),pivot=engine==='H1'?64:65,scale=11.5;
    const p=100/(1+Math.exp(-(x-pivot)/scale));
    return grClamp(Math.round(18+p*.72),18,91);
  }
  /* ===== V1.19.5 GOAL RADAR CALIBRATION V2 — QSIG FIRST =====
     Uses official QSIG T0 resolved waves first. Legacy watch calibration is a
     fallback only while official samples are still sparse. This layer never
     changes H1/FT score, state, thresholds or QSIG qualification. */
  function grResolved(engine){
    const key=engine==='H1'?'goal_before_ht':'goal_ft';
    let official=[];
    try{official=(qsigRead(engine)||[]).filter(r=>typeof r?.[key]==='boolean').map(r=>({...r,__hit:!!r[key],__basis:'QSIG',tier:r.level==='HIGH_CONFIRMATION'?'STRONG':'READY'}))}catch(_){official=[]}
    if(official.length>=8)return official;
    const legacyRows=engine==='H1'?(h1WatchState.calibration||[]):(watchState.calibration||[]);
    const legacy=legacyRows.filter(r=>typeof r?.[key]==='boolean').map(r=>({...r,__hit:!!r[key],__basis:'LEGACY'}));
    return official.length?[...official,...legacy]:legacy;
  }
  function grReliability(n,basis='MODEL'){
    n=Number(n||0);
    if(!n)return {level:'MODEL',label:'ƯỚC TÍNH',rank:0};
    let rank=n>=80?4:n>=40?3:n>=20?2:1;
    if(basis!=='QSIG')rank=Math.max(1,rank-1);
    return rank>=4?{level:'VERY_GOOD',label:'RẤT TỐT',rank}:rank===3?{level:'GOOD',label:'TỐT',rank}:rank===2?{level:'MEDIUM',label:'TRUNG BÌNH',rank}:{level:'LOW',label:'MẪU THẤP',rank};
  }
  function grEstimate(item,engine){
    const e=item?.eval||{},s=item?.latest||{},score=Number(e.score||0),minute=Number(s.minute||0),fallback=grFallback(score,engine);
    if(e.scoreMode!=='FULL'||e.hardVeto||!Number.isFinite(score))return {prob:null,n:0,source:e.scoreMode==='BASELINE'?'BASELINE':'DATA_WAIT',raw:null,basis:'NONE',reliability:grReliability(0)};
    const all=grResolved(engine),minuteWin=engine==='H1'?4:7;
    let near=all.filter(r=>Math.abs(Number(r.score||0)-score)<=5&&Math.abs(Number(r.minute||0)-minute)<=minuteWin);
    if(near.length<12)near=all.filter(r=>Math.abs(Number(r.score||0)-score)<=8&&Math.abs(Number(r.minute||0)-minute)<=minuteWin*1.75);
    if(near.length<8){const tier=engine==='H1'?h1WatchTier(score):watchTierForScore(score);near=all.filter(r=>String(r.tier||'')===String(tier)&&Math.abs(Number(r.minute||0)-minute)<=minuteWin*2.4)}
    if(!near.length)return {prob:fallback,n:0,source:'MODEL',raw:null,basis:'MODEL',reliability:grReliability(0)};
    const qsigN=near.filter(r=>r.__basis==='QSIG').length,basis=qsigN>=Math.ceil(near.length*.5)?'QSIG':'LEGACY';
    const basePool=all.filter(r=>Math.abs(Number(r.minute||0)-minute)<=minuteWin*2.5),baseHits=basePool.filter(r=>r.__hit).length;
    const empiricalPrior=basePool.length>=20?baseHits/basePool.length:fallback/100;
    const hits=near.filter(r=>r.__hit).length,n=near.length,priorWeight=basis==='QSIG'?14:20;
    const post=(hits+priorWeight*empiricalPrior)/(n+priorWeight),prob=Math.round(grClamp(post*100,8,94)),rel=grReliability(n,basis);
    return {prob,n,source:n>=40?'CAL_STRONG':n>=20?'CAL':n>=8?'CAL_EARLY':'MODEL',raw:hits/n,basis,reliability:rel,qsig_n:qsigN,prior:empiricalPrior};
  }
  function grTrack(item,engine){
    if(!item)return null;
    const s=item.latest||{},goals=Number(s.goals?.home||0)+Number(s.goals?.away||0),reds=Number(s.metrics?.total?.red||0),sig=`${goals}|${reds}`;
    if(item._grResetSig!=null&&item._grResetSig!==sig)item.goalRadar=[];
    item._grResetSig=sig;
    const est=grEstimate(item,engine),now=Number(s.captured_at||Date.now()),minute=Number(s.minute||0);
    if(est.prob==null)return est;
    item.goalRadar=Array.isArray(item.goalRadar)?item.goalRadar:[];
    const last=item.goalRadar[item.goalRadar.length-1];
    if(!last||now-Number(last.ts||0)>=8000||Number(last.prob)!==Number(est.prob))item.goalRadar.push({ts:now,minute,prob:est.prob});
    item.goalRadar=item.goalRadar.filter(x=>now-Number(x.ts||0)<=20*60000).slice(-24);
    return est;
  }
  function grTrend(item){
    const pts=Array.isArray(item?.goalRadar)?item.goalRadar:[];if(pts.length<2)return {delta:0,dir:'flat',label:'ỔN ĐỊNH'};
    const last=pts[pts.length-1],cut=Number(last.ts)-5*60000,base=[...pts].reverse().find(x=>Number(x.ts)<=cut)||pts[0],delta=Math.round(Number(last.prob)-Number(base.prob));
    return {delta,dir:delta>=4?'up':delta<=-4?'down':'flat',label:delta>=4?'TĂNG':delta<=-4?'GIẢM':'ỔN ĐỊNH'};
  }
  function grSpark(item,engine){
    const pts=(Array.isArray(item?.goalRadar)?item.goalRadar:[]).slice(-12),stroke=engine==='H1'?'#6558df':'#ef4e70',fill=engine==='H1'?'rgba(101,88,223,.10)':'rgba(239,78,112,.10)';
    if(!pts.length)return `<div class="goal-radar-chart"><div style="height:78px;display:grid;place-items:center;font-size:7px;color:var(--muted)">Đang tạo đường xu hướng...</div></div>`;
    const w=320,h=82,pad=8,usableW=w-pad*2,usableH=h-pad*2,coords=pts.map((p,i)=>{const x=pad+(pts.length===1?usableW/2:i*usableW/(pts.length-1)),y=pad+(100-grClamp(p.prob))*usableH/100;return {x,y,p}}),line=coords.map((c,i)=>`${i?'L':'M'} ${c.x.toFixed(1)} ${c.y.toFixed(1)}`).join(' '),area=`M ${coords[0].x.toFixed(1)} ${(h-pad).toFixed(1)} ${line.replace(/^M /,'L ')} L ${coords[coords.length-1].x.toFixed(1)} ${(h-pad).toFixed(1)} Z`,dots=coords.map((c,i)=>`<circle cx="${c.x.toFixed(1)}" cy="${c.y.toFixed(1)}" r="${i===coords.length-1?3.6:2.1}" fill="${stroke}"/>`).join(''),first=pts[0],last=pts[pts.length-1];
    return `<div class="goal-radar-chart"><svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-label="Goal probability trend"><line x1="${pad}" y1="${pad+usableH*.25}" x2="${w-pad}" y2="${pad+usableH*.25}" stroke="rgba(126,155,173,.15)"/><line x1="${pad}" y1="${pad+usableH*.5}" x2="${w-pad}" y2="${pad+usableH*.5}" stroke="rgba(126,155,173,.15)"/><line x1="${pad}" y1="${pad+usableH*.75}" x2="${w-pad}" y2="${pad+usableH*.75}" stroke="rgba(126,155,173,.15)"/><path d="${area}" fill="${fill}"/><path d="${line}" fill="none" stroke="${stroke}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>${dots}</svg><div class="goal-radar-axis"><span>${esc(first.minute)}'</span><span>${pts.length>2?esc(pts[Math.floor((pts.length-1)/2)].minute)+"'":''}</span><span>${esc(last.minute)}'</span></div></div>`;
  }
  function feGoalProbVisual(prob){
    const p=Number(prob);
    if(!Number.isFinite(p))return {cls:'gp-low',label:'CHỜ DỮ LIỆU'};
    if(p<50)return {cls:'gp-low',label:'<50% • THẤP'};
    if(p<60)return {cls:'gp-watch',label:'50–59% • WATCH'};
    if(p<70)return {cls:'gp-candidate',label:'60–69% • CANDIDATE'};
    if(p<80)return {cls:'gp-ready',label:'70–79% • READY ZONE'};
    return {cls:'gp-strong',label:'80%+ • STRONG ZONE'};
  }
  function feScoreVisual(engine,score,state){
    const x=Number(score),t=engine==='H1'?{watch:54,candidate:64,ready:72,strong:79}:{watch:55,candidate:65,ready:73,strong:80};
    let cls='zone-low',label='THẤP';
    if(Number.isFinite(x)&&x>=t.strong){cls='zone-strong';label='STRONG SCORE ZONE'}
    else if(Number.isFinite(x)&&x>=t.ready){cls='zone-ready';label='READY SCORE ZONE'}
    else if(Number.isFinite(x)&&x>=t.candidate){cls='zone-candidate';label='CANDIDATE ZONE'}
    else if(Number.isFinite(x)&&x>=t.watch){cls='zone-watch';label='WATCH ZONE'}
    const actual=String(state||''),qualified=cls==='zone-strong'?actual==='STRONG':cls==='zone-ready'?['READY','STRONG'].includes(actual):true;
    return {cls,label,qualified,display:qualified?label:`${label} • CHƯA QUALIFIED`};
  }
  function feGapVisual(gap,state){
    const x=Math.abs(Number(gap)||0),actual=String(state||''),strongActual=['HOME_STRONG','AWAY_STRONG'].includes(actual);
    if(x<10)return {cls:'gap-balanced',label:'0–9 • BALANCED',strongActual:false};
    if(x<18)return {cls:'gap-slight',label:'10–17 • SLIGHT',strongActual:false};
    if(x<22)return {cls:'gap-advantage',label:'18–21 • ADVANTAGE',strongActual:false};
    if(x<30)return {cls:'gap-qualified',label:'22–29 • QUALIFIED ZONE',strongActual:false};
    return {cls:'gap-strong',label:`30+ • STRONG GAP ZONE${strongActual?'':' • CHƯA STRONG'}`,strongActual};
  }
  function grHTML(item,engine){
    const est=grTrack(item,engine),tr=grTrend(item),h1=engine==='H1',prob=est?.prob==null?'—':`${est.prob}%`,basis=est?.basis==='QSIG'?'QSIG T0':est?.basis==='LEGACY'?'LEGACY CAL':'MODEL',rel=est?.reliability?.label||'ƯỚC TÍNH',source=est?.source==='MODEL'?`ƯỚC TÍNH • chưa đủ QSIG`:est?.source==='CAL_EARLY'?`${basis} • ${rel} • n=${est.n}`:est?.source==='CAL'?`${basis} • ${rel} • n=${est.n}`:est?.source==='CAL_STRONG'?`${basis} • ${rel} • n=${est.n}`:est?.source==='BASELINE'?'ĐANG TẠO BASELINE':'CHỜ DỮ LIỆU',delta=tr.delta===0?'±0%':`${tr.delta>0?'+':''}${tr.delta}%`,trendIcon=tr.dir==='up'?'↑':tr.dir==='down'?'↓':'→',pv=feGoalProbVisual(est?.prob);
    return `<div class="goal-radar ${h1?'h1':'ft'}"><div class="goal-radar-head"><div><div class="goal-radar-label">🔥 GOAL RADAR • ${h1?'H1':'FT'}</div><div class="goal-radar-prob ${pv.cls}"><strong>${prob}</strong><span class="${tr.dir}">${trendIcon} ${esc(tr.label)}</span></div><span class="goal-radar-zone ${pv.cls}">${esc(pv.label)}</span></div><div class="goal-radar-meta"><b>${esc(source)}</b><small>${h1?'đến hết H1':'đến hết trận'}</small></div></div>${grSpark(item,engine)}<div class="goal-radar-foot"><b>${esc(delta)} trong ~5 phút gần nhất</b><span>Engine score vẫn giữ riêng: ${esc(item?.eval?.score??'-')}/100</span></div><div class="goal-radar-note">Calibration V2 ưu tiên QSIG T0 đã resolve, ghép theo phút + score và shrink khi mẫu nhỏ. Màu % chỉ là probability zone; READY/STRONG thật vẫn do engine xác nhận.</div></div>`;
  }

  function grHCBadges(fixtureId){
    const id=Number(fixtureId),parts=[];
    for(const [engine,state,label] of [['H1',h1WatchState,'H1'],['FT',watchState,'FT']]){
      const it=(state?.items||[]).find(x=>Number(x.id)===id&&x.state!=='ENDED');if(!it)continue;
      const est=grEstimate(it,engine);if(est?.prob==null)continue;const tr=grTrend(it),icon=tr.dir==='up'?'↑':tr.dir==='down'?'↓':'→';
      parts.push(`<span class="hc-goal-radar-badge ${engine==='H1'?'h1':'ft'}">🔥 ${label} GOAL ${esc(est.prob)}% <i class="${tr.dir}">${icon}</i></span>`);
    }
    return parts.length?`<div class="hc-goal-radar-badges">${parts.join('')}</div>`:'';
  }

  function watchCalRead(){try{const x=JSON.parse(localStorage.getItem(WATCH_CAL_KEY)||'[]');return Array.isArray(x)?x.slice(-WATCH_CAL_MAX):[]}catch{return []}}
  function watchCalWrite(){try{localStorage.setItem(WATCH_CAL_KEY,JSON.stringify((watchState.calibration||[]).slice(-WATCH_CAL_MAX)))}catch{}}
  function watchCalibrationStats(){
    const rows=watchState.calibration||[],r10=rows.filter(r=>typeof r.goal_10m==='boolean'),hits=r10.filter(r=>r.goal_10m).length,rate=r10.length?hits/r10.length:0;
    const byTier={};for(const tier of ['WATCH','CANDIDATE','READY','STRONG']){const rr=r10.filter(r=>r.tier===tier);byTier[tier]={n:rr.length,rate:rr.length?rr.filter(x=>x.goal_10m).length/rr.length:null}}
    return {n:rows.length,resolved10:r10.length,hits10:hits,rate10:rate,byTier};
  }
  function watchLearnedStrong(){
    const rows=(watchState.calibration||[]).filter(r=>typeof r.goal_10m==='boolean');if(rows.length<500)return {threshold:80,learned:false,n:rows.length};const base=rows.filter(r=>r.score>=55),baseRate=base.length?base.filter(r=>r.goal_10m).length/base.length:0;
    const candidates=[];for(let t=76;t<=84;t++){const rr=rows.filter(r=>r.score>=t);if(rr.length<80)continue;const rate=rr.filter(r=>r.goal_10m).length/rr.length;if(rate>=baseRate*1.15)candidates.push({t,n:rr.length,rate})}
    if(!candidates.length)return {threshold:80,learned:false,n:rows.length,baseRate};const best=Math.max(...candidates.map(x=>x.rate)),near=candidates.filter(x=>x.rate>=best-.02).sort((a,b)=>a.t-b.t)[0];return {threshold:near.t,learned:true,n:rows.length,rate:near.rate,baseRate};
  }
  function watchThresholds(){
    const shadow=watchLearnedStrong();
    return {watch:55,candidate:65,ready:73,strong:80,learned:{...shadow,shadow_only:true,active_threshold:80}}
  }
  function watchTierForScore(score){const t=watchThresholds();return score>=t.strong?'STRONG':score>=t.ready?'READY':score>=t.candidate?'CANDIDATE':score>=t.watch?'WATCH':'LOW'}
  function watchGoalTimes(events){return (events||[]).filter(e=>/goal/i.test(String(e.type||''))&&!/missed|disallow/i.test(String(e.detail||''))).map(e=>Number(e.time)).filter(Number.isFinite).sort((a,b)=>a-b)}
  function watchCalSettle(item,s,ended=false){
    const rows=watchState.calibration||[],gNow=Number(s?.goals?.home||0)+Number(s?.goals?.away||0),goalTimes=watchGoalTimes(s?.events||[]);let changed=false;
    for(const r of rows){if(Number(r.fixture_id)!==Number(item.id))continue;if(r.goal_ft===true&&r.goal_5m!==null&&r.goal_10m!==null&&r.goal_15m!==null)continue;let first=goalTimes.find(m=>m>Number(r.minute));if(first==null&&gNow>Number(r.goals_total||0))first=Number(s.minute||r.minute);
      if(first!=null){r.first_goal_min=r.first_goal_min??first;for(const h of [5,10,15])if(r[`goal_${h}m`]===null||r[`goal_${h}m`]===undefined)r[`goal_${h}m`]=first-Number(r.minute)<=h;r.goal_ft=true;changed=true}
      for(const h of [5,10,15])if((r[`goal_${h}m`]===null||r[`goal_${h}m`]===undefined)&&Number(s.minute)>=Number(r.minute)+h){r[`goal_${h}m`]=false;changed=true}
      if(ended&&(r.goal_ft===null||r.goal_ft===undefined)){r.goal_ft=gNow>Number(r.goals_total||0);changed=true}
    }
    if(changed)watchCalWrite();
  }
  function watchCalRecord(item,s){
    const e=item.eval||{};if(e.scoreMode!=='FULL'||e.score<55||e.hardVeto||['COOLDOWN','ENDED','STALE'].includes(item.state))return;const rows=watchState.calibration||[],last=[...rows].reverse().find(r=>Number(r.fixture_id)===Number(item.id));if(last&&Date.now()-Number(last.captured_at)<60000&&last.tier===watchTierForScore(e.score))return;
    const bo=s.market?.best_over||null;rows.push({id:`${item.id}-${s.captured_at}`,fixture_id:item.id,league:item.league,home:item.home,away:item.away,captured_at:s.captured_at,minute:Number(s.minute||0),goals_total:Number(s.goals?.home||0)+Number(s.goals?.away||0),score:e.score,tier:watchTierForScore(e.score),core:e.core?.strongCount??0,pressure:e.pressure,chance:e.chance,momentum:e.momentum,game:e.game,market:e.market,context:e.context,dq:item.initialDQ||0,d5:e.recent5?.delta||null,d10:e.recent10?.delta||null,over_line:bo?.line??null,over_odd:bo?.odd??null,goal_5m:null,goal_10m:null,goal_15m:null,goal_ft:null,first_goal_min:null});watchState.calibration=rows.slice(-WATCH_CAL_MAX);watchCalWrite();
  }

  function watchEvaluate(item,s){
    const game=watchGameStateScore(s),pr=watchPressureScore(item,s),rawChance=watchChanceScore(item,s,pr),mom=watchMomentum(item,s),mk=watchMarketScore(s),context=watchContextScore(s),quality=watchQualityScore(item,s),baselineAge=watchHistoryAge(item,s),presence=s.stats_presence||null,veto=[],warnings=[];
    const statTotal=(Number(s.metrics?.total?.shots)||0)+(Number(s.metrics?.total?.sot)||0)+(Number(s.metrics?.total?.inbox)||0)+(Number(s.metrics?.total?.corners)||0)+(Number(s.metrics?.total?.xg)||0),noStats=presence?presence.pressure===false:(Number(s.minute)>=55&&statTotal===0),partialStats=presence?presence.pressure===true&&presence.core===false:false,baselineIncomplete=baselineAge<2;
    if(noStats)veto.push('NO_LIVE_STATS');else if(partialStats)warnings.push('PARTIAL_LIVE_STATS');if(s.market?.raw_count>0&&s.market?.valid_count===0)veto.push('MARKET_INTEGRITY_INVALID');
    let pressure=pr.score,chance=rawChance,momentum=mom.score,scoreMode='FULL';
    if(noStats){pressure=null;chance=null;momentum=null;scoreMode='DATA_INCOMPLETE'}
    else if(baselineIncomplete){pressure=null;chance=null;momentum=null;scoreMode='BASELINE'}
    else if(partialStats){pressure=presence?.pressure?pr.score:null;chance=presence?.chance?rawChance:null;momentum=presence?.momentum?mom.score:null;scoreMode='PARTIAL_STATS'}
    const core=watchCore({pressure,chance,momentum}),rawScore=watchClamp(game+pr.score+rawChance+mom.score+mk.score+context+quality,0,100),partialRaw=watchClamp(game+(pressure??0)+(chance??0)+(momentum??0)+mk.score+context+quality,0,100),score=scoreMode==='FULL'?rawScore:scoreMode==='PARTIAL_STATS'?Math.min(68,partialRaw):watchClamp(game+mk.score+context+quality,0,100);
    return {score,rawScore,partialRaw,scoreMode,dataIncomplete:['DATA_INCOMPLETE','BASELINE'].includes(scoreMode),partialData:scoreMode==='PARTIAL_STATS',baselineAge,game,pressure,chance,momentum,market:mk.score,context,quality,mature:mom.mature,delta:mom.delta,window_min:mom.window_min,accel:mom.accel,recent5:pr.w5,recent10:pr.w10,core,stats_presence:presence,market_available:mk.available,over_available:mk.over_available,best_over:mk.best_over,market_movement:mk.movement,hardVeto:veto.length>0,vetoReasons:veto,dataWarnings:warnings}
  }
  function watchNewResetEvent(prev,s){if(!prev)return null;const pg=(Number(prev.goals?.home)||0)+(Number(prev.goals?.away)||0),cg=(Number(s.goals?.home)||0)+(Number(s.goals?.away)||0);if(cg>pg)return 'GOAL';const pr=Number(prev.metrics?.total?.red||0),cr=Number(s.metrics?.total?.red||0);if(cr>pr)return 'RED_CARD';return null}
  function watchWhy(item,s,e){
    const good=[],bad=[],d5=e.recent5?.delta||{},d10=e.recent10?.delta||{},bo=e.best_over,mv=e.market_movement||{},gap=Math.abs(Number(s.goals?.home||0)-Number(s.goals?.away||0));
    if(e.scoreMode==='DATA_INCOMPLETE')bad.push('LIVE STATS không có • core không thể tính');if(e.scoreMode==='PARTIAL_STATS')bad.push(`PARTIAL STATS • ${watchHealthLabel(s.data_health)} • cap 68 • không nâng READY/STRONG`);if(e.scoreMode==='BASELINE')bad.push(`Đang tạo baseline ${Number(e.baselineAge||0).toFixed(1)}/2.0m`);
    if(e.scoreMode==='FULL'||e.scoreMode==='PARTIAL_STATS'){if(Number(d5.sot)>=2)good.push(`+${d5.sot} SOT / ${e.recent5.window_min||5}m`);if(Number(d10.xg)>=.25)good.push(`ΔxG10 +${Math.round(Number(d10.xg)*100)/100}`);if(Number(d5.inbox)>=3)good.push(`+${d5.inbox} InBox gần đây`);if(e.accel>=.35)good.push('Momentum đang tăng tốc');if(e.core?.pass)good.push(`CORE ${e.core.strongCount}/3 đạt`);if(e.recent5?.status==='complete'&&Number(d5.sot)===0)bad.push('~5m chưa có SOT');if(e.mature&&Number(d10.xg)<.08&&(Number(s.metrics?.total?.xg)||0)>0)bad.push('ΔxG gần đây thấp');if(e.momentum!=null&&e.momentum<5)bad.push('Momentum yếu/đang giảm');if(e.core?.available&&e.core?.weakCount)bad.push(`CORE có ${e.core.weakCount} trụ quá yếu`)}
    if(gap<=1)good.push(`Game-state cách biệt ${gap} bàn`);if(Number(mv.line_delta)>0)good.push(`Total line ↑ ${mv.line_delta>0?'+':''}${mv.line_delta}`);else if(Number(mv.over_price_delta)<=-.02)good.push(`Giá Tài giảm ${Math.abs(mv.over_price_delta).toFixed(2)}`);if(bo)good.push(`Tài ${bo.line??'?'} @${bo.odd.toFixed(2)}`);if(!e.market_available)bad.push('Chưa có live market hợp lệ');if(e.hardVeto)bad.push(...e.vetoReasons);return {good:good.slice(0,5),bad:[...new Set(bad)].slice(0,5)}
  }
  function watchApplyState(item,s,ev){
    const now=Date.now(),t=watchThresholds();if(ev){item.resetAt=now;item.cooldownUntil=now+(ev==='GOAL'?4:5)*60000;item.lowStreak=0;item.state='COOLDOWN';item.reason=`${ev==='GOAL'?'Vừa có bàn':'Vừa có thẻ đỏ'} • reset toàn bộ momentum`;item.history=[s];watchWriteHistory(item);return}
    if(item.cooldownUntil&&now<item.cooldownUntil){item.state='COOLDOWN';item.reason=`Cooldown còn ${Math.ceil((item.cooldownUntil-now)/60000)} phút`;return}const e=item.eval||{},fresh=(now-(s.fresh_at||now))/1000<=60;
    if(!fresh){item.state='STALE';item.reason='Dữ liệu >60s • không dùng tín hiệu cũ';return}if(e.hardVeto){const noStats=e.vetoReasons?.includes('NO_LIVE_STATS');if(noStats&&Number(item.dataMissStreak||0)<3){item.state='DATA_WAIT';item.reason=`DATA WAIT ${Number(item.dataMissStreak||0)}/3 • ${watchHealthLabel(s.data_health)}`;return}item.state='CANCELLED';item.reason=`DATA INCOMPLETE • ${e.vetoReasons.join(', ')}`;return}if(Number(e.baselineAge||0)<2){item.state='BASELINE';item.reason=`Đang tạo baseline ${Number(e.baselineAge||0).toFixed(1)}/2.0 phút • chưa phát signal`;return}
    if(e.scoreMode==='PARTIAL_STATS'){if(e.score>=t.candidate&&e.core?.available&&e.core?.partialPass){item.state='PARTIAL_CANDIDATE';item.reason=`PARTIAL CANDIDATE ${e.score}/68 • dùng ${e.core.availableCount}/3 trụ • confidence thấp hơn`;return}if(e.score>=t.watch){item.state='PARTIAL_WATCH';item.reason=`PARTIAL WATCH ${e.score}/68 • ${watchHealthLabel(s.data_health)}`;return}item.state='DATA_PARTIAL';item.reason=`DATA PARTIAL ${e.score}/68 • ${watchHealthLabel(s.data_health)}`;return}
    item.peak=Math.max(Number(item.peak||0),Number(e.score||0));if(item.peak>=t.ready&&e.score<60){item.lowStreak=(item.lowStreak||0)+1;if(item.lowStreak>=2){item.state='CANCELLED';item.reason='Áp lực giảm rõ 2 snapshot sau khi từng READY';return}}else item.lowStreak=0;
    if(e.score>=t.strong&&e.core?.available&&e.core?.pass&&e.mature&&e.market_available){item.state='STRONG';item.reason=`STRONG ${e.score} • CORE ${e.core.strongCount}/3 • market xác nhận`;return}if(e.score>=t.ready&&e.core?.available&&e.core?.strongCount>=2){item.state='READY';item.reason=e.market_available?`READY ${e.score} • CORE ${e.core.strongCount}/3`:`READY về bóng • CHỜ MARKET`;return}if(e.score>=t.candidate){item.state='CANDIDATE';item.reason=`Candidate ${e.score} • CORE ${e.core?.strongCount??0}/3`;return}if(e.score>=t.watch){item.state='WATCH';item.reason='Đáng canh nhưng chưa đủ đồng thuận';return}item.state='LOW';item.reason='Điểm thấp • chưa đáng canh'
  }
  function watchStateText(s){return ({STRONG:'🟢 STRONG SIGNAL',READY:'🟠 READY',CANDIDATE:'🔵 CANDIDATE',WATCH:'👁 THEO DÕI',PARTIAL_CANDIDATE:'🔵 PARTIAL CANDIDATE',PARTIAL_WATCH:'⚠ PARTIAL WATCH',LOW:'⚪ THẤP',BASELINE:'🟣 ĐANG TẠO BASELINE',DATA_WAIT:'🟣 DATA WAIT',DATA_PARTIAL:'⚠ DATA PARTIAL',CANCELLED:'CANCEL',COOLDOWN:'🔵 RESET / COOLDOWN',ENDED:'⚫ KẾT THÚC',STALE:'⚠ DATA STALE'})[s]||s}
  function watchStateClass(s){return s==='STRONG'?'strong':s==='READY'?'ready':s==='CANDIDATE'?'candidate':s==='PARTIAL_CANDIDATE'?'partial-candidate':s==='PARTIAL_WATCH'?'partial-watch':s==='LOW'?'low':s==='BASELINE'||s==='DATA_WAIT'?'baseline':s==='DATA_PARTIAL'?'partial-watch':s==='STALE'?'stale':s==='CANCELLED'?'cancel':s==='COOLDOWN'?'cooldown':''}
  function watchAlert(item,oldState,ev){if(ev){showToast('err',`${ev==='GOAL'?'GOAL':'RED CARD'} • reset LIVE WATCH`,`${item.home} vs ${item.away} • tín hiệu cũ bị hủy.`);return}if(item.state==='STRONG'&&oldState!=='STRONG'){showToast('ok','STRONG SIGNAL',`${item.home} vs ${item.away} • ${item.eval?.score||'-'}/100 • CORE ${item.eval?.core?.strongCount||0}/3.`);watchBeep()}else if(item.state==='READY'&&!['READY','STRONG'].includes(oldState))showToast('ok','LIVE WATCH READY',`${item.home} vs ${item.away} • ${item.eval?.score||'-'}/100.`);else if(item.state==='CANCELLED'&&oldState!==item.state)showToast('err','LIVE WATCH hủy tín hiệu',`${item.home} vs ${item.away} • ${item.reason||'áp lực giảm'}`)}
  function watchBeep(){if(!$('watchSound')?.checked)return;try{const ctx=watchState.audio;if(!ctx)return;const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=880;g.gain.setValueAtTime(.0001,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.14,ctx.currentTime+.02);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.28);o.connect(g);g.connect(ctx.destination);o.start();o.stop(ctx.currentTime+.3)}catch{}}
  function watchInitAudio(){try{if(!watchState.audio)watchState.audio=new (window.AudioContext||window.webkitAudioContext)();watchState.audio.resume?.()}catch{}}

  async function fetchWatchSnapshot(item,forceMarket=false,fixtureHint=null){
    const hb=fixtureHint?null:await ultraHeartbeat(false),f=fixtureHint||hb?.map?.get(String(item.id));
    if(!f)return {ended:true,f:null,meta:null};
    const meta=compactFixtureMeta(f,autoModeForFixture(f));if(!isLive(f))return {ended:true,f,meta};
    const u=await ultraLiveRaw(f,item,'FT',forceMarket),rawStats=u.statsRaw||[],rawEvents=u.eventsRaw||[],liveOdds=u.liveOdds.slice(0,40),
          marketHistory=saveLiveOddsSnapshot(item.id,{fixture:f.fixture,goals:f.goals},liveOdds),half=u.halfRaw,
          marketTime=await mtBuildShadow(item,f,u.rawOdds||[],'FT',u.freshness?.market_content_age??null),
          marketExpectation=await meBuildShadow(item,marketTime,'FT'),
          fullMap=statMap(rawStats),halves=half?normalizeHalfStatistics(half,rawStats):null,metrics=watchAggregate(fullMap,meta),stats_presence=watchStatsPresence(fullMap,meta),
          h1=halves?watchAggregate(halves.first_half||{},meta):null,h2=halves?watchAggregate(halves.second_half||{},meta):null;
    item.lastMarketAt=u.marketAt||Date.now();item.lastMarketRows=liveOdds;item.lastHalfRaw=half;item.lastHalfAt=u.entry?.fields?.half?.at||item.lastHalfAt||0;
    return {captured_at:Date.now(),minute:Number(f.fixture?.status?.elapsed||0),status:f.fixture?.status?.short||'',goals:{home:Number(f.goals?.home||0),away:Number(f.goals?.away||0)},
      metrics,stats_presence,data_health:watchDataHealth(stats_presence,item.apiCoverage||null),h1,h2,market:watchMarketInfo(liveOdds,marketHistory),market_rows:liveOdds,
      dq:item.initialDQ||0,integrity:item.initialIntegrity??null,events:eventsCompact(rawEvents).slice(-40),fresh_at:u.statsAt||Date.now(),fixture:f,
      hub_tier:u.tier,content_freshness:u.freshness,personnel:u.personnel,market_time:marketTime,market_expectation:marketExpectation,half_derived:halves?.second_half_derived??false,source:'ULTRA_HUB'};
  }
  function initialWatchEval(item,s){item.eval=watchEvaluate(item,s);item.peak=item.eval.score;watchApplyState(item,s,null);qsigUpdateFT(item,s,null,false);grTrack(item,'FT');item.reason+=' • baseline ban đầu'}
  function renderCalibration(){
    const st=watchCalibrationStats(),l=watchLearnedStrong(),qs=qsigStats('FT'),el=$('watchCalibration');$('watchCalCount').textContent=String(qs.n);if(!el)return;const tiers=['WATCH','CANDIDATE','READY','STRONG'].map(k=>{const x=st.byTier[k];return x.n?`${k} n=${x.n}: ${(x.rate*100).toFixed(1)}%/10m`:null}).filter(Boolean).join(' • ');el.innerHTML=`<b>V1.16.2 FIXED BENCHMARK:</b> Qualified waves n=${qs.n} • High ${qs.high} • Open ${qs.open}<br><span class="tiny">FT: 46–80' • Score ≥73 • FULL • DQ ≥4/5 • fresh ≤20s • Evidence ≤180s • CORE ≥2/3 • recent Chance • SUSTAINED/ACCELERATING. HIGH: Score ≥80 • CORE 3/3 • Evidence ≤90s • market.</span>`;
  }
  // FE_TOP_LIVE_STABLE_DOM_START — presentation only; no engine state or timers.
  function feLivePatchHTML(root,html){
    if(!root)return;
    const template=document.createElement('template');template.innerHTML=html;
    const focused=document.activeElement;
    const key=node=>node.nodeType===1?(node.id||node.getAttribute('data-fe-live-key')||node.getAttribute('data-master-fixture')||''):'';
    const compatible=(a,b)=>a.nodeType===b.nodeType&&(a.nodeType!==1||(a.tagName===b.tagName&&key(a)===key(b)&&
      (key(a)||(a.getAttribute('class')||'').split(/\s+/)[0]===(b.getAttribute('class')||'').split(/\s+/)[0])));
    function children(parent,next){
      const old=Array.from(parent.childNodes),used=new Set();let cursor=parent.firstChild;
      for(const fresh of Array.from(next.childNodes)){
        const k=key(fresh);
        const live=old.find(n=>!used.has(n)&&compatible(n,fresh)&&(k?key(n)===k:!key(n)));
        if(!live){parent.insertBefore(fresh.cloneNode(true),cursor);continue}
        used.add(live);
        if(live!==cursor)parent.insertBefore(live,cursor);
        patch(live,fresh);cursor=live.nextSibling;
      }
      for(const node of old)if(!used.has(node))node.remove();
    }
    function patch(live,fresh){
      if(live.nodeType!==1){if(live.nodeValue!==fresh.nodeValue)live.nodeValue=fresh.nodeValue;return}
      const keepOpen=live.tagName==='DETAILS';
      for(const attr of Array.from(live.attributes)){
        if(keepOpen&&attr.name==='open')continue;
        if(!fresh.hasAttribute(attr.name))live.removeAttribute(attr.name);
      }
      for(const attr of Array.from(fresh.attributes)){
        if(keepOpen&&attr.name==='open')continue;
        if(live.getAttribute(attr.name)!==attr.value)live.setAttribute(attr.name,attr.value);
      }
      children(live,fresh);
    }
    children(root,template.content);
    if(focused&&root.contains(focused)&&document.activeElement!==focused)focused.focus({preventScroll:true});
  }
  // FE_TOP_LIVE_STABLE_DOM_END

  function renderLiveWatch(){
    const list=$('watchList'),items=watchState.items||[];$('watchCount').textContent=String(items.length);$('watchApiUsage').textContent=String(apiUsageSnapshot().network_calls||0);renderCalibration();if(!items.length){feLivePatchHTML(list,'<div class="watch-alert-note"><b>Chưa có watchlist FT.</b> Quét LIVE rồi bấm CANH TOP 5 FT.</div>');$('watchPacketActions').classList.add('hidden');return}$('watchPacketActions').classList.remove('hidden');
    feLivePatchHTML(list,items.map((it,i)=>{const s=it.latest||{},e=it.eval||{},d=e.delta||{},cls=watchStateClass(it.state),market=s.market?.text||'Chưa có market',fresh=Math.max(0,Math.round((Date.now()-(s.fresh_at||Date.now()))/1000)),qa=qsigAssessFT(it,s),why=watchWhy(it,s,e),good=why.good.length?why.good.join(' • '):'Chưa có tín hiệu tăng tốc nổi bật',bad=why.bad.length?why.bad.join(' • '):'Chưa thấy yếu tố phủ định mạnh',mv=s.market?.movement_text||'',core=e.core||{},mode=e.scoreMode||'FULL',flag=mode==='DATA_INCOMPLETE'?'DATA INCOMPLETE':mode==='BASELINE'?'BASELINE':mode==='PARTIAL_STATS'?'PARTIAL DATA':'',coreHtml=mode==='PARTIAL_STATS'?(core.available?`<b>CORE PARTIAL ${core.availableCount}/3:</b> <span class="${core.partialPass?'pass':'fail'}">${core.strongCount}/${core.availableCount} ${core.partialPass?'PASS PARTIAL':'chưa đủ'}</span> • thiếu trụ không có dữ liệu`:`<b>CORE PARTIAL:</b> <span class="data-guard-na">${core.availableCount||0}/3 trụ có dữ liệu</span>`):!core.available?`<b>CORE:</b> <span class="data-guard-na">${mode==='BASELINE'?'WAIT • đang tạo baseline':`N/A • ${watchHealthLabel(s.data_health)}`}</span>`:`<b>CORE 2/3:</b> <span class="${core.pass?'pass':'fail'}">${core.strongCount}/3 ${core.pass?'PASS':'chưa đủ'}</span> • Pressure / Chance / Momentum`,deltaHtml=mode==='DATA_INCOMPLETE'?`<b>DELTA:</b> N/A • ${watchHealthLabel(s.data_health)}`:mode==='BASELINE'?`<b>DELTA:</b> ĐANG TẠO BASELINE ${Number(e.baselineAge||0).toFixed(1)}/2.0m`:`<b>Δ ${esc(e.window_min??0)}m:</b> ${esc(watchDeltaText(d,'shots','Shots'))} • ${esc(watchDeltaText(d,'sot','SOT'))} • ${esc(watchDeltaText(d,'inbox','InBox'))} • ${esc(watchDeltaText(d,'corners','Corners'))} • ${esc(watchDeltaText(d,'xg','xG',2))}`;
      const sv=feScoreVisual('FT',e.score,it.state);
      return `<div class="watch-ticket ${cls}" data-fe-live-key="${esc(it.id)}"><div class="watch-head"><div class="watch-name"><b>#${i+1} ${esc(it.home)} vs ${esc(it.away)}</b><span>${esc(it.league||'')} • ${esc(s.minute??'-')}' • ${esc(s.goals?.home??'-')}-${esc(s.goals?.away??'-')} • Fixture #${esc(it.id)}</span></div><span class="watch-badge ${cls}">${esc(watchStateText(it.state))}</span></div>${grHTML(it,'FT')}<div class="watch-score-row ${sv.cls}"><div class="watch-score">${esc(e.score??'-')}<small>/100</small>${flag?`<span class="watch-score-flag ${mode==='PARTIAL_STATS'?'partial':''}">${flag}</span>`:''}<span class="fe-score-zone ${sv.cls} ${sv.qualified?'':'unqualified'}">${esc(sv.display)}</span></div><div class="watch-bar visual-threshold"><i class="${sv.cls}" style="width:${watchClamp(Number(e.score)||0,0,100)}%"></i></div><div class="watch-fresh ${fresh>60?'stale':''}" data-watch-fresh="${esc(s.fresh_at||0)}">${fresh>60?'STALE ':'fresh '}${fresh}s</div></div>${qsigBadgeHTML(qa)}<div class="watch-components v181"><div class="watch-comp"><span>GAME</span><b>${esc(e.game??'-')}/15</b></div><div class="watch-comp"><span>PRESS</span><b>${e.pressure==null?'N/A':esc(e.pressure)+'/20'}</b></div><div class="watch-comp"><span>CHANCE</span><b>${e.chance==null?'N/A':esc(e.chance)+'/20'}</b></div><div class="watch-comp"><span>MOM</span><b>${e.momentum==null?'N/A':esc(e.momentum)+'/15'}</b></div><div class="watch-comp"><span>MARKET</span><b>${esc(e.market??'-')}/15</b></div><div class="watch-comp"><span>CONTEXT</span><b>${esc(e.context??'-')}/10</b></div><div class="watch-comp"><span>DQ</span><b>${esc(e.quality??'-')}/5</b></div></div><div class="watch-core ${!core.available?'na':''}">${coreHtml}</div><div class="watch-delta ${['DATA_INCOMPLETE','BASELINE'].includes(mode)?'data-guard-box':''}">${deltaHtml}<br><b>ENGINE:</b> ${esc(it.reason||'')}</div><div class="watch-why"><div class="watch-why-box good"><b>WHY NOW</b>${esc(good)}</div><div class="watch-why-box bad"><b>WHY NOT / RỦI RO</b>${esc(bad)}</div></div>${fmdHTML(s.final_model_decision)}${mtIntelHTML(s,'FT')}<details class="mt-model-details"><summary>MODEL DETAILS</summary>${gpShadowHTML(s.goal_potential,'FT')}${meShadowHTML(s.market_expectation)}${lvmShadowHTML(s.live_vs_market)}${lpvShadowHTML(s.line_price_value)}<div class="watch-market"><strong>LIVE MARKET:</strong> ${esc(market)}${mv?`<div class="watch-market-move">${esc(mv)}</div>`:''}</div>${mtShadowHTML(s.market_time,'FT')}</details></div>`}).join(''))
  }
  function watchNextInterval(){if(watchState.items.some(x=>['STRONG','READY'].includes(x.state)))return 12000;if(watchState.items.some(x=>x.state==='CANDIDATE'))return 18000;return 25000}
  function scheduleLiveWatch(){clearTimeout(watchState.timer);if(feWorkspaceAutoStopIfDone('FT'))return;if(!watchState.active||!$('watchAuto')?.checked){watchState.nextAt=0;updateWatchClock();return}const ms=watchNextInterval();watchState.nextAt=Date.now()+ms;watchState.timer=setTimeout(()=>refreshLiveWatch(true),ms);updateWatchClock()}
  function updateWatchClock(){document.querySelectorAll('[data-watch-fresh]').forEach(el=>{const ts=Number(el.dataset.watchFresh||0);if(ts)el.textContent=`fresh ${Math.max(0,Math.round((Date.now()-ts)/1000))}s`});const c=$('watchCountdown');if(!c)return;c.textContent=watchState.nextAt?`${Math.max(0,Math.ceil((watchState.nextAt-Date.now())/1000))}s`:(watchState.active?'PAUSE':'—');$('watchApiUsage').textContent=String(apiUsageSnapshot().network_calls||0)}
  async function refreshLiveWatch(quiet=false){
    if(watchState.refreshing||!watchState.items.length)return;if(document.visibilityState!=='visible'&&quiet){scheduleLiveWatch();return}
    watchState.refreshing=true;clearTimeout(watchState.timer);watchState.nextAt=0;status($('watchStatus'),`ULTRA HUB • cập nhật ${watchState.items.length} fixture FT...`,'busy');
    try{
      const hb=await ultraHeartbeat(!quiet);
      await mapLimit(watchState.items,4,async(item)=>{
        if(item.state==='ENDED')return item;const oldState=item.state,prev=item.latest,f=hb.map.get(String(item.id));
        try{
          const s=await fetchWatchSnapshot(item,!quiet,f);
          if(s.ended){const endF=s.f||f||{},endSnap={...(item.latest||{}),minute:Number(endF.fixture?.status?.elapsed||item.latest?.minute||90),goals:{home:Number(endF.goals?.home||item.latest?.goals?.home||0),away:Number(endF.goals?.away||item.latest?.goals?.away||0)},events:item.latest?.events||[]};watchCalSettle(item,endSnap,true);qsigUpdateFT(item,endSnap,null,true);item.state='ENDED';item.reason='Fixture không còn LIVE';bgUnregisterFixtureIds([item.id],true).catch(()=>{});return item}
          const ev=watchNewResetEvent(prev,s);item.latest=s;item.dataHealth=s.data_health||watchDataHealth(s.stats_presence,item.apiCoverage||null);item.dataMissStreak=item.dataHealth?.level==='NO_STATS'?(Number(item.dataMissStreak||0)+1):0;
          item.history=(item.history||[]).concat([s]).slice(-80);item.eval=watchEvaluate(item,s);grTrack(item,'FT');s.goal_potential=await gpBuildShadow(item,s,item.eval,'FT');s.live_vs_market=await lvmBuildShadow(item,s.goal_potential,s.market_expectation,'FT');s.line_price_value=await lpvBuildShadow(item,s.market_time,s.goal_potential,s.market_expectation,s.live_vs_market,'FT');s.robustness=await rbBuildShadow(item,s.goal_potential,s.market_expectation,s.live_vs_market,s.line_price_value,'FT');s.final_model_decision=await fmdBuildShadow(item,s,'FT');s.validation=await valUpdate(item,s,'FT');await fmdAttachValidationT0(item,s);s.decision_journal=await fmdJournalUpdate(item,s,s.final_model_decision,'FT');await fmdBenchmarkRefresh(false);evidenceMaybeRefresh();watchCalSettle(item,s,false);watchApplyState(item,s,ev);qsigUpdateFT(item,s,ev,false);watchCalRecord(item,s);watchWriteHistory(item);watchAlert(item,oldState,ev)
        }catch(e){item.state='STALE';item.reason='API/HUB lỗi: '+e.message;log('Watch fixture error',{id:item.id,error:e.message})}
        return item
      });
      watchState.items=watchState.items.filter(x=>x.state!=='ENDED'&&(x.dataHealth?.level!=='NO_STATS'||Number(x.dataMissStreak||0)<3));
      watchState.items.sort((a,b)=>(Number(b.latest?.data_health?.priority||0)-Number(a.latest?.data_health?.priority||0))||(Number(b.eval?.score||-1)-Number(a.eval?.score||-1)));
      watchState.cycle++;renderLiveWatch();const strong=watchState.items.filter(x=>x.state==='STRONG').length,ready=watchState.items.filter(x=>x.state==='READY').length,cand=watchState.items.filter(x=>x.state==='CANDIDATE').length;
      status($('watchStatus'),`LIVE WATCH • ${strong} STRONG • ${ready} READY • ${cand} CANDIDATE • ${ultraHubSummary()}`,'ok')
    }finally{watchState.refreshing=false;scheduleLiveWatch()}
  }
  function watchBundleScore(b,f){const item={id:b.meta?.fixture_id,initialDQ:b.coverage?.score||0,initialIntegrity:b.coverage?.integrity_score??100,history:[]};const s=watchSnapshotFromBundle(b,f);item.latest=s;item.history=[s];const e=watchEvaluate(item,s);return {...e,rank:e.score+e.core.strongCount*2}}
  async function startLiveWatch(){
    const feIsolationSnap=feCaptureOtherEngines('FT');
    watchInitAudio();if(!els.fkey.value.trim()){showToast('err','Chưa có Football API Key','Lưu API key trước.');return}
    let all=[];try{all=await feWorkspaceScanFixtures('FT')}catch(e){showToast('err','FT scan lỗi',e.message);return}
    watchState.sourceFixtureIds=all.map(f=>Number(f?.fixture?.id)).filter(Number.isFinite);
    if(!all.length){showToast('err','Không có FT phù hợp','FT workspace vừa quét LIVE độc lập nhưng chưa có trận 2H phút 45–89 phù hợp.');return}
    const cap=watchPrefilterCap(),pref=[...all].sort((a,b)=>cheapWatchRank(b)-cheapWatchRank(a)).slice(0,cap);loading(true,'Đang sàng lọc FT độc lập',`0/${pref.length} fixture • chọn TOP 5`);status($('watchStatus'),`FT workspace • screening ${pref.length}/${all.length} trận • H1/Handicap giữ nguyên...`,'busy');
    try{const bundles=await mapLimit(pref,4,getGroupBundle,(done,n,f)=>{els.loadingText.textContent=`${done}/${n} • ${f?.teams?.home?.name||''} vs ${f?.teams?.away?.name||''}`});const screened=await watchSelectUsableBundles(bundles,pref,'FT',WATCH_MAX_ITEMS,watchBundleScore,'FT STATS');const ranked=screened.selected,hs=screened.summary;
      watchState.items=ranked.map(({b,f,health})=>{const s=watchSnapshotFromBundle(b,f),old=watchReadHistory(b.meta.fixture_id).filter(x=>x.captured_at>=Date.now()-30*60000),item={id:Number(b.meta.fixture_id),home:b.meta.teams?.home?.name||'',away:b.meta.teams?.away?.name||'',league:`${b.meta.league?.name||''}${b.meta.league?.country?' | '+b.meta.league.country:''}`,home_id:b.meta.teams?.home?.id,away_id:b.meta.teams?.away?.id,initialDQ:b.coverage?.score||0,initialIntegrity:b.coverage?.integrity_score??100,apiCoverage:b.data?.api_coverage||null,dataHealth:health,dataMissStreak:health?.level==='NO_STATS'?1:0,history:old.concat([s]).slice(-80),latest:s,state:'WATCH',reason:'',lowStreak:0,peak:0,lastMarketRows:b.data?.live_odds||[],lastMarketAt:Date.now(),resetAt:null,cooldownUntil:0};initialWatchEval(item,s);watchCalSettle(item,s,false);watchCalRecord(item,s);watchWriteHistory(item);return item});watchState.items.sort((a,b)=>(Number(b.latest?.data_health?.priority||0)-Number(a.latest?.data_health?.priority||0))||(Number(b.eval?.score||0)-Number(a.eval?.score||0)));watchState.active=watchState.items.length>0;watchState.cycle=0;renderLiveWatch();$('liveWatchCard')?.scrollIntoView({behavior:'smooth',block:'start'});const t=watchThresholds();status($('watchStatus'),`STATS HEALTH • HEALTHY ${hs.healthy} • PARTIAL ${hs.partial} • NO STATS ${hs.no_stats} • retry ${hs.retried}${hs.recovered?` / recovered ${hs.recovered}`:''}. TOP ${watchState.items.length} ưu tiên HEALTHY; PARTIAL vẫn được tính các trường có thật (cap 68, không READY/STRONG); NO STATS bị loại. Ngưỡng ${t.watch}/${t.candidate}/${t.ready}/${t.strong}.`,'ok');if(watchState.active){scheduleLiveWatch();bgRegisterItems(watchState.items,'FT').catch(()=>{})}showToast('ok','FT STATS HEALTH',`TOP ${watchState.items.length} • HEALTHY ${hs.healthy} • PARTIAL ${hs.partial} • loại NO STATS ${hs.no_stats}. • ${feWorkspaceSummary()}`)}catch(e){status($('watchStatus'),'Không khởi động được LIVE WATCH: '+e.message,'err');showToast('err','LIVE WATCH lỗi',e.message)}finally{feRestoreOtherEngines(feIsolationSnap,'START_FT');loading(false)}
  }
  function stopLiveWatch(){feMarkEngineManualStop('FT');watchState.active=false;clearTimeout(watchState.timer);watchState.nextAt=0;updateWatchClock();status($('watchStatus'),'Đã dừng AUTO. Watchlist + snapshot + calibration vẫn lưu trên máy.','ok')}
  function buildWatchPacket(){
    const usage=apiUsageSnapshot(),cal=watchCalibrationStats(),th=watchThresholds(),rows=watchState.items.map((it,i)=>{const s=it.latest||{},e=it.eval||{},d=e.delta||{},why=watchWhy(it,s,e);return `#${i+1} | FX ${it.id} | ${it.league}\nTRẬN: ${it.home} vs ${it.away}\nLIVE: ${s.minute??'-'}' | ${s.goals?.home??'-'}-${s.goals?.away??'-'} | ${watchStateText(it.state)} | SCORE ${e.score??'-'}/100 | CORE ${e.core?.strongCount??0}/3 ${e.core?.pass?'PASS':'NO'}\nCOMP: GAME ${e.game??'-'}/15 | PRESSURE ${e.pressure??'-'}/20 | CHANCE ${e.chance??'-'}/20 | MOM ${e.momentum??'-'}/15 | MARKET ${e.market??'-'}/15 | CONTEXT ${e.context??'-'}/10 | DQ ${e.quality??'-'}/5\nDELTA ${e.window_min??0}m: Shots +${d.shots??0} | SOT +${d.sot??0} | InBox +${d.inbox??0} | Corners +${d.corners??0} | xG +${Math.round(Number(d.xg||0)*100)/100}\nWHY NOW: ${why.good.join(' ; ')||'-'}\nWHY NOT: ${why.bad.join(' ; ')||'-'}\nMARKET: ${s.market?.text||'N/A'}\nMOVE: ${s.market?.movement_text||'N/A'}\nGOAL_POTENTIAL_SHADOW: ${gpPacketText(s.goal_potential)}\nMARKET_EXPECTATION_SHADOW: ${mePacketText(s.market_expectation)}\nLIVE_VS_MARKET_SHADOW: ${lvmPacketText(s.live_vs_market)}\nLINE_PRICE_VALUE_SHADOW: ${lpvPacketText(s.line_price_value)}\nROBUSTNESS_SHADOW: ${rbPacketText(s.robustness)}\nVALIDATION_LAB: ${valPacketText(s.validation)}\nEVIDENCE_GATE: ${evidencePacketText()}\nFINAL_MODEL_DECISION: ${fmdPacketText(s.final_model_decision)}\nMARKET_TIME_SHADOW: ${mtPacketText(s.market_time)}\nENGINE: ${it.reason||'-'}`}).join('\n\n');
    return `[FOOTBALL_EDGE_LIVE_WATCH]\nVERSION: V1.18.3 SINGLE MATCH ANALYZER\nMODE: RUNG_TAI_LIVE_WATCH\nTIME_VN: ${new Date().toLocaleString('vi-VN',{timeZone:TZ})}\nWATCHLIST: ${watchState.items.length}\nTHRESHOLDS: WATCH ${th.watch} | CANDIDATE ${th.candidate} | READY ${th.ready} | STRONG ${th.strong}${th.learned.learned?' LEARNED':' DEFAULT'}\nCALIBRATION: n=${cal.n} | resolved_10m=${cal.resolved10} | goal_10m_rate=${cal.resolved10?(cal.rate10*100).toFixed(1)+'%':'N/A'}\nAPI_CALLS_LOCAL_TODAY: ${usage.network_calls||0}\n\nYÊU CẦU GPT:\n1. So sánh chéo TOP ${watchState.items.length}; TOP 5 là ranking tương đối, không có nghĩa cả 5 đều đạt ngưỡng tuyệt đối.\n2. Ưu tiên WHY NOW + delta 5/10 phút + xG/SOT/InBox + game-state. FULL stats chỉ là nền.\n3. CORE 2/3 = Pressure + Chance + Momentum. PARTIAL chỉ dùng các trụ có dữ liệu thật, score cap 68 và không được xem là READY/STRONG. DATA INCOMPLETE / CORE N/A / BASELINE không được xem là signal xác nhận.\n4. Market/odds là model vote. Đọc cả line/price movement; thiếu market thì ghi CHỜ MARKET, không bịa.\n5. Goal/Red Card/cooldown làm tín hiệu cũ mất hiệu lực. Nếu pressure giảm thì hạ/hủy.\n6. Trả: HẠNG | GIẢI | TRẬN | PHÚT/TỶ SỐ | STATE | SCORE/CORE | MARKET | WHY NOW | WHY NOT.\n\n=== TOP LIVE WATCH ===\n${rows}\n=== END ===`;
  }
  async function copyWatchPacket(open=false){if(!watchState.items.length){showToast('err','Chưa có LIVE WATCH','Hãy bắt đầu CANH TOP 5 LIVE trước.');return}const p=buildWatchPacket();watchState.lastPacket=p;try{await navigator.clipboard.writeText(p)}catch(e){state.lastPacket=p;els.packetText.value=p;els.packetText.focus();els.packetText.select();document.execCommand('copy')}showToast('ok','Đã copy LIVE WATCH V1.18.1','Packet có WHY NOW / CORE / Calibration / Market movement.');if(open){saveConfig(true);openProject()}}

  watchState.calibration=watchCalRead();
  $('watchTop5Btn')?.addEventListener('click',startLiveWatch);$('startWatchBtn')?.addEventListener('click',startLiveWatch);$('refreshWatchBtn')?.addEventListener('click',()=>refreshLiveWatch(false));$('stopWatchBtn')?.addEventListener('click',stopLiveWatch);$('watchAuto')?.addEventListener('change',e=>{if(e.target.checked){watchState.active=true;scheduleLiveWatch()}else{clearTimeout(watchState.timer);watchState.nextAt=0;updateWatchClock()}});$('copyWatchPacketBtn')?.addEventListener('click',()=>copyWatchPacket(false));$('copyOpenWatchBtn')?.addEventListener('click',()=>copyWatchPacket(true));$('resetWatchCalBtn')?.addEventListener('click',()=>{if(!confirm('Xóa toàn bộ mẫu Calibration FT trên thiết bị này?'))return;watchState.calibration=[];watchCalWrite();qsigWrite('FT',[]);renderCalibration();showToast('ok','Đã xóa mẫu Calibration','Engine quay về ngưỡng mặc định 55 / 65 / 73 / 80.')});
  watchState.ticker=setInterval(updateWatchClock,1000);renderLiveWatch();


  /* ===== V1.11.5 PRO THEMES RUNG TAI H1 WATCH / CALIBRATION ENGINE ===== */
  const H1_WATCH_HISTORY_PREFIX='FE_H1_WATCH_V182_';
  const H1_WATCH_CAL_KEY='FE_H1_WATCH_CAL_V182';
  const H1_WATCH_MAX_ITEMS=5, H1_WATCH_PREFILTER_MAX=40, H1_WATCH_CAL_MAX=5000;
  const h1WatchState={active:false,refreshing:false,items:[],timer:null,ticker:null,nextAt:0,cycle:0,audio:null,lastPacket:'',calibration:null};

  function h1WatchEligible(f){
    const st=f?.fixture?.status?.short||'',m=Number(f?.fixture?.status?.elapsed);
    return feLiveSourceValid(f)&&['1H','LIVE'].includes(st)&&Number.isFinite(m)&&m>=20&&m<=45;
  }
  function cheapH1WatchRank(f){
    const m=Number(f?.fixture?.status?.elapsed||0),h=Number(f?.goals?.home||0),a=Number(f?.goals?.away||0),gap=Math.abs(h-a),tg=h+a;
    let s=0;
    s+=m>=28&&m<=40?30:m>=23&&m<=43?23:15;
    s+=gap===0?24:gap===1?20:gap===2?7:2;
    s+=tg===0?18:tg<=2?14:6;
    s+=f?.fixture?.status?.short==='1H'?10:5;
    return s;
  }
  function h1WatchPrefilterCap(){return H1_WATCH_PREFILTER_MAX}
  function h1WatchHistoryKey(id){return H1_WATCH_HISTORY_PREFIX+id}
  function h1WatchReadHistory(id){try{const x=JSON.parse(localStorage.getItem(h1WatchHistoryKey(id))||'[]');const cutoff=Date.now()-28*60*1000;return (Array.isArray(x)?x:[]).filter(s=>Number(s.captured_at)>=cutoff).slice(-90)}catch{return []}}
  function h1WatchWriteHistory(item){try{localStorage.setItem(h1WatchHistoryKey(item.id),JSON.stringify((item.history||[]).slice(-90)))}catch{}}

  function h1WatchMarketInfo(markets,history=null){
    const all=(markets||[]);
    const h1raw=all.filter(r=>{
      const nm=String(r.market||r.bet||'').toLowerCase();
      return r.category==='h1_total'||/first half.*(over|under|total)|1st half.*(over|under|total)|half time.*total|1h.*total/.test(nm);
    });
    const valid=h1raw.filter(r=>r.integrity?.valid!==false&&!r.status?.blocked&&!r.status?.stopped&&!r.status?.finished&&(r.values||[]).some(v=>!v.suspended));
    const best=watchBestOver(valid);
    const move=history?.categories?.h1_total||null;
    const fp=move?watchOverPriceFromMap(move.from_prices):null,tp=move?watchOverPriceFromMap(move.to_prices):null;
    const txt=xienMarketText(valid,true,3);
    return {
      raw_count:h1raw.length,valid_count:valid.length,invalid_count:Math.max(0,h1raw.length-valid.length),
      has_over:valid.length>0,best_over:best,history,
      move:{line_delta:move?.line_delta??null,from_line:move?.from_line??null,to_line:move?.to_line??null,
            over_price_delta:fp!=null&&tp!=null?Math.round((tp-fp)*1000)/1000:null,from_over_price:fp,to_over_price:tp},
      text:txt.join(' || ')||'Chưa có H1 Total hợp lệ',
      movement_text:move&&move.changed?movementCompactText({snapshot_count:history?.snapshot_count||0,categories:{h1_total:move}})||'':''
    };
  }

  function h1WatchSnapshotFromBundle(b,f){
    const m=b.meta,n=b.data||{},source=n.live_statistics||{},metrics=watchAggregate(source,m),stats_presence=watchStatsPresence(source,m),
          market=h1WatchMarketInfo(n.live_odds||[],n.live_market_movement||null),now=Date.now();
    return {captured_at:now,minute:Number(m.fixture?.status?.elapsed||0),status:m.fixture?.status?.short||'',
      goals:{home:Number(m.goals?.home||0),away:Number(m.goals?.away||0)},metrics,stats_presence,data_health:watchDataHealth(stats_presence,n.api_coverage||null),market,market_rows:n.live_odds||[],
      dq:b.coverage?.score||0,integrity:b.coverage?.integrity_score??null,events:n.events||[],fresh_at:now};
  }
  function h1WatchFindBaseline(item,cur,minutes){
    const rows=(item.history||[]).filter(s=>Number(s.captured_at)<Number(cur.captured_at)&&(!item.resetAt||s.captured_at>=item.resetAt));
    if(!rows.length)return null;
    const target=cur.captured_at-minutes*60000;let pick=rows[0],best=Infinity;
    for(const r of rows){const diff=Math.abs(Number(r.captured_at)-target);if(diff<best){pick=r;best=diff}}
    return pick;
  }
  function h1WatchWindow(item,cur,minutes){
    const base=h1WatchFindBaseline(item,cur,minutes);
    if(!base)return {mature:false,window_min:0,delta:{shots:0,sot:0,inbox:0,corners:0,xg:0,red:0},base:null};
    const win=Math.max(.1,(cur.captured_at-base.captured_at)/60000);
    return {mature:win>=Math.min(1,minutes*.4),window_min:Math.round(win*10)/10,delta:watchMetricDelta(cur,base),base};
  }
  function h1WatchHistoryAge(item,cur){
    const rows=(item.history||[]).filter(s=>Number(s.captured_at)<=Number(cur.captured_at)&&(!item.resetAt||Number(s.captured_at)>=Number(item.resetAt)));
    if(rows.length<2)return 0;
    const first=rows.reduce((a,b)=>Number(a.captured_at)<=Number(b.captured_at)?a:b);
    return Math.max(0,Math.round(((Number(cur.captured_at)-Number(first.captured_at))/60000)*10)/10);
  }
  function h1WatchDisplayWindow(item,cur,minutes){
    const age=h1WatchHistoryAge(item,cur);
    if(age<2)return {status:'baseline',target:minutes,age,window_min:0,delta:null};
    const w=h1WatchWindow(item,cur,minutes);
    if(!w.base)return {status:'baseline',target:minutes,age,window_min:0,delta:null};
    if(w.window_min>minutes*1.30)return {status:'gap',target:minutes,age,window_min:w.window_min,delta:null};
    const complete=w.window_min>=minutes*.80;
    return {status:complete?'complete':'partial',target:minutes,age,window_min:w.window_min,delta:w.delta};
  }
  function h1WatchDeltaLine(item,s,minutes,noStats=false){
    if(noStats)return `<div class="h1-delta-row na"><b>${minutes} PHÚT GẦN:</b> N/A • API không trả LIVE STATS để tính delta.</div>`;
    const w=h1WatchDisplayWindow(item,s,minutes);
    if(w.status==='baseline')return `<div class="h1-delta-row wait"><b>${minutes} PHÚT GẦN:</b> ĐANG TẠO BASELINE ${w.age.toFixed(1)}/2.0m tối thiểu.</div>`;
    if(w.status==='gap')return `<div class="h1-delta-row wait"><b>${minutes} PHÚT GẦN:</b> CHƯA CÓ SNAPSHOT LIÊN TỤC • không dùng dữ liệu cũ cách ${w.window_min.toFixed(1)}m.</div>`;
    const d=w.delta||{},tag=w.status==='complete'?'':` <span style="opacity:.75">(đang tích lũy ${w.window_min.toFixed(1)}/${minutes}m)</span>`;
    return `<div class="h1-delta-row"><b>${minutes} PHÚT GẦN:</b>${tag}<br>${esc(watchDeltaText(d,'shots','Shots'))} • ${esc(watchDeltaText(d,'sot','SOT'))} • ${esc(watchDeltaText(d,'inbox','InBox'))} • ${esc(watchDeltaText(d,'corners','Corners'))} • ${esc(watchDeltaText(d,'xg','xG',2))}</div>`;
  }

  function h1WatchGameScore(s){
    const m=Number(s.minute||0),h=Number(s.goals?.home||0),a=Number(s.goals?.away||0),gap=Math.abs(h-a),tg=h+a;let x=0;
    x+=m>=28&&m<=38?7:m>=39&&m<=42?6:m>=23&&m<=27?5:m>=43&&m<=44?4:m>=20&&m<=22?3:2;
    x+=gap===0?4:gap===1?3:gap===2?1:0;
    x+=tg<=1?3:tg<=2?2:1;
    x+=s.status==='1H'?1:0;
    return watchClamp(Math.round(x),0,15);
  }
  function h1WatchPressure(item,s){
    const w5=h1WatchWindow(item,s,5),w10=h1WatchWindow(item,s,10),m=Math.max(20,Number(s.minute||30)),t=s.metrics?.total||{};let x=0;
    const d=w5.mature?w5.delta:w10.delta,win=Math.max(1,w5.mature?w5.window_min:w10.window_min||5),scale=5/win;
    if(w5.mature||w10.mature){
      x+=watchClamp(d.shots*scale/4*6,0,6);
      x+=watchClamp(d.sot*scale/1.5*7,0,7);
      x+=watchClamp(d.inbox*scale/3*4,0,4);
      x+=watchClamp(d.corners*scale/1.5*2,0,2);
      if(Number(t.xg)>0)x+=watchClamp(d.xg*scale/.28*3,0,3);
    }else{
      const p=45/m;
      x+=watchClamp((Number(t.shots)||0)*p/9*5,0,5);
      x+=watchClamp((Number(t.sot)||0)*p/3.5*6,0,6);
      x+=watchClamp((Number(t.inbox)||0)*p/5.5*4,0,4);
      x+=watchClamp((Number(t.corners)||0)*p/4*2,0,2);
      if(Number(t.xg)>0)x+=watchClamp((Number(t.xg)||0)*p/1.05*3,0,3);
    }
    return {score:watchClamp(Math.round(x),0,22),w5,w10};
  }
  function h1WatchChance(item,s,p){
    const t=s.metrics?.total||{},shots=Math.max(1,Number(t.shots)||0),sot=Number(t.sot)||0,inbox=Number(t.inbox)||0,xg=Number(t.xg)||0,
          w=p?.w5?.mature?p.w5:p?.w10,d=w?.delta||{};let x=0;
    x+=watchClamp((sot/shots)/.40*4,0,4);
    x+=watchClamp((inbox/shots)/.60*3,0,3);
    if(xg>0)x+=watchClamp((xg/shots)/.12*4,0,4);
    if(w?.mature){
      const scale=5/Math.max(1,w.window_min);
      x+=watchClamp((Number(d.sot)||0)*scale/1.4*3,0,3);
      x+=watchClamp((Number(d.inbox)||0)*scale/2.8*2,0,2);
      if(xg>0)x+=watchClamp((Number(d.xg)||0)*scale/.28*4,0,4);
    }else x+=watchClamp(sot/3.5*2,0,2);
    return watchClamp(Math.round(x),0,20);
  }
  function h1WatchMomentum(item,s){
    const w3=h1WatchWindow(item,s,3),w6=h1WatchWindow(item,s,6);
    if(!w3.mature)return {score:5,mature:false,window_min:w3.window_min,delta:w3.delta,accel:0};
    const d=w3.delta,scale=3/Math.max(.5,w3.window_min);let x=0;
    x+=watchClamp(d.shots*scale/3*4,0,4);
    x+=watchClamp(d.sot*scale/1.15*6,0,6);
    x+=watchClamp((Number(d.inbox)||0)*scale/2.1*3,0,3);
    x+=watchClamp((Number(d.corners)||0)*scale/1.3*2,0,2);
    if(s.stats_presence?.xg===true)x+=watchClamp((Number(d.xg)||0)*scale/.20*3,0,3);
    let accel=0;
    if(w6.mature&&w6.base&&w3.base){
      const prev=watchMetricDelta(w3.base,w6.base),rw=Math.max(.5,(w3.base.captured_at-w6.base.captured_at)/60000),
            recentRate=(d.sot*2+d.shots*.35+d.xg*5)/Math.max(.5,w3.window_min),
            prevRate=(prev.sot*2+prev.shots*.35+prev.xg*5)/rw;
      accel=prevRate>0?(recentRate-prevRate)/prevRate:(recentRate>0?1:0);
      if(accel>.35)x+=2;else if(accel<-.4)x-=2;
    }
    return {score:watchClamp(Math.round(x),0,18),mature:w3.window_min>=1,window_min:w3.window_min,delta:d,accel:Math.round(accel*100)/100};
  }
  function h1WatchMarketScore(s){
    const m=s.market||{},mv=m.move||{};let x=0;
    if(m.has_over)x+=6;
    if(m.valid_count>=1)x+=1;
    const bo=m.best_over;
    if(bo&&bo.odd>=1.45&&bo.odd<=2.40)x+=3;else if(bo&&bo.odd>=1.30&&bo.odd<=2.60)x+=1;
    if(Number(mv.line_delta)>0)x+=4;
    else if(Number(mv.over_price_delta)<=-.05)x+=4;
    else if(Number(mv.over_price_delta)<=-.02)x+=2;
    else if(m.history?.snapshot_count>=2)x+=1;
    return {score:watchClamp(Math.round(x),0,15),available:m.valid_count>0,over_available:m.has_over,best_over:bo,movement:mv};
  }
  function h1WatchContextScore(s){
    const m=Number(s.minute||0),gap=Math.abs(Number(s.goals?.home||0)-Number(s.goals?.away||0));let x=0;
    x+=m>=25&&m<=39?2:m<=42?1:0;
    x+=gap<=1?1:0;
    x+=Number(s.metrics?.total?.red||0)===0?1:0;
    if((Number(s.metrics?.total?.sot)||0)>=2)x+=1;
    return watchClamp(x,0,5);
  }
  function h1WatchQualityScore(item,s){
    const dq=Number(item.initialDQ||s.dq||60),integ=Number(s.integrity??item.initialIntegrity??100);let x=watchClamp(Math.round(dq/25),0,4);if(integ>=85)x+=1;x=watchClamp(x,0,5);
    const p=s.stats_presence,age=(Date.now()-Number(s.fresh_at||Date.now()))/1000;if(p&&p.core===false)x=Math.min(x,p.pressure?2:1);else if(p&&p.coverage<3)x=Math.min(x,3);if(age>55)x=Math.min(x,1);return watchClamp(x,0,5)
  }
  function h1WatchCore(e){
    const dims=[
      {name:'PRESS',value:e.pressure,strong:13,weak:6},
      {name:'CHANCE',value:e.chance,strong:12,weak:6},
      {name:'MOM',value:e.momentum,strong:10,weak:4}
    ],available=dims.filter(x=>x.value!=null);
    if(available.length<2)return {available:false,complete:false,availableCount:available.length,strongCount:available.length?0:null,weakCount:available.length?0:null,pass:false,partialPass:false};
    const strongCount=available.filter(x=>Number(x.value)>=x.strong).length,weakCount=available.filter(x=>Number(x.value)<x.weak).length,complete=available.length===3;
    return {available:true,complete,availableCount:available.length,strongCount,weakCount,pass:complete&&strongCount>=2&&weakCount===0,partialPass:!complete&&strongCount>=2&&weakCount===0};
  }

  function h1WatchCalRead(){try{const x=JSON.parse(localStorage.getItem(H1_WATCH_CAL_KEY)||'[]');return Array.isArray(x)?x.slice(-H1_WATCH_CAL_MAX):[]}catch{return []}}
  function h1WatchCalWrite(){try{localStorage.setItem(H1_WATCH_CAL_KEY,JSON.stringify((h1WatchState.calibration||[]).slice(-H1_WATCH_CAL_MAX)))}catch{}}
  function h1WatchGoalTimes(events){
    return (events||[]).filter(e=>/goal/i.test(String(e.type||''))&&!/missed|disallow/i.test(String(e.detail||'')))
      .map(e=>Number(e.time)+(Number(e.extra)||0)/60).filter(Number.isFinite).sort((a,b)=>a-b);
  }
  function h1WatchCalibrationStats(){
    const rows=h1WatchState.calibration||[],r5=rows.filter(r=>typeof r.goal_5m==='boolean'),hit5=r5.filter(r=>r.goal_5m).length,
          rht=rows.filter(r=>typeof r.goal_before_ht==='boolean'),hitHt=rht.filter(r=>r.goal_before_ht).length,byTier={};
    for(const tier of ['WATCH','CANDIDATE','READY','STRONG']){
      const rr=r5.filter(r=>r.tier===tier);byTier[tier]={n:rr.length,rate:rr.length?rr.filter(x=>x.goal_5m).length/rr.length:null};
    }
    return {n:rows.length,resolved5:r5.length,hits5:hit5,rate5:r5.length?hit5/r5.length:0,resolvedHt:rht.length,hitsHt:hitHt,rateHt:rht.length?hitHt/rht.length:0,byTier};
  }
  function h1WatchLearnedStrong(){
    const rows=(h1WatchState.calibration||[]).filter(r=>typeof r.goal_5m==='boolean');
    if(rows.length<300)return {threshold:79,learned:false,n:rows.length};
    const base=rows.filter(r=>r.score>=54),baseRate=base.length?base.filter(r=>r.goal_5m).length/base.length:0,candidates=[];
    for(let t=76;t<=82;t++){const rr=rows.filter(r=>r.score>=t);if(rr.length<50)continue;const rate=rr.filter(r=>r.goal_5m).length/rr.length;if(rate>=baseRate*1.15)candidates.push({t,n:rr.length,rate})}
    if(!candidates.length)return {threshold:79,learned:false,n:rows.length,baseRate};
    const best=Math.max(...candidates.map(x=>x.rate)),near=candidates.filter(x=>x.rate>=best-.02).sort((a,b)=>a.t-b.t)[0];
    return {threshold:near.t,learned:true,n:rows.length,rate:near.rate,baseRate};
  }
  function h1WatchThresholds(){
    const shadow=h1WatchLearnedStrong();
    return {watch:54,candidate:64,ready:72,strong:79,learned:{...shadow,shadow_only:true,active_threshold:79}}
  }
  function h1WatchTier(score){const t=h1WatchThresholds();return score>=t.strong?'STRONG':score>=t.ready?'READY':score>=t.candidate?'CANDIDATE':score>=t.watch?'WATCH':'LOW'}

  function h1WatchCalSettle(item,s,ended=false){
    const rows=h1WatchState.calibration||[],gNow=Number(s?.goals?.home||0)+Number(s?.goals?.away||0),goalTimes=h1WatchGoalTimes(s?.events||[]);let changed=false;
    for(const r of rows){
      if(Number(r.fixture_id)!==Number(item.id))continue;
      if(r.goal_before_ht!==null&&r.goal_3m!==null&&r.goal_5m!==null&&r.goal_10m!==null)continue;
      let first=goalTimes.find(m=>m>Number(r.minute));
      if(first==null&&gNow>Number(r.goals_total||0))first=Number(s.minute||r.minute)+0.01;
      if(first!=null){
        r.first_goal_min=r.first_goal_min??first;
        for(const h of [3,5,10])if(r[`goal_${h}m`]===null||r[`goal_${h}m`]===undefined)r[`goal_${h}m`]=(first-Number(r.minute))<=h;
        r.goal_before_ht=true;changed=true;
      }
      for(const h of [3,5,10]){
        if((r[`goal_${h}m`]===null||r[`goal_${h}m`]===undefined)&&Number(s.minute)>=Number(r.minute)+h){r[`goal_${h}m`]=false;changed=true}
      }
      if(ended){
        for(const h of [3,5,10])if(r[`goal_${h}m`]===null||r[`goal_${h}m`]===undefined){r[`goal_${h}m`]=false;changed=true}
        if(r.goal_before_ht===null||r.goal_before_ht===undefined){r.goal_before_ht=gNow>Number(r.goals_total||0);changed=true}
      }
    }
    if(changed)h1WatchCalWrite();
  }
  function h1WatchCalRecord(item,s){
    const e=item.eval||{},t=h1WatchThresholds();
    if(e.scoreMode!=='FULL'||e.score<t.watch||e.hardVeto||['BASELINE','COOLDOWN','ENDED','STALE'].includes(item.state))return;
    const rows=h1WatchState.calibration||[],last=[...rows].reverse().find(r=>Number(r.fixture_id)===Number(item.id));
    if(last&&Date.now()-Number(last.captured_at)<45000&&last.tier===h1WatchTier(e.score))return;
    const bo=s.market?.best_over||null;
    rows.push({id:`H1-${item.id}-${s.captured_at}`,fixture_id:item.id,league:item.league,home:item.home,away:item.away,
      captured_at:s.captured_at,minute:Number(s.minute||0),goals_total:Number(s.goals?.home||0)+Number(s.goals?.away||0),
      score:e.score,tier:h1WatchTier(e.score),core:e.core?.strongCount??0,pressure:e.pressure,chance:e.chance,momentum:e.momentum,
      game:e.game,market:e.market,context:e.context,dq:item.initialDQ||0,d5:e.recent5?.delta||null,d10:e.recent10?.delta||null,
      h1_over_line:bo?.line??null,h1_over_odd:bo?.odd??null,goal_3m:null,goal_5m:null,goal_10m:null,goal_before_ht:null,first_goal_min:null});
    h1WatchState.calibration=rows.slice(-H1_WATCH_CAL_MAX);h1WatchCalWrite();
  }

  function h1WatchEvaluate(item,s){
    const game=h1WatchGameScore(s),pr=h1WatchPressure(item,s),rawChance=h1WatchChance(item,s,pr),mom=h1WatchMomentum(item,s),mk=h1WatchMarketScore(s),context=h1WatchContextScore(s),quality=h1WatchQualityScore(item,s),baselineAge=h1WatchHistoryAge(item,s),presence=s.stats_presence||null,veto=[],warnings=[];
    const statTotal=(Number(s.metrics?.total?.shots)||0)+(Number(s.metrics?.total?.sot)||0)+(Number(s.metrics?.total?.inbox)||0)+(Number(s.metrics?.total?.corners)||0)+(Number(s.metrics?.total?.xg)||0),noStats=presence?presence.pressure===false:(Number(s.minute)>=25&&statTotal===0),partialStats=presence?presence.pressure===true&&presence.core===false:false,baselineIncomplete=baselineAge<2;
    if(noStats)veto.push('NO_H1_LIVE_STATS');else if(partialStats)warnings.push('H1_PARTIAL_LIVE_STATS');if(s.market?.raw_count>0&&s.market?.valid_count===0)veto.push('H1_MARKET_INTEGRITY_INVALID');
    let pressure=pr.score,chance=rawChance,momentum=mom.score,scoreMode='FULL';
    if(noStats){pressure=null;chance=null;momentum=null;scoreMode='DATA_INCOMPLETE'}
    else if(baselineIncomplete){pressure=null;chance=null;momentum=null;scoreMode='BASELINE'}
    else if(partialStats){pressure=presence?.pressure?pr.score:null;chance=presence?.chance?rawChance:null;momentum=presence?.momentum?mom.score:null;scoreMode='PARTIAL_STATS'}
    const core=h1WatchCore({pressure,chance,momentum}),rawScore=watchClamp(game+pr.score+rawChance+mom.score+mk.score+context+quality,0,100),partialRaw=watchClamp(game+(pressure??0)+(chance??0)+(momentum??0)+mk.score+context+quality,0,100),score=scoreMode==='FULL'?rawScore:scoreMode==='PARTIAL_STATS'?Math.min(68,partialRaw):watchClamp(game+mk.score+context+quality,0,100),recent3=h1WatchDisplayWindow(item,s,3),recent5d=h1WatchDisplayWindow(item,s,5),recent10d=h1WatchDisplayWindow(item,s,10);
    return {score,rawScore,partialRaw,scoreMode,dataIncomplete:['DATA_INCOMPLETE','BASELINE'].includes(scoreMode),partialData:scoreMode==='PARTIAL_STATS',game,pressure,chance,momentum,market:mk.score,context,quality,mature:mom.mature,delta:mom.delta,window_min:mom.window_min,accel:mom.accel,recent3,recent5:recent5d,recent10:recent10d,pressure5:pr.w5,pressure10:pr.w10,core,baselineAge,stats_presence:presence,market_available:mk.available,over_available:mk.over_available,best_over:mk.best_over,market_movement:mk.movement,hardVeto:veto.length>0,vetoReasons:veto,dataWarnings:warnings}
  }
  function h1WatchResetEvent(prev,s){
    if(!prev)return null;
    const pg=(Number(prev.goals?.home)||0)+(Number(prev.goals?.away)||0),cg=(Number(s.goals?.home)||0)+(Number(s.goals?.away)||0);
    if(cg>pg)return 'GOAL';
    const pr=Number(prev.metrics?.total?.red||0),cr=Number(s.metrics?.total?.red||0);if(cr>pr)return 'RED_CARD';
    return null;
  }
  function h1WatchWhy(item,s,e){
    const good=[],bad=[],d5=e.recent5?.delta||{},d10=e.recent10?.delta||{},bo=e.best_over,mv=e.market_movement||{},m=Number(s.minute||0),remaining=Math.max(0,45-m),baselineAge=Number(e.baselineAge||0);
    if(e.scoreMode==='DATA_INCOMPLETE')bad.push('H1 LIVE STATS không có • core không thể tính');if(e.scoreMode==='PARTIAL_STATS')bad.push(`PARTIAL H1 STATS • ${watchHealthLabel(s.data_health)} • cap 68 • không nâng READY/STRONG`);if(e.scoreMode==='BASELINE'||baselineAge<2)bad.push(`Đang tạo baseline ${baselineAge.toFixed(1)}/2.0m • chưa phát signal`);
    if(e.scoreMode==='FULL'||e.scoreMode==='PARTIAL_STATS'){if(e.recent5?.status==='complete'&&Number(d5.sot)>=2)good.push(`+${d5.sot} SOT / ~5m`);if(e.recent10?.status==='complete'&&Number(d10.xg)>=.22)good.push(`ΔxG10 +${Math.round(Number(d10.xg)*100)/100}`);if(e.recent5?.status==='complete'&&Number(d5.inbox)>=3)good.push(`+${d5.inbox} InBox / ~5m`);if(e.accel>=.35)good.push('Momentum H1 đang tăng tốc');if(e.core?.pass)good.push(`CORE ${e.core.strongCount}/3 đạt`);if(e.mature&&Number(d5.sot)===0)bad.push(`${e.recent5.window_min||5}m chưa có SOT`);if(e.recent10?.status==='complete'&&Number(d10.xg)<.07&&(Number(s.metrics?.total?.xg)||0)>0)bad.push('ΔxG10 thấp');if(e.momentum!=null&&e.momentum<5)bad.push('Momentum H1 yếu/đang giảm');if(e.core?.available&&e.core?.weakCount)bad.push(`CORE có ${e.core.weakCount} trụ quá yếu`)}
    if(m>=28&&m<=42)good.push(`Phút ${m} • còn khoảng ${remaining}m + bù giờ`);if(Number(mv.line_delta)>0)good.push(`H1 Total line ↑ +${mv.line_delta}`);else if(Number(mv.over_price_delta)<=-.02)good.push(`Giá Tài H1 giảm ${Math.abs(mv.over_price_delta).toFixed(2)}`);if(bo)good.push(`Tài H1 ${bo.line??'?'} @${bo.odd.toFixed(2)}`);if(m>=43)bad.push('Đã sát HT • thời gian còn lại ngắn');if(!e.market_available)bad.push('Chưa có H1 Total hợp lệ');if(e.hardVeto)bad.push(...e.vetoReasons);return {good:good.slice(0,6),bad:[...new Set(bad)].slice(0,5)}
  }
  function h1WatchApplyState(item,s,ev){
    const now=Date.now(),t=h1WatchThresholds();if(ev){item.resetAt=now;item.cooldownUntil=now+(ev==='GOAL'?2:3)*60000;item.lowStreak=0;item.state='COOLDOWN';item.reason=`${ev==='GOAL'?'Vừa có bàn H1':'Vừa có thẻ đỏ'} • reset momentum H1`;item.history=[s];h1WatchWriteHistory(item);return}
    if(item.cooldownUntil&&now<item.cooldownUntil){item.state='COOLDOWN';item.reason=`Cooldown H1 còn ${Math.ceil((item.cooldownUntil-now)/60000)} phút`;return}const e=item.eval||{},fresh=(now-(s.fresh_at||now))/1000<=55;
    if(!fresh){item.state='STALE';item.reason='Dữ liệu H1 >55s • tín hiệu bị vô hiệu cho đến khi refresh thành công';return}if(e.hardVeto){const noStats=e.vetoReasons?.includes('NO_H1_LIVE_STATS');if(noStats&&Number(item.dataMissStreak||0)<3){item.state='DATA_WAIT';item.reason=`DATA WAIT ${Number(item.dataMissStreak||0)}/3 • ${watchHealthLabel(s.data_health)}`;return}item.state='CANCELLED';item.reason=`DATA INCOMPLETE • ${e.vetoReasons.join(', ')}`;return}if(Number(s.minute)>45||!['1H','LIVE'].includes(s.status)){item.state='ENDED';item.reason='H1 đã kết thúc';return}if(Number(e.baselineAge||0)<2){item.state='BASELINE';item.reason=`Đang tạo baseline ${Number(e.baselineAge||0).toFixed(1)}/2.0 phút • chưa phát signal`;return}
    if(e.scoreMode==='PARTIAL_STATS'){if(e.score>=t.candidate&&e.core?.available&&e.core?.partialPass){item.state='PARTIAL_CANDIDATE';item.reason=`PARTIAL CANDIDATE H1 ${e.score}/68 • dùng ${e.core.availableCount}/3 trụ • confidence thấp hơn`;return}if(e.score>=t.watch){item.state='PARTIAL_WATCH';item.reason=`PARTIAL WATCH H1 ${e.score}/68 • ${watchHealthLabel(s.data_health)}`;return}item.state='DATA_PARTIAL';item.reason=`DATA PARTIAL H1 ${e.score}/68 • ${watchHealthLabel(s.data_health)}`;return}
    item.peak=Math.max(Number(item.peak||0),Number(e.score||0));if(item.peak>=t.ready&&e.score<58){item.lowStreak=(item.lowStreak||0)+1;if(item.lowStreak>=2){item.state='CANCELLED';item.reason='Pressure H1 giảm rõ 2 snapshot sau khi từng READY';return}}else item.lowStreak=0;
    if(e.score>=t.strong&&e.core?.available&&e.core?.pass&&e.mature&&e.market_available){item.state='STRONG';item.reason=`STRONG H1 ${e.score} • CORE ${e.core.strongCount}/3 • market H1 xác nhận`;return}if(e.score>=t.ready&&e.core?.available&&e.core?.strongCount>=2){item.state='READY';item.reason=e.market_available?`READY H1 ${e.score} • CORE ${e.core.strongCount}/3`:`READY về bóng H1 • CHỜ MARKET`;return}if(e.score>=t.candidate){item.state='CANDIDATE';item.reason=`Candidate H1 ${e.score} • CORE ${e.core?.strongCount??0}/3`;return}if(e.score>=t.watch){item.state='WATCH';item.reason='Đáng canh H1 nhưng chưa đủ đồng thuận';return}item.state='LOW';item.reason='Điểm H1 thấp • chưa đáng canh'
  }
  function h1WatchAlert(item,oldState,ev){
    if(ev){showToast('err',`${ev==='GOAL'?'GOAL H1':'RED CARD'} • reset RUNG H1`,`${item.home} vs ${item.away} • tín hiệu cũ bị hủy.`);return}
    if(item.state==='STRONG'&&oldState!=='STRONG'){showToast('ok','STRONG H1 SIGNAL',`${item.home} vs ${item.away} • ${item.eval?.score||'-'}/100 • CORE ${item.eval?.core?.strongCount||0}/3.`);h1WatchBeep()}
    else if(item.state==='READY'&&!['READY','STRONG'].includes(oldState))showToast('ok','RUNG H1 READY',`${item.home} vs ${item.away} • ${item.eval?.score||'-'}/100.`)
    else if(item.state==='CANCELLED'&&oldState!==item.state)showToast('err','RUNG H1 hủy tín hiệu',`${item.home} vs ${item.away} • ${item.reason||'áp lực giảm'}`);
  }
  function h1WatchBeep(){
    if(!$('h1WatchSound')?.checked)return;
    try{const ctx=h1WatchState.audio;if(!ctx)return;const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=980;g.gain.setValueAtTime(.0001,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.14,ctx.currentTime+.02);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.28);o.connect(g);g.connect(ctx.destination);o.start();o.stop(ctx.currentTime+.3)}catch{}
  }
  function h1WatchInitAudio(){try{if(!h1WatchState.audio)h1WatchState.audio=new (window.AudioContext||window.webkitAudioContext)();h1WatchState.audio.resume?.()}catch{}}

  async function fetchH1WatchSnapshot(item,forceMarket=false,fixtureHint=null){
    const hb=fixtureHint?null:await ultraHeartbeat(false),f=fixtureHint||hb?.map?.get(String(item.id));
    if(!f)return {ended:true,f:null,meta:null};
    const meta=compactFixtureMeta(f,autoModeForFixture(f)),st=f.fixture?.status?.short||'',min=Number(f.fixture?.status?.elapsed||0);
    if(!isLive(f)||!['1H','LIVE'].includes(st)||min>45)return {ended:true,f,meta};
    const u=await ultraLiveRaw(f,item,'H1',forceMarket),rawStats=u.statsRaw||[],rawEvents=u.eventsRaw||[],liveOdds=u.liveOdds.slice(0,40),
          marketHistory=saveLiveOddsSnapshot(item.id,{fixture:f.fixture,goals:f.goals},liveOdds),
          marketTime=await mtBuildShadow(item,f,u.rawOdds||[],'H1',u.freshness?.market_content_age??null),
          marketExpectation=await meBuildShadow(item,marketTime,'H1'),
          fullMap=statMap(rawStats),metrics=watchAggregate(fullMap,meta),stats_presence=watchStatsPresence(fullMap,meta);
    item.lastMarketAt=u.marketAt||Date.now();item.lastMarketRows=liveOdds;
    return {captured_at:Date.now(),minute:min,status:st,goals:{home:Number(f.goals?.home||0),away:Number(f.goals?.away||0)},metrics,stats_presence,
      data_health:watchDataHealth(stats_presence,item.apiCoverage||null),market:h1WatchMarketInfo(liveOdds,marketHistory),market_rows:liveOdds,
      dq:item.initialDQ||0,integrity:item.initialIntegrity??null,events:eventsCompact(rawEvents).slice(-40),fresh_at:u.statsAt||Date.now(),fixture:f,
      hub_tier:u.tier,content_freshness:u.freshness,personnel:u.personnel,market_time:marketTime,market_expectation:marketExpectation,source:'ULTRA_HUB'};
  }

  function h1InitialEval(item,s){item.eval=h1WatchEvaluate(item,s);item.peak=item.eval.score;h1WatchApplyState(item,s,null);qsigUpdateH1(item,s,null,false);grTrack(item,'H1');item.reason+=' • baseline H1 ban đầu'}
  function renderH1Calibration(){
    const st=h1WatchCalibrationStats(),l=h1WatchLearnedStrong(),qs=qsigStats('H1'),el=$('h1WatchCalibration');$('h1WatchCalCount').textContent=String(qs.n);
    if(!el)return;
    const tiers=['WATCH','CANDIDATE','READY','STRONG'].map(k=>{const x=st.byTier[k];return x.n?`${k} n=${x.n}: ${(x.rate*100).toFixed(1)}%/5m`:null}).filter(Boolean).join(' • ');
    el.innerHTML=`<b>V1.16.2 FIXED BENCHMARK H1:</b> Qualified waves n=${qs.n} • High ${qs.high} • Open ${qs.open}<br><span class="tiny">H1: 20–42' • Score ≥72 • FULL • DQ ≥4/5 • fresh ≤20s • Evidence ≤120s • CORE ≥2/3 • recent Chance • SUSTAINED/ACCELERATING. HIGH: Score ≥79 • CORE 3/3 • Evidence ≤90s • market.</span>`;
  }
  function renderH1Watch(){
    const list=$('h1WatchList'),items=h1WatchState.items||[];$('h1WatchCount').textContent=String(items.length);$('h1WatchApiUsage').textContent=String(apiUsageSnapshot().network_calls||0);renderH1Calibration();if(!items.length){feLivePatchHTML(list,'<div class="watch-alert-note"><b>Chưa có H1 watchlist.</b> Quét LIVE rồi bấm CANH TOP 5 H1. Engine nhận trận 1H khoảng phút 20–45.</div>');$('h1WatchPacketActions').classList.add('hidden');return}$('h1WatchPacketActions').classList.remove('hidden');
    feLivePatchHTML(list,items.map((it,i)=>{const s=it.latest||{},e=it.eval||{},cls=watchStateClass(it.state),market=s.market?.text||'Chưa có H1 market',fresh=Math.max(0,Math.round((Date.now()-(s.fresh_at||Date.now()))/1000)),qa=qsigAssessH1(it,s),why=h1WatchWhy(it,s,e),good=why.good.length?why.good.join(' • '):'Chưa có tín hiệu tăng tốc H1 nổi bật',bad=why.bad.length?why.bad.join(' • '):'Chưa thấy yếu tố phủ định mạnh',mv=s.market?.movement_text||'',core=e.core||{},remain=Math.max(0,45-Number(s.minute||0)),mode=e.scoreMode||'FULL',noStats=e.vetoReasons?.includes('NO_H1_LIVE_STATS'),flag=mode==='DATA_INCOMPLETE'?'DATA INCOMPLETE':mode==='BASELINE'?'BASELINE':mode==='PARTIAL_STATS'?'PARTIAL DATA':'',coreHtml=mode==='PARTIAL_STATS'?(core.available?`<b>CORE PARTIAL ${core.availableCount}/3:</b> <span class="${core.partialPass?'pass':'fail'}">${core.strongCount}/${core.availableCount} ${core.partialPass?'PASS PARTIAL':'chưa đủ'}</span> • trụ thiếu hiển thị N/A`:`<b>CORE PARTIAL:</b> <span class="data-guard-na">${core.availableCount||0}/3 trụ có dữ liệu</span>`):!core.available?`<b>CORE:</b> <span class="data-guard-na">${mode==='BASELINE'?'WAIT • đang tạo baseline':`N/A • ${watchHealthLabel(s.data_health)}`}</span>`:`<b>CORE 2/3:</b> <span class="${core.pass?'pass':'fail'}">${core.strongCount}/3 ${core.pass?'PASS':'chưa đủ'}</span> • Pressure / Chance / Momentum`;
      const sv=feScoreVisual('H1',e.score,it.state);
      return `<div class="watch-ticket ${cls}" data-fe-live-key="${esc(it.id)}"><div class="watch-head"><div class="watch-name"><b>#${i+1} ${esc(it.home)} vs ${esc(it.away)}</b><span>${esc(it.league||'')} • H1 ${esc(s.minute??'-')}' • ${esc(s.goals?.home??'-')}-${esc(s.goals?.away??'-')} • còn ~${esc(remain)}m + bù giờ • Fixture #${esc(it.id)}</span></div><span class="watch-badge ${cls}">${esc(watchStateText(it.state))}</span></div>${grHTML(it,'H1')}<div class="watch-score-row ${sv.cls}"><div class="watch-score">${esc(e.score??'-')}<small>/100</small>${flag?`<span class="watch-score-flag ${mode==='PARTIAL_STATS'?'partial':''}">${flag}</span>`:''}<span class="fe-score-zone ${sv.cls} ${sv.qualified?'':'unqualified'}">${esc(sv.display)}</span></div><div class="watch-bar visual-threshold"><i class="${sv.cls}" style="width:${watchClamp(Number(e.score)||0,0,100)}%"></i></div><div class="watch-fresh ${fresh>55?'stale':''}" data-h1-watch-fresh="${esc(s.fresh_at||0)}">${fresh>55?'STALE ':'fresh '}${fresh}s</div></div>${qsigBadgeHTML(qa)}<div class="watch-components v181"><div class="watch-comp"><span>GAME</span><b>${esc(e.game??'-')}/15</b></div><div class="watch-comp"><span>PRESS</span><b>${e.pressure==null?'N/A':esc(e.pressure)+'/22'}</b></div><div class="watch-comp"><span>CHANCE</span><b>${e.chance==null?'N/A':esc(e.chance)+'/20'}</b></div><div class="watch-comp"><span>MOM</span><b>${e.momentum==null?'N/A':esc(e.momentum)+'/18'}</b></div><div class="watch-comp"><span>H1 MKT</span><b>${esc(e.market??'-')}/15</b></div><div class="watch-comp"><span>CLOCK</span><b>${esc(e.context??'-')}/5</b></div><div class="watch-comp"><span>DQ</span><b>${esc(e.quality??'-')}/5</b></div></div><div class="watch-core ${!core.available?'na':''}">${coreHtml}</div><div class="h1-delta-grid">${h1WatchDeltaLine(it,s,3,noStats)}${h1WatchDeltaLine(it,s,5,noStats)}${h1WatchDeltaLine(it,s,10,noStats)}<div class="h1-delta-row ${['DATA_INCOMPLETE','BASELINE'].includes(mode)?'data-guard-box':''}"><b>ENGINE:</b> ${esc(it.reason||'')}</div></div><div class="watch-why"><div class="watch-why-box good"><b>WHY NOW</b>${esc(good)}</div><div class="watch-why-box bad"><b>WHY NOT / RỦI RO</b>${esc(bad)}</div></div>${fmdHTML(s.final_model_decision)}${mtIntelHTML(s,'H1')}<details class="mt-model-details"><summary>MODEL DETAILS</summary>${gpShadowHTML(s.goal_potential,'H1')}${meShadowHTML(s.market_expectation)}${lvmShadowHTML(s.live_vs_market)}${lpvShadowHTML(s.line_price_value)}<div class="watch-market"><strong>H1 LIVE MARKET:</strong> ${esc(market)}${mv?`<div class="watch-market-move">${esc(mv)}</div>`:''}</div>${mtShadowHTML(s.market_time,'H1')}</details></div>`}).join(''))
  }
  function h1WatchNextInterval(){if(h1WatchState.items.some(x=>['STRONG','READY'].includes(x.state)))return 10000;if(h1WatchState.items.some(x=>x.state==='CANDIDATE'))return 15000;return 22000}
  function scheduleH1Watch(){
    clearTimeout(h1WatchState.timer);
    if(feWorkspaceAutoStopIfDone('H1'))return;
    if(!h1WatchState.active||!$('h1WatchAuto')?.checked){h1WatchState.nextAt=0;updateH1WatchClock();return}
    const ms=h1WatchNextInterval();
    h1WatchState.nextAt=Date.now()+ms;h1WatchState.timer=setTimeout(()=>refreshH1Watch(true),ms);updateH1WatchClock();
  }
  function updateH1WatchClock(){
    let becameStale=false;
    document.querySelectorAll('[data-h1-watch-fresh]').forEach(el=>{
      const ts=Number(el.dataset.h1WatchFresh||0);
      if(!ts)return;
      const age=Math.max(0,Math.round((Date.now()-ts)/1000));
      el.textContent=age>55?`STALE ${age}s`:`fresh ${age}s`;
      el.classList.toggle('stale',age>55);
    });
    for(const it of (h1WatchState.items||[])){
      const s=it.latest||{},age=s.fresh_at?Math.max(0,(Date.now()-Number(s.fresh_at))/1000):999;
      if(age>55&&!['ENDED','STALE'].includes(it.state)){
        it.state='STALE';
        it.reason=`Dữ liệu H1 stale ${Math.round(age)}s • mọi tín hiệu trước đó bị vô hiệu`;
        becameStale=true;
      }
    }
    if(becameStale)renderH1Watch();
    const c=$('h1WatchCountdown');if(!c)return;c.textContent=h1WatchState.nextAt?`${Math.max(0,Math.ceil((h1WatchState.nextAt-Date.now())/1000))}s`:(h1WatchState.active?'PAUSE':'—');
    $('h1WatchApiUsage').textContent=String(apiUsageSnapshot().network_calls||0);
  }
  async function refreshH1Watch(quiet=false){
    if(h1WatchState.refreshing||!h1WatchState.items.length)return;
    if(document.visibilityState!=='visible'&&quiet){scheduleH1Watch();return}
    h1WatchState.refreshing=true;clearTimeout(h1WatchState.timer);h1WatchState.nextAt=0;status($('h1WatchStatus'),`ULTRA HUB • cập nhật ${h1WatchState.items.length} fixture H1...`,'busy');
    try{
      const hb=await ultraHeartbeat(!quiet);
      await mapLimit(h1WatchState.items,4,async(item)=>{
        if(item.state==='ENDED')return item;const oldState=item.state,prev=item.latest,f=hb.map.get(String(item.id));
        try{
          const s=await fetchH1WatchSnapshot(item,!quiet,f);
          if(s.ended){const endF=s.f||f||{},endedSnap={...(item.latest||{}),minute:Number(endF.fixture?.status?.elapsed||item.latest?.minute||45),goals:{home:Number(endF.goals?.home??item.latest?.goals?.home??0),away:Number(endF.goals?.away??item.latest?.goals?.away??0)},events:item.latest?.events||[]};h1WatchCalSettle(item,endedSnap,true);qsigUpdateH1(item,endedSnap,null,true);item.state='ENDED';item.reason='H1 đã kết thúc';bgUnregisterFixtureIds([item.id],true).catch(()=>{});return item}
          const staleGap=prev?.captured_at&&(Number(s.captured_at)-Number(prev.captured_at)>70000),ev=h1WatchResetEvent(prev,s);
          item.latest=s;item.dataHealth=s.data_health||watchDataHealth(s.stats_presence,item.apiCoverage||null);item.dataMissStreak=item.dataHealth?.level==='NO_STATS'?(Number(item.dataMissStreak||0)+1):0;
          if(staleGap&&!ev){item.resetAt=s.captured_at;item.history=[s];item.lowStreak=0;item.peak=0}else item.history=(item.history||[]).concat([s]).slice(-90);
          item.eval=h1WatchEvaluate(item,s);grTrack(item,'H1');s.goal_potential=await gpBuildShadow(item,s,item.eval,'H1');s.live_vs_market=await lvmBuildShadow(item,s.goal_potential,s.market_expectation,'H1');s.line_price_value=await lpvBuildShadow(item,s.market_time,s.goal_potential,s.market_expectation,s.live_vs_market,'H1');s.robustness=await rbBuildShadow(item,s.goal_potential,s.market_expectation,s.live_vs_market,s.line_price_value,'H1');s.final_model_decision=await fmdBuildShadow(item,s,'H1');s.validation=await valUpdate(item,s,'H1');await fmdAttachValidationT0(item,s);s.decision_journal=await fmdJournalUpdate(item,s,s.final_model_decision,'H1');await fmdBenchmarkRefresh(false);evidenceMaybeRefresh();h1WatchCalSettle(item,s,false);h1WatchApplyState(item,s,ev);qsigUpdateH1(item,s,ev,false);
          if(staleGap&&!ev){item.state='BASELINE';item.reason='Vừa khôi phục sau DATA STALE • reset lịch sử cũ và tạo baseline mới 0.0/2.0 phút'}
          h1WatchCalRecord(item,s);h1WatchWriteHistory(item);h1WatchAlert(item,oldState,ev)
        }catch(e){item.state='STALE';item.reason='API/HUB H1 lỗi: '+e.message;log('H1 Watch fixture error',{id:item.id,error:e.message})}
        return item
      });
      h1WatchState.items=h1WatchState.items.filter(x=>x.state!=='ENDED'&&(x.dataHealth?.level!=='NO_STATS'||Number(x.dataMissStreak||0)<3));
      h1WatchState.items.sort((a,b)=>(Number(b.latest?.data_health?.priority||0)-Number(a.latest?.data_health?.priority||0))||(Number(b.eval?.score||-1)-Number(a.eval?.score||-1)));
      h1WatchState.cycle++;renderH1Watch();const strong=h1WatchState.items.filter(x=>x.state==='STRONG').length,ready=h1WatchState.items.filter(x=>x.state==='READY').length,cand=h1WatchState.items.filter(x=>x.state==='CANDIDATE').length;
      status($('h1WatchStatus'),`RUNG H1 • ${strong} STRONG • ${ready} READY • ${cand} CANDIDATE • ${ultraHubSummary()}`,'ok')
    }finally{h1WatchState.refreshing=false;scheduleH1Watch()}
  }
  function h1WatchBundleScore(b,f){
    const item={id:b.meta?.fixture_id,initialDQ:b.coverage?.score||0,initialIntegrity:b.coverage?.integrity_score??100,history:[]},
          s=h1WatchSnapshotFromBundle(b,f);item.latest=s;item.history=[s];const e=h1WatchEvaluate(item,s);
    return {...e,rank:e.score+e.core.strongCount*2};
  }
  async function startH1Watch(){
    const feIsolationSnap=feCaptureOtherEngines('H1');
    h1WatchInitAudio();
    // V1.16.3: H1 / FT / HANDICAP may run together; ULTRA HUB dedupes shared fixture calls.
    if(!els.fkey.value.trim()){showToast('err','Chưa có Football API Key','Lưu API key trước.');return}
    let all=[];try{all=await feWorkspaceScanFixtures('H1')}catch(e){showToast('err','H1 scan lỗi',e.message);return}
    h1WatchState.sourceFixtureIds=all.map(f=>Number(f?.fixture?.id)).filter(Number.isFinite);
    if(!all.length){showToast('err','Không có H1 phù hợp','H1 workspace vừa quét LIVE độc lập nhưng chưa có trận phút 20–45 phù hợp.');return}
    const cap=h1WatchPrefilterCap(),pref=[...all].sort((a,b)=>cheapH1WatchRank(b)-cheapH1WatchRank(a)).slice(0,cap);
    loading(true,'Đang sàng lọc H1 độc lập',`0/${pref.length} fixture • chọn TOP 5`);status($('h1WatchStatus'),`H1 workspace • screening ${pref.length}/${all.length} trận • FT/Handicap giữ nguyên...`,'busy');
    try{
      const bundles=await mapLimit(pref,4,getGroupBundle,(done,n,f)=>{els.loadingText.textContent=`H1 ${done}/${n} • ${f?.teams?.home?.name||''} vs ${f?.teams?.away?.name||''}`});
      const screened=await watchSelectUsableBundles(bundles,pref,'H1',H1_WATCH_MAX_ITEMS,h1WatchBundleScore,'H1 STATS'),ranked=screened.selected,hs=screened.summary;
      h1WatchState.items=ranked.map(({b,f,health})=>{
        const s=h1WatchSnapshotFromBundle(b,f),old=h1WatchReadHistory(b.meta.fixture_id).filter(x=>x.captured_at>=Date.now()-28*60000),
              item={id:Number(b.meta.fixture_id),home:b.meta.teams?.home?.name||'',away:b.meta.teams?.away?.name||'',
                league:`${b.meta.league?.name||''}${b.meta.league?.country?' | '+b.meta.league.country:''}`,
                home_id:b.meta.teams?.home?.id,away_id:b.meta.teams?.away?.id,initialDQ:b.coverage?.score||0,
                initialIntegrity:b.coverage?.integrity_score??100,apiCoverage:b.data?.api_coverage||null,dataHealth:health,dataMissStreak:health?.level==='NO_STATS'?1:0,history:old.concat([s]).slice(-90),latest:s,state:'WATCH',reason:'',
                lowStreak:0,peak:0,lastMarketRows:b.data?.live_odds||[],lastMarketAt:Date.now(),resetAt:null,cooldownUntil:0};
        h1InitialEval(item,s);h1WatchCalSettle(item,s,false);h1WatchCalRecord(item,s);h1WatchWriteHistory(item);return item;
      });
      h1WatchState.items.sort((a,b)=>(Number(b.latest?.data_health?.priority||0)-Number(a.latest?.data_health?.priority||0))||(Number(b.eval?.score||0)-Number(a.eval?.score||0)));h1WatchState.active=h1WatchState.items.length>0;h1WatchState.cycle=0;renderH1Watch();
      $('h1WatchCard')?.scrollIntoView({behavior:'smooth',block:'start'});
      const t=h1WatchThresholds();status($('h1WatchStatus'),`H1 STATS HEALTH • HEALTHY ${hs.healthy} • PARTIAL ${hs.partial} • NO STATS ${hs.no_stats} • retry ${hs.retried}${hs.recovered?` / recovered ${hs.recovered}`:''}. TOP ${h1WatchState.items.length} ưu tiên HEALTHY; PARTIAL vẫn được tính các trường có thật (cap 68, không READY/STRONG); NO STATS bị loại. Ngưỡng ${t.watch}/${t.candidate}/${t.ready}/${t.strong}.`,'ok');
      if(h1WatchState.active){scheduleH1Watch();bgRegisterItems(h1WatchState.items,'H1').catch(()=>{})}showToast('ok','H1 STATS HEALTH',`TOP ${h1WatchState.items.length} • HEALTHY ${hs.healthy} • PARTIAL ${hs.partial} • loại NO STATS ${hs.no_stats}. • ${feWorkspaceSummary()}`);
    }catch(e){status($('h1WatchStatus'),'Không khởi động được RUNG H1: '+e.message,'err');showToast('err','RUNG H1 lỗi',e.message)}
    finally{feRestoreOtherEngines(feIsolationSnap,'START_H1');loading(false)}
  }
  function stopH1Watch(silent=false){if(!silent)feMarkEngineManualStop('H1');h1WatchState.active=false;clearTimeout(h1WatchState.timer);h1WatchState.nextAt=0;updateH1WatchClock();if(!silent)status($('h1WatchStatus'),'Đã dừng AUTO H1. Watchlist + snapshot + calibration H1 vẫn lưu trên máy.','ok')}
  function h1WatchStopForOther(){log('Workspace isolation: ignore legacy cross-stop',{engine:'H1'});return false}

  function buildH1WatchPacket(){
    const usage=apiUsageSnapshot(),cal=h1WatchCalibrationStats(),th=h1WatchThresholds(),
          rows=h1WatchState.items.map((it,i)=>{
            const s=it.latest||{},e=it.eval||{},d=e.delta||{},why=h1WatchWhy(it,s,e),remain=Math.max(0,45-Number(s.minute||0));
            return `#${i+1} | FX ${it.id} | ${it.league}
TRẬN: ${it.home} vs ${it.away}
H1: ${s.minute??'-'}' | ${s.goals?.home??'-'}-${s.goals?.away??'-'} | còn ~${remain}m + bù giờ | ${watchStateText(it.state)} | SCORE ${e.score??'-'}/100 | CORE ${e.core?.strongCount??0}/3 ${e.core?.pass?'PASS':'NO'}
COMP: GAME ${e.game??'-'}/15 | PRESSURE ${e.pressure??'-'}/22 | CHANCE ${e.chance??'-'}/20 | MOM ${e.momentum??'-'}/18 | H1 MARKET ${e.market??'-'}/15 | CLOCK ${e.context??'-'}/5 | DQ ${e.quality??'-'}/5
DELTA_3M: ${e.recent3?.status||'baseline'} | ${e.recent3?.delta?`Shots +${e.recent3.delta.shots??0} | SOT +${e.recent3.delta.sot??0} | InBox +${e.recent3.delta.inbox??0} | Corners +${e.recent3.delta.corners??0} | xG +${Math.round(Number(e.recent3.delta.xg||0)*100)/100}`:`history ${Number(e.baselineAge||0).toFixed(1)}m`}
DELTA_5M: ${e.recent5?.status||'baseline'} | ${e.recent5?.delta?`Shots +${e.recent5.delta.shots??0} | SOT +${e.recent5.delta.sot??0} | InBox +${e.recent5.delta.inbox??0} | Corners +${e.recent5.delta.corners??0} | xG +${Math.round(Number(e.recent5.delta.xg||0)*100)/100}`:`history ${Number(e.baselineAge||0).toFixed(1)}m`}
DELTA_10M: ${e.recent10?.status||'baseline'} | ${e.recent10?.delta?`Shots +${e.recent10.delta.shots??0} | SOT +${e.recent10.delta.sot??0} | InBox +${e.recent10.delta.inbox??0} | Corners +${e.recent10.delta.corners??0} | xG +${Math.round(Number(e.recent10.delta.xg||0)*100)/100}`:`history ${Number(e.baselineAge||0).toFixed(1)}m`}
WHY NOW: ${why.good.join(' ; ')||'-'}
WHY NOT: ${why.bad.join(' ; ')||'-'}
H1 MARKET: ${s.market?.text||'N/A'}
MOVE: ${s.market?.movement_text||'N/A'}
ENGINE: ${it.reason||'-'}`;
          }).join('\n\n');
    return `[FOOTBALL_EDGE_H1_WATCH]
VERSION: V1.18.3 SINGLE MATCH ANALYZER
MODE: RUNG_TAI_H1_WATCH
TIME_VN: ${new Date().toLocaleString('vi-VN',{timeZone:TZ})}
WATCHLIST: ${h1WatchState.items.length}
H1_WINDOW: 20'-45+
THRESHOLDS: WATCH ${th.watch} | CANDIDATE ${th.candidate} | READY ${th.ready} | STRONG ${th.strong}${th.learned.learned?' LEARNED':' DEFAULT'}
CALIBRATION: n=${cal.n} | resolved_5m=${cal.resolved5} | goal_5m_rate=${cal.resolved5?(cal.rate5*100).toFixed(1)+'%':'N/A'} | before_HT=${cal.resolvedHt?(cal.rateHt*100).toFixed(1)+'%':'N/A'}
API_CALLS_LOCAL_TODAY: ${usage.network_calls||0}

YÊU CẦU GPT:
1. Đây là RUNG TÀI H1, không dùng rule FT/H2 để chấm.
2. So sánh TOP ${h1WatchState.items.length}; ranking tương đối không đồng nghĩa tất cả đều đạt ngưỡng tuyệt đối.
3. Ưu tiên Pressure 5–10m + Chance Quality + Momentum + thời gian còn lại trước HT.
4. H1 Total/Odds là market vote. Không thay bằng FT Over/Under nếu H1 market thiếu.
5. CORE 2/3 = Pressure + Chance + Momentum. PARTIAL chỉ dùng các trụ có dữ liệu thật, score cap 68 và không được xem là READY/STRONG. DATA INCOMPLETE / CORE N/A / BASELINE không được xem là signal xác nhận. Sát HT phải phạt yếu tố thời gian.
6. Goal hoặc Red Card làm tín hiệu cũ mất hiệu lực; sau reset phải đọc lại game-state.
7. Trả: HẠNG | GIẢI | TRẬN | PHÚT/TỶ SỐ H1 | STATE | SCORE/CORE | H1 MARKET | WHY NOW | WHY NOT.

=== TOP RUNG H1 WATCH ===
${rows}
=== END ===`;
  }
  async function copyH1WatchPacket(open=false){
    if(!h1WatchState.items.length){showToast('err','Chưa có RUNG H1','Hãy bắt đầu CANH TOP 5 H1 trước.');return}
    const p=buildH1WatchPacket();h1WatchState.lastPacket=p;
    try{await navigator.clipboard.writeText(p)}catch(e){state.lastPacket=p;els.packetText.value=p;els.packetText.focus();els.packetText.select();document.execCommand('copy')}
    showToast('ok','Đã copy RUNG H1 V1.18.1','Packet có H1 Total/Odds • WHY NOW • CORE • Calibration riêng.');
    if(open){saveConfig(true);openProject()}
  }

  h1WatchState.calibration=h1WatchCalRead();
  $('watchH1Top5Btn')?.addEventListener('click',startH1Watch);
  $('startH1WatchBtn')?.addEventListener('click',startH1Watch);
  $('refreshH1WatchBtn')?.addEventListener('click',()=>refreshH1Watch(false));
  $('stopH1WatchBtn')?.addEventListener('click',()=>stopH1Watch(false));
  $('h1WatchAuto')?.addEventListener('change',e=>{if(e.target.checked){h1WatchState.active=true;scheduleH1Watch()}else{clearTimeout(h1WatchState.timer);h1WatchState.nextAt=0;updateH1WatchClock()}});
  $('copyH1WatchPacketBtn')?.addEventListener('click',()=>copyH1WatchPacket(false));
  $('copyOpenH1WatchBtn')?.addEventListener('click',()=>copyH1WatchPacket(true));
  $('resetH1WatchCalBtn')?.addEventListener('click',()=>{
    if(!confirm('Xóa toàn bộ mẫu Calibration RUNG H1 trên thiết bị này?'))return;
    h1WatchState.calibration=[];h1WatchCalWrite();qsigWrite('H1',[]);renderH1Calibration();showToast('ok','Đã xóa mẫu H1 Calibration','RUNG H1 quay về ngưỡng mềm mặc định 54 / 64 / 72 / 79.');
  });
  h1WatchState.ticker=setInterval(updateH1WatchClock,1000);renderH1Watch();





  /* ===== V1.14 LIVE HANDICAP + MARKET INTELLIGENCE ENGINE ===== */
  const HANDICAP_HISTORY_PREFIX='FE_HANDICAP_WATCH_V120_';
  const HANDICAP_CAL_KEY='FE_HANDICAP_CAL_V120';
  const HANDICAP_POOL_MAX=20, HANDICAP_PREFILTER_MAX=40, HANDICAP_TOP_MAX=5, HANDICAP_CAL_MAX=5000;
  const handicapWatchState={active:false,refreshing:false,pool:[],timer:null,ticker:null,nextAt:0,cycle:0,lastPacket:'',calibration:null};

  /* ===== V1.18.5 PARALLEL WORKSPACE ISOLATION =====
     H1 / FT / HANDICAP are independent workspaces. Starting one engine must never
     stop another. This layer does not alter scoring, thresholds, QSIG, DQ or market logic. */
  function feMarkEngineManualStop(engine){
    const f=feMarkEngineManualStop;
    f.at=f.at||{H1:0,FT:0,HC:0};
    f.at[engine]=Date.now();
  }
  function feEngineManualStopAt(engine){
    const a=feMarkEngineManualStop.at||{H1:0,FT:0,HC:0};
    return Number(a[engine]||0);
  }
  function feEngineRef(engine){
    if(engine==='H1')return {state:h1WatchState,count:()=>h1WatchState.items.length,schedule:scheduleH1Watch};
    if(engine==='FT')return {state:watchState,count:()=>watchState.items.length,schedule:scheduleLiveWatch};
    if(engine==='HC')return {state:handicapWatchState,count:()=>handicapWatchState.pool.length,schedule:scheduleHandicapWatch};
    return null;
  }
  function feCaptureOtherEngines(exclude){
    const snap={};
    for(const e of ['H1','FT','HC']){
      if(e===exclude)continue;
      const r=feEngineRef(e);if(!r)continue;
      snap[e]={active:!!r.state.active,count:r.count(),manualStopAt:feEngineManualStopAt(e)};
    }
    return snap;
  }
  function feRestoreOtherEngines(snap,source){
    if(!snap)return;
    for(const [e,before] of Object.entries(snap)){
      const r=feEngineRef(e);if(!r)continue;
      const manuallyStopped=feEngineManualStopAt(e)!==before.manualStopAt;
      if(before.active&&!r.state.active&&!manuallyStopped&&r.count()>0){
        r.state.active=true;
        try{r.schedule()}catch(_){}
        log('Workspace isolation restored engine',{source,engine:e,count:r.count()});
      }
    }
  }
  function feWorkspaceSummary(){
    return `H1 ${h1WatchState.active?'ON':'OFF'}(${h1WatchState.items.length}) • FT ${watchState.active?'ON':'OFF'}(${watchState.items.length}) • HC ${handicapWatchState.active?'ON':'OFF'}(${handicapWatchState.pool.length})`;
  }


  /* ===== V1.18.7 INDEPENDENT LIVE WORKSPACE SCAN =====
     Each engine scans the shared ULTRA live heartbeat independently and owns its
     own candidate source. It never consumes / clears another workspace's source. */
  const FE_WORKSPACE_SCAN_STATE={
    H1:{lastScanAt:0,sourceFixtureIds:[],totalLive:0,rejectedStale:0},
    FT:{lastScanAt:0,sourceFixtureIds:[],totalLive:0,rejectedStale:0},
    HC:{lastScanAt:0,sourceFixtureIds:[],totalLive:0,rejectedStale:0}
  };
  const FE_UNIFIED_LIVE_CACHE={rows:[],at:0,ttl:18000,source:'INIT'};
  const FE_UNIFIED_SCAN_STATE={running:false,lastAt:0,lastFreshCount:0,lastSource:'-',errors:[]};
  function feUnifiedCacheFresh(){return Array.isArray(FE_UNIFIED_LIVE_CACHE.rows)&&FE_UNIFIED_LIVE_CACHE.rows.length&&(Date.now()-Number(FE_UNIFIED_LIVE_CACHE.at||0)<=Number(FE_UNIFIED_LIVE_CACHE.ttl||0));}
  function fePrimeUnifiedLiveCache(rows,source='UNIFIED'){FE_UNIFIED_LIVE_CACHE.rows=Array.isArray(rows)?rows.slice():[];FE_UNIFIED_LIVE_CACHE.at=Date.now();FE_UNIFIED_LIVE_CACHE.source=source;FE_UNIFIED_SCAN_STATE.lastAt=FE_UNIFIED_LIVE_CACHE.at;FE_UNIFIED_SCAN_STATE.lastFreshCount=FE_UNIFIED_LIVE_CACHE.rows.filter(feLiveSourceValid).length;FE_UNIFIED_SCAN_STATE.lastSource=source;return FE_UNIFIED_LIVE_CACHE.rows}
  async function feWorkspaceScanFixtures(engine){
    let rows=[],source='ULTRA_HEARTBEAT';
    if(feUnifiedCacheFresh()){rows=FE_UNIFIED_LIVE_CACHE.rows.slice();source=FE_UNIFIED_LIVE_CACHE.source||'UNIFIED_CACHE'}
    else{const hb=await ultraHeartbeat(false);rows=Array.isArray(hb?.rows)?hb.rows:[]}
    const freshRows=rows.filter(feLiveSourceValid);
    let out=[];
    if(engine==='H1')out=freshRows.filter(h1WatchEligible);
    else if(engine==='FT')out=freshRows.filter(watchLiveEligible);
    else if(engine==='HC')out=freshRows.filter(handicapWatchEligible);
    const st=FE_WORKSPACE_SCAN_STATE[engine];
    if(st){st.lastScanAt=Date.now();st.totalLive=rows.length;st.rejectedStale=rows.length-freshRows.length;st.sourceFixtureIds=out.map(f=>Number(f?.fixture?.id)).filter(Number.isFinite);st.lastSource=source}
    return out;
  }
  function feWorkspaceOpenItems(engine){
    if(engine==='H1')return (h1WatchState.items||[]).filter(x=>x.state!=='ENDED');
    if(engine==='FT')return (watchState.items||[]).filter(x=>x.state!=='ENDED');
    if(engine==='HC')return (handicapWatchState.pool||[]).filter(x=>x.eval?.state!=='ENDED');
    return [];
  }
  function feWorkspaceAllItems(engine){
    if(engine==='H1')return h1WatchState.items||[];
    if(engine==='FT')return watchState.items||[];
    if(engine==='HC')return handicapWatchState.pool||[];
    return [];
  }
  function feWorkspaceAutoStopIfDone(engine){
    const r=feEngineRef(engine);if(!r||!r.state.active)return false;
    const all=feWorkspaceAllItems(engine);if(all.length&&feWorkspaceOpenItems(engine).length)return false;
    r.state.active=false;clearTimeout(r.state.timer);r.state.nextAt=0;
    if(engine==='H1')updateH1WatchClock();
    else if(engine==='FT')updateWatchClock();
    else updateHandicapWatchClock();
    const ids=all.map(x=>Number(x.id)).filter(Number.isFinite);bgUnregisterFixtureIds(ids,true).catch(()=>{});
    const el=engine==='H1'?$('h1WatchStatus'):engine==='FT'?$('watchStatus'):$('handicapWatchStatus');
    const label=engine==='H1'?'H1':engine==='FT'?'FT':'HANDICAP';
    if(el)status(el,`AUTO ${label} đã nghỉ • không còn fixture hợp lệ. History / calibration vẫn giữ • workspace khác không bị ảnh hưởng.`,'ok');
    log('Workspace terminal auto-stop',{engine,count:all.length});
    return true;
  }

  function feUnifiedFmtAt(ts){if(!ts)return '—';try{return new Date(ts).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit',second:'2-digit',timeZone:TZ})}catch(_){return '—'}}
  function feUnifiedActiveCount(){return ['H1','FT','HC'].filter(e=>feEngineRef(e)?.state?.active).length}
  function feUnifiedEngineData(engine){
    if(engine==='H1'){const items=h1WatchState.items||[],top=items[0]||null,est=top?grEstimate(top,'H1'):null,tr=top?grTrend(top):null;return {engine,label:'RUNG H1',cls:'h1',count:items.length,total:FE_WORKSPACE_SCAN_STATE.H1.sourceFixtureIds.length||0,top,prob:est?.prob,trend:tr,state:top?.state||'-',score:top?.eval?.score??'-',why:top?.latest?.market_text||top?.reason||'',scanAt:FE_WORKSPACE_SCAN_STATE.H1.lastScanAt||0};}
    if(engine==='FT'){const items=watchState.items||[],top=items[0]||null,est=top?grEstimate(top,'FT'):null,tr=top?grTrend(top):null;return {engine,label:'RUNG FT',cls:'ft',count:items.length,total:FE_WORKSPACE_SCAN_STATE.FT.sourceFixtureIds.length||0,top,prob:est?.prob,trend:tr,state:top?.state||'-',score:top?.eval?.score??'-',why:top?.latest?.market_text||top?.reason||'',scanAt:FE_WORKSPACE_SCAN_STATE.FT.lastScanAt||0};}
    const items=handicapWatchState.pool||[],top=items[0]||null,e=top?.eval||{};return {engine,label:'HANDICAP',cls:'hc',count:items.length,total:FE_WORKSPACE_SCAN_STATE.HC.sourceFixtureIds.length||0,top,prob:null,trend:null,state:e.state||'-',score:e.states?.gap??e.score??'-',why:e.recommendation||top?.reason||'',scanAt:FE_WORKSPACE_SCAN_STATE.HC.lastScanAt||0};
  }
  function feUnifiedTopNote(d){
    const top=d.top;if(!top)return '<div class="unified-live-empty">Chưa có card ' + esc(d.label) + '. Hãy bấm QUÉT CẢ 3 CHẾ ĐỘ.</div>';
    const s=top.latest||{},home=top.home||'',away=top.away||'',minute=Number(s.minute||0),scoreLine=`${Number(s.goals?.home||0)}-${Number(s.goals?.away||0)}`;
    let note=`<b>${esc(home)} vs ${esc(away)}</b> • ${minute||'-'}' • ${esc(scoreLine)}`;
    if(d.engine==='HC')note+=` • ${esc(d.why||'Đang theo dõi team state')}`;
    else if(d.prob!=null)note+=` • Goal Radar ${esc(d.prob)}%`;
    return `<div class="unified-live-topnote">${note}</div>`;
  }
  /* ===== V1.19.2 MASTER OPPORTUNITY + CONFLUENCE / CONFLICT — PRESENTATION ONLY =====
     Reads current H1 / FT / HC workspace outputs and merges duplicate fixture IDs.
     Interaction labels are descriptive only: no combined score, no ranking model,
     no threshold/state/core mutation. Explicit HC↔market divergence is surfaced as conflict. */
  function feMasterTrendIcon(tr){return tr?.dir==='up'?'↑':tr?.dir==='down'?'↓':'→'}
  function feMasterFreshest(a,b){
    const ta=Number(a?.latest?.captured_at||a?.latest?.fresh_at||0),tb=Number(b?.latest?.captured_at||b?.latest?.fresh_at||0);
    return tb>ta?b:a;
  }
  function feMasterMergeFixtures(){
    const map=new Map();
    const add=(engine,it)=>{
      if(!it||!Number.isFinite(Number(it.id)))return;
      const id=Number(it.id),cur=map.get(id)||{id,home:it.home||'',away:it.away||'',league:it.league||'',h1:null,ft:null,hc:null,latest:null};
      if(engine==='H1')cur.h1=it;else if(engine==='FT')cur.ft=it;else cur.hc=it;
      if(!cur.home)cur.home=it.home||'';if(!cur.away)cur.away=it.away||'';if(!cur.league)cur.league=it.league||'';
      cur.latest=cur.latest?feMasterFreshest(cur.latest,it):it;
      map.set(id,cur);
    };
    (h1WatchState.items||[]).forEach(it=>add('H1',it));
    (watchState.items||[]).forEach(it=>add('FT',it));
    (typeof hcTopItems==='function'?hcTopItems():(handicapWatchState.pool||[])).forEach(it=>add('HC',it));
    return [...map.values()].sort((a,b)=>{
      const am=Number(a.latest?.latest?.minute||0),bm=Number(b.latest?.latest?.minute||0);
      return bm-am||a.id-b.id;
    });
  }
  function feMasterGoalSignal(it,engine){
    if(!it)return '';
    const e=it.eval||{},est=grEstimate(it,engine),tr=grTrend(it),prob=est?.prob==null?'—':`${est.prob}%`,trend=feMasterTrendIcon(tr),dq=e.quality==null?'—':`${e.quality}/5`,score=e.score==null?'—':e.score,state=it.state||'WATCH',calBasis=est?.basis==='QSIG'?'QSIG':est?.basis==='LEGACY'?'LEGACY':'MODEL',source=est?.source==='CAL_STRONG'?`${calBasis} ${est?.reliability?.label||'CAL'} n=${est.n}`:est?.source==='CAL'?`${calBasis} ${est?.reliability?.label||'CAL'} n=${est.n}`:est?.source==='CAL_EARLY'?`${calBasis} ${est?.reliability?.label||'MẪU THẤP'} n=${est.n}`:est?.source==='MODEL'?'ƯỚC TÍNH':'CHỜ CAL';
    const pv=feGoalProbVisual(est?.prob);
    return `<div class="master-op-signal ${engine==='H1'?'h1':'ft'}"><div class="left"><b>🔥 ${engine} GOAL RADAR • ${esc(state)}</b><small>Engine score ${esc(score)}/100 • DQ ${esc(dq)} • ${esc(source)} • ${esc(pv.label)}</small></div><div class="value ${pv.cls}">${esc(prob)} ${esc(trend)}</div></div>`;
  }
  function feMasterHCSignal(it){
    if(!it)return '';
    const e=it.eval||{},s=it.latest||{},dir=e.states?.direction||'BALANCED',state=e.state||'BALANCED',gap=e.states?.liveGap,market=e.marketFit?.level||'NO_MARKET',dq=e.dq==null?'—':`${e.dq}/5`,rec=(typeof hcRecText==='function'?hcRecText(e,s):e.recommendation)||'NO SIGNAL';
    const gv=feGapVisual(gap,state);
    return `<div class="master-op-signal hc ${gv.cls}"><div class="left"><b>⚖️ HANDICAP • ${esc(dir)} • ${esc(state)}</b><small>LIVE GAP ${gap==null?'—':esc((Number(gap)>0?'+':'')+gap)} • DQ ${esc(dq)} • Market ${esc(market)} • ${esc(gv.label)}</small></div><div class="value">${esc(rec)}</div></div>`;
  }
  function feMasterGoalQualified(it){
    if(!it)return false;const e=it.eval||{};
    return ['READY','STRONG'].includes(it.state)&&e.scoreMode==='FULL'&&!e.hardVeto;
  }
  function feMasterGoalCaution(it,engine){
    if(!it)return [];const out=[],e=it.eval||{},tr=grTrend(it),mv=e.market_movement||{};
    if(feMasterGoalQualified(it)&&tr?.dir==='down')out.push(`${engine} Goal Radar đang GIẢM`);
    const snaps=Number(it.latest?.market?.history?.snapshot_count||0),ld=Number(mv?.line_delta),pd=Number(mv?.over_price_delta);
    if(feMasterGoalQualified(it)&&snaps>=2&&((Number.isFinite(ld)&&ld<0)||(Number.isFinite(pd)&&pd>=0.05)))out.push(`${engine} market move đang phản biện tín hiệu bàn`);
    if(e.scoreMode==='PARTIAL_STATS')out.push(`${engine} PARTIAL DATA`);
    return out;
  }
  function feMasterHCQualified(it){
    if(!it)return false;const e=it.eval||{},lvl=e.marketFit?.level||'';
    return /_(STRONG)$/.test(String(e.state||''))&&['SOFT_AGREEMENT','HARD_AGREEMENT'].includes(lvl)&&Number(e.dq||0)>=4;
  }
  function feMasterHCConflict(it){
    if(!it)return {hard:[],soft:[]};const e=it.eval||{},hard=[],soft=[],lvl=e.marketFit?.level||'';
    if(e.state==='DIVERGENCE'||lvl==='HARD_DIVERGENCE')hard.push(`HC ↔ MARKET ${lvl==='HARD_DIVERGENCE'?'HARD DIVERGENCE':'DIVERGENCE'}`);
    else if(lvl==='SOFT_DIVERGENCE')soft.push('HC ↔ MARKET SOFT DIVERGENCE');
    if(e.dataTier==='PARTIAL')soft.push('HC PARTIAL DATA');
    if(['STALE','DATA_INCOMPLETE','MARKET_WATCH'].includes(e.state))soft.push(`HC ${e.state}`);
    return {hard,soft};
  }
  function feMasterInteractionMeta(x){
    const h1Q=feMasterGoalQualified(x.h1),ftQ=feMasterGoalQualified(x.ft),hcQ=feMasterHCQualified(x.hc),goalQ=h1Q||ftQ;
    const hcC=feMasterHCConflict(x.hc),cautions=[...feMasterGoalCaution(x.h1,'H1'),...feMasterGoalCaution(x.ft,'FT'),...hcC.soft],hard=[...hcC.hard];
    const mechs=[x.h1?'H1':null,x.ft?'FT':null,x.hc?'HC':null].filter(Boolean),evidence=[];
    if(h1Q)evidence.push('H1 READY/STRONG');if(ftQ)evidence.push('FT READY/STRONG');if(hcQ)evidence.push('HC STRONG + MARKET AGREES');
    let verdict='SINGLE',cls='single-only',title='SINGLE SIGNAL',detail='Chỉ có một cơ chế đang hiện diện; chưa có tương tác chéo.';
    if(hard.length){verdict='CONFLICT';cls='conflict';title='⚠ CONFLICT';detail=hard.join(' • ')}
    else if(goalQ&&hcQ){verdict='CONFLUENCE';cls='confluence';title='✓ CONFLUENCE';detail='Goal engine đạt READY/STRONG đồng thời Handicap STRONG và market đang agreement.'}
    else if(cautions.length&&mechs.length>1){verdict='CAUTION';cls='caution';title='△ CAUTION';detail=cautions.join(' • ')}
    else if(mechs.length>1){verdict='MULTI';cls='multi-only';title='MULTI SIGNAL';detail='Nhiều cơ chế cùng xuất hiện nhưng chưa đủ điều kiện để gọi CONFLUENCE.'}
    return {verdict,cls,title,detail,evidence,cautions,hard,goalQ,hcQ};
  }
  function feMasterInteractionHTML(meta){
    const ev=meta.evidence.length?`<div class="master-op-evidence">${meta.evidence.map(x=>`<span>${esc(x)}</span>`).join('')}</div>`:'';
    return `<div class="master-op-verdict"><div class="master-op-verdict-main"><b>${esc(meta.title)}</b><small>${esc(meta.detail)}</small>${ev}</div><span class="master-op-verdict-badge">${esc(meta.verdict)}</span></div>`;
  }
  function feMasterActionButtons(x){
    const b=[],manual=typeof feSmartIsManual==='function'&&feSmartIsManual(x.id);
    b.push(`<button type="button" class="smart-follow-btn ${manual?'on':''}" data-smart-follow="${esc(x.id)}">${manual?'★ ĐANG FOLLOW':'☆ FOLLOW'}</button>`);
    if(x.h1)b.push(`<button type="button" data-master-target="h1WatchCard">XEM H1</button>`);
    if(x.ft)b.push(`<button type="button" data-master-target="liveWatchCard">XEM FT</button>`);
    if(x.hc)b.push(`<button type="button" data-master-target="handicapWatchCard">XEM HC</button>`);
    return b.length?`<div class="master-op-actions">${b.join('')}</div>`:'';
  }
  /* ===== V1.19.3 TOP OPPORTUNITY RANKING — PRESENTATION ONLY =====
     Lexicographic priority only; no weighted/combined score is created.
     Order: STATE → DQ → FRESHNESS → EVIDENCE → MARKET → CALIBRATION → CONFLUENCE.
     Hard CONFLICT is excluded from TOP-qualified ranks but remains visible. */
  var FE_ADAPTIVE_KEY='fe_adaptive_live_v1210';
  var FE_ADAPTIVE_CACHE={at:0,ttl:300000,rowsSig:'',reviews:{}};
  function feMasterStateRank(state,engine){
    const s=String(state||'');
    if(engine==='HC')return /_STRONG$/.test(s)?4:/_LEAN$/.test(s)?2:/_BIAS$/.test(s)?1:0;
    return s==='STRONG'?4:s==='READY'?3:s==='CANDIDATE'?2:s==='WATCH'?1:s==='PARTIAL_CANDIDATE'?1:0;
  }
  function feMasterCalMeta(it,engine){
    if(!it||engine==='HC')return {rank:0,n:0,label:'CAL N/A'};
    const est=grEstimate(it,engine),src=est?.source||'';
    const rank=src==='CAL_STRONG'?3:src==='CAL'?2:src==='CAL_EARLY'?1:0,n=Number(est?.n||0);
    return {rank,n,label:rank===3?`CAL TỐT n=${n}`:rank===2?`CAL n=${n}`:rank===1?`CAL SỚM n=${n}`:'MODEL'};
  }
  function feMasterMarketRank(it,engine){
    if(!it)return {rank:0,label:'NO MARKET'};const e=it.eval||{};
    if(engine==='HC'){
      const lvl=String(e.marketFit?.level||'NO_MARKET');
      const rank=lvl==='HARD_AGREEMENT'?3:lvl==='SOFT_AGREEMENT'?2:lvl==='NO_MARKET'?0:/DIVERGENCE/.test(lvl)?-1:1;
      return {rank,label:lvl};
    }
    const mv=e.market_movement||{},available=!!e.market_available,ld=Number(mv.line_delta),pd=Number(mv.over_price_delta);
    const aligned=available&&((Number.isFinite(ld)&&ld>0)||(Number.isFinite(pd)&&pd<=-.02));
    const opposed=available&&((Number.isFinite(ld)&&ld<0)||(Number.isFinite(pd)&&pd>=.05));
    return {rank:aligned?2:opposed?0:available?1:0,label:aligned?'MARKET CONFIRM':opposed?'MARKET CAUTION':available?'MARKET LIVE':'NO MARKET'};
  }
  function feMasterDescriptor(it,engine){
    if(!it)return null;const e=it.eval||{},s=it.latest||{};
    const qa=engine==='H1'?qsigAssessH1(it,s):engine==='FT'?qsigAssessFT(it,s):qsigAssessHC(it,s);
    const stateRank=feMasterStateRank(engine==='HC'?e.state:it.state,engine),dq=Number(engine==='HC'?e.dq:e.quality)||0;
    const fresh=Number.isFinite(Number(qa?.fresh))?Number(qa.fresh):99999,evidenceAge=Number.isFinite(Number(qa?.evidenceAge))?Number(qa.evidenceAge):99999;
    const evidenceRank=qa?.high?2:qa?.qualified?1:0,market=feMasterMarketRank(it,engine),cal=feMasterCalMeta(it,engine);
    const adaptive=alvLiveDecision(engine,it);
    return {engine,stateRank,dq,fresh,evidenceRank,evidenceAge,marketRank:market.rank,marketLabel:market.label,calRank:cal.rank,calN:cal.n,calLabel:cal.label,qualified:!!qa?.qualified,high:!!qa?.high,adaptive};
  }
  function feMasterDescriptorKey(d){const ar=d?.adaptive?.mode==='CONFIRMED'?1:d?.adaptive?.mode==='GUARD'?-1:0;return d?[d.stateRank,d.dq,-d.fresh,d.evidenceRank,-d.evidenceAge,d.marketRank,d.calRank,d.calN,ar]:[-1,-1,-99999,-1,-99999,-1,-1,-1,0]}
  function feMasterTupleCompare(a,b){
    const A=a||[],B=b||[],n=Math.max(A.length,B.length);for(let i=0;i<n;i++){const av=Number(A[i]??0),bv=Number(B[i]??0);if(av!==bv)return bv-av}return 0;
  }
  function feMasterPrimaryDescriptor(x){
    const ds=[feMasterDescriptor(x.h1,'H1'),feMasterDescriptor(x.ft,'FT'),feMasterDescriptor(x.hc,'HC')].filter(Boolean);
    ds.sort((a,b)=>feMasterTupleCompare(feMasterDescriptorKey(a),feMasterDescriptorKey(b)));return ds[0]||null;
  }
  function feMasterRankMeta(x){
    const interaction=feMasterInteractionMeta(x),p=feMasterPrimaryDescriptor(x),mechs=[x.h1?'H1':null,x.ft?'FT':null,x.hc?'HC':null].filter(Boolean);
    const hardConflict=interaction.verdict==='CONFLICT',adaptiveGuard=p?.adaptive?.allowTop===false,eligible=!!p&&p.stateRank>=3&&!hardConflict&&!adaptiveGuard;
    const group=eligible?3:(hardConflict&&p?.stateRank>=3)?2:adaptiveGuard&&p?.stateRank>=3?2:1;
    const confluence=interaction.verdict==='CONFLUENCE'?1:0,multi=mechs.length>1?1:0,adaptiveRank=p?.adaptive?.mode==='CONFIRMED'?1:p?.adaptive?.mode==='GUARD'?-1:0;
    const key=[group,p?.stateRank||0,p?.dq||0,-(p?.fresh??99999),p?.evidenceRank||0,-(p?.evidenceAge??99999),p?.marketRank||0,p?.calRank||0,p?.calN||0,adaptiveRank,confluence,multi];
    return {interaction,primary:p,eligible,hardConflict,adaptiveGuard,group,key,mechs};
  }
  function feMasterRankRows(rows){
    const out=(rows||[]).map(x=>({...x,__rank:feMasterRankMeta(x)}));
    out.sort((a,b)=>feMasterTupleCompare(a.__rank.key,b.__rank.key)||Number(b.latest?.latest?.minute||0)-Number(a.latest?.latest?.minute||0)||a.id-b.id);
    let n=0;for(const x of out){if(x.__rank.eligible&&n<5)x.__rank.top=n+=1;else x.__rank.top=null}return out;
  }
  function feMasterRankWhy(r){
    const p=r?.primary;if(!p)return 'Chưa có tín hiệu đủ dữ liệu để xếp ưu tiên.';
    const state=p.stateRank>=4?'STRONG':p.stateRank===3?'READY':p.stateRank===2?'CANDIDATE/LEAN':p.stateRank===1?'WATCH/BIAS':'LOW';
    const fresh=p.fresh>=99999?'fresh —':`fresh ${Math.round(p.fresh)}s`,ev=p.evidenceAge>=99999?'evidence —':`evidence ${Math.round(p.evidenceAge)}s`,evQ=p.high?'HIGH':p.qualified?'QUALIFIED':'chưa QSIG';
    const ad=p.adaptive?.mode==='CONFIRMED'?' • ADAPTIVE CONFIRMED':p.adaptive?.mode==='GUARD'?` • ADAPTIVE GUARD: ${(p.adaptive.fails||[]).join(', ')}`:p.adaptive?.mode==='DISABLED'?' • ADAPTIVE OFF':' • CORE FALLBACK';
    return `${p.engine} ${state} • DQ ${p.dq}/5 • ${fresh} • ${evQ}/${ev} • ${p.marketLabel} • ${p.calLabel}${ad}`;
  }
  function feMasterRankBadge(r){
    if(r?.top===1)return '<span class="master-op-rank top1">#1 TOP</span>';
    if(r?.top)return `<span class="master-op-rank top5">#${r.top} TOP</span>`;
    if(r?.hardConflict)return '<span class="master-op-rank conflict-rank">CONFLICT</span>';
    if(r?.adaptiveGuard)return '<span class="master-op-rank watch-rank">ADAPTIVE GUARD</span>';
    return '<span class="master-op-rank watch-rank">THEO DÕI</span>';
  }
  /* ===== V1.19.4.1 TOP BACKGROUND ONLY — ORCHESTRATION ONLY =====
     Selection uses existing V1.19.3 TOP ranking. No score/threshold mutation.
     Auto background: current TOP 1–5 only. Manual FOLLOW always stays.
     READY/STRONG outside TOP and near-threshold fixtures are NOT auto-registered. */
  const FE_SMART_FOLLOW_KEY='FE_SMART_FOLLOW_MANUAL_V1194';
  const FE_SMART_FOLLOW_GRACE_MS=0;
  const FE_SMART_FOLLOW={timer:null,syncing:false,lastIds:new Set(),lowSince:new Map(),lastReason:'INIT',lastAt:0};
  function feSmartManualRead(){try{const x=JSON.parse(localStorage.getItem(FE_SMART_FOLLOW_KEY)||'[]');return new Set((Array.isArray(x)?x:[]).map(Number).filter(Number.isFinite))}catch{return new Set()}}
  function feSmartManualWrite(set){try{localStorage.setItem(FE_SMART_FOLLOW_KEY,JSON.stringify([...set].map(Number).filter(Number.isFinite)))}catch{}}
  function feSmartIsManual(id){return feSmartManualRead().has(Number(id))}
  function feSmartToggleManual(id){const set=feSmartManualRead(),n=Number(id);if(!Number.isFinite(n))return false;if(set.has(n))set.delete(n);else set.add(n);feSmartManualWrite(set);feSmartFollowSchedule('MANUAL_TOGGLE',80);try{renderMasterOpportunityBoard()}catch(_){}return set.has(n)}
  function feSmartNearThreshold(x){
    const h1=Number(x?.h1?.eval?.score),ft=Number(x?.ft?.eval?.score),gap=Math.abs(Number(x?.hc?.eval?.states?.liveGap));
    const h1ok=Number.isFinite(h1)&&h1>=69,ftok=Number.isFinite(ft)&&ft>=70,hcok=Number.isFinite(gap)&&gap>=19;
    return h1ok||ftok||hcok;
  }
  function feSmartStrongReady(x){
    const hs=String(x?.h1?.state||''),fs=String(x?.ft?.state||''),cs=String(x?.hc?.eval?.state||'');
    return ['READY','STRONG'].includes(hs)||['READY','STRONG'].includes(fs)||/_STRONG$/.test(cs);
  }
  function feSmartReason(x){
    const manual=feSmartIsManual(x.id),r=x.__rank||feMasterRankMeta(x),top=!!r?.top;
    if(manual)return {keep:true,reason:'MANUAL',manual:true};
    if(top)return {keep:true,reason:`TOP ${r.top}`,manual:false};
    return {keep:false,reason:'NOT TOP',manual:false};
  }
  function feSmartFixtureFromRow(x){
    const it=x?.latest||x?.h1||x?.ft||x?.hc,s=it?.latest||{};
    return {id:Number(x.id),home:x.home||it?.home||'',away:x.away||it?.away||'',league:x.league||it?.league||'',status:s.status||null,minute:Number(s.minute||0)||0};
  }
  function feSmartSelectRows(rows){
    const out=[];
    for(const x of rows||[]){
      const d=feSmartReason(x),id=Number(x.id);if(!Number.isFinite(id))continue;
      if(d.keep)out.push({...x,__smart:{...d,grace:false}});
    }
    return out;
  }
  function feSmartChip(x){
    const rows=feMasterRankRows(feMasterMergeFixtures()),cur=rows.find(r=>Number(r.id)===Number(x.id)),d=cur?feSmartReason(cur):{keep:false,reason:'LOW'},manual=feSmartIsManual(x.id);
    if(manual)return '<span class="smart-follow-chip manual">★ FOLLOW THỦ CÔNG</span>';
    if(d.keep)return `<span class="smart-follow-chip focus">◉ BACKGROUND • ${esc(d.reason)}</span>`;
    return '<span class="smart-follow-chip">○ KHÔNG BG • KHÔNG TOP</span>';
  }
  function feSmartUpdateCounters(selected=[]){
    if($('smartFollowCount'))$('smartFollowCount').textContent=String(selected.length);
    const reg=bgRegistryRead().filter(r=>String(r.engine||'')==='SMART').length;if($('smartFollowBgCount'))$('smartFollowBgCount').textContent=String(reg);
  }
  async function feSmartFollowSync(reason='AUTO'){
    if(FE_SMART_FOLLOW.syncing)return;FE_SMART_FOLLOW.syncing=true;FE_SMART_FOLLOW.lastReason=reason;
    try{
      const ranked=feMasterRankRows(feMasterMergeFixtures()),selected=feSmartSelectRows(ranked),desired=new Set(selected.map(x=>Number(x.id)).filter(Number.isFinite));
      feSmartUpdateCounters(selected);
      if(!bgEnabled()){FE_SMART_FOLLOW.lastIds=desired;return}
      const registryBefore=bgRegistryRead(),protectedIds=new Set(registryBefore.filter(r=>String(r.engine||'')==='SINGLE_MATCH').map(r=>Number(r.fixture_id)).filter(Number.isFinite));
      const fixtures=selected.map(feSmartFixtureFromRow).filter(f=>Number.isFinite(f.id)&&!protectedIds.has(Number(f.id)));
      if(fixtures.length)await bgRegisterFixtures(fixtures,'focus','SMART',true);
      const currentWorkspaceIds=new Set(ranked.map(x=>Number(x.id)).filter(Number.isFinite));
      const legacy=bgRegistryRead().filter(r=>['SMART','H1','FT','HC'].includes(String(r.engine||''))).map(r=>Number(r.fixture_id)).filter(Number.isFinite);
      const drop=[...new Set(legacy)].filter(id=>currentWorkspaceIds.has(id)&&!desired.has(id));
      if(drop.length)await bgUnregisterFixtureIds(drop,true);
      FE_SMART_FOLLOW.lastIds=desired;FE_SMART_FOLLOW.lastAt=Date.now();feSmartUpdateCounters(selected);
    }catch(e){log('Smart Follow sync error',{reason,error:e.message})}
    finally{FE_SMART_FOLLOW.syncing=false}
  }
  function feSmartFollowSchedule(reason='AUTO',delay=900){clearTimeout(FE_SMART_FOLLOW.timer);FE_SMART_FOLLOW.timer=setTimeout(()=>feSmartFollowSync(reason),Math.max(50,Number(delay)||900))}
  /* ===== V1.22.0 ENTRY INTELLIGENCE — MARKET NORMALIZATION SHADOW =====
     Observation only: normalize current market odds and remove bookmaker margin.
     No engine/ranking/entry mutation. */
  function mnDec(v,fmt='AUTO'){
    const n=Number(v);if(!Number.isFinite(n)||n<=0)return null;
    if(fmt==='HK')return n+1;if(fmt==='DEC')return n>1?n:null;
    return n>1?n:(n<=1?n+1:null);
  }
  function mnImp(dec){const d=Number(dec);return Number.isFinite(d)&&d>1?1/d:null}
  function mnPct(v,d=1){return Number.isFinite(Number(v))?`${(Number(v)*100).toFixed(d)}%`:'—'}
  function mnOdd(v){const d=mnDec(v);return d==null?'—':d.toFixed(2)}
  function mnLineFromValue(v){
    const h=numericHandicap(v?.handicap);if(Number.isFinite(h))return h;
    const s=String(v?.value||''),m=s.match(/([+-]?\d+(?:[.,]\d+)?)\s*$/);return m?numericHandicap(m[1]):null;
  }
  function mnOutcome(v,category,ctx={}){
    const s=normalizedKey(v?.value||'');
    if(category==='match_winner')return v?.selection_outcome||selectionOutcome(v?.value,ctx)||(/^(home|1)(\s|$)/.test(s)?'home':/^(away|2)(\s|$)/.test(s)?'away':/draw|^x(\s|$)/.test(s)?'draw':null);
    if(ASIAN_HANDICAP_CATEGORIES.has(category))return v?.selection_outcome||v?.selection_side||null;
    if(/\bover\b|\btai\b|\btài\b/.test(s))return 'over';
    if(/\bunder\b|\bxiu\b|\bxỉu\b/.test(s))return 'under';
    if(/\bhome\b/.test(s))return 'home';if(/\baway\b/.test(s))return 'away';
    return null;
  }
  function mnMarketLabel(category,line){
    const l=Number.isFinite(Number(line))?` ${Number(line)>0?'+':''}${Number(line)}`:'';
    return ({h1_total:'H1 O/U',over_under:'FT O/U',h2_total:'H2 O/U',asian_handicap:'AH FT',h1_handicap:'AH H1',h2_handicap:'AH H2',match_winner:'1X2',team_total:'TEAM TOTAL'})[category]||String(category||'MARKET').toUpperCase()+l;
  }
  function mnRequired(category){
    if(category==='match_winner')return ['home','draw','away'];
    if(ASIAN_HANDICAP_CATEGORIES.has(category))return ['home','away'];
    if(['over_under','h1_total','h2_total','team_total'].includes(category))return ['over','under'];
    return [];
  }
  function mnGroups(row,ctx={}){
    const category=row?.category,vals=(row?.values||[]).filter(v=>!v?.suspended),req=mnRequired(category);if(!req.length)return [];
    const groups=new Map();
    for(const v of vals){
      const out=mnOutcome(v,category,ctx);if(!out||!req.includes(out))continue;
      const line=category==='match_winner'?null:mnLineFromValue(v),key=category==='match_winner'?'ML':Number.isFinite(line)?String(Math.abs(line)):'NO_LINE';
      if(!groups.has(key))groups.set(key,{line:Number.isFinite(line)?line:null,values:{},main:0});
      const g=groups.get(key),dec=mnDec(v.odd);if(dec==null)continue;
      const prev=g.values[out],cand={out,dec,raw:v.odd,line,main:v.main===true};
      if(!prev||cand.main&&!prev.main)g.values[out]=cand;if(cand.main)g.main++;
    }
    return [...groups.values()].filter(g=>req.every(k=>g.values[k])).map(g=>({...g,required:req}));
  }
  function mnNormalizeGroup(row,g){
    const probs=g.required.map(k=>mnImp(g.values[k].dec));if(probs.some(x=>x==null))return null;
    const sum=probs.reduce((a,b)=>a+b,0);if(!(sum>0))return null;
    const p={};g.required.forEach((k,i)=>p[k]=probs[i]/sum);
    const margin=(sum-1)*100,dec={};g.required.forEach(k=>dec[k]=g.values[k].dec);
    let line=null;if(row.category!=='match_winner'){
      if(ASIAN_HANDICAP_CATEGORIES.has(row.category)){const hv=g.values.home;line=Number.isFinite(Number(hv?.line))?Number(hv.line):g.line}
      else line=Number.isFinite(Number(g.line))?Number(g.line):null;
    }
    return {category:row.category,line,prob:p,dec,margin,main:g.main,bookmaker:row.bookmaker||'LIVE_FEED',update:row.update||null,integrity:row.integrity||null};
  }
  function mnNormalizeRow(row,ctx={}){
    if(!row||row.integrity?.valid===false||row.status?.blocked||row.status?.stopped||row.status?.finished)return null;
    const all=mnGroups(row,ctx).map(g=>mnNormalizeGroup(row,g)).filter(Boolean);if(!all.length)return null;
    all.sort((a,b)=>Number(b.main)-Number(a.main)||Math.abs(a.margin-4)-Math.abs(b.margin-4));return all[0];
  }
  function mnFixtureRows(x){
    const src=[];for(const it of [x?.h1,x?.ft,x?.hc]){
      const rows=it?.latest?.market_rows||it?.lastMarketRows||[];for(const r of rows)src.push(r)
    }
    const seen=new Set(),out=[];for(const r of src){const key=`${r.category}|${r.market||r.bet||''}|${r.main_line??''}|${JSON.stringify((r.values||[]).map(v=>[v.value,v.handicap,v.odd,v.main,v.suspended]))}`;if(seen.has(key))continue;seen.add(key);out.push(r)}return out;
  }
  function mnPreferredCats(x){
    const a=[];if(x?.h1)a.push('h1_total');if(x?.ft)a.push('over_under');if(x?.hc)a.push('asian_handicap');a.push('match_winner');return [...new Set(a)];
  }
  function mnFixtureSnapshot(x){
    const rows=mnFixtureRows(x),cats=mnPreferredCats(x),markets=[];
    const ctx={homeName:x?.home||'',awayName:x?.away||''};
    for(const c of cats){const picks=rows.filter(r=>r.category===c).map(r=>mnNormalizeRow(r,ctx)).filter(Boolean);if(!picks.length)continue;picks.sort((a,b)=>Number(b.main)-Number(a.main)||Math.abs(a.margin-4)-Math.abs(b.margin-4));markets.push(picks[0])}
    const fr=marketFreshness(rows,true);return {markets,rows:rows.length,freshness:fr};
  }
  function mnProbText(m){
    const p=m.prob||{};
    if(m.category==='match_winner')return `H ${mnPct(p.home)} • X ${mnPct(p.draw)} • A ${mnPct(p.away)}`;
    if(ASIAN_HANDICAP_CATEGORIES.has(m.category))return `H ${mnPct(p.home)} • A ${mnPct(p.away)}`;
    return `O ${mnPct(p.over)} • U ${mnPct(p.under)}`;
  }
  function mnOddsText(m){
    const d=m.dec||{};
    if(m.category==='match_winner')return `DEC H ${mnOdd(d.home)} / X ${mnOdd(d.draw)} / A ${mnOdd(d.away)}`;
    if(ASIAN_HANDICAP_CATEGORIES.has(m.category))return `DEC H ${mnOdd(d.home)} / A ${mnOdd(d.away)}`;
    return `DEC O ${mnOdd(d.over)} / U ${mnOdd(d.under)}`;
  }
  function mnMarketHTML(x,rank){
    if(!rank?.top)return '';
    const s=mnFixtureSnapshot(x),ms=s.markets||[];
    if(!ms.length)return `<div class="market-norm-shell"><div class="market-norm-head"><b>◈ MARKET NORMALIZATION • SHADOW</b><span>CHƯA CÓ MARKET HỢP LỆ</span></div><div class="market-norm-empty">TOP đã đạt nhưng chưa có cặp giá đủ để tính no-vig. Không suy diễn giá thiếu.</div></div>`;
    const boxes=ms.slice(0,4).map(m=>{const line=m.category==='match_winner'?'':Number.isFinite(Number(m.line))?` ${Number(m.line)>0?'+':''}${Number(m.line)}`:'';const marginCls=m.margin>=10?'market-norm-bad':m.margin<=6?'market-norm-good':'';return `<div class="market-norm-box"><div class="t"><b>${esc(mnMarketLabel(m.category,m.line))}${esc(line)}</b><span>${esc(m.bookmaker)}</span></div><div class="market-norm-p">NO-VIG • ${esc(mnProbText(m))}</div><div class="market-norm-odds">${esc(mnOddsText(m))}</div><div class="market-norm-odds ${marginCls}">BOOK MARGIN ${m.margin.toFixed(1)}% • chưa phải Model Probability</div></div>`}).join('');
    const age=s.freshness?.age_min==null?'—':`${s.freshness.age_min.toFixed(1)}m`,status=s.freshness?.status||'OK';
    return `<div class="market-norm-shell"><div class="market-norm-head"><b>◈ MARKET NORMALIZATION • SHADOW</b><span>${ms.length} MARKET</span></div><div class="market-norm-grid">${boxes}</div><div class="market-norm-foot"><span>Freshness: <b>${esc(age)}</b> • ${esc(status)}</span><span><b>No-vig</b> = xác suất thị trường sau khi loại margin; chưa chấm GOOD/BAD PRICE.</span></div></div>`;
  }
  function mnReadyTopCount(rows){return (rows||[]).filter(x=>x.__rank?.top&&mnFixtureSnapshot(x).markets.length).length}

  /* ===== V1.22.1 FAIR PRICE & EDGE ZONE SHADOW =====
     User policy: seek edge only inside a reasonable decimal-price zone.
     Outside zone = PASS in SHADOW. Fair probability is only compared when the
     model target and market settlement target are semantically identical. */
  const EI_PRICE_POLICY={min:1.65,max:2.20,sweetMin:1.80,sweetMax:2.05};
  function eiPct(v,d=1){return Number.isFinite(Number(v))?`${(Number(v)*100).toFixed(d)}%`:'—'}
  function eiSignedPct(v,d=1){if(!Number.isFinite(Number(v)))return '—';const x=Number(v)*100;return `${x>=0?'+':''}${x.toFixed(d)}%`}
  function eiPriceZone(dec){
    const d=Number(dec);if(!Number.isFinite(d)||d<=1)return {key:'NO_PRICE',label:'NO PRICE',cls:'bad',eligible:false,edgeMin:999};
    if(d<1.55)return {key:'TOO_SHORT',label:'TOO SHORT <1.55',cls:'bad',eligible:false,edgeMin:999};
    if(d<1.65)return {key:'EXPENSIVE',label:'EXPENSIVE 1.55–1.64',cls:'warn',eligible:false,edgeMin:999};
    if(d<1.80)return {key:'ACCEPTABLE',label:'ACCEPTABLE 1.65–1.79',cls:'ok',eligible:true,edgeMin:.06};
    if(d<=2.05)return {key:'SWEET',label:'SWEET 1.80–2.05',cls:'sweet',eligible:true,edgeMin:.04};
    if(d<=2.20)return {key:'ACCEPTABLE_HIGH',label:'ACCEPTABLE HIGH 2.06–2.20',cls:'ok',eligible:true,edgeMin:.07};
    return {key:'HIGH_VARIANCE',label:'HIGH VARIANCE >2.20',cls:'bad',eligible:false,edgeMin:999};
  }
  function eiCurrentTotal(x){const it=x?.latest||x?.h1||x?.ft||x?.hc,s=it?.latest||{};return Number(s.goals?.home||0)+Number(s.goals?.away||0)}
  function eiMarketPick(snapshot,category){return (snapshot?.markets||[]).find(m=>m.category===category)||null}
  function eiGoalFairCandidate(x,engine){
    const it=engine==='H1'?x?.h1:x?.ft;if(!it)return null;
    const snap=mnFixtureSnapshot(x),cat=engine==='H1'?'h1_total':'over_under',m=eiMarketPick(snap,cat);
    if(!m)return {engine,kind:'GOAL',supported:false,status:'NO_MARKET',reason:`Chưa có ${engine} O/U hợp lệ.`};
    const cur=eiCurrentTotal(x),line=Number(m.line);
    if(!Number.isFinite(line)||Math.abs(line-(cur+.5))>.061)return {engine,kind:'GOAL',supported:false,status:'TARGET_MISMATCH',market:m,reason:`Line ${Number.isFinite(line)?line:'—'} không phải current goals ${cur} + 0.5; Goal Radar không được dùng để giả fair probability cho target khác.`};
    const est=grEstimate(it,engine),model=Number(est?.prob)/100,dec=Number(m.dec?.over),market=Number(m.prob?.over),be=mnImp(dec),zone=eiPriceZone(dec);
    if(!Number.isFinite(model)||!Number.isFinite(dec)||!Number.isFinite(be))return {engine,kind:'GOAL',supported:false,status:'MODEL_WAIT',market:m,reason:'Chưa đủ probability/price hợp lệ để so fair price.'};
    const edge=model-be,ev=model*dec-1,rel=est?.reliability||grReliability(0),sampleN=Number(est?.n||0),basis=est?.basis||'MODEL';
    let verdict='PASS',cls='pass',reason='';
    if(!zone.eligible){verdict='PASS • PRICE OUTSIDE ZONE';reason=`Giá ${dec.toFixed(2)} nằm ngoài vùng ${EI_PRICE_POLICY.min.toFixed(2)}–${EI_PRICE_POLICY.max.toFixed(2)}.`}
    else if(basis==='MODEL'||sampleN<8){verdict='WAIT • FAIR MODEL';cls='wait';reason='Price nằm trong vùng nhưng calibration chưa đủ mẫu để gọi edge đáng tin.'}
    else if(edge<=0||ev<=0){verdict='PASS • NO EDGE';reason='Model probability không vượt break-even price.'}
    else if(edge<zone.edgeMin||ev<.05){verdict='WAIT PRICE • EDGE THIN';cls='wait';reason=`Edge chưa đạt ngưỡng SHADOW ${(zone.edgeMin*100).toFixed(0)}pp cho vùng giá này.`}
    else{verdict='SUITABLE • EDGE SHADOW';cls='good';reason='Signal target khớp market, price nằm vùng hợp lý và model vượt break-even đủ biên SHADOW.'}
    return {engine,kind:'GOAL',supported:true,status:verdict,cls,reason,market:m,selection:'OVER',line,dec,modelProb:model,marketProb:market,breakEven:be,edge,ev,zone,basis,sampleN,reliability:rel};
  }
  function eiHCPriceCandidate(x){
    const it=x?.hc;if(!it)return null;const snap=mnFixtureSnapshot(x),m=eiMarketPick(snap,'asian_handicap');if(!m)return {engine:'HC',kind:'HC',supported:false,status:'NO_MARKET',reason:'Chưa có AH hợp lệ.'};
    const e=it.eval||{},dir=String(e.states?.direction||'').toUpperCase(),sel=dir==='HOME'?'home':dir==='AWAY'?'away':null;if(!sel)return {engine:'HC',kind:'HC',supported:false,status:'NO_DIRECTION',market:m,reason:'HC chưa có LIVE direction rõ.'};
    const dec=Number(m.dec?.[sel]),zone=eiPriceZone(dec),fit=String(e.marketFit?.level||'NO_MARKET');
    return {engine:'HC',kind:'HC',supported:false,status:zone.eligible?'PRICE IN ZONE • FAIR COVER N/A':'PASS • PRICE OUTSIDE ZONE',cls:zone.eligible?'observer':'pass',reason:'HC LIVE GAP/strength chưa phải cover probability cho line cụ thể; chỉ kiểm tra price zone, không bịa fair probability.',market:m,selection:sel.toUpperCase(),dec,zone,marketProb:Number(m.prob?.[sel]),fit};
  }
  function eiCandidates(x){return [eiGoalFairCandidate(x,'H1'),eiGoalFairCandidate(x,'FT'),eiHCPriceCandidate(x)].filter(Boolean)}
  function eiCandidateHTML(c){
    const title=c.engine==='H1'?'H1 OVER':c.engine==='FT'?'FT OVER':`HC ${c.selection||''}`;
    if(!c.supported){const dec=Number(c.dec),z=c.zone,zone=z?`<span class="entry-edge-zone ${z.cls}">${esc(z.label)}</span>`:'';return `<div class="entry-edge-box ${esc(c.cls||'observer')}"><div class="entry-edge-title"><b>${esc(title)}</b><span>${c.market?esc(mnMarketLabel(c.market.category,c.market.line)):'OBS'}</span></div><div class="entry-edge-verdict">${esc(c.status||'OBSERVE')}</div>${zone}<div class="entry-edge-reason">${esc(c.reason||'')}</div>${Number.isFinite(dec)?`<div class="entry-edge-metrics"><div><span>PRICE</span><b>${dec.toFixed(2)}</b></div><div><span>NO-VIG MKT</span><b>${eiPct(c.marketProb)}</b></div></div>`:''}</div>`}
    return `<div class="entry-edge-box ${esc(c.cls)}"><div class="entry-edge-title"><b>${esc(title)} ${Number.isFinite(c.line)?esc(c.line):''}</b><span>${esc(c.basis)} n=${esc(c.sampleN)}</span></div><div class="entry-edge-verdict">${esc(c.status)}</div><span class="entry-edge-zone ${esc(c.zone.cls)}">${esc(c.zone.label)}</span><div class="entry-edge-metrics"><div><span>MODEL FAIR</span><b>${eiPct(c.modelProb)}</b></div><div><span>BREAK-EVEN</span><b>${eiPct(c.breakEven)}</b></div><div><span>NO-VIG MARKET</span><b>${eiPct(c.marketProb)}</b></div><div><span>PRICE</span><b>${c.dec.toFixed(2)}</b></div><div><span>EDGE</span><b>${eiSignedPct(c.edge)}</b></div><div><span>MODEL EV</span><b>${eiSignedPct(c.ev)}</b></div></div><div class="entry-edge-reason">${esc(c.reason)}</div></div>`
  }
  function eiEntryHTML(x,rank){
    if(!rank?.top)return '';const cs=eiCandidates(x);if(!cs.length)return '';const good=cs.filter(c=>c.supported&&c.cls==='good').length,pass=cs.filter(c=>/PASS/.test(String(c.status||''))).length;
    return `<div class="entry-edge-shell"><div class="entry-edge-head"><b>◇ FAIR PRICE & EDGE • SHADOW</b><span>${good?`${good} EDGE`:pass?`${pass} PASS`:'OBSERVE'}</span></div><div class="entry-edge-grid">${cs.map(eiCandidateHTML).join('')}</div><div class="entry-edge-foot"><b>Rule:</b> chỉ tìm edge trong DEC ${EI_PRICE_POLICY.min.toFixed(2)}–${EI_PRICE_POLICY.max.toFixed(2)}; SWEET ${EI_PRICE_POLICY.sweetMin.toFixed(2)}–${EI_PRICE_POLICY.sweetMax.toFixed(2)}. Ngoài vùng = PASS. Đây là SHADOW, chưa thay TOP/engine.</div></div>`
  }

  /* ===== V1.22.2 MARKET + DATA BEHAVIOR SHADOW =====
     Cross-check market with football state, data freshness and event context.
     Observation only: no ranking/engine mutation and no automatic entry action yet. */
  function biEventGuard(it){
    if(!it)return null;const now=Date.now(),cool=Number(it.cooldownUntil||0),reset=Number(it.resetAt||0);
    if(cool>now)return {state:'EVENT_REPRICING',cls:'warn',reason:`Đang cooldown/rebaseline còn ${Math.ceil((cool-now)/1000)}s.`};
    if(reset&&now-reset<180000)return {state:'EVENT_REPRICING',cls:'warn',reason:'Goal/Red/event gần đây — market move cần rebaseline trước khi đọc như pressure mới.'};
    return null;
  }
  function biDataGuard(it,engine){
    if(!it)return {state:'NO_DATA',cls:'warn',reason:'Không có engine item.'};const d=feMasterDescriptor(it,engine),e=it.eval||{};
    const partial=engine==='HC'?['PARTIAL','MARKET_WATCH'].includes(String(e.dataTier||'')):String(e.scoreMode||'')!=='FULL';
    if(partial)return {state:'DATA_UNVERIFIED',cls:'warn',reason:'Football data chưa FULL — không kết luận market conflict/agreement mạnh.'};
    if(Number(d?.dq||0)<4)return {state:'DATA_UNVERIFIED',cls:'warn',reason:`DQ ${Number(d?.dq||0)}/5 chưa đủ để kiểm chứng market.`};
    if(Number(d?.fresh||99999)>60)return {state:'DATA_STALE',cls:'warn',reason:`Football evidence stale ~${Math.round(Number(d?.fresh||0))}s.`};
    return null;
  }
  function biGoalState(x,engine){
    const it=engine==='H1'?x?.h1:x?.ft;if(!it)return null;const ev=biEventGuard(it);if(ev)return {engine,...ev};const dg=biDataGuard(it,engine);if(dg)return {engine,...dg};
    const snap=mnFixtureSnapshot(x),cat=engine==='H1'?'h1_total':'over_under',m=eiMarketPick(snap,cat),est=grEstimate(it,engine),model=Number(est?.prob)/100,d=feMasterDescriptor(it,engine),strongFootball=Number(d?.stateRank||0)>=3&&Number.isFinite(model)&&model>=.58;
    if(!m)return {engine,state:strongFootball?'FOOTBALL_LEADS':'NO_MARKET',cls:strongFootball?'lead':'neutral',reason:strongFootball?'Football READY/STRONG nhưng chưa có market hợp lệ để xác nhận.':'Chưa có market đủ dữ liệu.'};
    const mp=Number(m.prob?.over),mv=it?.latest?.market?.move||it?.eval?.market_movement||{},ld=Number(mv?.line_delta),pd=Number(mv?.over_price_delta),sn=Number(it?.latest?.market?.history?.snapshot_count||0);
    const push=(Number.isFinite(ld)&&ld>0)||(Number.isFinite(pd)&&pd<=-.02),against=(Number.isFinite(ld)&&ld<0)||(Number.isFinite(pd)&&pd>=.04);
    if(strongFootball&&against){const hard=sn>=3||(Number.isFinite(pd)&&pd>=.08)||(Number.isFinite(ld)&&ld<=-.25);return {engine,state:hard?'HARD_DIVERGENCE':'SOFT_DIVERGENCE',cls:'bad',reason:`Football ${it.state} nhưng O/U move phản hướng${sn?` qua ${sn} snapshot`:''}.`}}
    if(strongFootball&&push){const hard=sn>=3||mp>=.62;return {engine,state:hard?'HARD_AGREEMENT':'SOFT_AGREEMENT',cls:'good',reason:`Football ${it.state} + market O/U đang cùng hướng${sn?` (${sn} snapshot)`:''}.`}}
    if(Number.isFinite(mp)&&mp>=.58&&(!Number.isFinite(model)||model<.58))return {engine,state:'MARKET_LEADS',cls:'lead',reason:`Market no-vig OVER ${eiPct(mp)} đi trước football probability ${Number.isFinite(model)?eiPct(model):'—'}.`};
    if(strongFootball&&Number.isFinite(mp)&&mp<.55)return {engine,state:'FOOTBALL_LEADS',cls:'lead',reason:`Football ${it.state} / model ${eiPct(model)} đi trước market no-vig OVER ${eiPct(mp)}.`};
    if(strongFootball&&Number.isFinite(mp)&&mp>=.52)return {engine,state:'SOFT_AGREEMENT',cls:'good',reason:`Football và market cùng nghiêng OVER nhưng movement chưa đủ mạnh.`};
    if(strongFootball&&Number.isFinite(mp)&&mp<=.47)return {engine,state:'SOFT_DIVERGENCE',cls:'bad',reason:`Football nghiêng goal nhưng market no-vig OVER chỉ ${eiPct(mp)}.`};
    return {engine,state:'NEUTRAL',cls:'neutral',reason:`Chưa có alignment đủ rõ • model ${Number.isFinite(model)?eiPct(model):'—'} • market ${Number.isFinite(mp)?eiPct(mp):'—'}.`};
  }
  function biHCState(x){
    const it=x?.hc;if(!it)return null;const ev=biEventGuard(it);if(ev)return {engine:'HC',...ev};const dg=biDataGuard(it,'HC');if(dg)return {engine:'HC',...dg};
    const e=it.eval||{},lvl=String(e.marketFit?.level||'NO_MARKET'),dir=String(e.states?.direction||'NEUTRAL');
    if(lvl==='HARD_AGREEMENT')return {engine:'HC',state:'HARD_AGREEMENT',cls:'good',reason:`${dir} football state + AH line/price HARD AGREEMENT.`};
    if(lvl==='SOFT_AGREEMENT')return {engine:'HC',state:'SOFT_AGREEMENT',cls:'good',reason:`${dir} football state + AH market SOFT AGREEMENT.`};
    if(lvl==='HARD_DIVERGENCE')return {engine:'HC',state:'HARD_DIVERGENCE',cls:'bad',reason:`${dir} football state nhưng AH market HARD DIVERGENCE.`};
    if(lvl==='SOFT_DIVERGENCE'||e.state==='DIVERGENCE')return {engine:'HC',state:'SOFT_DIVERGENCE',cls:'bad',reason:`${dir} football state đang bị AH market phản biện.`};
    if(lvl==='NO_MARKET'&&feMasterStateRank(e.state,'HC')>=2)return {engine:'HC',state:'FOOTBALL_LEADS',cls:'lead',reason:`${dir} LIVE state có lợi thế nhưng market chưa đủ để xác nhận.`};
    return {engine:'HC',state:'NEUTRAL',cls:'neutral',reason:`Market fit ${lvl}; chưa đủ kết luận behavior mạnh.`};
  }
  function biStates(x){return [biGoalState(x,'H1'),biGoalState(x,'FT'),biHCState(x)].filter(Boolean)}
  function biOverall(states){
    const s=states||[],has=k=>s.some(x=>x.state===k),find=re=>s.find(x=>re.test(x.state));
    let hit=find(/^HARD_DIVERGENCE$/);if(hit)return {state:'HARD_CONFLICT',cls:'bad',title:'⚠ HARD CONFLICT',reason:`${hit.engine}: ${hit.reason}`};
    hit=find(/^EVENT_REPRICING$/);if(hit)return {state:'REBASELINE',cls:'warn',title:'↻ EVENT REPRICING',reason:`${hit.engine}: ${hit.reason}`};
    hit=find(/^DATA_(UNVERIFIED|STALE)$/);if(hit)return {state:'VERIFY_DATA',cls:'warn',title:'△ VERIFY DATA',reason:`${hit.engine}: ${hit.reason}`};
    if(has('HARD_AGREEMENT'))return {state:'CONFIRMED',cls:'good',title:'✓ DATA + MARKET CONFIRMED',reason:'Có ít nhất một cơ chế HARD AGREEMENT sau data gate.'};
    if(has('SOFT_DIVERGENCE'))return {state:'CAUTION',cls:'bad',title:'⚠ SOFT CONFLICT',reason:'Football và market đang có phản biện; chưa gọi entry policy.'};
    if(has('MARKET_LEADS'))return {state:'MARKET_LEADS',cls:'lead',title:'MARKET LEADS',reason:'Market đi trước football data; chờ dữ liệu bắt kịp.'};
    if(has('FOOTBALL_LEADS'))return {state:'FOOTBALL_LEADS',cls:'lead',title:'FOOTBALL LEADS',reason:'Football state đi trước market; chờ market xác nhận hoặc giữ observation.'};
    if(has('SOFT_AGREEMENT'))return {state:'ALIGNED',cls:'good',title:'✓ SOFT ALIGNMENT',reason:'Football và market cùng hướng nhưng chưa đủ HARD confirmation.'};
    return {state:'NEUTRAL',cls:'neutral',title:'NEUTRAL',reason:'Chưa có market/data behavior đủ mạnh.'};
  }
  function biBehaviorHTML(x,rank){
    if(!rank?.top)return '';const states=biStates(x),o=biOverall(states);if(!states.length)return '';
    return `<div class="behavior-shell"><div class="behavior-head"><b>◎ MARKET + DATA BEHAVIOR • SHADOW</b><span>${esc(o.state)}</span></div><div class="behavior-summary ${esc(o.cls)}"><div><b>${esc(o.title)}</b><small>${esc(o.reason)}</small></div></div><div class="behavior-grid">${states.map(s=>`<div class="behavior-box"><div class="t"><b>${esc(s.engine)}</b><span>BEHAVIOR</span></div><div class="behavior-state ${esc(s.cls)}">${esc(s.state)}</div><div class="behavior-reason">${esc(s.reason)}</div></div>`).join('')}</div><div class="behavior-foot"><b>Nguyên tắc:</b> market không tự sinh lựa chọn. Agreement/Divergence chỉ hợp lệ sau Data Gate + Freshness + Event Rebaseline. Behavior chỉ là lớp kiểm chứng; quyết định ứng xử cuối được Entry Policy V1.22.3 xử lý riêng và vẫn không tự đặt cược.</div></div>`
  }

  /* ===== V1.22.3 ENTRY POLICY ENGINE — ADVISORY ONLY =====
     Combines Signal + Data Reality + Market Behavior + Price Zone + Edge into
     a transparent response policy. No auto-bet, no ranking mutation, no core mutation. */
  function epBehaviorForEngine(x,engine){
    if(engine==='H1'||engine==='FT')return biGoalState(x,engine);
    if(engine==='HC')return biHCState(x);
    return null;
  }
  function epSignalGate(x,engine){
    const it=engine==='H1'?x?.h1:engine==='FT'?x?.ft:x?.hc;if(!it)return {ok:false,level:'bad',label:'SIGNAL N/A',reason:'Không có engine item.'};
    if(engine==='HC'){const e=it.eval||{},rank=feMasterStateRank(e.state,'HC'),ok=rank>=4;return {ok,level:ok?'ok':'wait',label:`SIGNAL ${esc(e.state||'WAIT')}`,reason:ok?'HC STRONG.':'HC chưa STRONG; chỉ theo dõi.'}}
    const e=it.eval||{},ok=['READY','STRONG'].includes(String(it.state||''))&&e.scoreMode==='FULL'&&!e.hardVeto;return {ok,level:ok?'ok':'wait',label:`SIGNAL ${esc(it.state||'WAIT')}`,reason:ok?'Goal engine READY/STRONG với FULL data.':'Goal engine chưa đủ READY/STRONG FULL.'};
  }
  function epDataGate(x,engine,behavior){
    const it=engine==='H1'?x?.h1:engine==='FT'?x?.ft:x?.hc;if(!it)return {ok:false,level:'bad',label:'DATA N/A',reason:'Không có data.'};
    if(['DATA_UNVERIFIED','DATA_STALE'].includes(String(behavior?.state||'')))return {ok:false,level:'bad',label:'DATA VERIFY',reason:behavior?.reason||'Data gate chưa đạt.'};
    if(String(behavior?.state||'')==='EVENT_REPRICING')return {ok:false,level:'wait',label:'REBASELINE',reason:behavior?.reason||'Vừa có event lớn.'};
    if(engine==='HC'){const e=it.eval||{},ok=Number(e.dq||0)>=4&&!['STALE','DATA_INCOMPLETE'].includes(String(e.state||''));return {ok,level:ok?'ok':'bad',label:`DQ ${e.dq??'—'}/5`,reason:ok?'HC data đủ kiểm chứng.':'HC data chưa đủ sạch.'}}
    const e=it.eval||{},ok=Number(e.quality||0)>=4&&e.scoreMode==='FULL'&&!e.hardVeto;return {ok,level:ok?'ok':'bad',label:`DQ ${e.quality??'—'}/5`,reason:ok?'Goal data đủ kiểm chứng.':'Goal data chưa đủ sạch.'};
  }
  function epMarketGate(behavior){
    const s=String(behavior?.state||'NEUTRAL');
    if(s==='HARD_AGREEMENT')return {ok:true,level:'ok',label:'MKT HARD ✓',reason:behavior.reason};
    if(s==='SOFT_AGREEMENT')return {ok:true,level:'ok',label:'MKT SOFT ✓',reason:behavior.reason};
    if(s==='HARD_DIVERGENCE')return {ok:false,level:'bad',label:'MKT HARD ×',reason:behavior.reason};
    if(s==='SOFT_DIVERGENCE')return {ok:false,level:'bad',label:'MKT CONFLICT',reason:behavior.reason};
    if(s==='MARKET_LEADS')return {ok:false,level:'info',label:'MARKET LEADS',reason:behavior.reason};
    if(s==='FOOTBALL_LEADS')return {ok:false,level:'info',label:'FOOTBALL LEADS',reason:behavior.reason};
    if(s==='EVENT_REPRICING')return {ok:false,level:'wait',label:'REPRICE',reason:behavior.reason};
    if(/^DATA_/.test(s))return {ok:false,level:'bad',label:'VERIFY DATA',reason:behavior.reason};
    return {ok:false,level:'wait',label:'MKT NEUTRAL',reason:behavior?.reason||'Market chưa xác nhận.'};
  }
  function epCandidateForEngine(x,engine){return eiCandidates(x).find(c=>c.engine===engine)||null}
  function epPriceGate(c){
    if(!c)return {ok:false,level:'wait',label:'PRICE N/A',reason:'Chưa có market/price phù hợp.'};
    const z=c.zone;if(!z)return {ok:false,level:'wait',label:'PRICE WAIT',reason:c.reason||'Chưa có price zone.'};
    if(!z.eligible)return {ok:false,level:'bad',label:`PRICE ${z.key}`,reason:`Giá ngoài vùng hợp lý ${EI_PRICE_POLICY.min.toFixed(2)}–${EI_PRICE_POLICY.max.toFixed(2)}.`};
    return {ok:true,level:z.key==='SWEET'?'ok':'info',label:`PRICE ${z.key}`,reason:`Giá ${Number(c.dec).toFixed(2)} nằm trong vùng policy.`};
  }
  function epEdgeGate(c){
    if(!c)return {ok:false,level:'wait',label:'EDGE N/A',reason:'Chưa có candidate.'};
    if(!c.supported)return {ok:false,level:'wait',label:c.kind==='HC'?'FAIR COVER N/A':'EDGE WAIT',reason:c.reason||'Fair probability chưa được hỗ trợ.'};
    const s=String(c.status||'');
    if(c.cls==='good')return {ok:true,level:'ok',label:`EDGE ${eiSignedPct(c.edge)}`,reason:c.reason};
    if(/PRICE OUTSIDE|NO EDGE/.test(s))return {ok:false,level:'bad',label:/NO EDGE/.test(s)?'NO EDGE':'EDGE EXPIRED',reason:c.reason};
    if(/WAIT PRICE|EDGE THIN/.test(s))return {ok:false,level:'wait',label:'EDGE THIN',reason:c.reason};
    return {ok:false,level:'wait',label:'EDGE WAIT',reason:c.reason||s};
  }
  function epPolicyForEngine(x,engine){
    const behavior=epBehaviorForEngine(x,engine),signal=epSignalGate(x,engine),data=epDataGate(x,engine,behavior),market=epMarketGate(behavior),cand=epCandidateForEngine(x,engine),price=epPriceGate(cand),edge=epEdgeGate(cand);
    let status='WAIT_CONFIRM',cls='wait-confirm',reason='Chờ thêm xác nhận.';
    const bs=String(behavior?.state||'');
    if(bs==='HARD_DIVERGENCE'){status='PASS';cls='pass';reason='Hard market/data conflict: không đuổi theo signal.'}
    else if(bs==='EVENT_REPRICING'||/^DATA_/.test(bs)){status='CAUTION';cls='caution';reason=bs==='EVENT_REPRICING'?'Vừa có event lớn; cần rebaseline trước khi xét entry.':'Data chưa đủ sạch/fresh để xác nhận entry.'}
    else if(!signal.ok){status='WAIT_CONFIRM';cls='wait-confirm';reason='Signal chưa đạt READY/STRONG phù hợp.'}
    else if(!data.ok){status='CAUTION';cls='caution';reason='Signal có nhưng Data Gate chưa đạt.'}
    else if(cand&&cand.zone&&!cand.zone.eligible){status='PASS';cls='pass';reason='Price ngoài vùng hợp lý; edge được xem là hết/không phù hợp.'}
    else if(bs==='SOFT_DIVERGENCE'){status='CAUTION';cls='caution';reason='Market đang phản biện football signal; chưa phù hợp để vào.'}
    else if(cand?.supported&&/NO EDGE/.test(String(cand.status||''))){status='PASS';cls='pass';reason='Model không vượt break-even; không có edge.'}
    else if(cand?.supported&&/WAIT PRICE|EDGE THIN/.test(String(cand.status||''))){status='WAIT_PRICE';cls='wait-price';reason='Trận/signal có thể tốt nhưng giá hiện tại chưa cho đủ edge.'}
    else if(cand?.supported&&cand.cls==='good'&&['HARD_AGREEMENT','SOFT_AGREEMENT'].includes(bs)){status='SUITABLE';cls='suitable';reason='Signal + Data + Market alignment + Price Zone + Edge đều qua gate.'}
    else if(cand?.supported&&cand.cls==='good'&&['FOOTBALL_LEADS','MARKET_LEADS','NEUTRAL','NO_MARKET'].includes(bs)){status='WAIT_CONFIRM';cls='wait-confirm';reason='Edge/price có thể đạt nhưng market-data alignment chưa được xác nhận.'}
    else if(engine==='HC'&&price.ok){status='WAIT_CONFIRM';cls='wait-confirm';reason='HC signal/price có thể phù hợp nhưng Fair Cover Probability cho line cụ thể chưa được chứng minh; không gọi SUITABLE.'}
    else if(!price.ok&&price.level==='bad'){status='PASS';cls='pass';reason='Price ngoài vùng policy.'}
    else{status='WAIT_CONFIRM';cls='wait-confirm';reason='Chưa đủ tất cả gate để gọi SUITABLE.'}
    return {engine,status,cls,reason,behavior,signal,data,market,price,edge,candidate:cand};
  }
  function epPolicies(x){return [x?.h1?epPolicyForEngine(x,'H1'):null,x?.ft?epPolicyForEngine(x,'FT'):null,x?.hc?epPolicyForEngine(x,'HC'):null].filter(Boolean)}
  function epOverall(ps){
    const p=ps||[],find=s=>p.find(x=>x.status===s),beh=re=>p.find(x=>re.test(String(x.behavior?.state||'')));
    let x=beh(/^HARD_DIVERGENCE$/);if(x)return {status:'PASS',cls:'pass',reason:`${x.engine}: hard market/data conflict — không ưu tiên entry.`,engine:x.engine};
    x=beh(/^(EVENT_REPRICING|DATA_UNVERIFIED|DATA_STALE)$/);if(x)return {status:'CAUTION',cls:'caution',reason:`${x.engine}: ${x.reason}`,engine:x.engine};
    x=beh(/^SOFT_DIVERGENCE$/);if(x)return {status:'CAUTION',cls:'caution',reason:`${x.engine}: market đang phản biện football signal.`,engine:x.engine};
    x=find('SUITABLE');if(x)return {status:'SUITABLE',cls:'suitable',reason:`${x.engine}: ${x.reason}`,engine:x.engine};
    x=find('WAIT_PRICE');if(x)return {status:'WAIT_PRICE',cls:'wait-price',reason:`${x.engine}: ${x.reason}`,engine:x.engine};
    x=find('WAIT_CONFIRM');if(x)return {status:'WAIT_CONFIRM',cls:'wait-confirm',reason:`${x.engine}: ${x.reason}`,engine:x.engine};
    x=find('CAUTION');if(x)return {status:'CAUTION',cls:'caution',reason:`${x.engine}: ${x.reason}`,engine:x.engine};
    x=find('PASS')||p[0];return {status:'PASS',cls:'pass',reason:x?`${x.engine}: ${x.reason}`:'Không có entry candidate.',engine:x?.engine||null};
  }
  function epGateHTML(g,name){return `<span class="entry-policy-gate ${esc(g?.level||'wait')}">${esc(name)} • ${esc(g?.label||'—')}</span>`}
  function epPolicyCardHTML(p){
    const cand=p.candidate,title=p.engine==='H1'?'H1 O/U':p.engine==='FT'?'FT O/U':'HANDICAP',market=cand?.market?mnMarketLabel(cand.market.category,cand.market.line):'NO MARKET';
    return `<div class="entry-policy-card"><div class="top"><div><b>${esc(title)}</b><div style="margin-top:2px;font-size:6.8px;color:var(--muted)">${esc(market)}</div></div><span class="entry-policy-status ${esc(p.cls)}">${esc(p.status)}</span></div><div class="entry-policy-gates">${epGateHTML(p.signal,'SIGNAL')}${epGateHTML(p.data,'DATA')}${epGateHTML(p.market,'MARKET')}${epGateHTML(p.price,'PRICE')}${epGateHTML(p.edge,'EDGE')}</div><div class="entry-policy-reason">${esc(p.reason)}</div></div>`;
  }
  function epEntryPolicyHTML(x,rank){
    if(!rank?.top)return '';const ps=epPolicies(x);if(!ps.length)return '';const o=epOverall(ps);
    return `<div class="entry-policy-shell"><div class="entry-policy-head"><b>◆ ENTRY POLICY • ADVISORY</b><span>${esc(o.status)}</span></div><div class="entry-policy-overall ${esc(o.cls)}"><b>${esc(o.status)}</b><small>${esc(o.reason)}</small></div><div class="entry-policy-grid">${ps.map(epPolicyCardHTML).join('')}</div><div class="entry-policy-foot"><b>Gating:</b> SIGNAL → DATA → MARKET BEHAVIOR → PRICE ZONE → EDGE. <b>SUITABLE</b> chỉ xuất hiện khi cùng một market candidate qua đủ các gate. Không tự đặt cược, không tự đổi TOP Ranking. HC chưa có Fair Cover Probability thì không được gọi SUITABLE chỉ nhờ GAP/market.</div></div>`
  }
  function epSuitableTopCount(rows){return (rows||[]).filter(x=>x.__rank?.top&&epOverall(epPolicies(x)).status==='SUITABLE').length}


  /* ===== V1.22.4 ENTRY VALIDATION — PAPER / COUNTERFACTUAL ONLY =====
     Captures Entry Policy states for TOP fixtures and resolves exact H1/FT O/U
     market outcomes later. It never mutates policy, ranking, thresholds or core.
     HC is captured as observation only until exact live-AH fair-cover semantics
     are validated. Actual Bet Tracker ROI remains a separate evidence stream. */
  const ENTRY_VALIDATION_KEY='fe_entry_validation_v1224',ENTRY_VALIDATION_MAX=2600;
  function evRead(){try{const x=JSON.parse(localStorage.getItem(ENTRY_VALIDATION_KEY)||'[]');return Array.isArray(x)?x.slice(-ENTRY_VALIDATION_MAX):[]}catch{return []}}
  function evWrite(rows){try{localStorage.setItem(ENTRY_VALIDATION_KEY,JSON.stringify((rows||[]).slice(-ENTRY_VALIDATION_MAX)))}catch(e){log('Entry Validation storage error',e.message)}}
  function evPolicyMarketType(engine){return engine==='H1'?'OU_H1':engine==='FT'?'OU_FT':'AH_FT'}
  function evPolicyItem(x,engine){return engine==='H1'?x?.h1:engine==='FT'?x?.ft:x?.hc}
  function evPolicySignature(r){return [r.policy_status,r.market_type,r.selection,Number(r.line),r.price_zone,Number.isFinite(Number(r.price))?Math.round(Number(r.price)*20)/20:'-',r.behavior_state].join('|')}
  function evCaptureMasterRows(rows){
    const now=Date.now(),store=evRead(),newRows=[];let added=0;
    for(const x of rows||[]){if(!x?.__rank?.top)continue;const ps=epPolicies(x);
      for(const p of ps){const c=p?.candidate;if(!c?.market)continue;const engine=p.engine,it=evPolicyItem(x,engine),s=it?.latest||{},dec=Number(c.dec),line=Number(c.market?.line??c.line),sel=String(c.selection||'').toUpperCase();
        if(!Number.isFinite(dec)||!Number.isFinite(line)||!sel)continue;
        if(engine!=='HC'&&!c.supported)continue;
        const r={id:`EV-${now}-${Math.random().toString(36).slice(2,7)}`,schema:'ENTRY_VALIDATION_V1.22.4',sample_type:'ENTRY_POLICY_PAPER',fixture_id:Number(x.id),league:x.league||'',home:x.home||'',away:x.away||'',engine,policy_status:p.status,policy_reason:p.reason||'',captured_at:now,minute:Number(s.minute||0),entry_score:{home:Number(s.goals?.home||0),away:Number(s.goals?.away||0)},market_type:evPolicyMarketType(engine),selection:sel,line,price:dec,odds_format:'DEC',price_zone:c.zone?.key||'NO_ZONE',behavior_state:String(p.behavior?.state||'NEUTRAL'),signal_state:String(p.signal?.state||p.signal?.label||''),data_level:String(p.data?.label||''),market_level:String(p.market?.label||''),edge_level:String(p.edge?.label||''),model_prob:Number.isFinite(Number(c.modelProb))?Number(c.modelProb):null,break_even:Number.isFinite(Number(c.breakEven))?Number(c.breakEven):null,market_prob:Number.isFinite(Number(c.marketProb))?Number(c.marketProb):null,edge:Number.isFinite(Number(c.edge))?Number(c.edge):null,model_ev:Number.isFinite(Number(c.ev))?Number(c.ev):null,candidate_supported:!!c.supported,auto_settle_supported:engine==='H1'||engine==='FT',resolution:engine==='HC'?'OBSERVATION_ONLY':'OPEN',outcome:null,unit_pl:null,resolved_at:null};
        r.signature=evPolicySignature(r);
        const prev=[...store].reverse().find(z=>Number(z.fixture_id)===r.fixture_id&&z.engine===engine);
        if(prev){const age=now-Number(prev.captured_at||0);if(prev.signature===r.signature&&age<15*60000)continue;if(prev.signature!==r.signature&&age<90000)continue}
        store.push(r);newRows.push(r);added++;
      }
    }
    if(added){evWrite(store);if(typeof feDbQueueEntryDecision==='function')newRows.forEach(r=>feDbQueueEntryDecision(r).catch(()=>{}))}return added
  }
  function evSettleOU(line,selection,total){const legs=splitQuarter(Number(line)).map(l=>legOutcome(String(selection).toUpperCase()==='OVER'?Number(total)-l:l-Number(total)));return combineLegOutcomes(legs)}
  function evResolveRecord(r,f){
    if(!r?.auto_settle_supported||r.resolution!=='OPEN')return false;const st=String(f?.status||'');let sc=null;
    if(r.engine==='H1'){if(!['HT','2H','ET','BT','P','FT','AET','PEN'].includes(st)||f?.halftime?.home==null)return false;sc=f.halftime}
    else if(r.engine==='FT'){if(!['FT','AET','PEN'].includes(st)||f?.fulltime?.home==null)return false;sc=f.fulltime}
    else return false;
    const total=Number(sc.home)+Number(sc.away),result=evSettleOU(r.line,r.selection,total);if(!result||result==='MIXED')return false;
    r.resolution='RESOLVED';r.outcome=result;r.unit_pl=outcomeProfit(result,1,r.price,'DEC');r.final_score={home:Number(sc.home),away:Number(sc.away)};r.resolved_at=Date.now();return true
  }
  async function evRefreshResolutions(showToastFlag=true){
    if(!els.fkey.value.trim()){if(showToastFlag)showToast('err','Chưa có Football API Key','Lưu API key trước để cập nhật Entry Validation.');return}
    const rows=evRead(),open=rows.filter(r=>r.resolution==='OPEN'&&r.auto_settle_supported),ids=[...new Set(open.map(r=>Number(r.fixture_id)).filter(Number.isFinite))];if(!ids.length){renderEntryValidation();if(showToastFlag)showToast('ok','Entry Validation','Không có mẫu H1/FT đang chờ kết quả.');return}
    let resolved=0,resolvedRows=[];const cache={};
    await mapLimit(ids,3,async fid=>{try{const raw=await football('/fixtures',{id:fid,timezone:TZ},true),f=compactTrackerFixture(raw?.[0]);if(f)cache[fid]=f}catch(e){log('Entry Validation fixture resolve error',{fid,error:e.message})}});
    for(const r of rows){const f=cache[Number(r.fixture_id)];if(f&&evResolveRecord(r,f)){resolved++;resolvedRows.push(r)}}
    if(resolved){evWrite(rows);if(typeof feDbQueueEntryDecision==='function')resolvedRows.forEach(r=>feDbQueueEntryDecision(r).catch(()=>{}))}renderEntryValidation();renderEntryCalibration();if(showToastFlag)showToast('ok','Entry Validation cập nhật',`${resolved} mẫu vừa được settle • ${ids.length} fixture kiểm tra.`)
  }
  function evReliability(n){return n>=100?'TỐT':n>=30?'ĐỦ XEM':n>=10?'SỚM':'MẪU MỎNG'}
  function evGroupStats(rows,keyFn){const out={};for(const r of rows){const k=keyFn(r);if(!out[k])out[k]={n:0,pl:0,pos:0,neg:0,push:0,edgeSum:0,edgeN:0};const g=out[k];g.n++;g.pl+=Number(r.unit_pl||0);if(Number(r.unit_pl)>0)g.pos++;else if(Number(r.unit_pl)<0)g.neg++;else g.push++;if(Number.isFinite(Number(r.edge))){g.edgeSum+=Number(r.edge);g.edgeN++}}return out}
  function evStatusClass(s){return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'_')}
  function evStatusOrder(){return ['SUITABLE','WAIT_PRICE','WAIT_CONFIRM','CAUTION','PASS']}
  function evExport(){const rows=evRead();validationDownload(`football_edge_entry_validation_${new Date().toISOString().slice(0,10)}.json`,'application/json',JSON.stringify({schema:'ENTRY_VALIDATION_V1.22.4',exported_at:new Date().toISOString(),rows},null,2))}
  function renderEntryValidation(){
    const el=$('validationEntryPolicy');if(!el)return;const rows=evRead(),resolved=rows.filter(r=>r.resolution==='RESOLVED'&&['H1','FT'].includes(r.engine)),open=rows.filter(r=>r.resolution==='OPEN').length,hcObs=rows.filter(r=>r.engine==='HC').length,groups=evGroupStats(resolved,r=>r.policy_status),eng=evGroupStats(resolved,r=>r.engine),suitable=groups.SUITABLE||{n:0,pl:0,pos:0,neg:0,push:0},other=resolved.filter(r=>r.policy_status!=='SUITABLE'),otherPl=other.reduce((a,r)=>a+Number(r.unit_pl||0),0),otherN=other.length;
    const statusRows=evStatusOrder().map(st=>{const g=groups[st]||{n:0,pl:0,pos:0,neg:0,push:0,edgeSum:0,edgeN:0},roi=g.n?g.pl/g.n*100:0,pos=g.n?g.pos/g.n*100:0,edge=g.edgeN?g.edgeSum/g.edgeN:null;return `<div class="entry-val-row"><b class="entry-val-status ${evStatusClass(st)}">${esc(st)}</b><span>${g.n}</span><span class="${roi>0?'entry-val-pos':roi<0?'entry-val-neg':'entry-val-neutral'}">${g.n?roi.toFixed(1)+'%':'—'}</span><span>${g.n?pos.toFixed(1)+'%':'—'}</span><span class="ev-hide-mobile">${edge==null?'—':eiSignedPct(edge)}</span><span class="ev-hide-mobile">${evReliability(g.n)}</span></div>`}).join('');
    const h1=eng.H1||{n:0,pl:0},ft=eng.FT||{n:0,pl:0},h1roi=h1.n?h1.pl/h1.n*100:0,ftroi=ft.n?ft.pl/ft.n*100:0,sroi=suitable.n?suitable.pl/suitable.n*100:0,oroi=otherN?otherPl/otherN*100:0;
    el.innerHTML=`<div class="entry-val-shell"><div class="entry-val-head"><div><b>V1.22.4 • ENTRY VALIDATION</b><span>Đo PAPER outcome của đúng market/line/price đã xuất hiện trên TOP card. H1/FT O/U tự settle; HC chỉ quan sát cho đến khi fair-cover + settlement semantics được chứng minh.</span></div><div class="entry-val-badge">POLICY EVIDENCE</div></div><div class="entry-val-actions"><button id="entryValidationRefreshBtn" type="button">↻ CẬP NHẬT KẾT QUẢ</button><button id="entryValidationExportBtn" type="button">XUẤT ENTRY JSON</button></div><div class="entry-val-kpis"><div class="entry-val-kpi"><span>TỔNG SNAPSHOT</span><b>${rows.length}</b></div><div class="entry-val-kpi"><span>ĐÃ RESOLVE H1/FT</span><b>${resolved.length}</b></div><div class="entry-val-kpi"><span>ĐANG CHỜ</span><b>${open}</b></div><div class="entry-val-kpi"><span>HC OBSERVATION</span><b>${hcObs}</b></div><div class="entry-val-kpi"><span>SUITABLE RESOLVED</span><b>${suitable.n}</b></div></div>${resolved.length?`<div class="entry-val-table"><div class="entry-val-row head"><span>POLICY</span><span>N</span><span>PAPER ROI</span><span>POSITIVE</span><span class="ev-hide-mobile">AVG EDGE</span><span class="ev-hide-mobile">RELIABILITY</span></div>${statusRows}</div><div class="entry-val-compare"><div><span>SUITABLE PAPER ROI</span><b class="${sroi>0?'entry-val-pos':sroi<0?'entry-val-neg':''}">${suitable.n?sroi.toFixed(1)+'%':'—'} • n=${suitable.n}</b></div><div><span>NON-SUITABLE PAPER ROI</span><b class="${oroi>0?'entry-val-pos':oroi<0?'entry-val-neg':''}">${otherN?oroi.toFixed(1)+'%':'—'} • n=${otherN}</b></div><div><span>H1 PAPER ROI</span><b>${h1.n?h1roi.toFixed(1)+'%':'—'} • n=${h1.n}</b></div><div><span>FT PAPER ROI</span><b>${ft.n?ftroi.toFixed(1)+'%':'—'} • n=${ft.n}</b></div></div>`:`<div class="entry-val-empty">Chưa có mẫu H1/FT đã resolve. App sẽ thu snapshot khi TOP card có Entry Policy hợp lệ; bấm CẬP NHẬT KẾT QUẢ sau khi hiệp/trận kết thúc.</div>`}<div class="entry-val-note"><b>Cách đọc:</b> PAPER ROI dùng 1 unit tại đúng odds snapshot để so chất lượng policy; đây là counterfactual/paper evidence, không phải lợi nhuận tiền thật. WAIT/PASS thắng không tự chứng minh policy sai vì mục tiêu còn gồm price/edge/risk. Bet Tracker thực tế vẫn được giữ tách riêng. Chỉ khi sample đủ lớn mới dùng để xem xét rule ở release sau; V1.22.4 không auto-tune.</div></div>`;
    $('entryValidationRefreshBtn')?.addEventListener('click',()=>evRefreshResolutions(true));$('entryValidationExportBtn')?.addEventListener('click',evExport)
  }


  /* ===== V1.22.5 ENTRY POLICY CALIBRATION — SHADOW ONLY =====
     Reads resolved V1.22.4 paper outcomes and asks whether the policy separates
     better entry contexts from weaker ones. It NEVER changes price zones, edge
     thresholds, Entry Policy, TOP ranking or live engines. Reliability gates are
     intentionally conservative and use de-duplicated decision episodes. */
  const EPCAL_MIN_EPISODES=120,EPCAL_MIN_FIXTURES=60,EPCAL_MIN_SUITABLE=40,EPCAL_MIN_OTHER=40,EPCAL_MIN_BUCKET=20;
  function epcalResolved(){return evRead().filter(r=>r.resolution==='RESOLVED'&&['H1','FT'].includes(r.engine)&&Number.isFinite(Number(r.unit_pl)))}
  function epcalEpisodeRows(){
    const rows=epcalResolved().slice().sort((a,b)=>Number(a.captured_at||0)-Number(b.captured_at||0)),m=new Map();
    for(const r of rows){const k=[r.fixture_id,r.engine,r.policy_status,r.selection,Number(r.line),r.price_zone,r.behavior_state].join('|');if(!m.has(k))m.set(k,r)}
    return [...m.values()]
  }
  function epcalGroup(rows,keyFn){
    const o={};for(const r of rows){const k=String(keyFn(r)??'UNKNOWN');if(!o[k])o[k]={n:0,pl:0,pos:0,neg:0,push:0,priceSum:0,priceN:0,edgeSum:0,edgeN:0,fixtures:new Set()};const g=o[k];g.n++;g.pl+=Number(r.unit_pl||0);if(Number(r.unit_pl)>0)g.pos++;else if(Number(r.unit_pl)<0)g.neg++;else g.push++;if(Number.isFinite(Number(r.price))){g.priceSum+=Number(r.price);g.priceN++}if(Number.isFinite(Number(r.edge))){g.edgeSum+=Number(r.edge);g.edgeN++}g.fixtures.add(Number(r.fixture_id))}return o
  }
  function epcalRoi(g){return g&&g.n?g.pl/g.n*100:null}
  function epcalEdgeBand(r){const e=Number(r.edge);if(!Number.isFinite(e))return 'NO EDGE';if(e<=0)return '≤0pp';if(e<.04)return '0–3.9pp';if(e<.07)return '4–6.9pp';if(e<.10)return '7–9.9pp';return '≥10pp'}
  function epcalPriceLabel(k){return ({TOO_SHORT:'<1.55 TOO SHORT',EXPENSIVE:'1.55–1.64',ACCEPTABLE:'1.65–1.79',SWEET:'1.80–2.05 SWEET',ACCEPTABLE_HIGH:'2.06–2.20',HIGH_VARIANCE:'>2.20 HIGH VAR',NO_PRICE:'NO PRICE'})[k]||k}
  function epcalBehaviorBucket(r){const s=String(r.behavior_state||'NEUTRAL');if(s.includes('AGREEMENT'))return 'AGREEMENT';if(s.includes('DIVERGENCE'))return 'DIVERGENCE';if(s==='FOOTBALL_LEADS')return 'FOOTBALL LEADS';if(s==='MARKET_LEADS')return 'MARKET LEADS';if(s==='EVENT_REPRICING')return 'EVENT REPRICING';return 'NEUTRAL / OTHER'}
  function epcalTable(title,subtitle,groups,order,labelFn=x=>x){
    const keys=[...new Set([...(order||[]),...Object.keys(groups)])].filter(k=>groups[k]);
    const rows=keys.map(k=>{const g=groups[k],roi=epcalRoi(g),pos=g.n?g.pos/g.n*100:null,edge=g.edgeN?g.edgeSum/g.edgeN:null,rel=g.n>=EPCAL_MIN_BUCKET?'REVIEWABLE':'THIN';return `<div class="entry-cal-row"><b>${esc(labelFn(k))}</b><span>${g.n}</span><span class="${roi>0?'hot':roi<0?'cold':'thin'}">${roi==null?'—':roi.toFixed(1)+'%'}</span><span>${pos==null?'—':pos.toFixed(1)+'%'}</span><span class="cal-hide-mobile ${g.n>=EPCAL_MIN_BUCKET?'hot':'thin'}">${rel}${edge==null?'':` • ${eiSignedPct(edge)}`}</span></div>`}).join('');
    return `<div class="entry-cal-section"><div><h4>${esc(title)}</h4><small>${esc(subtitle)}</small></div><div class="entry-cal-table"><div class="entry-cal-row head"><span>BUCKET</span><span>N</span><span>ROI</span><span>POSITIVE</span><span class="cal-hide-mobile">EVIDENCE / AVG EDGE</span></div>${rows||'<div class="entry-val-empty">Chưa có dữ liệu.</div>'}</div></div>`
  }
  function epcalSnapshot(){
    const rows=epcalEpisodeRows(),fixtures=new Set(rows.map(r=>Number(r.fixture_id))).size,pg=epcalGroup(rows,r=>r.policy_status),eg=epcalGroup(rows,r=>r.engine),s=pg.SUITABLE||{n:0,pl:0},others=rows.filter(r=>r.policy_status!=='SUITABLE'),other={n:others.length,pl:others.reduce((a,r)=>a+Number(r.unit_pl||0),0)},sr=epcalRoi(s),orr=epcalRoi(other),delta=sr==null||orr==null?null:sr-orr,h1=eg.H1?.n||0,ft=eg.FT?.n||0;
    const gates=[['EPISODES',rows.length,EPCAL_MIN_EPISODES],['UNIQUE FIXTURES',fixtures,EPCAL_MIN_FIXTURES],['SUITABLE',s.n||0,EPCAL_MIN_SUITABLE],['NON-SUITABLE',other.n,EPCAL_MIN_OTHER],['H1 / FT MIN',Math.min(h1,ft),20]],ready=rows.length>=EPCAL_MIN_EPISODES&&fixtures>=EPCAL_MIN_FIXTURES&&(s.n||0)>=EPCAL_MIN_SUITABLE&&other.n>=EPCAL_MIN_OTHER&&h1>=20&&ft>=20;
    let verdict='COLLECTING',cls='warn',reason='Chưa đủ mẫu độc lập để đánh giá policy; tiếp tục thu evidence và không đổi rule.';
    if(ready){if((sr||0)>0&&delta>=5){verdict='PROMISING SEPARATION',cls='good',reason=`SUITABLE đang tách tốt hơn nhóm còn lại ${delta.toFixed(1)} điểm ROI. Đây vẫn là shadow evidence, chưa đủ để auto-tune.`}else if(delta!=null&&delta>0){verdict='MIXED / SMALL SEPARATION',cls='warn',reason=`SUITABLE đang tốt hơn ${delta.toFixed(1)} điểm ROI nhưng biên còn nhỏ; giữ rule và thu thêm mẫu.`}else{verdict='REVIEW NEEDED',cls='bad',reason='SUITABLE chưa tách tốt hơn nhóm còn lại trên mẫu review-ready; cần phân tích bucket trước khi cân nhắc sửa policy.'}}
    return {rows,fixtures,pg,eg,s,other,sr,orr,delta,h1,ft,gates,ready,verdict,cls,reason}
  }
  function epcalExport(){const x=epcalSnapshot(),payload={schema:'ENTRY_POLICY_CALIBRATION_V1.22.5',exported_at:new Date().toISOString(),shadow_only:true,readiness:{ready:x.ready,episodes:x.rows.length,unique_fixtures:x.fixtures,suitable:x.s.n||0,non_suitable:x.other.n,h1:x.h1,ft:x.ft},verdict:{state:x.verdict,reason:x.reason,suitable_roi:x.sr,non_suitable_roi:x.orr,separation_pp:x.delta},episodes:x.rows};validationDownload(`football_edge_entry_calibration_${new Date().toISOString().slice(0,10)}.json`,'application/json',JSON.stringify(payload,null,2))}
  function renderEntryCalibration(){
    const el=$('validationEntryCalibration');if(!el)return;const x=epcalSnapshot(),price=epcalGroup(x.rows,r=>r.price_zone),edge=epcalGroup(x.rows,epcalEdgeBand),behavior=epcalGroup(x.rows,epcalBehaviorBucket),engine=epcalGroup(x.rows,r=>r.engine),gateHtml=x.gates.map(([n,v,t])=>`<div class="entry-cal-gate ${v>=t?'pass':'wait'}"><span>${esc(n)}</span><b>${v}/${t} ${v>=t?'✓':'…'}</b></div>`).join('');
    const sep=x.delta==null?'—':`${x.delta>=0?'+':''}${x.delta.toFixed(1)}pp`;
    el.innerHTML=`<div class="entry-cal-shell"><div class="entry-cal-head"><div><b>V1.22.5 • ENTRY POLICY CALIBRATION • SHADOW</b><span>Dùng các decision episode đã resolve để xem Price Zone + Edge + Market Behavior + Policy có thật sự tạo separation hay không. Không tự chỉnh rule.</span></div><div class="entry-cal-badge">NO AUTO-TUNE</div></div><div class="entry-cal-kpis"><div class="entry-cal-kpi"><span>DECISION EPISODES</span><b>${x.rows.length}</b></div><div class="entry-cal-kpi"><span>UNIQUE FIXTURES</span><b>${x.fixtures}</b></div><div class="entry-cal-kpi"><span>SUITABLE ROI</span><b class="${(x.sr||0)>0?'entry-val-pos':(x.sr||0)<0?'entry-val-neg':''}">${x.sr==null?'—':x.sr.toFixed(1)+'%'}</b></div><div class="entry-cal-kpi"><span>NON-SUITABLE ROI</span><b>${x.orr==null?'—':x.orr.toFixed(1)+'%'}</b></div><div class="entry-cal-kpi"><span>SEPARATION</span><b>${sep}</b></div></div><div class="entry-cal-verdict ${esc(x.cls)}"><b>${esc(x.verdict)}</b><small>${esc(x.reason)}</small><div class="entry-cal-readiness">${gateHtml}</div></div>${epcalTable('PRICE ZONE','Kiểm tra vùng 1.80–2.05 có thực sự tốt hơn vùng quá thấp/quá cao hay không.',price,['TOO_SHORT','EXPENSIVE','ACCEPTABLE','SWEET','ACCEPTABLE_HIGH','HIGH_VARIANCE'],epcalPriceLabel)}${epcalTable('EDGE BAND','Kiểm tra edge mỏng hay dày có tạo khác biệt kết quả paper.',edge,['≤0pp','0–3.9pp','4–6.9pp','7–9.9pp','≥10pp','NO EDGE'])}${epcalTable('MARKET BEHAVIOR','Kiểm tra agreement/divergence/leads có hỗ trợ Entry Policy đúng hướng không.',behavior,['AGREEMENT','FOOTBALL LEADS','MARKET LEADS','NEUTRAL / OTHER','DIVERGENCE','EVENT REPRICING'])}${epcalTable('ENGINE','Đảm bảo kết quả không chỉ đến từ riêng H1 hoặc FT.',engine,['H1','FT'])}<div class="entry-cal-actions"><button id="entryCalibrationExportBtn" type="button">XUẤT CALIBRATION JSON</button></div><div class="entry-cal-note"><b>Quan trọng:</b> V1.22.5 khử bớt việc đếm lặp bằng decision episode và chỉ coi bucket có n≥${EPCAL_MIN_BUCKET} là reviewable. Ngay cả khi trạng thái PROMISING xuất hiện, hệ thống vẫn <b>không thay</b> vùng giá 1.65–2.20, SWEET 1.80–2.05, edge threshold, Entry Policy hay TOP Ranking. Muốn thay rule phải qua bước review/holdout riêng sau này.</div></div>`;
    $('entryCalibrationExportBtn')?.addEventListener('click',epcalExport)
  }

  function renderMasterOpportunityBoard(){
    const el=$('masterOpportunityBoard');if(!el)return;
    const raw=feMasterMergeFixtures(),rows=feMasterRankRows(raw);
    try{evCaptureMasterRows(rows)}catch(e){log('Entry Validation capture error',e.message)}
    try{feDbCaptureLiveRows(rows).catch(e=>log('Smart Live Persistence error',e.message))}catch(e){log('Smart Live Persistence init error',e.message)}
    if($('masterOpportunityCount'))$('masterOpportunityCount').textContent=String(rows.length);
    const topN=rows.filter(x=>x.__rank?.top).length,confN=rows.filter(x=>x.__rank?.interaction?.verdict==='CONFLUENCE').length,conflictN=rows.filter(x=>x.__rank?.hardConflict).length,smartSel=typeof feSmartSelectRows==='function'?feSmartSelectRows(rows):[],marketNormN=typeof mnReadyTopCount==='function'?mnReadyTopCount(rows):0,suitableN=typeof epSuitableTopCount==='function'?epSuitableTopCount(rows):0;
    const sum=$('masterRankSummary');if(sum)feLivePatchHTML(sum,`<span><b>TOP ĐỦ NGƯỠNG</b><strong>${topN}</strong></span><span><b>ENTRY SUITABLE</b><strong>${suitableN}</strong></span><span><b>MARKET NORM</b><strong>${marketNormN}</strong></span><span><b>SMART FOLLOW</b><strong id="smartFollowCount">${smartSel.length}</strong></span><span><b>CONFLICT</b><strong>${conflictN}</strong></span><span><b>BG REGISTERED</b><strong id="smartFollowBgCount">${bgRegistryRead().filter(r=>String(r.engine||'')==='SMART').length}</strong></span>`);
    if(!rows.length){feLivePatchHTML(el,'<div class="master-op-empty">Chưa có fixture trong H1 / FT / Handicap. Bấm QUÉT CẢ 3 CHẾ ĐỘ để bắt đầu.</div>');return}
    feLivePatchHTML(el,rows.map(x=>{
      const it=x.latest||x.h1||x.ft||x.hc,s=it?.latest||{},minute=Number(s.minute||0),gh=s.goals?.home,ga=s.goals?.away,mechs=[x.h1?'H1':null,x.ft?'FT':null,x.hc?'HC':null].filter(Boolean),multi=mechs.length>1,meta=x.__rank?.interaction||feMasterInteractionMeta(x),rank=x.__rank||feMasterRankMeta(x);
      const score=(gh==null||ga==null)?'-':`${gh}-${ga}`,rankCls=rank.top===1?'rank-top1':rank.top?'rank-top5':'';
      const smart=typeof feSmartReason==='function'?feSmartReason(x):{keep:false},smartCls=smart.keep||feSmartIsManual(x.id)?'smart-followed':'';
      return `<article class="master-op-card ${multi?'multi':''} ${esc(meta.cls)} ${rankCls} ${smartCls}" data-master-fixture="${esc(x.id)}"><div class="master-op-rankline">${feMasterRankBadge(rank)}${alvChip(rank.primary?.adaptive)}<span class="master-op-rankwhy">${esc(feMasterRankWhy(rank))}</span></div><div class="master-op-head"><div class="master-op-match"><b>${esc(x.home)} vs ${esc(x.away)}</b><span>${esc(x.league||'')} • ${minute||'-'}' • ${esc(score)} • Fixture #${esc(x.id)}</span></div><span class="master-op-mechs">${mechs.length} CƠ CHẾ • ${esc(mechs.join(' + '))}</span></div><div class="smart-follow-strip">${typeof feSmartChip==='function'?feSmartChip(x):''}</div>${feMasterInteractionHTML(meta)}<div class="master-op-signals">${feMasterGoalSignal(x.h1,'H1')}${feMasterGoalSignal(x.ft,'FT')}${feMasterHCSignal(x.hc)}</div>${typeof mnMarketHTML==='function'?mnMarketHTML(x,rank):''}${typeof eiEntryHTML==='function'?eiEntryHTML(x,rank):''}${typeof biBehaviorHTML==='function'?biBehaviorHTML(x,rank):''}${typeof epEntryPolicyHTML==='function'?epEntryPolicyHTML(x,rank):''}${feMasterActionButtons(x)}</article>`;
    }).join(''));
    if(typeof feSmartFollowSchedule==='function')feSmartFollowSchedule('MASTER_RENDER');
  }
  function renderUnifiedLiveBoard(){
    const board=$('unifiedLiveBoard');if(!board)return;
    const rows=['H1','FT','HC'].map(feUnifiedEngineData);
    const fresh=Number(FE_UNIFIED_SCAN_STATE.lastFreshCount||0),counts=`${rows[0].count} / ${rows[1].count} / ${rows[2].count}`,active=feUnifiedActiveCount();
    if($('unifiedLiveFreshCount'))$('unifiedLiveFreshCount').textContent=String(fresh||0);
    if($('unifiedLiveCounts'))$('unifiedLiveCounts').textContent=counts;
    if($('unifiedLiveActiveCount'))$('unifiedLiveActiveCount').textContent=String(active);
    if($('unifiedLiveLastAt'))$('unifiedLiveLastAt').textContent=feUnifiedFmtAt(FE_UNIFIED_SCAN_STATE.lastAt||0);
    feLivePatchHTML(board,rows.map(d=>{
      const top=d.top,s=top?.latest||{},trend=d.trend?`${d.trend.dir==='up'?'↑':d.trend.dir==='down'?'↓':'→'} ${d.trend.label}`:'—';
      const league=top?.league?`<div class="unified-live-statusline">${esc(top.league)}</div>`:'';
      const tag1=d.engine==='HC'?`<span class="unified-live-tag">RECO: ${esc(d.why||'-')}</span>`:`<span class="unified-live-tag">GOAL RADAR: ${d.prob==null?'—':esc(d.prob)+'%'}</span>`;
      const tag2=`<span class="unified-live-tag">STATE: ${esc(d.state||'-')}</span>`;
      const tag3=`<span class="unified-live-tag">SOURCE: ${esc(FE_WORKSPACE_SCAN_STATE[d.engine]?.lastSource||'-')}</span>`;
      const tag4=`<span class="unified-live-tag">SCAN: ${esc(d.total||0)} → TOP ${esc(d.count||0)}</span>`;
      return `<div class="unified-live-row ${d.cls}" data-fe-live-key="${esc(d.engine)}"><div class="unified-live-head"><div><div class="unified-live-label">${d.engine==='H1'?'🔥':d.engine==='FT'?'🔥':'⚖️'} ${esc(d.label)}</div>${league}</div><span class="unified-live-badge">${d.count||0} ACTIVE</span></div><div class="unified-live-mini"><div class="box"><span>TOP / SOURCE</span><b>${esc(d.count||0)} / ${esc(d.total||0)}</b></div><div class="box"><span>TRẠNG THÁI</span><b>${esc(d.state||'-')}</b></div><div class="box"><span>${d.engine==='HC'?'LIVE GAP':'SCORE'}</span><b>${esc(d.score??'-')}</b></div><div class="box"><span>${d.engine==='HC'?'XU HƯỚNG':'GOAL TREND'}</span><b>${esc(d.engine==='HC'?d.why||'-':trend)}</b></div></div>${feUnifiedTopNote(d)}<div class="unified-live-tags">${tag1}${tag2}${tag3}${tag4}</div></div>`;
    }).join(''));
    try{renderMasterOpportunityBoard()}catch(_){}
  }
  async function startUnifiedLiveScan(forceRefresh=false){
    if(FE_UNIFIED_SCAN_STATE.running){showToast('err','Đang quét LIVE toàn diện','Hãy chờ lượt hiện tại hoàn tất.');return}
    if(!els.fkey.value.trim()){showToast('err','Chưa có Football API Key','Lưu API key trước.');return}
    FE_UNIFIED_SCAN_STATE.running=true;
    try{
      loading(true,forceRefresh?'Đang cập nhật 3 cơ chế':'Đang quét 3 cơ chế',forceRefresh?'Lấy snapshot LIVE mới cho H1 / FT / HANDICAP':'Lấy 1 snapshot LIVE chung rồi phân luồng H1 / FT / HANDICAP');
      status($('unifiedLiveStatus'),'Đang lấy 1 snapshot LIVE chung cho H1 / FT / HANDICAP...','busy');
      const hb=await ultraHeartbeat(true),rows=Array.isArray(hb?.rows)?hb.rows:[];
      fePrimeUnifiedLiveCache(rows,forceRefresh?'UNIFIED_REFRESH':'UNIFIED_SCAN');
      const freshRows=rows.filter(feLiveSourceValid);
      const split={H1:freshRows.filter(h1WatchEligible).length,FT:freshRows.filter(watchLiveEligible).length,HC:freshRows.filter(handicapWatchEligible).length};
      status($('unifiedLiveStatus'),`Đã nhận ${freshRows.length}/${rows.length} LIVE fresh • H1 ${split.H1} • FT ${split.FT} • HC ${split.HC} • đang dựng TOP 5 từng cơ chế...`,'busy');
      await startH1Watch();
      await startLiveWatch();
      await startHandicapWatch();
      renderUnifiedLiveBoard();
      const on=feUnifiedActiveCount();
      status($('unifiedLiveStatus'),`LIVE toàn diện hoàn tất • H1 ${h1WatchState.items.length} • FT ${watchState.items.length} • HC ${handicapWatchState.pool.length} • workspace ON ${on}/3. Các card chi tiết cũ bên dưới vẫn giữ nguyên.`,'ok');
      showToast('ok','Đã quét cả 3 chế độ',`H1 ${h1WatchState.items.length} • FT ${watchState.items.length} • HC ${handicapWatchState.pool.length}.`);
    }catch(e){status($('unifiedLiveStatus'),'Lỗi QUÉT CẢ 3: '+e.message,'err');showToast('err','Quét 3 chế độ lỗi',e.message)}
    finally{FE_UNIFIED_SCAN_STATE.running=false;loading(false);renderUnifiedLiveBoard()}
  }
  async function refreshUnifiedLiveScan(){return startUnifiedLiveScan(true)}
  function stopUnifiedLiveScan(){try{stopH1Watch()}catch(_){}try{stopLiveWatch()}catch(_){}try{stopHandicapWatch()}catch(_){}status($('unifiedLiveStatus'),'Đã dừng cả 3 cơ chế. Dữ liệu đang hiển thị vẫn giữ nguyên để xem lại.','ok');renderUnifiedLiveBoard();showToast('ok','Đã dừng cả 3 cơ chế','Có thể bấm QUÉT CẢ 3 CHẾ ĐỘ để chạy lại.')}

  function handicapWatchEligible(f){const st=f?.fixture?.status?.short||'',m=Number(f?.fixture?.status?.elapsed);return feLiveSourceValid(f)&&['1H','2H','ET','BT','LIVE','INT','HT'].includes(st)&&Number.isFinite(m)&&m>=25&&m<=88}
  function handicapCheapRank(f){const m=Number(f?.fixture?.status?.elapsed||0),h=Number(f?.goals?.home||0),a=Number(f?.goals?.away||0),gap=Math.abs(h-a);let s=0;s+=m>=45&&m<=80?24:m>=25&&m<=87?18:8;s+=gap===0?20:gap===1?24:gap===2?8:2;s+=['1H','2H'].includes(f?.fixture?.status?.short)?8:4;return s}
  function hcStat(side,names){const v=getAnyStat(side,names);return v==null?null:watchNum(v)}
  function handicapSideMetrics(side){return {shots:hcStat(side,['Total Shots']),sot:hcStat(side,['Shots on Goal','Shots on Target']),inbox:hcStat(side,['Shots insidebox','Shots inside box']),corners:hcStat(side,['Corner Kicks','Corners']),xg:hcStat(side,['expected_goals','Expected Goals']),possession:hcStat(side,['Ball Possession','Possession']),red:hcStat(side,['Red Cards'])}}
  function handicapAggregate(sm,meta){const h=handicapSideMetrics(sm?.[meta?.teams?.home?.id]),a=handicapSideMetrics(sm?.[meta?.teams?.away?.id]);const available=['shots','sot','inbox','corners','xg','possession'].filter(k=>h[k]!=null||a[k]!=null);const chance=['sot','inbox','xg'].filter(k=>h[k]!=null||a[k]!=null);return {home:h,away:a,available,coverage:available.length,chanceCoverage:chance.length,dataTier:available.length>=4&&chance.length>=1?'FULL':available.length>=1?'PARTIAL':'MARKET_WATCH'}}
  function hcHistoryKey(id){return HANDICAP_HISTORY_PREFIX+id}
  function hcReadHistory(id){try{const a=JSON.parse(localStorage.getItem(hcHistoryKey(id))||'[]'),cut=Date.now()-25*60000;return (Array.isArray(a)?a:[]).filter(x=>Number(x.captured_at)>=cut).slice(-140)}catch{return []}}
  function hcWriteHistory(item){try{localStorage.setItem(hcHistoryKey(item.id),JSON.stringify((item.history||[]).slice(-140)))}catch{}}
  function hcMetricDelta(cur,old){const out={home:{},away:{}};for(const side of ['home','away'])for(const k of ['shots','sot','inbox','corners','xg']){const a=cur?.metrics?.[side]?.[k],b=old?.metrics?.[side]?.[k];out[side][k]=(a==null||b==null)?null:Math.max(0,Number(a)-Number(b))}return out}
  function hcFindBase(item,cur,mins){const rows=(item.history||[]).filter(x=>Number(x.captured_at)<Number(cur.captured_at)&&(!item.resetAt||Number(x.captured_at)>=Number(item.resetAt)));if(!rows.length)return null;const target=Number(cur.captured_at)-mins*60000;let best=null,d=Infinity;for(const r of rows){const z=Math.abs(Number(r.captured_at)-target);if(z<d){d=z;best=r}}return best}
  function hcWindow(item,cur,mins){const b=hcFindBase(item,cur,mins);if(!b)return {usable:false,mature:false,window_min:0,delta:null};const wm=Math.max(.05,(cur.captured_at-b.captured_at)/60000);return {usable:wm>=Math.min(1.5,mins*.55),mature:wm>=mins*.8,window_min:Math.round(wm*10)/10,delta:hcMetricDelta(cur,b)}}
  function hcSideIndex(w,side){if(!w?.usable)return 0;const d=w.delta?.[side]||{},scale=5/Math.max(1,w.window_min);let x=0;if(d.shots!=null)x+=d.shots*scale*1.2;if(d.sot!=null)x+=d.sot*scale*3.2;if(d.inbox!=null)x+=d.inbox*scale*1.8;if(d.corners!=null)x+=d.corners*scale*.9;if(d.xg!=null)x+=d.xg*scale*8;return Math.round(x*100)/100}
  function hcSubDelta(wide,narrow){const out={home:{},away:{}};for(const side of ['home','away'])for(const k of ['shots','sot','inbox','corners','xg']){const a=wide?.delta?.[side]?.[k],b=narrow?.delta?.[side]?.[k];out[side][k]=(a==null||b==null)?null:Math.max(0,Number(a)-Number(b))}return out}
  function hcSegmentWindow(delta,mins){return {usable:!!delta,window_min:mins,delta}}
  function hcSegments(w3,w5,w10){
    const s03=w3?.usable?hcSegmentWindow(w3.delta,Math.max(.5,Math.min(3,w3.window_min||3))):null;
    const s35=w5?.usable&&w3?.usable?hcSegmentWindow(hcSubDelta(w5,w3),Math.max(.5,(w5.window_min||5)-(w3.window_min||3))):null;
    const s510=w10?.usable&&w5?.usable?hcSegmentWindow(hcSubDelta(w10,w5),Math.max(1,(w10.window_min||10)-(w5.window_min||5))):null;
    return {s03,s35,s510}
  }
  function hcTrend(w3,w5,w10,side){
    const seg=hcSegments(w3,w5,w10),i3=hcSideIndex(seg.s03,side),i35=hcSideIndex(seg.s35,side),i510=hcSideIndex(seg.s510,side);
    let trend='STABLE';
    const active=[i3,i35,i510].filter(x=>x>=1).length;
    if(i3>=1.5&&i35<.65&&i510<.65)trend='ISOLATED';
    else if(i3>=2&&i35>=1&&i3>=i35*1.28)trend='ACCELERATING';
    else if(i3>=1.4&&i35>=1&&i510>=.8)trend='SUSTAINED';
    else if(i35>=1.5&&i3<=i35*.58)trend='DECAYING';
    else if(active===0)trend='QUIET';
    return {trend,i3,i5:i35,i10:i510,segments:seg}
  }
  function hcShare(a,b,neutral=.5){if(a==null&&b==null)return neutral;const x=Math.max(0,Number(a||0)),y=Math.max(0,Number(b||0));return x+y>0?x/(x+y):neutral}
  function ultraMedian(nums){const a=(nums||[]).map(Number).filter(Number.isFinite).sort((x,y)=>x-y);if(!a.length)return null;const m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2}
  function hcMarketQuotes(rows){
    const valid=(rows||[]).filter(r=>r.category==='asian_handicap'&&r.integrity?.valid!==false&&!r.status?.blocked&&!r.status?.stopped&&!r.status?.finished),quotes=[],seen=new Set();
    for(const r of valid){
      const vals=(r.values||[]).filter(v=>!v.suspended),hv=vals.find(v=>v.selection_outcome==='home'||v.selection_side==='home'),av=vals.find(v=>v.selection_outcome==='away'||v.selection_side==='away');
      if(!hv||!av)continue;const line=numericHandicap(hv.handicap),ho=Number(hv.odd),ao=Number(av.odd);if(!Number.isFinite(line))continue;
      const book=String(r.bookmaker_name||r.bookmaker||'LIVE_FEED'),key=book.toLowerCase();if(seen.has(key))continue;seen.add(key);
      quotes.push({book,line,homeOdd:Number.isFinite(ho)?ho:null,awayOdd:Number.isFinite(ao)?ao:null})
    }
    return quotes
  }
  function hcMarketFromRows(rows,homeName,awayName){
    const q=hcMarketQuotes(rows);if(!q.length)return {valid:false,line:null,homeOdd:null,awayOdd:null,text:'N/A',bookmakerCount:0,consensus:false,lineDispersion:null};
    if(q.length<3){
      const x=q[0];return {valid:true,line:x.line,homeOdd:x.homeOdd,awayOdd:x.awayOdd,bookmaker:x.book,text:`HOME ${x.line>0?'+':''}${x.line} @${x.homeOdd??'-'} • AWAY ${-x.line>0?'+':''}${-x.line} @${x.awayOdd??'-'} • ${q.length} book`,bookmakerCount:q.length,consensus:false,lineDispersion:0,quotes:q}
    }
    const med=ultraMedian(q.map(x=>x.line)),near=q.filter(x=>Math.abs(x.line-med)<=.25),homeOdd=ultraMedian(near.map(x=>x.homeOdd)),awayOdd=ultraMedian(near.map(x=>x.awayOdd)),
          min=Math.min(...q.map(x=>x.line)),max=Math.max(...q.map(x=>x.line)),disp=Math.round((max-min)*100)/100,
          exact=q.filter(x=>Math.abs(x.line-med)<1e-9).length,breadth=Math.round(exact/q.length*100);
    return {valid:true,line:Math.round(med*100)/100,homeOdd:homeOdd==null?null:Math.round(homeOdd*1000)/1000,awayOdd:awayOdd==null?null:Math.round(awayOdd*1000)/1000,
      bookmaker:'CONSENSUS',text:`CONSENSUS ${q.length} books • HOME ${med>0?'+':''}${med} @${homeOdd??'-'} • AWAY ${-med>0?'+':''}${-med} @${awayOdd??'-'} • breadth ${breadth}%`,
      bookmakerCount:q.length,consensus:true,lineDispersion:disp,breadth,quotes:q}
  }
  function hcMarketHistory(item,mkt,s){
    if(!mkt?.valid)return;
    const snap={
      captured_at:Number(s.captured_at||Date.now()),
      minute:Number(s.minute||0),
      score:`${s.goals.home}-${s.goals.away}`,
      line:Number(mkt.line),
      homeOdd:Number.isFinite(Number(mkt.homeOdd))?Number(mkt.homeOdd):null,
      awayOdd:Number.isFinite(Number(mkt.awayOdd))?Number(mkt.awayOdd):null
    };
    item.marketHistory=item.marketHistory||[];
    const last=item.marketHistory[item.marketHistory.length-1];
    const priceChanged=(x,y)=>x==null||y==null?x!==y:Math.abs(Number(x)-Number(y))>=.005;
    const changed=!last||last.score!==snap.score||Number(last.line)!==snap.line||
      priceChanged(last.homeOdd,snap.homeOdd)||priceChanged(last.awayOdd,snap.awayOdd)||
      snap.captured_at-Number(last.captured_at||0)>=120000;
    if(changed)item.marketHistory.push(snap);
    item.marketHistory=item.marketHistory
      .filter(x=>Date.now()-Number(x.captured_at||0)<=30*60*1000)
      .slice(-60);
  }
  function hcMarketMovement(item,s){
    const score=`${s.goals.home}-${s.goals.away}`,now=Number(s.captured_at||Date.now());
    const same=(item.marketHistory||[])
      .filter(x=>x.score===score&&now-Number(x.captured_at||0)<=20*60*1000)
      .sort((x,y)=>Number(x.captured_at)-Number(y.captured_at));
    if(!s.market?.valid||same.length<2){
      return {
        status:'BASELINE',text:'BASELINE • cần thêm market history cùng tỷ số',
        sameScore:true,lineDir:'FLAT',priceDir:'FLAT',velocity:'NONE',levelHint:'BASELINE',
        lineDelta:0,priceBalance:0,durationSec:null,strength:0
      };
    }

    const first=same[0],last=same[same.length-1];
    const durationSec=Math.max(1,Math.round((Number(last.captured_at)-Number(first.captured_at))/1000));
    const lineDelta=Number(last.line)-Number(first.line);

    // Home line more negative = market strengthens HOME.
    let lineDir='FLAT';
    if(lineDelta<=-.24)lineDir='HOME_STRENGTHEN';
    else if(lineDelta>=.24)lineDir='AWAY_STRENGTHEN';

    const h0=Number(first.homeOdd),h1=Number(last.homeOdd),a0=Number(first.awayOdd),a1=Number(last.awayOdd);
    const hasH=Number.isFinite(h0)&&Number.isFinite(h1),hasA=Number.isFinite(a0)&&Number.isFinite(a1);
    const dh=hasH?h1-h0:0,da=hasA?a1-a0:0;

    // Positive balance => HOME price strengthens; negative => AWAY.
    // Uses both sides when possible to reduce bookmaker-margin noise.
    const priceBalance=(hasA?da:0)-(hasH?dh:0);
    let priceDir='FLAT';
    if(priceBalance>=.10)priceDir='HOME_STRENGTHEN';
    else if(priceBalance<=-.10)priceDir='AWAY_STRENGTHEN';
    else if(hasH&&dh<=-.07)priceDir='HOME_STRENGTHEN';
    else if(hasH&&dh>=.07)priceDir='AWAY_STRENGTHEN';
    else if(hasA&&da<=-.07)priceDir='AWAY_STRENGTHEN';
    else if(hasA&&da>=.07)priceDir='HOME_STRENGTHEN';

    const lineUnits=Math.abs(lineDelta)/.25;
    const priceUnits=Math.abs(priceBalance)/.10;
    const magnitude=Math.min(6,lineUnits*1.8+priceUnits*.8);
    const perMin=magnitude/Math.max(.5,durationSec/60);
    let velocity='SLOW';
    if(perMin>=2.6)velocity='SHARP';
    else if(perMin>=1.35)velocity='FAST';
    else if(perMin>=.55)velocity='NORMAL';

    const sideFromLine=lineDir==='HOME_STRENGTHEN'?'HOME':lineDir==='AWAY_STRENGTHEN'?'AWAY':'NEUTRAL';
    const sideFromPrice=priceDir==='HOME_STRENGTHEN'?'HOME':priceDir==='AWAY_STRENGTHEN'?'AWAY':'NEUTRAL';
    let marketSide='NEUTRAL';
    if(sideFromLine!=='NEUTRAL'&&sideFromPrice!=='NEUTRAL'){
      marketSide=sideFromLine===sideFromPrice?sideFromLine:'MIXED';
    }else marketSide=sideFromLine!=='NEUTRAL'?sideFromLine:sideFromPrice;

    const fmtOdd=x=>Number.isFinite(Number(x))?Number(x).toFixed(3):'-';
    const fmtLine=x=>`${Number(x)>0?'+':''}${Number(x)}`;
    const mins=Math.max(1,Math.round(durationSec/60));
    const text=`${fmtLine(first.line)} @${fmtOdd(first.homeOdd)} → ${fmtLine(last.line)} @${fmtOdd(last.homeOdd)} • ${score} • ${mins}m • ${velocity}`;

    return {
      status:'HISTORY',text,sameScore:true,lineDir,priceDir,velocity,marketSide,
      lineDelta:Math.round(lineDelta*100)/100,
      priceBalance:Math.round(priceBalance*1000)/1000,
      durationSec,strength:Math.round(Math.min(100,magnitude/6*100)),
      first,last
    };
  }
  function hcDataQuality(s){let q=0;const m=s.metrics;q+=m.dataTier==='FULL'?4:m.dataTier==='PARTIAL'?2.6:m.dataTier==='MARKET_WATCH'?1:0;if(s.market?.valid)q+=.7;const age=(Date.now()-s.captured_at)/1000;if(age<=45)q+=.3;return watchClamp(Math.round(q*10)/10,0,5)}
  function hcGameRegime(s,w3,w5){
    const hg=Number(s.goals.home||0),ag=Number(s.goals.away||0),m=Number(s.minute||0),hr=Number(s.metrics.home.red||0),ar=Number(s.metrics.away.red||0);
    const mh=hcSideIndex(w5?.usable?w5:w3,'home'),ma=hcSideIndex(w5?.usable?w5:w3,'away');
    if(hr>ar)return {name:'HOME 10v11',chasing:null};
    if(ar>hr)return {name:'AWAY 10v11',chasing:null};
    if(hg===ag)return {name:'LEVEL GAME',chasing:null};
    const homeTrailing=hg<ag,trailing=homeTrailing?'HOME':'AWAY',tm=homeTrailing?mh:ma,lm=homeTrailing?ma:mh;
    if(m>=75&&tm>=Math.max(1.5,lm*1.2))return {name:`${trailing} LATE CHASE`,chasing:trailing};
    if(tm>=Math.max(1.8,lm*1.28))return {name:`${trailing} TRAILING CHASE`,chasing:trailing};
    return {name:homeTrailing?'AWAY LEADING':'HOME LEADING',chasing:null}
  }
  function hcEvidenceAge(item,s,side){
    const rows=(item.history||[]).filter(x=>Number(x.captured_at)<=Number(s.captured_at)&&(!item.resetAt||Number(x.captured_at)>=Number(item.resetAt))).slice(-80);
    if(rows.length<2)return null;
    for(let i=rows.length-1;i>0;i--){
      const cur=rows[i]?.metrics?.[side]||{},prev=rows[i-1]?.metrics?.[side]||{};
      let changed=false;
      for(const k of ['shots','sot','inbox','corners','xg']){
        if(cur[k]!=null&&prev[k]!=null&&Number(cur[k])>Number(prev[k])+0.0001){changed=true;break}
      }
      if(changed)return Math.max(0,Math.round((Number(s.captured_at)-Number(rows[i].captured_at))/1000))
    }
    return null
  }
  async function hcLoadPreBaseline(f){
    try{
      const rows=await football('/predictions',{fixture:f.fixture.id},true)||[],p=Array.isArray(rows)?rows[0]:null,pct=p?.predictions?.percent||{};
      const hv=parseFloat(String(pct.home??'').replace('%','')),av=parseFloat(String(pct.away??'').replace('%',''));
      if(Number.isFinite(hv)&&Number.isFinite(av)){
        const adv=watchClamp((hv-av)/Math.max(50,hv+av)*16,-10,10);
        return {adv:Math.round(adv*10)/10,source:'PREDICTION',home:hv,away:av}
      }
    }catch{}
    return {adv:0,source:'N/A',home:null,away:null}
  }
  function hcTeamStates(item,s,w3,w5,w10,regime){const h=s.metrics.home,a=s.metrics.away;let liveAdv=0;
    const volH=(h.shots??0)+(h.corners??0)*.5,volA=(a.shots??0)+(a.corners??0)*.5;liveAdv+=(hcShare(volH,volA)-.5)*22;
    const chH=(h.sot??0)*2+(h.inbox??0)*1.2+(h.xg??0)*5,chA=(a.sot??0)*2+(a.inbox??0)*1.2+(a.xg??0)*5;liveAdv+=(hcShare(chH,chA)-.5)*28;
    const mh=hcSideIndex(w5?.usable?w5:w3,'home'),ma=hcSideIndex(w5?.usable?w5:w3,'away');let momAdv=(hcShare(mh,ma)-.5)*20;
    if(regime?.chasing==='HOME'&&momAdv>0)momAdv*=.68;
    if(regime?.chasing==='AWAY'&&momAdv<0)momAdv*=.68;
    liveAdv+=momAdv;
    if(h.possession!=null&&a.possession!=null)liveAdv+=(hcShare(h.possession,a.possession)-.5)*7;
    const hr=Number(h.red||0),ar=Number(a.red||0);liveAdv+=(ar-hr)*10;
    let gameAdj=0;
    const scoreGap=Number(s.goals.home)-Number(s.goals.away);
    if(scoreGap>0&&mh>=ma*.85)gameAdj+=2.5;
    if(scoreGap<0&&ma>=mh*.85)gameAdj-=2.5;
    liveAdv+=gameAdj;
    liveAdv=watchClamp(liveAdv,-38,38);
    const minute=Number(s.minute||0),preRaw=Number(item.preBaseline?.adv||0),preWeight=watchClamp(1-minute/100,.15,.72),preAdv=preRaw*preWeight;
    const adv=watchClamp(liveAdv+preAdv,-44,44),home=watchClamp(Math.round(50+adv),0,100),away=watchClamp(Math.round(50-adv),0,100);
    return {home,away,gap:home-away,direction:Math.abs(home-away)<10?'BALANCED':home>away?'HOME':'AWAY',preAdv:Math.round(preAdv*10)/10,liveAdv:Math.round(liveAdv*10)/10,liveGap:Math.round(liveAdv*2),momentumAdv:Math.round(momAdv*10)/10,gameAdj:Math.round(gameAdj*10)/10,regime:regime?.name||'N/A'}}
  function hcMarketFit(item,s,states,movement){
    if(!s.market?.valid){
      return {
        score:null,agreement:'NO_MARKET',level:'NO_MARKET',corePass:false,
        lineMove:'N/A',priceMove:'N/A',velocity:'N/A'
      };
    }

    const dir=states.direction;
    const mv=movement||{};
    let score=50;

    // Current AH sign is only a small contextual confirmation, not a model line.
    if(dir==='HOME'&&Number(s.market.line)<0)score+=5;
    if(dir==='AWAY'&&Number(s.market.line)>0)score+=5;

    const lineSide=mv.lineDir==='HOME_STRENGTHEN'?'HOME':mv.lineDir==='AWAY_STRENGTHEN'?'AWAY':'NEUTRAL';
    const priceSide=mv.priceDir==='HOME_STRENGTHEN'?'HOME':mv.priceDir==='AWAY_STRENGTHEN'?'AWAY':'NEUTRAL';

    let agreeParts=0,opposeParts=0;
    if(dir!=='BALANCED'){
      if(lineSide===dir)agreeParts+=2;
      else if(lineSide!=='NEUTRAL')opposeParts+=2;
      if(priceSide===dir)agreeParts+=1;
      else if(priceSide!=='NEUTRAL')opposeParts+=1;
    }

    if(agreeParts)score+=agreeParts*8;
    if(opposeParts)score-=opposeParts*9;
    if((mv.velocity==='FAST'||mv.velocity==='SHARP')&&(agreeParts>=2))score+=8;
    if((mv.velocity==='FAST'||mv.velocity==='SHARP')&&(opposeParts>=2))score-=8;
    score=watchClamp(Math.round(score),0,100);

    let level='NEUTRAL';
    if(dir==='BALANCED'||mv.status==='BASELINE'||mv.marketSide==='MIXED'){
      level='NEUTRAL';
    }else if(opposeParts>=3){
      level=(mv.velocity==='FAST'||mv.velocity==='SHARP'||Math.abs(Number(mv.lineDelta||0))>=.25)
        ?'HARD_DIVERGENCE':'SOFT_DIVERGENCE';
    }else if(opposeParts>=1){
      level='SOFT_DIVERGENCE';
    }else if(agreeParts>=3){
      level=(mv.velocity==='FAST'||mv.velocity==='SHARP'||Math.abs(Number(mv.lineDelta||0))>=.25)
        ?'HARD_AGREEMENT':'SOFT_AGREEMENT';
    }else if(agreeParts>=1){
      level='SOFT_AGREEMENT';
    }

    const agreement=(level==='HARD_AGREEMENT'||level==='SOFT_AGREEMENT')?'AGREES':
      (level==='HARD_DIVERGENCE'||level==='SOFT_DIVERGENCE')?'DIVERGENCE':'NEUTRAL';

    return {
      score,agreement,level,
      corePass:level==='HARD_AGREEMENT'||level==='SOFT_AGREEMENT',
      lineMove:mv.lineDir||'FLAT',
      priceMove:mv.priceDir||'FLAT',
      velocity:mv.velocity||'NONE'
    };
  }
  function hcEvaluate(item,s){const w3=hcWindow(item,s,3),w5=hcWindow(item,s,5),w10=hcWindow(item,s,10),ht=hcTrend(w3,w5,w10,'home'),at=hcTrend(w3,w5,w10,'away'),regime=hcGameRegime(s,w3,w5),states=hcTeamStates(item,s,w3,w5,w10,regime),move=hcMarketMovement(item,s),mf=hcMarketFit(item,s,states,move),gap=Math.abs(states.gap),dq=hcDataQuality(s);
    const recent=w5?.usable?w5:w3,rd=recent?.delta||{home:{},away:{}},rch=rd.home||{},rca=rd.away||{};
    const chanceH=(rch.sot??0)*2+(rch.inbox??0)+(rch.xg??0)*5,chanceA=(rca.sot??0)*2+(rca.inbox??0)+(rca.xg??0)*5,chanceDiff=Math.abs(chanceH-chanceA);
    const dirTrend=states.direction==='HOME'?ht:states.direction==='AWAY'?at:null,oppTrend=states.direction==='HOME'?at:states.direction==='AWAY'?ht:null;
    const momDiff=dirTrend?Number(dirTrend.i3||0)+Number(dirTrend.i5||0)*.7-(Number(oppTrend?.i3||0)+Number(oppTrend?.i5||0)*.7):0;
    const momentumPass=!!dirTrend&&['ACCELERATING','SUSTAINED'].includes(dirTrend.trend)&&momDiff>=2;
    const football={superiority:Math.abs(states.liveGap)>=18,chance:s.metrics.chanceCoverage>0&&chanceDiff>=2,momentum:momentumPass};const market=mf.corePass;const coreCount=[football.superiority,football.chance,football.momentum,market].filter(Boolean).length,footballCount=[football.superiority,football.chance,football.momentum].filter(Boolean).length,corePass=coreCount>=3&&footballCount>=2;
    const evSide=states.direction==='HOME'?rch:rca,oppSide=states.direction==='HOME'?rca:rch;
    const liveEvidence=(Number(evSide?.shots||0)-Number(oppSide?.shots||0))*1+(Number(evSide?.sot||0)-Number(oppSide?.sot||0))*3+(Number(evSide?.inbox||0)-Number(oppSide?.inbox||0))*1.5+(evSide?.xg!=null&&oppSide?.xg!=null?(Number(evSide.xg)-Number(oppSide.xg))*6:0);
    const evidenceAge={home:hcEvidenceAge(item,s,'home'),away:hcEvidenceAge(item,s,'away')};evidenceAge.direction=states.direction==='HOME'?evidenceAge.home:states.direction==='AWAY'?evidenceAge.away:null;
    const evidenceThin=s.metrics.dataTier!=='FULL'||s.metrics.chanceCoverage<=0||liveEvidence<4||evidenceAge.direction==null||evidenceAge.direction>300||dirTrend?.trend==='ISOLATED';
    const strongEvidence=!evidenceThin&&football.chance&&football.momentum&&evidenceAge.direction!=null&&evidenceAge.direction<=180;
    const footballWatch=footballCount>=2&&liveEvidence>=2&&dirTrend?.trend!=='ISOLATED'&&(evidenceAge.direction==null||evidenceAge.direction<=480);
    const marketAvailable=!!s.market.valid;
    let state='BALANCED',rec='NO SIGNAL';
    if(states.direction!=='BALANCED'){
      if((mf.level==='HARD_DIVERGENCE'||mf.level==='SOFT_DIVERGENCE')&&footballWatch){state='DIVERGENCE';rec=`KHÔNG XÁC NHẬN ${states.direction}`}
      else if(gap>=30&&corePass&&strongEvidence&&marketAvailable&&(mf.level==='HARD_AGREEMENT'||mf.level==='SOFT_AGREEMENT')){state=`${states.direction}_STRONG`;rec=`STRONG ${states.direction}`}
      else if(gap>=10&&footballWatch){state=`${states.direction}_LEAN`;rec=`WATCH ${states.direction}`}
      else {state=`${states.direction}_BIAS`;rec='NO SIGNAL'}
    }
    if(s.metrics.dataTier==='MARKET_WATCH')state=s.market.valid?'MARKET_WATCH':'DATA_INCOMPLETE';
    if((Date.now()-s.captured_at)>55000){state='STALE';rec='WAIT DATA'}
    return {w3,w5,w10,segments:hcSegments(w3,w5,w10),homeTrend:ht,awayTrend:at,regime:regime.name,evidenceAge,states,marketFit:mf,movement:move,gap,core:{tests:{...football,market},count:coreCount,footballCount,pass:corePass},dq,dataTier:s.metrics.dataTier,evidenceThin,strongEvidence,footballWatch,marketAvailable,liveEvidence,state,recommendation:rec}}
  function hcStateText(s){return ({HOME_STRONG:'HOME STRONG',AWAY_STRONG:'AWAY STRONG',HOME_LEAN:'HOME LEAN',AWAY_LEAN:'AWAY LEAN',HOME_BIAS:'HOME BIAS',AWAY_BIAS:'AWAY BIAS',BALANCED:'BALANCED',DIVERGENCE:'DIVERGENCE',MARKET_WATCH:'MARKET WATCH',DATA_INCOMPLETE:'NO DATA',BASELINE:'BASELINE',COOLDOWN:'COOLDOWN',STALE:'STALE / WAIT DATA',ENDED:'ENDED'})[s]||s}
  function hcCalRead(){try{const a=JSON.parse(localStorage.getItem(HANDICAP_CAL_KEY)||'[]');return Array.isArray(a)?a:[]}catch{return []}}
  function hcCalWrite(){try{localStorage.setItem(HANDICAP_CAL_KEY,JSON.stringify((handicapWatchState.calibration||[]).slice(-HANDICAP_CAL_MAX)))}catch{}}
  function hcCalUpdate(item,s,event){
    const a=item.activeSignal;if(!a)return;const elapsed=(s.captured_at-a.start_at)/60000;
    if(event==='RED_CARD'){a.resolved=false;a.void_reason='RED_CARD';a.resolved_at=s.captured_at;handicapWatchState.calibration.push(a);item.activeSignal=null;hcCalWrite();return}
    if(elapsed>=15||['FT','AET','PEN'].includes(s.status)){
      const dh=s.goals.home-a.start_home,da=s.goals.away-a.start_away;a.resolved=true;a.resolved_at=s.captured_at;a.elapsed=Math.round(elapsed*10)/10;
      a.goal_delta={home:dh,away:da};a.neutral=dh===da;a.confirmed=a.direction==='HOME'?dh>da:a.direction==='AWAY'?da>dh:null;
      handicapWatchState.calibration.push(a);item.activeSignal=null;hcCalWrite()
    }
  }
  function hcMaybeStartSignal(item,s){
    const e=item.eval;if(item.activeSignal||!['HOME_STRONG','AWAY_STRONG','HOME_LEAN','AWAY_LEAN'].includes(e.state))return;
    item.activeSignal={fixture_id:item.id,league:item.league,home:item.home,away:item.away,start_at:s.captured_at,minute:s.minute,
      start_home:s.goals.home,start_away:s.goals.away,direction:e.states.direction,gap:e.gap,live_gap:e.states.liveGap,core:e.core.count,
      market_fit:e.marketFit.score,market_level:e.marketFit.level,line_move:e.marketFit.lineMove,price_move:e.marketFit.priceMove,
      market_velocity:e.marketFit.velocity,line:s.market.line,home_odd:s.market.homeOdd,away_odd:s.market.awayOdd,
      data_tier:e.dataTier,recommendation:e.recommendation}
  }
  function hcCalStats(){const r=(handicapWatchState.calibration||[]).filter(x=>x.resolved===true),c=r.filter(x=>x.confirmed===true).length;return {n:r.length,confirmed:c,rate:r.length?c/r.length:0}}
  function renderHandicapCalibration(){const s=hcCalStats(),qs=qsigStats('HC'),el=$('handicapWatchCalibration');if($('handicapWatchCalCount'))$('handicapWatchCalCount').textContent=String(qs.n);if(el)el.innerHTML=`<b>V1.16.2 FIXED BENCHMARK HANDICAP:</b> Qualified waves n=${qs.n} • High ${qs.high} • Open ${qs.open}<br><span class="tiny">30–80' • LIVE GAP ≥22 • CORE ≥3/4 & Football Core ≥2/3 • FULL • DQ ≥4/5 • fresh ≤20s • Evidence ≤180s • Football Core ≥2/3 • Market ≥ SOFT_AGREEMENT • không bắt buộc đồng thời Chance+Momentum. HIGH: LIVE GAP ≥30 • CORE 4/4 • Evidence ≤90s • HARD_AGREEMENT.</span>`}
  function hcMarketDue(item,force){return force||!item.lastMarketAt||Date.now()-item.lastMarketAt>=15000||/STRONG|DIVERGENCE/.test(item.eval?.state||'')}
  async function hcFetchSnapshot(item,f,liveBetRef,force=false){
    if(!f||!handicapWatchEligible(f))return {ended:true,fixture:f};
    const meta=compactFixtureMeta(f,autoModeForFixture(f)),u=await ultraLiveRaw(f,item,'HC',force),raw=u.statsRaw||[],rows=u.liveOdds.slice(0,60),
          metrics=handicapAggregate(statMap(raw),meta),market=hcMarketFromRows(rows,item.home,item.away),half=u.halfRaw?normalizeHalfStatistics(u.halfRaw,raw):null,now=Date.now();
    item.lastMarketRows=rows;item.lastMarketAt=u.marketAt||now;
    const s={captured_at:now,fresh_at:u.statsAt||now,minute:Number(f.fixture?.status?.elapsed||0),status:f.fixture?.status?.short||'',
      goals:{home:Number(f.goals?.home||0),away:Number(f.goals?.away||0)},metrics,market,fixture:f,events:eventsCompact(u.eventsRaw||[]).slice(-40),
      hub_tier:u.tier,content_freshness:u.freshness,personnel:u.personnel,half_context:half?{
        first_half:handicapAggregate(half.first_half||{},meta),second_half:handicapAggregate(half.second_half||{},meta),second_half_derived:half.second_half_derived
      }:null,source:'ULTRA_HUB'};
    hcMarketHistory(item,market,s);return s
  }
  async function hcSeedSnapshot(f,liveBetRef){const item={id:f.fixture.id,home:f.teams?.home?.name||'',away:f.teams?.away?.name||'',lastMarketRows:[],lastMarketAt:0,marketHistory:[]};return hcFetchSnapshot(item,f,liveBetRef,true)}
  function hcSeedRank(s){const m=s.metrics,h=m.home,a=m.away;let x=0;const sh=Math.abs(Number(h.shots||0)-Number(a.shots||0)),sot=Math.abs(Number(h.sot||0)-Number(a.sot||0)),ib=Math.abs(Number(h.inbox||0)-Number(a.inbox||0)),xg=Math.abs(Number(h.xg||0)-Number(a.xg||0));x+=Math.min(25,sh*2)+Math.min(24,sot*5)+Math.min(18,ib*2)+Math.min(18,xg*12)+(s.market.valid?12:0)+(m.dataTier==='FULL'?8:m.dataTier==='PARTIAL'?4:0);return Math.round(x)}
  function hcFmtAge(sec){if(sec==null)return 'N/A';if(sec<60)return `${sec}s`;return `${Math.floor(sec/60)}m${String(sec%60).padStart(2,'0')}s`}
  function hcFmtAdv(v){const n=Number(v||0);return `${n>0?'+':''}${Math.round(n*10)/10}`}
  function hcWindowText(w,label){if(!w?.usable)return `<div class="handicap-window"><b>${label}:</b> đang tích lũy</div>`;const h=w.delta.home,a=w.delta.away;return `<div class="handicap-window"><b>${label}:</b> Shots ${h.shots??'N/A'}-${a.shots??'N/A'} • SOT ${h.sot??'N/A'}-${a.sot??'N/A'} • InBox ${h.inbox??'N/A'}-${a.inbox??'N/A'} • xG ${h.xg??'N/A'}-${a.xg??'N/A'}</div>`}
  function hcRecText(e,s){const dir=e.states.direction;if(e.recommendation==='NO SIGNAL')return 'NO SIGNAL';if(e.recommendation==='WAIT DATA')return 'WAIT DATA / STALE';if(e.recommendation.startsWith('KHÔNG'))return e.recommendation;const line=s.market.valid&&s.market.line!=null?(dir==='HOME'?s.market.line:-Number(s.market.line)):null;return `THEO DÕI ${dir}${line!=null?' '+(line>0?'+':'')+line:''}`}
  function hcWhy(item){const e=item.eval,good=[],bad=[];if(Math.abs(e.states.liveGap)>=30)good.push('LIVE GAP mạnh');else if(Math.abs(e.states.liveGap)>=18)good.push('LIVE superiority rõ');if(e.core.tests.chance)good.push('Recent chance xác nhận');if(e.core.tests.momentum)good.push(`${e.states.direction} momentum ${e.states.direction==='HOME'?e.homeTrend.trend:e.awayTrend.trend}`);if(e.marketFit.level==='HARD_AGREEMENT')good.push('HARD AGREEMENT: line/price cùng hướng');else if(e.marketFit.level==='SOFT_AGREEMENT')good.push('SOFT AGREEMENT');if(e.marketFit.level==='HARD_DIVERGENCE')bad.push('HARD DIVERGENCE: market đi ngược nhanh');else if(e.marketFit.level==='SOFT_DIVERGENCE')bad.push('SOFT DIVERGENCE');if(!e.footballWatch)bad.push('Chưa đủ 2/3 Football Core + recent evidence để WATCH');if(e.evidenceThin)bad.push('LIVE evidence còn mỏng / cũ / isolated');if(!e.core.tests.chance)bad.push('Recent chance chưa PASS');if((e.states.direction==='HOME'?e.homeTrend.trend:e.awayTrend.trend)==='ISOLATED')bad.push('Một event lẻ bị lặp trong cửa sổ 3/5/10m');if(/CHASE/.test(e.regime||''))bad.push('Đang trailing chase — pressure được giảm trọng số');if(e.dataTier==='PARTIAL')bad.push('PARTIAL DATA');if(e.dataTier==='MARKET_WATCH')bad.push('Thiếu LIVE stats');if(!item.latest.market.valid)bad.push('AH live N/A');return {good,bad}}
  function hcProMonogram(name){
    const parts=String(name||'?').trim().split(/\s+/).filter(Boolean);if(!parts.length)return '?';
    return esc((parts.length===1?parts[0].slice(0,2):parts[0][0]+parts[parts.length-1][0]).toUpperCase())
  }
  function hcProMarketLineText(s){
    if(!s?.market?.valid||s.market.line==null)return 'AH LINE N/A';
    const raw=Number(s.market.line);if(!Number.isFinite(raw))return 'AH LINE N/A';
    const home=`HOME ${raw>0?'+':''}${raw}`;
    const awayLine=-raw,away=`AWAY ${awayLine>0?'+':''}${awayLine}`;
    const ho=s.market.homeOdd!=null?` @${Number(s.market.homeOdd).toFixed(3).replace(/0+$/,'').replace(/\.$/,'')}`:'';
    const ao=s.market.awayOdd!=null?` @${Number(s.market.awayOdd).toFixed(3).replace(/0+$/,'').replace(/\.$/,'')}`:'';
    return `${home}${ho} • ${away}${ao}`
  }
  function hcProLiveReality(e){
    const gap=Number(e?.states?.liveGap||0),abs=Math.abs(gap);
    if(abs<10)return {dir:'BALANCED',label:'BALANCED',className:'balanced'};
    const dir=gap>0?'HOME':'AWAY';
    if(abs<18)return {dir,label:`SLIGHT ${dir}`,className:'slight'};
    return {dir,label:`${dir} ADVANTAGE`,className:'advantage'}
  }
  function hcProPreDirection(e){
    const p=Number(e?.states?.preAdv||0);
    if(Math.abs(p)<2)return 'NEUTRAL';
    return p>0?'HOME':'AWAY'
  }
  function hcProCurrentRead(e){
    const live=hcProLiveReality(e),pre=hcProPreDirection(e);
    if(e?.dataTier==='MARKET_WATCH')return {
      title:'CHỈ MARKET WATCH • LIVE STATS CHƯA ĐỦ',
      detail:pre==='NEUTRAL'?'PRE trung tính • chưa có LIVE evidence đủ để xác nhận cục diện':`Nền nghiêng ${pre} • chưa có LIVE evidence đủ để xác nhận`
    };
    if(e?.dataTier==='PARTIAL')return {
      title:`DỮ LIỆU LIVE CHƯA ĐỦ • ${live.label}`,
      detail:pre==='NEUTRAL'?'PRE trung tính • cần thêm LIVE evidence':`PRE nghiêng ${pre} • LIVE hiện chưa đủ dữ liệu để kết luận mạnh`
    };
    if(live.dir==='BALANCED'){
      if(pre==='NEUTRAL')return {title:'LIVE ĐANG CÂN BẰNG',detail:'PRE trung tính • hiện tại chưa có lợi thế LIVE rõ'};
      return {title:`NỀN NGHIÊNG ${pre} • LIVE CHƯA XÁC NHẬN`,detail:`PRE ${hcFmtAdv(e.states.preAdv)} nhưng LIVE GAP ${e.states.liveGap>0?'+':''}${e.states.liveGap} • hiện trạng chưa xác nhận kỳ vọng ban đầu`}
    }
    if(pre==='NEUTRAL')return {title:`LIVE NGHIÊNG ${live.dir}`,detail:`LIVE GAP ${e.states.liveGap>0?'+':''}${e.states.liveGap} • lợi thế xuất hiện từ diễn biến thực tế`};
    if(pre===live.dir)return {title:`LIVE ĐANG XÁC NHẬN ${pre}`,detail:`PRE và LIVE cùng hướng • LIVE GAP ${e.states.liveGap>0?'+':''}${e.states.liveGap}`};
    return {title:`EXPECTATION REVERSAL • LIVE NGHIÊNG ${live.dir}`,detail:`PRE nghiêng ${pre} nhưng hiện trạng LIVE đã đảo hướng • LIVE GAP ${e.states.liveGap>0?'+':''}${e.states.liveGap}`}
  }
  function hcProSelectionForDirection(s,dir){
    if(!s?.market?.valid||s.market.line==null||!['HOME','AWAY'].includes(dir))return null;
    const raw=Number(s.market.line);if(!Number.isFinite(raw))return null;
    const line=dir==='HOME'?raw:-raw;
    const odd=dir==='HOME'?s.market.homeOdd:s.market.awayOdd;
    const lineText=`${dir} ${line>0?'+':''}${line}`;
    const oddText=odd!=null&&Number.isFinite(Number(odd))?` @${Number(odd).toFixed(3).replace(/0+$/,'').replace(/\.$/,'')}`:'';
    return {dir,line,odd:odd==null?null:Number(odd),text:lineText+oddText}
  }
  function hcProFinalSignal(e,s,qa,stale){
    const dir=e?.states?.direction;
    const sel=hcProSelectionForDirection(s,dir);
    if(stale)return {
      confirmed:false,level:'WAIT DATA',title:'NO CONFIRMED SIGNAL',
      selection:null,reason:'Dữ liệu đang STALE • không sử dụng market line làm tín hiệu cuối'
    };
    if(!qa?.qualified)return {
      confirmed:false,level:'NO SIGNAL',title:'NO CONFIRMED SIGNAL',
      selection:null,
      reason:e?.dataTier==='MARKET_WATCH'
        ?'Chỉ có market watch / LIVE evidence chưa đủ • market line chỉ là tham chiếu'
        :'Chưa đạt ngưỡng QUALIFIED • market line chỉ là tham chiếu'
    };
    if(!sel)return {
      confirmed:false,level:'WAIT MARKET',title:'NO CONFIRMED SIGNAL',
      selection:null,reason:'Đã đủ football evidence nhưng chưa có LIVE AH hợp lệ để gắn line'
    };
    return {
      confirmed:true,
      level:qa.high?'HIGH CONFIRMATION':'QUALIFIED SIGNAL',
      title:'FINAL ANALYTICS SIGNAL',
      selection:sel.text,
      reason:qa.high
        ?'LIVE state + CORE + Evidence + HARD market agreement cùng xác nhận'
        :'Đạt fixed QUALIFIED benchmark • football evidence và market cùng xác nhận'
    }
  }

  function hcProSignalLabel(e,qa,stale){
    if(stale)return 'WAIT DATA';if(qa?.high)return 'HIGH CONFIRMATION';if(qa?.qualified)return 'QUALIFIED SIGNAL';
    return hcStateText(e?.state||'BALANCED')
  }
  function hcProSignalClass(e,qa,stale){
    if(stale)return 'wait';if(qa?.high)return 'high';if(qa?.qualified)return 'qualified';
    if(e?.state==='DIVERGENCE')return 'diverge';if(/STRONG/.test(e?.state||''))return 'high';if(/LEAN/.test(e?.state||''))return 'lean';return 'neutral'
  }
  function hcTopItems(){return [...(handicapWatchState.pool||[])].filter(x=>x.eval?.state!=='ENDED').sort((a,b)=>{const pa=/STRONG/.test(a.eval?.state)?4:/LEAN/.test(a.eval?.state)?3:a.eval?.state==='DIVERGENCE'?2:/BIAS/.test(a.eval?.state)?1:0,pb=/STRONG/.test(b.eval?.state)?4:/LEAN/.test(b.eval?.state)?3:b.eval?.state==='DIVERGENCE'?2:/BIAS/.test(b.eval?.state)?1:0;return pb-pa||Number(b.eval?.gap||0)-Number(a.eval?.gap||0)}).slice(0,HANDICAP_TOP_MAX)}
  function renderHandicapWatch(){
    const list=$('handicapWatchList'),top=hcTopItems(),pool=handicapWatchState.pool||[];
    $('handicapWatchCount').textContent=`${top.length} / ${pool.length}`;
    $('handicapWatchApiUsage').textContent=String(apiUsageSnapshot().network_calls||0);
    renderHandicapCalibration();
    if(!pool.length){
      feLivePatchHTML(list,'<div class="watch-alert-note"><b>Chưa có HANDICAP.</b> Quét LIVE rồi bấm CANH TOP 5 HANDICAP.</div>');
      $('handicapWatchPacketActions').classList.add('hidden');return
    }
    $('handicapWatchPacketActions').classList.remove('hidden');
    feLivePatchHTML(list,top.map((it,i)=>{
      const s=it.latest,e=it.eval,w=hcWhy(it),dir=e.states.direction,
            fresh=Math.max(0,Math.round((Date.now()-s.captured_at)/1000)),staleNow=fresh>55,qa=qsigAssessHC(it,s),
            stateNow=staleNow?'STALE':e.state,signalLabel=hcProSignalLabel(e,qa,staleNow),signalClass=hcProSignalClass(e,qa,staleNow),
            liveGap=Number(e.states.liveGap||0),liveReality=hcProLiveReality(e),liveBar=Math.min(50,Math.max(0,Math.abs(liveGap)*1.25)),
            totalGap=Number(e.states.gap||0),directionTrend=liveReality.dir==='HOME'?e.homeTrend:liveReality.dir==='AWAY'?e.awayTrend:{trend:'QUIET'},
            currentRead=hcProCurrentRead(e),finalSignal=hcProFinalSignal(e,s,qa,staleNow),seg=e.segments||{},marketCls=(e.marketFit.level==='HARD_DIVERGENCE'||e.marketFit.level==='SOFT_DIVERGENCE')?' diverge':'',
            goodText=w.good.join(' • ')||'Chưa có xác nhận LIVE mới đủ mạnh',badText=w.bad.join(' • ')||'Chưa có veto đáng kể',
            dqNow=fresh>30?Math.max(1,e.dq-1):e.dq;
      const gapVisual=feGapVisual(liveGap,stateNow);
      return `<article class="hc-pro-card ${signalClass}" data-fe-live-key="${esc(it.id)}">
        <header class="hc-pro-topline">
          <div class="hc-pro-rank">#${i+1}</div>
          <div class="hc-pro-league"><span>${esc(it.league)}</span><small>FX ${it.id}</small></div>
          <div class="hc-pro-fresh ${staleNow?'stale':''}">${staleNow?'STALE':`fresh ${fresh}s`}</div>
        </header>

        <section class="hc-pro-match">
          <div class="hc-pro-team home">
            <div class="hc-pro-logo">${hcProMonogram(it.home)}</div>
            <b>${esc(it.home)}</b>
            <span>HOME</span>
          </div>
          <div class="hc-pro-score">
            <span class="minute">${s.minute}'</span>
            <strong>${s.goals.home} - ${s.goals.away}</strong>
            <small>${esc(e.regime)}</small>
          </div>
          <div class="hc-pro-team away">
            <div class="hc-pro-logo">${hcProMonogram(it.away)}</div>
            <b>${esc(it.away)}</b>
            <span>AWAY</span>
          </div>
        </section>
        ${grHCBadges(it.id)}

        <section class="hc-pro-signal">
          <div class="hc-pro-signal-main">
            <div>
              <span class="eyebrow">CURRENT LIVE REALITY</span>
              <strong class="live-reality ${liveReality.className} ${gapVisual.cls}">${esc(liveReality.label)}</strong>
              <small>${esc(directionTrend.trend)} • LIVE GAP ${liveGap>0?'+':''}${Math.round(liveGap)} • không bao gồm PRE</small>
              <span class="hc-gap-zone-note ${gapVisual.cls} ${gapVisual.cls==='gap-strong'&&!gapVisual.strongActual?'unqualified':''}">${esc(gapVisual.label)}</span>
            </div>
            <div class="hc-pro-signal-pill ${signalClass}">${esc(signalLabel)}</div>
          </div>
          <div class="hc-pro-statebar present-first">
            <span class="hc-pro-midline"></span>
            ${liveReality.dir==='BALANCED'?'':`<i class="${liveReality.dir==='AWAY'?'away ':''}${gapVisual.cls}" style="width:${liveBar}%"></i>`}
          </div>
          <div class="hc-pro-statebar-label"><span>HOME</span><b>LIVE GAP ${liveGap>0?'+':''}${Math.round(liveGap)}</b><span>AWAY</span></div>
        </section>

        <section class="hc-pro-metrics primary">
          <div><span>PRE PRIOR</span><b>${hcFmtAdv(e.states.preAdv)}</b><small>Kỳ vọng nền</small></div>
          <div><span>LIVE REALITY</span><b>${hcFmtAdv(e.states.liveAdv)}</b><small>Hiện trạng</small></div>
          <div><span>MOM</span><b>${hcFmtAdv(e.states.momentumAdv)}</b><small>${esc(directionTrend.trend)}</small></div>
          <div><span>CORE</span><b>${e.core.count}/4</b><small>Football ${e.core.footballCount}/3</small></div>
        </section>

        <section class="hc-pro-metrics secondary">
          <div><span>MARKET</span><b>${e.marketFit.score==null?'N/A':e.marketFit.score}</b><small>${esc(e.marketFit.level)}</small></div>
          <div><span>DQ</span><b>${dqNow}/5</b><small>${esc(e.dataTier)}</small></div>
          <div><span>EVIDENCE</span><b>${hcFmtAge(e.evidenceAge?.direction)}</b><small>${e.evidenceThin?'THIN':'CURRENT'}</small></div>
          <div><span>TOTAL GAP</span><b>${totalGap>0?'+':''}${Math.round(totalGap)}</b><small>PRE + LIVE</small></div>
        </section>

        ${qa?.qualified?`<div class="hc-pro-qualified ${qa.high?'high':''}"><span>${qa.high?'◆':'●'}</span><b>${qa.high?'HIGH CONFIRMATION':'QUALIFIED SIGNAL'}</b><small>T0 benchmark • fixed threshold • not probability</small></div>`:''}

        <section class="hc-pro-read ${marketCls}">
          <div class="hc-pro-read-head"><span>PRESENT-FIRST READ</span><b>${esc(currentRead.title)}</b></div>
          <p>${esc(currentRead.detail)}${goodText&&goodText!=='Chưa có xác nhận LIVE mới đủ mạnh'?` • ${esc(goodText)}`:''}</p>
        </section>

        <section class="hc-pro-final ${finalSignal.confirmed?'confirmed':'no-signal'}">
          <div class="hc-pro-final-head">
            <span>FINAL ANALYTICS SIGNAL</span>
            <b class="${finalSignal.confirmed?'confirmed':'no-signal'}">${esc(finalSignal.level)}</b>
          </div>
          <div class="hc-pro-final-main">
            <strong>${esc(finalSignal.confirmed?finalSignal.selection:finalSignal.title)}</strong>
            <small>${esc(finalSignal.reason)}</small>
          </div>
          ${finalSignal.confirmed
            ?`<div class="hc-pro-final-rule">✓ Chỉ xuất hiện khi QSIG đã đạt ${esc(finalSignal.level)} tại T0.</div>`
            :`<div class="hc-pro-final-rule warn">⚠ MARKET LINE bên dưới chỉ là REFERENCE — không phải FINAL SIGNAL.</div>`}
        </section>

        <section class="hc-pro-market">
          <div class="hc-pro-section-title"><span>MARKET INTELLIGENCE</span><small>${esc(hcProMarketLineText(s))}</small></div>
          <div class="hc-pro-market-context"><b>MARKET REFERENCE</b><span>${esc(hcProMarketLineText(s))}</span><small>${finalSignal.confirmed?'Line này đã được gắn vào FINAL ANALYTICS SIGNAL phía trên':'REFERENCE ONLY • chưa được xem là tín hiệu cuối'}</small></div>
          <div class="hc-pro-market-grid">
            <div><span>LINE</span><b>${esc(e.marketFit.lineMove)}</b></div>
            <div><span>PRICE</span><b>${esc(e.marketFit.priceMove)}</b></div>
            <div><span>VELOCITY</span><b>${esc(e.marketFit.velocity)}</b></div>
            <div><span>AGREEMENT</span><b>${esc(e.marketFit.level)}</b></div>
          </div>
        </section>

        <div class="hc-pro-risk"><b>WHY NOT / RISK</b><span>${esc(badText)}</span></div>

        <details class="hc-pro-details">
          <summary><span>CHI TIẾT ENGINE</span><b>+</b></summary>
          <div class="hc-pro-details-body">
            <div class="watch-core"><b>CORE 4:</b> ${e.core.count}/4 ${e.core.pass?'PASS':'chưa đủ'} • SUPERIORITY ${e.core.tests.superiority?'✓':'–'} • CHANCE ${e.core.tests.chance?'✓':'–'} • MOM ${e.core.tests.momentum?'✓':'–'} • MARKET ${e.core.tests.market?'✓':'–'}</div>
            <div class="hc-ultra-diagnostic"><b>ULTRA DATA:</b> ${esc(s.hub_tier||'N/A')} • stats content ${s.content_freshness?.stats_content_age??'N/A'}s • events ${s.content_freshness?.events_content_age??'N/A'}s • market ${s.content_freshness?.market_content_age??'N/A'}s • last sub ${s.personnel?.last_sub_minute??'N/A'}'</div>
            <div class="hc-window-title">INCREMENTAL MOMENTUM — không đếm lặp cùng một event</div>
            ${hcWindowText(seg.s03,'0–3M')}${hcWindowText(seg.s35,'3–5M')}${hcWindowText(seg.s510,'5–10M')}
            <div class="handicap-market-grid"><div class="handicap-market-box"><b>LIVE AH • SCORE-AT-QUOTE</b>${esc(s.market.text)}<br>${s.minute}' • ${s.goals.home}-${s.goals.away}<br>${s.market.consensus?`CONSENSUS ${s.market.bookmakerCount} books • dispersion ${s.market.lineDispersion}`:`BOOKS ${s.market.bookmakerCount||0}`}</div><div class="handicap-market-box"><b>MARKET FIT ${e.marketFit.score==null?'N/A':e.marketFit.score+'/100'}</b>${esc(e.marketFit.level)}<br>${esc(e.movement.text)}<br>LINE ${esc(e.marketFit.lineMove)} • PRICE ${esc(e.marketFit.priceMove)} • ${esc(e.marketFit.velocity)}</div></div>
          </div>
        </details>
      </article>`
    }).join(''))
  }

  function hcNextInterval(){const top=hcTopItems();if(top.some(x=>/STRONG|DIVERGENCE/.test(x.eval?.state||'')))return 8000;if(top.some(x=>/LEAN/.test(x.eval?.state||'')))return 12000;return 18000}
  function updateHandicapWatchClock(){const el=$('handicapWatchCountdown');if(!el)return;if(!handicapWatchState.active||!handicapWatchState.nextAt){el.textContent='—';return}el.textContent=Math.max(0,Math.ceil((handicapWatchState.nextAt-Date.now())/1000))+'s'}
  function scheduleHandicapWatch(){clearTimeout(handicapWatchState.timer);if(feWorkspaceAutoStopIfDone('HC'))return;if(!handicapWatchState.active||!$('handicapWatchAuto')?.checked){handicapWatchState.nextAt=0;updateHandicapWatchClock();return}const ms=hcNextInterval();handicapWatchState.nextAt=Date.now()+ms;handicapWatchState.timer=setTimeout(()=>refreshHandicapWatch(true),ms);updateHandicapWatchClock()}
  async function refreshHandicapWatch(quiet=false){
    if(handicapWatchState.refreshing||!handicapWatchState.pool.length)return;handicapWatchState.refreshing=true;
    if(!quiet)status($('handicapWatchStatus'),'ULTRA HUB • cập nhật Team State + AH consensus...','busy');
    try{
      const hb=await ultraHeartbeat(!quiet),liveRef=await getBetReference('live');
      await mapLimit(handicapWatchState.pool,5,async item=>{
        const f=hb.map.get(String(item.id));if(!f||!handicapWatchEligible(f)){item.eval={...(item.eval||{}),state:'ENDED'};bgUnregisterFixtureIds([item.id],true).catch(()=>{});return item}
        const prev=item.latest,s=await hcFetchSnapshot(item,f,liveRef,false);if(s.ended)return item;let event=null;
        if(prev&&(s.goals.home!==prev.goals.home||s.goals.away!==prev.goals.away)){event='GOAL';item.resetAt=Date.now();item.cooldownUntil=Date.now()+100000;item.marketHistory=[]}
        const pr=Number(prev?.metrics?.home?.red||0)+Number(prev?.metrics?.away?.red||0),cr=Number(s.metrics?.home?.red||0)+Number(s.metrics?.away?.red||0);
        if(cr>pr){event='RED_CARD';item.resetAt=Date.now();item.cooldownUntil=Date.now()+170000;item.marketHistory=[]}
        item.history=(item.history||[]).concat([s]).slice(-140);item.latest=s;item.eval=hcEvaluate(item,s);if(item.cooldownUntil>Date.now())item.eval.state='COOLDOWN';
        hcCalUpdate(item,s,event);if(event==='GOAL')item.activeSignal=null;hcMaybeStartSignal(item,s);qsigUpdateHC(item,s,event,false);hcWriteHistory(item);return item
      });
      handicapWatchState.pool=handicapWatchState.pool.filter(x=>x.eval?.state!=='ENDED');
      handicapWatchState.cycle++;renderHandicapWatch();
      if(!quiet)status($('handicapWatchStatus'),`Đã cập nhật ${handicapWatchState.pool.length} trận active • stale-source đã chặn ${FE_WORKSPACE_SCAN_STATE.HC.rejectedStale||0} • ${ultraHubSummary()}`,'ok')
    }catch(e){status($('handicapWatchStatus'),'Lỗi cập nhật HANDICAP: '+e.message,'err')}
    finally{handicapWatchState.refreshing=false;scheduleHandicapWatch()}
  }
  async function startHandicapWatch(){
    const feIsolationSnap=feCaptureOtherEngines('HC');
    let source=[];try{source=await feWorkspaceScanFixtures('HC')}catch(e){showToast('err','HANDICAP scan lỗi',e.message);return}
    const cand=source.sort((a,b)=>handicapCheapRank(b)-handicapCheapRank(a)).slice(0,HANDICAP_PREFILTER_MAX);
    handicapWatchState.sourceFixtureIds=cand.map(f=>Number(f?.fixture?.id)).filter(Number.isFinite);
    if(!cand.length){showToast('err','Không có trận phù hợp','HANDICAP workspace vừa quét LIVE độc lập nhưng chưa có trận phút 25–88 phù hợp.');return}
    loading(true,'HANDICAP WORKSPACE ĐỘC LẬP','Đọc LIVE stats + Events + AH consensus • H1/FT tiếp tục chạy riêng.');
    try{
      const liveRef=await getBetReference('live'),seeds=(await mapLimit(cand,5,async f=>{
        const temp={id:f.fixture.id,home:f.teams?.home?.name||'',away:f.teams?.away?.name||'',lastMarketRows:[],lastMarketAt:0,marketHistory:[],history:[]};
        const s=await hcFetchSnapshot(temp,f,liveRef,true);return {f,s,temp,rank:hcSeedRank(s)}
      })).filter(Boolean);
      const picked=seeds.sort((a,b)=>b.rank-a.rank).slice(0,HANDICAP_POOL_MAX),preRows=await mapLimit(picked,5,x=>hcLoadPreBaseline(x.f));
      handicapWatchState.pool=picked.map(({f,s,temp},idx)=>{
        const item={id:f.fixture.id,home:f.teams?.home?.name||'',away:f.teams?.away?.name||'',league:`${f.league?.name||''}${f.league?.country?' | '+f.league.country:''}`,
          home_id:f.teams?.home?.id,away_id:f.teams?.away?.id,preBaseline:preRows[idx]||{adv:0,source:'N/A'},history:hcReadHistory(f.fixture.id).concat([s]).slice(-140),latest:s,
          lastMarketRows:temp.lastMarketRows,lastMarketAt:temp.lastMarketAt,marketHistory:temp.marketHistory||[],resetAt:null,cooldownUntil:0,activeSignal:null};
        item.eval=hcEvaluate(item,s);hcMaybeStartSignal(item,s);qsigUpdateHC(item,s,null,false);hcWriteHistory(item);return item
      });
      handicapWatchState.active=true;renderHandicapWatch();$('handicapWatchCard')?.scrollIntoView({behavior:'smooth',block:'start'});
      status($('handicapWatchStatus'),`Pool ${handicapWatchState.pool.length}/${cand.length} • stale-source chặn ${FE_WORKSPACE_SCAN_STATE.HC.rejectedStale||0} • AH consensus • ${ultraHubSummary()}`,'ok');
      scheduleHandicapWatch();bgRegisterItems(handicapWatchState.pool,'HC').catch(()=>{});showToast('ok','LIVE HANDICAP V1.16.3',`Shared HUB • adaptive polling • event/half/personnel context • AH consensus. • ${feWorkspaceSummary()}`)
    }catch(e){status($('handicapWatchStatus'),'Không khởi động được HANDICAP: '+e.message,'err');showToast('err','HANDICAP lỗi',e.message)}
    finally{feRestoreOtherEngines(feIsolationSnap,'START_HC');loading(false)}
  }
  function stopHandicapWatch(){feMarkEngineManualStop('HC');handicapWatchState.active=false;clearTimeout(handicapWatchState.timer);handicapWatchState.nextAt=0;updateHandicapWatchClock();status($('handicapWatchStatus'),'Đã dừng AUTO HANDICAP. History và calibration vẫn lưu trên máy.','ok')}
  function handicapWatchStopForOther(){log('Workspace isolation: ignore legacy cross-stop',{engine:'HC'});return false}
  function buildHandicapWatchPacket(){const st=hcCalStats(),top=hcTopItems(),rows=top.map((it,i)=>{const s=it.latest,e=it.eval,w=hcWhy(it);return `#${i+1} | FX ${it.id} | ${it.league}\nTRẬN: ${it.home} vs ${it.away}\nLIVE: ${s.minute}' | ${s.goals.home}-${s.goals.away}\nTEAM_STATE: HOME ${e.states.home} | AWAY ${e.states.away} | GAP ${e.states.gap>0?'+':''}${e.states.gap} ${e.states.direction} | PRE_ADV ${e.states.preAdv} | LIVE_ADV ${e.states.liveAdv} | LIVE_GAP ${e.states.liveGap}\nREGIME: ${e.regime} | EVIDENCE_AGE ${hcFmtAge(e.evidenceAge?.direction)}\nSTATE: ${hcStateText(e.state)} | SƠ BỘ: ${e.recommendation}\nCORE: ${e.core.count}/4 ${e.core.pass?'PASS':'NO'} | football=${e.core.footballCount}/3\nMARKET: ${s.market.text} | FIT ${e.marketFit.score??'N/A'}/100 ${e.marketFit.level} | LINE ${e.marketFit.lineMove} | PRICE ${e.marketFit.priceMove} | VELOCITY ${e.marketFit.velocity} | MOVE ${e.movement.text}\nDATA: ${e.dataTier} | DQ ${e.dq}/5\n3M HOME/AWAY INDEX: ${e.homeTrend.i3}/${e.awayTrend.i3}\n5M HOME/AWAY INDEX: ${e.homeTrend.i5}/${e.awayTrend.i5}\n10M HOME/AWAY INDEX: ${e.homeTrend.i10}/${e.awayTrend.i10}\nWHY NOW: ${w.good.join(' ; ')||'-'}\nRISK: ${w.bad.join(' ; ')||'-'}`}).join('\n\n');return `[FOOTBALL_EDGE_HANDICAP_WATCH]\nVERSION: V1.18.3 SINGLE MATCH ANALYZER\nMODE: LIVE_HANDICAP_ANALYTICS\nTIME_VN: ${new Date().toLocaleString('vi-VN',{timeZone:TZ})}\nPOOL: ${handicapWatchState.pool.length} | TOP: ${top.length}\nCALIBRATION: resolved=${st.n} | confirmed15m=${st.confirmed}\n\nNGUYÊN TẮC:\n1. TEAM STATE và MARKET FIT là hai trục độc lập.\n2. SCORE/GAP là strength signal, không phải xác suất.\n3. QUALIFIED cho phép CORE 3/4 với ≥2/3 football cores; HIGH mới yêu cầu CORE 4/4.\n4. MARKET V2 tách LINE / PRICE / VELOCITY và phân SOFT/HARD AGREEMENT-DIVERGENCE; không tự kết luận market hay model bên nào đúng.\n5. Goal/Red Card làm market cũ mất hiệu lực và phải rebaseline.\n6. SƠ BỘ là nhãn analytics để theo dõi/calibration, không phải lệnh giao dịch.\n\n=== TOP LIVE HANDICAP ===\n${rows}\n=== END ===`}
  async function copyHandicapWatchPacket(open=false){if(!handicapWatchState.pool.length){showToast('err','Chưa có HANDICAP','Hãy CANH TOP 5 HANDICAP trước.');return}const p=buildHandicapWatchPacket();handicapWatchState.lastPacket=p;try{await navigator.clipboard.writeText(p)}catch{state.lastPacket=p;els.packetText.value=p;els.packetText.focus();els.packetText.select();document.execCommand('copy')}showToast('ok','Đã copy LIVE HANDICAP','Packet có Team State • GAP • CORE • score-at-quote • Line/Price/Velocity.');if(open){saveConfig(true);openProject()}}

  handicapWatchState.calibration=hcCalRead();
  $('watchHandicapTop5Btn')?.addEventListener('click',startHandicapWatch);$('startHandicapWatchBtn')?.addEventListener('click',startHandicapWatch);$('refreshHandicapWatchBtn')?.addEventListener('click',()=>refreshHandicapWatch(false));$('stopHandicapWatchBtn')?.addEventListener('click',stopHandicapWatch);$('handicapWatchAuto')?.addEventListener('change',e=>{if(e.target.checked){handicapWatchState.active=true;scheduleHandicapWatch()}else{clearTimeout(handicapWatchState.timer);handicapWatchState.nextAt=0;updateHandicapWatchClock()}});$('copyHandicapWatchPacketBtn')?.addEventListener('click',()=>copyHandicapWatchPacket(false));$('copyOpenHandicapWatchBtn')?.addEventListener('click',()=>copyHandicapWatchPacket(true));$('resetHandicapWatchCalBtn')?.addEventListener('click',()=>{if(!confirm('Xóa toàn bộ Calibration LIVE HANDICAP trên thiết bị này?'))return;handicapWatchState.calibration=[];hcCalWrite();qsigWrite('HC',[]);renderHandicapCalibration();showToast('ok','Đã xóa Handicap Calibration','Engine tiếp tục thu mẫu mới.')});handicapWatchState.ticker=setInterval(updateHandicapWatchClock,1000);renderHandicapWatch();

  /* FE_GAP_PRESSURE_SHADOW_V11_INLINE_START */
/*
 * FOOTBALL EDGE — GAP PRESSURE SHADOW V1.1
 * Additive / non-regression research layer.
 * DOES NOT modify HC engine, Goal Radar, thresholds, ranking, DQ or production Push.
 * Reads existing live state and creates de-duplicated dominance episodes + 3/5/10m validation.
 */
(()=>{
'use strict';

const FE_GPS_VERSION='GAP_PRESSURE_SHADOW_V1.1.0';
const FE_GPS_KEY='FOOTBALL_EDGE_GAP_PRESSURE_SHADOW_V1';
const FE_GPS_MAX_EPISODES=600;
const FE_GPS_MAX_SNAPS=140;
const FE_GPS_CFG=Object.freeze({
  latentGap:60,
  watchGap:70,
  goalRadarFloor:65,           // SHADOW band only; rising Goal Radar may confirm earlier
  goalRadarStrong:70,          // SHADOW band only; not a production threshold change
  fastMinSnapshots:2,          // adaptive confirmation: never blocks the immediate GAP WATCH
  fastMinSeconds:45,           // early confirmation path when pressure/evidence agree
  standardMinSnapshots:3,      // stronger persistence path
  standardMinSeconds:60,
  triggerMinSeconds:60,        // TRIGGER_CANDIDATE research label, not production Push
  decayCloseSeconds:120,       // episode de-duplication grace; not an engine threshold
  freshMaxSeconds:60,
  evidenceAgeMaxSeconds:180,
  continuityMaxSeconds:90,
  horizons:[3,5,10]
});

const now=()=>Date.now();
const n=v=>{if(v===null||v===undefined||v==='')return null;const x=Number(v);return Number.isFinite(x)?x:null};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const clone=v=>JSON.parse(JSON.stringify(v));
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const signed=v=>v==null?'—':`${v>0?'+':''}${v}`;
const fmtSec=s=>!Number.isFinite(Number(s))?'—':Number(s)<60?`${Math.round(s)}s`:`${Math.floor(s/60)}m${String(Math.round(s%60)).padStart(2,'0')}s`;
const iso=t=>t?new Date(Number(t)).toISOString():null;

function emptyState(){return {schema:FE_GPS_VERSION,updated_at:0,episodes:[]}}
function readState(){
  try{
    const x=JSON.parse(localStorage.getItem(FE_GPS_KEY)||'null');
    if(!x||!Array.isArray(x.episodes))return emptyState();
    x.schema=FE_GPS_VERSION;return x;
  }catch(_){return emptyState()}
}
let DB=readState();
let saveTimer=null;
function saveSoon(){
  clearTimeout(saveTimer);saveTimer=setTimeout(()=>{
    try{
      DB.episodes=DB.episodes.slice(-FE_GPS_MAX_EPISODES);DB.updated_at=now();
      localStorage.setItem(FE_GPS_KEY,JSON.stringify(DB));
    }catch(_){/* research layer must never break the app */}
  },180);
}

function openEpisode(fixtureId){
  for(let i=DB.episodes.length-1;i>=0;i--){const e=DB.episodes[i];if(Number(e.fixture_id)===Number(fixtureId)&&e.status==='OPEN')return e}
  return null;
}
function latestEpisode(fixtureId){for(let i=DB.episodes.length-1;i>=0;i--){if(Number(DB.episodes[i].fixture_id)===Number(fixtureId))return DB.episodes[i]}return null}

function goalRadarForFixture(fixtureId){
  const out={ft:null,h1:null,primary:null};
  try{
    if(typeof watchState!=='undefined'&&typeof grEstimate==='function'){
      const it=(watchState.items||[]).find(x=>Number(x.id)===Number(fixtureId)&&x.state!=='ENDED');
      if(it){const est=grEstimate(it,'FT'),tr=typeof grTrend==='function'?grTrend(it):null;out.ft={prob:n(est?.prob),trend:tr?.dir||null,state:it.state||null,score:n(it.eval?.score)}}
    }
  }catch(_){}
  try{
    if(typeof h1WatchState!=='undefined'&&typeof grEstimate==='function'){
      const it=(h1WatchState.items||[]).find(x=>Number(x.id)===Number(fixtureId)&&x.state!=='ENDED');
      if(it){const est=grEstimate(it,'H1'),tr=typeof grTrend==='function'?grTrend(it):null;out.h1={prob:n(est?.prob),trend:tr?.dir||null,state:it.state||null,score:n(it.eval?.score)}}
    }
  }catch(_){}
  out.primary=out.ft?.prob!=null?{engine:'FT',...out.ft}:out.h1?.prob!=null?{engine:'H1',...out.h1}:null;
  return out;
}

function snapshotMeta(item,s,e){
  const gap=n(e?.states?.liveGap),captured=n(s?.captured_at)||now(),freshAt=n(s?.fresh_at),freshAge=freshAt==null?null:Math.max(0,(captured-freshAt)/1000),
        dataTier=String(e?.dataTier||s?.metrics?.dataTier||'UNKNOWN'),dq=n(e?.dq),evAge=n(e?.evidenceAge?.direction),
        core=e?.core||{},tests=core?.tests||{},radar=goalRadarForFixture(item.id),minute=n(s?.minute),gh=n(s?.goals?.home),ga=n(s?.goals?.away),
        hr=n(s?.metrics?.home?.red)??0,ar=n(s?.metrics?.away?.red)??0;
  const gapValid=gap!=null&&dataTier==='FULL'&&dq!=null&&dq>=4&&(freshAge==null||freshAge<=FE_GPS_CFG.freshMaxSeconds);
  let evidence='LOW';
  if(gapValid&&Number(core?.footballCount||0)>=3&&tests.chance===true&&tests.momentum===true&&evAge!=null&&evAge<=FE_GPS_CFG.evidenceAgeMaxSeconds)evidence='HIGH';
  else if(gapValid&&Number(core?.footballCount||0)>=2&&tests.chance===true)evidence='MEDIUM';
  const dir=gap==null?'UNKNOWN':Math.abs(gap)<10?'BALANCED':gap>0?'HOME':'AWAY';
  return {captured_at:captured,minute,score:{home:gh,away:ga},reds:{home:hr,away:ar},gap,gap_valid:gapValid,direction:dir,
    data_tier:dataTier,dq,fresh_age_sec:freshAge,evidence_age_sec:evAge,evidence_support:evidence,
    football_core:Number(core?.footballCount||0),chance:tests.chance===true,momentum:tests.momentum===true,superiority:tests.superiority===true,
    goal_radar:radar,market_level:e?.marketFit?.level||null,engine_state:e?.state||null,regime:e?.regime||null};
}

function dominantLead(meta,dir){
  const h=n(meta.score?.home)??0,a=n(meta.score?.away)??0;return dir==='HOME'?h-a:dir==='AWAY'?a-h:0
}
function gameState(meta,dir){
  const min=n(meta.minute)||0,lead=dominantLead(meta,dir),rh=n(meta.reds?.home)||0,ra=n(meta.reds?.away)||0;
  let key='OPEN_GAME',favorable=true;
  if(min>=70&&lead>=2){key='LEADING_CONTROL_RISK';favorable=false}
  else if(lead<=-1)key='DOMINANT_SIDE_CHASING';
  else if(lead===1)key='DOMINANT_SIDE_LEADING_ONE';
  else if(lead===0)key='LEVEL_GAME';
  if(rh!==ra)key+=`_${rh<ra?'HOME_MAN_ADV':'AWAY_MAN_ADV'}`;
  return {key,favorable,minute:min,lead_for_direction:lead,red_diff_home:ra-rh};
}

function blankValidation(t0){
  const o={};for(const h of FE_GPS_CFG.horizons)o[h]={deadline:t0+h*60000,state:'WAITING',goal_any:null,goal_for_direction:null,resolved_at:null,reason:null};return o
}
function makeEpisode(item,meta){
  const dir=meta.direction,t=meta.captured_at;
  return {id:`GPS-${item.id}-${dir}-${t}`,schema:FE_GPS_VERSION,fixture_id:Number(item.id),home:item.home||'',away:item.away||'',league:item.league||'',direction:dir,
    status:'OPEN',started_at:t,watch_at:null,strong_at:null,trigger_at:null,closed_at:null,close_reason:null,
    thresholds_seen:[Math.abs(meta.gap)>=FE_GPS_CFG.latentGap?60:null].filter(Boolean),start_gap:meta.gap,current_gap:meta.gap,peak_gap:Math.abs(meta.gap),peak_signed_gap:meta.gap,
    gap_sum:Math.abs(meta.gap),gap_n:1,avg_abs_gap:Math.abs(meta.gap),watch_snapshot_count:0,watch_streak_count:0,watch_streak_started_at:null,
    max_watch_streak_count:0,max_watch_streak_sec:0,below_latent_since:null,max_observation_gap_sec:0,last_observed_at:t,last_valid_at:meta.gap_valid?t:null,data_break_open:null,continuity_breaks:[],
    start_score:clone(meta.score),last_score:clone(meta.score),last_reds:clone(meta.reds),goal_event:null,
    strongest_class:'LATENT',current_class:'LATENT',confirmation_mode:null,strongest_confirmation_mode:null,last_confirmation_reason:null,
    evidence_at_watch:null,goal_radar_at_watch:null,game_state_at_watch:null,
    unknown_observations:0,missing_reasons:[],validation:null,snapshots:[]};
}
function pushSnap(ep,meta,cls){
  ep.snapshots.push({t:meta.captured_at,minute:meta.minute,gap:meta.gap,gap_valid:meta.gap_valid,data_tier:meta.data_tier,dq:meta.dq,fresh:meta.fresh_age_sec,
    evidence_age:meta.evidence_age_sec,evidence:meta.evidence_support,goal_ft:meta.goal_radar?.ft?.prob??null,goal_h1:meta.goal_radar?.h1?.prob??null,
    cls,confirmation_mode:ep.confirmation_mode||null,confirmation_reason:ep.last_confirmation_reason||null,score:clone(meta.score),reds:clone(meta.reds),game:gameState(meta,ep.direction).key});
  if(ep.snapshots.length>FE_GPS_MAX_SNAPS)ep.snapshots=ep.snapshots.slice(-FE_GPS_MAX_SNAPS);
}
function classRank(x){return ({LATENT:0,DOMINANCE_WATCH:1,PRESSURE_STRONG:2,TRIGGER_CANDIDATE:3,UNKNOWN:0})[x]??0}
function confirmationState(ep,meta){
  if(!meta.gap_valid)return {cls:'UNKNOWN',mode:'DATA_GUARD',reason:'GAP/DATA NOT VALID'};
  const abs=Math.abs(meta.gap),same=meta.direction===ep.direction;
  if(!same||abs<FE_GPS_CFG.watchGap)return {cls:'LATENT',mode:null,reason:'BELOW WATCH OR DIRECTION CHANGED'};

  // WATCH is immediate at GAP 70. Confirmation is deliberately adaptive and never blocks WATCH.
  const p=meta.goal_radar?.primary?.prob,trend=String(meta.goal_radar?.primary?.trend||'').toLowerCase(),
        streakSec=ep.watch_streak_started_at==null?0:Math.max(0,(meta.captured_at-ep.watch_streak_started_at)/1000),
        fastPersist=ep.watch_streak_count>=FE_GPS_CFG.fastMinSnapshots&&streakSec>=FE_GPS_CFG.fastMinSeconds,
        standardPersist=ep.watch_streak_count>=FE_GPS_CFG.standardMinSnapshots&&streakSec>=FE_GPS_CFG.standardMinSeconds,
        evidenceMedium=['MEDIUM','HIGH'].includes(meta.evidence_support),evidenceHigh=meta.evidence_support==='HIGH',
        goalStrong=p!=null&&p>=FE_GPS_CFG.goalRadarStrong,goalRising=p!=null&&p>=FE_GPS_CFG.goalRadarFloor&&trend==='up',
        gs=gameState(meta,ep.direction);

  let mode=null,reason='WATCH ONLY — confirmation not mature yet';
  if(evidenceMedium&&fastPersist&&goalStrong){mode='FAST_CONFIRM';reason=`GAP sustained ${Math.round(streakSec)}s / ${ep.watch_streak_count} snaps + Goal ${Math.round(p)} + ${meta.evidence_support} evidence`}
  else if(evidenceMedium&&standardPersist&&goalRising){mode='RISING_CONFIRM';reason=`GAP sustained ${Math.round(streakSec)}s / ${ep.watch_streak_count} snaps + Goal ${Math.round(p)} rising + ${meta.evidence_support} evidence`}
  else if(evidenceHigh&&standardPersist&&p!=null&&p>=FE_GPS_CFG.goalRadarFloor){mode='EVIDENCE_CONFIRM';reason=`GAP sustained + HIGH evidence + Goal ${Math.round(p)}`}
  else return {cls:'DOMINANCE_WATCH',mode:null,reason};

  // TRIGGER_CANDIDATE is a research upgrade, not a production gate.
  const triggerReady=evidenceHigh&&gs.favorable&&(streakSec>=FE_GPS_CFG.triggerMinSeconds||ep.watch_streak_count>=FE_GPS_CFG.standardMinSnapshots)&&
    (goalStrong||goalRising);
  if(triggerReady)return {cls:'TRIGGER_CANDIDATE',mode,reason:`${reason} + game-state ${gs.key}`};
  return {cls:'PRESSURE_STRONG',mode,reason:`${reason}${!gs.favorable?' + game-state caution':''}`};
}
function classify(ep,meta){return confirmationState(ep,meta).cls}

function markVoidFuture(ep,reason,t){
  if(!ep.validation)return;
  for(const h of FE_GPS_CFG.horizons){const v=ep.validation[h];if(v.state==='WAITING'){v.state='CENSORED';v.resolved_at=t;v.reason=reason}}
}

function hasContinuityBreak(ep,deadline){
  if(!ep?.watch_at)return false;
  const a=Number(ep.watch_at),d=Number(deadline);
  const rows=[...(ep.continuity_breaks||[])];
  if(ep.data_break_open!=null)rows.push({start:ep.data_break_open,end:Infinity});
  return rows.some(x=>Number(x.start)<d&&Number(x.end??Infinity)>a)
}

function settleGoal(ep,meta,prevT,dh,da){
  if(!ep.watch_at||!ep.validation)return;
  const t=meta.captured_at,forDir=ep.direction==='HOME'?dh>da:ep.direction==='AWAY'?da>dh:null;
  ep.goal_event={observed_at:t,elapsed_sec:Math.max(0,(t-ep.watch_at)/1000),home_delta:dh,away_delta:da,for_direction:forDir};
  for(const h of FE_GPS_CFG.horizons){
    const v=ep.validation[h];if(v.state!=='WAITING')continue;
    if(t<=v.deadline){v.state='HIT';v.goal_any=true;v.goal_for_direction=forDir;v.resolved_at=t;v.reason='GOAL_OBSERVED_WITHIN_WINDOW'}
    else if(prevT!=null&&prevT<v.deadline){v.state='UNKNOWN';v.goal_any=null;v.goal_for_direction=null;v.resolved_at=t;v.reason='GOAL_TIME_AMBIGUOUS_ACROSS_WINDOW'}
    else {v.state='MISS';v.goal_any=false;v.goal_for_direction=false;v.resolved_at=v.deadline;v.reason='VALID_OBSERVATION_PASSED_WINDOW_BEFORE_GOAL'}
  }
}
function settleDueNoGoal(ep,meta){
  if(!ep.watch_at||!ep.validation||!meta.gap_valid)return;
  const t=meta.captured_at;
  for(const h of FE_GPS_CFG.horizons){const v=ep.validation[h];if(v.state!=='WAITING'||t<v.deadline)continue;
    if(Number(ep.max_observation_gap_sec||0)>FE_GPS_CFG.continuityMaxSeconds){v.state='UNKNOWN';v.reason='OBSERVATION_GAP_TOO_LARGE'}
    else if(hasContinuityBreak(ep,v.deadline)){v.state='UNKNOWN';v.reason='DATA_CONTINUITY_BROKEN'}
    else{v.state='MISS';v.goal_any=false;v.goal_for_direction=false;v.reason='NO_GOAL_WITH_CONTINUOUS_VALID_OBSERVATION'}
    v.resolved_at=t;
  }
}
function closeEpisode(ep,reason,t,censor=true){ep.status='CLOSED';ep.closed_at=t;ep.close_reason=reason;if(censor)markVoidFuture(ep,reason,t)}

function observeItem(item){
  if(!item||!item.latest||!item.eval)return;
  const meta=snapshotMeta(item,item.latest,item.eval),last=latestEpisode(item.id);
  if(last&&Number(last._last_input_at||0)===Number(meta.captured_at))return;
  let ep=openEpisode(item.id),prevT=ep?.last_observed_at??null;

  if(ep&&prevT!=null){const obsGap=Math.max(0,(meta.captured_at-prevT)/1000);ep.max_observation_gap_sec=Math.max(Number(ep.max_observation_gap_sec||0),obsGap)}

  // Detect hard rebaseline events before using current GAP.
  if(ep){
    const ph=n(ep.last_score?.home)??0,pa=n(ep.last_score?.away)??0,ch=n(meta.score?.home)??ph,ca=n(meta.score?.away)??pa,dh=ch-ph,da=ca-pa,
          prh=n(ep.last_reds?.home)??0,pra=n(ep.last_reds?.away)??0,crh=n(meta.reds?.home)??prh,cra=n(meta.reds?.away)??pra;
    if(crh>prh||cra>pra){closeEpisode(ep,'RED_CARD_REBASELINE',meta.captured_at,true);ep.last_score=clone(meta.score);ep.last_reds=clone(meta.reds);pushSnap(ep,meta,'CENSORED');ep._last_input_at=meta.captured_at;saveSoon();render();return}
    if(dh>0||da>0){settleGoal(ep,meta,prevT,dh,da);closeEpisode(ep,'GOAL_REBASELINE',meta.captured_at,false);ep.last_score=clone(meta.score);ep.last_reds=clone(meta.reds);pushSnap(ep,meta,'GOAL');ep._last_input_at=meta.captured_at;saveSoon();render();return}
  }

  // Missing/partial/stale data is UNKNOWN, never neutralized or failed.
  if(!meta.gap_valid){
    if(ep){ep.unknown_observations++;ep.current_class='UNKNOWN';if(ep.watch_at&&ep.data_break_open==null)ep.data_break_open=meta.captured_at;ep.missing_reasons=[...new Set([...(ep.missing_reasons||[]),`${meta.data_tier}|DQ=${meta.dq??'NA'}|fresh=${meta.fresh_age_sec??'NA'}`])].slice(-12);ep.last_observed_at=meta.captured_at;ep.last_score=clone(meta.score);ep.last_reds=clone(meta.reds);pushSnap(ep,meta,'UNKNOWN');ep._last_input_at=meta.captured_at}
    saveSoon();render();return;
  }

  if(ep&&ep.data_break_open!=null){ep.continuity_breaks=ep.continuity_breaks||[];ep.continuity_breaks.push({start:ep.data_break_open,end:meta.captured_at});ep.data_break_open=null}

  const abs=Math.abs(meta.gap),dir=meta.direction;
  if(ep&&dir!==ep.direction&&abs>=FE_GPS_CFG.latentGap){closeEpisode(ep,'DIRECTION_REVERSAL',meta.captured_at,true);ep=null}

  if(!ep&&['HOME','AWAY'].includes(dir)&&abs>=FE_GPS_CFG.latentGap){ep=makeEpisode(item,meta);DB.episodes.push(ep)}
  if(!ep){saveSoon();render();return}

  ep.current_gap=meta.gap;ep.gap_sum=Number(ep.gap_sum||0)+abs;ep.gap_n=Number(ep.gap_n||0)+1;ep.avg_abs_gap=Math.round(ep.gap_sum/ep.gap_n*10)/10;
  if(abs>Number(ep.peak_gap||0)){ep.peak_gap=abs;ep.peak_signed_gap=meta.gap}
  ep.last_valid_at=meta.captured_at;

  if(dir===ep.direction&&abs>=FE_GPS_CFG.watchGap){
    ep.below_latent_since=null;ep.watch_snapshot_count++;
    if(ep.watch_streak_count===0)ep.watch_streak_started_at=meta.captured_at;
    ep.watch_streak_count++;
    const streakSec=(meta.captured_at-ep.watch_streak_started_at)/1000;
    ep.max_watch_streak_count=Math.max(ep.max_watch_streak_count,ep.watch_streak_count);ep.max_watch_streak_sec=Math.max(ep.max_watch_streak_sec,streakSec);
    if(!ep.thresholds_seen.includes(70))ep.thresholds_seen.push(70);
    if(!ep.watch_at){ep.watch_at=meta.captured_at;ep.validation=blankValidation(ep.watch_at);ep.evidence_at_watch=meta.evidence_support;ep.goal_radar_at_watch=clone(meta.goal_radar);ep.game_state_at_watch=gameState(meta,ep.direction)}
  }else{
    ep.watch_streak_count=0;ep.watch_streak_started_at=null;
    if(abs<FE_GPS_CFG.latentGap){ep.below_latent_since=ep.below_latent_since||meta.captured_at;if((meta.captured_at-ep.below_latent_since)/1000>=FE_GPS_CFG.decayCloseSeconds){settleDueNoGoal(ep,meta);closeEpisode(ep,'GAP_DECAY_120S_SHADOW',meta.captured_at,true)}}else ep.below_latent_since=null;
  }

  if(ep.status==='OPEN'){
    const conf=confirmationState(ep,meta),cls=conf.cls;ep.current_class=cls;ep.confirmation_mode=conf.mode;ep.last_confirmation_reason=conf.reason;
    if(classRank(cls)>classRank(ep.strongest_class)){ep.strongest_class=cls;ep.strongest_confirmation_mode=conf.mode||ep.strongest_confirmation_mode||null;if(cls==='PRESSURE_STRONG')ep.strong_at=meta.captured_at;if(cls==='TRIGGER_CANDIDATE'){if(!ep.strong_at)ep.strong_at=meta.captured_at;ep.trigger_at=meta.captured_at}}
    settleDueNoGoal(ep,meta);
  }
  ep.last_observed_at=meta.captured_at;ep.last_score=clone(meta.score);ep.last_reds=clone(meta.reds);pushSnap(ep,meta,ep.current_class);ep._last_input_at=meta.captured_at;
  saveSoon();render();
}

function observeAll(){
  try{
    if(typeof handicapWatchState==='undefined'||!Array.isArray(handicapWatchState.pool))return;
    for(const item of handicapWatchState.pool)observeItem(item);
  }catch(_){/* never impact production */}
}

function resolvedStats(h=5){
  const vals=DB.episodes.map(e=>e.validation?.[h]).filter(Boolean),resolved=vals.filter(v=>['HIT','MISS','UNKNOWN','CENSORED'].includes(v.state)),hits=resolved.filter(v=>v.state==='HIT').length,miss=resolved.filter(v=>v.state==='MISS').length,unk=resolved.filter(v=>v.state==='UNKNOWN').length,cens=resolved.filter(v=>v.state==='CENSORED').length;
  return {resolved:resolved.length,hits,miss,unknown:unk,censored:cens,known:hits+miss,rate:(hits+miss)?hits/(hits+miss):null}
}
function summary(){
  const open=DB.episodes.filter(e=>e.status==='OPEN'),s5=resolvedStats(5);
  return {version:FE_GPS_VERSION,total:DB.episodes.length,open:open.length,watch:open.filter(e=>e.current_class==='DOMINANCE_WATCH').length,strong:open.filter(e=>e.current_class==='PRESSURE_STRONG').length,trigger:open.filter(e=>e.current_class==='TRIGGER_CANDIDATE').length,unknown:open.filter(e=>e.current_class==='UNKNOWN').length,validation5:s5}
}

function download(name,mime,text){const b=new Blob([text],{type:mime}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000)}
function exportJson(){download(`football-edge-gap-pressure-shadow-${new Date().toISOString().slice(0,10)}.json`,'application/json;charset=utf-8',JSON.stringify({schema:FE_GPS_VERSION,config:FE_GPS_CFG,exported_at:new Date().toISOString(),summary:summary(),episodes:DB.episodes},null,2))}
function csvCell(v){const s=String(v??'');return /[",\n]/.test(s)?`"${s.replace(/"/g,'""')}"`:s}
function exportCsv(){
  const head=['episode_id','fixture_id','home','away','direction','started_at','watch_at','strong_at','trigger_at','closed_at','close_reason','start_gap','peak_gap','avg_abs_gap','watch_snapshots','max_watch_streak_sec','strongest_class','confirmation_mode','strongest_confirmation_mode','confirmation_reason','evidence_at_watch','goal_ft_at_watch','game_state_at_watch','unknown_observations','v3','v5','v10'];
  const rows=DB.episodes.map(e=>[e.id,e.fixture_id,e.home,e.away,e.direction,iso(e.started_at),iso(e.watch_at),iso(e.strong_at),iso(e.trigger_at),iso(e.closed_at),e.close_reason,e.start_gap,e.peak_signed_gap,e.avg_abs_gap,e.watch_snapshot_count,e.max_watch_streak_sec,e.strongest_class,e.confirmation_mode,e.strongest_confirmation_mode,e.last_confirmation_reason,e.evidence_at_watch,e.goal_radar_at_watch?.ft?.prob,e.game_state_at_watch?.key,e.unknown_observations,e.validation?.[3]?.state,e.validation?.[5]?.state,e.validation?.[10]?.state]);
  download(`football-edge-gap-pressure-shadow-${new Date().toISOString().slice(0,10)}.csv`,'text/csv;charset=utf-8','\ufeff'+[head,...rows].map(r=>r.map(csvCell).join(',')).join('\n'))
}
function resetShadow(){if(!confirm('Chỉ xóa GAP PRESSURE SHADOW research data? HC engine / QSIG / Push production không bị ảnh hưởng.'))return;DB=emptyState();try{localStorage.removeItem(FE_GPS_KEY)}catch(_){}render()}

function injectUi(){
  if(document.getElementById('feGpsShadowPanel'))return;
  const card=document.getElementById('handicapWatchCard'),shell=card?.querySelector('.watch-shell');if(!shell)return;
  const style=document.createElement('style');style.id='feGpsShadowStyle';style.textContent=`
  .fe-gps{margin:10px 0;padding:10px;border:1px solid rgba(67,139,215,.22);border-radius:13px;background:rgba(67,139,215,.045)}
  .fe-gps-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.fe-gps-head b{font-size:10px}.fe-gps-head span{display:block;margin-top:3px;font-size:7.5px;color:var(--muted)}
  .fe-gps-badge{font-size:7px!important;padding:5px 7px;border:1px solid rgba(67,139,215,.25);border-radius:999px;color:#247bd2;white-space:nowrap}.fe-gps-grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:5px;margin-top:8px}
  .fe-gps-k{padding:7px;border:1px solid var(--line);border-radius:9px;background:var(--card)}.fe-gps-k span{display:block;font-size:6px;color:var(--muted)}.fe-gps-k b{display:block;margin-top:2px;font-size:11px}.fe-gps-actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.fe-gps-actions button{min-height:30px;font-size:7.5px}
  .fe-gps-list{margin-top:8px;display:grid;gap:5px}.fe-gps-row{padding:7px;border:1px solid var(--line);border-radius:9px;font-size:7.5px;line-height:1.45}.fe-gps-row b{font-size:8px}.fe-gps-row small{color:var(--muted)}
  .fe-gps-row.trigger{border-color:rgba(8,143,99,.35);background:rgba(8,143,99,.055)}.fe-gps-row.strong{border-color:rgba(53,191,139,.28)}.fe-gps-row.unknown{border-color:rgba(217,154,43,.28);background:rgba(217,154,43,.045)}
  @media(max-width:520px){.fe-gps-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
  `;document.head.appendChild(style);
  const el=document.createElement('section');el.className='fe-gps';el.id='feGpsShadowPanel';el.innerHTML=`<div class="fe-gps-head"><div><b>🧪 GAP → GOAL PRESSURE • SHADOW V1.1</b><span>WATCH GAP 70 báo sớm ngay • confirmation adaptive 45–60s+ • không chặn Push production.</span></div><b class="fe-gps-badge">NO AUTO-TUNE</b></div><div class="fe-gps-grid"><div class="fe-gps-k"><span>EPISODES</span><b id="feGpsTotal">0</b></div><div class="fe-gps-k"><span>OPEN</span><b id="feGpsOpen">0</b></div><div class="fe-gps-k"><span>WATCH</span><b id="feGpsWatch">0</b></div><div class="fe-gps-k"><span>STRONG</span><b id="feGpsStrong">0</b></div><div class="fe-gps-k"><span>TRIGGER CAND.</span><b id="feGpsTrigger">0</b></div><div class="fe-gps-k"><span>5M KNOWN HIT</span><b id="feGps5m">—</b></div></div><div class="fe-gps-actions"><button id="feGpsExportJson" type="button">XUẤT JSON</button><button id="feGpsExportCsv" type="button">XUẤT CSV</button><button id="feGpsReset" type="button">XÓA SHADOW</button></div><div class="fe-gps-list" id="feGpsList"></div>`;
  const status=document.getElementById('handicapWatchStatus');status?.after(el);if(!status)shell.prepend(el);
  document.getElementById('feGpsExportJson')?.addEventListener('click',exportJson);document.getElementById('feGpsExportCsv')?.addEventListener('click',exportCsv);document.getElementById('feGpsReset')?.addEventListener('click',resetShadow);
}
function render(){
  injectUi();const s=summary(),set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=String(v)};set('feGpsTotal',s.total);set('feGpsOpen',s.open);set('feGpsWatch',s.watch);set('feGpsStrong',s.strong);set('feGpsTrigger',s.trigger);set('feGps5m',s.validation5.known?`${s.validation5.hits}/${s.validation5.known}`:'—');
  const list=document.getElementById('feGpsList');if(!list)return;const rows=DB.episodes.slice(-8).reverse();
  list.innerHTML=rows.length?rows.map(e=>{const cls=e.current_class==='TRIGGER_CANDIDATE'?'trigger':e.current_class==='PRESSURE_STRONG'?'strong':e.current_class==='UNKNOWN'?'unknown':'',v=e.validation||{};return `<div class="fe-gps-row ${cls}"><b>#${esc(e.fixture_id)} • ${esc(e.home)} – ${esc(e.away)} • ${esc(e.direction)} • ${esc(e.current_class)}</b><br><small>GAP start ${esc(signed(e.start_gap))} • peak ${esc(signed(e.peak_signed_gap))} • avg |${esc(e.avg_abs_gap)}| • sustained max ${esc(fmtSec(e.max_watch_streak_sec))} • Goal@WATCH ${esc(e.goal_radar_at_watch?.ft?.prob??e.goal_radar_at_watch?.h1?.prob??'—')} • Confirm ${esc(e.confirmation_mode||'WATCH')} • Evidence ${esc(e.evidence_at_watch||'—')} • 3/5/10 ${esc(v[3]?.state||'—')}/${esc(v[5]?.state||'—')}/${esc(v[10]?.state||'—')}</small></div>`}).join(''):`<div class="fe-gps-row"><small>Chưa có dominance episode. Khi HC có |LIVE GAP| ≥60, Shadow bắt đầu ghi một episode; ≥70 mới vào WATCH.</small></div>`;
}

// Expose read-only helpers for audit/debug. No production hook is overridden.
window.FE_GAP_PRESSURE_SHADOW_V1={version:FE_GPS_VERSION,config:FE_GPS_CFG,summary:()=>clone(summary()),episodes:()=>clone(DB.episodes),observe:observeAll,exportJson,exportCsv,__debugClassify:(ep,meta)=>clone(confirmationState(ep,meta))};
function boot(){injectUi();render();observeAll();setInterval(observeAll,2000);setInterval(render,5000)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();

  /* FE_GAP_PRESSURE_SHADOW_V11_INLINE_END */
  /* ===== V1.22.2 MARKET + DATA BEHAVIOR SHADOW =====
     Entry Intelligence stage 3. Cross-checks market direction/movement with football state,
     DQ/freshness and event rebaseline. No ranking/engine/entry-policy mutation. */

  /* ===== V1.22.1 FAIR PRICE & EDGE SHADOW =====
     Entry Intelligence stage 2. Uses Goal Radar only when the O/U target exactly equals
     current goals + 0.5. Price outside 1.65–2.20 is PASS in SHADOW. No ranking mutation. */

  /* ===== V1.22.0 MARKET NORMALIZATION SHADOW =====
     Entry Intelligence stage 1. Normalizes current TOP market odds into no-vig market probabilities.
     Observation only: no fair-price verdict, no entry policy, no ranking/core mutation. */

  /* ===== V1.21.0.1 UI PATCH — HIDE H1/FT DETAIL CARDS BY DEFAULT =====
     UI only. H1 / FT engines keep running normally through Unified Live Scan. */
  const FE_RUNG_DETAIL_VIS_KEY='fe_rung_detail_visible_v12101';
  function feRungDetailsVisible(){try{return localStorage.getItem(FE_RUNG_DETAIL_VIS_KEY)==='1'}catch(_){return false}}
  function feApplyRungDetailsVisibility(show=feRungDetailsVisible(),persist=false){
    document.body.classList.toggle('fe-rung-details-hidden',!show);
    const btn=$('toggleRungDetailsBtn');
    if(btn)btn.textContent=show?'🙈 ẨN CHI TIẾT H1/FT':'👁 HIỆN CHI TIẾT H1/FT';
    if(persist){try{localStorage.setItem(FE_RUNG_DETAIL_VIS_KEY,show?'1':'0')}catch(_){}}
    return show;
  }
  function feRevealRungTarget(target){
    if(!target)return;
    if(target.id==='h1WatchCard'||target.id==='liveWatchCard')feApplyRungDetailsVisibility(true,true);
    requestAnimationFrame(()=>target.scrollIntoView({behavior:'smooth',block:'start'}));
  }
  feApplyRungDetailsVisibility(false,false);
  $('toggleRungDetailsBtn')?.addEventListener('click',()=>{const show=document.body.classList.contains('fe-rung-details-hidden');feApplyRungDetailsVisibility(show,true)});
  $('masterOpportunityBoard')?.addEventListener('click',e=>{const f=e.target.closest('[data-smart-follow]');if(f){const on=feSmartToggleManual(f.dataset.smartFollow);showToast('ok',on?'Manual follow enabled':'Manual follow removed',on?'Fixture sẽ được giữ Background dù không còn TOP.':'Fixture sẽ chỉ được Background tự động nếu đang thuộc TOP 1–5.');return}const b=e.target.closest('[data-master-target]');if(!b)return;const target=$(b.dataset.masterTarget);feRevealRungTarget(target)});
  $('startUnifiedLiveBtn')?.addEventListener('click',()=>startUnifiedLiveScan(false));$('refreshUnifiedLiveBtn')?.addEventListener('click',refreshUnifiedLiveScan);$('stopUnifiedLiveBtn')?.addEventListener('click',stopUnifiedLiveScan);const __feRenderH1Watch=renderH1Watch;renderH1Watch=function(){const r=__feRenderH1Watch.apply(this,arguments);try{renderUnifiedLiveBoard()}catch(_){}return r};const __feRenderLiveWatch=renderLiveWatch;renderLiveWatch=function(){const r=__feRenderLiveWatch.apply(this,arguments);try{renderUnifiedLiveBoard()}catch(_){}return r};const __feRenderHandicapWatch=renderHandicapWatch;renderHandicapWatch=function(){const r=__feRenderHandicapWatch.apply(this,arguments);try{renderUnifiedLiveBoard()}catch(_){}return r};renderUnifiedLiveBoard();

  /* ===== V1.19.5 GOAL RADAR CALIBRATION V2 =====
     QSIG-first resolved-wave calibration with minute/score neighborhood,
     Bayesian shrinkage and sample reliability labels. Presentation/calibration only. */

  /* ===== V1.19.4.1 TOP BACKGROUND ONLY =====
     Background selection: current TOP 1–5 + manual FOLLOW only.
     Engine scoring and V1.19.3 ranking remain unchanged. */

  /* ===== V1.19.3 TOP OPPORTUNITY RANKING =====
     Presentation-only lexicographic ranking on Master Opportunity cards.
     STATE → DQ → FRESHNESS → EVIDENCE → MARKET → CALIBRATION → CONFLUENCE.
     No weighted score, no H1/FT/HC score aggregation, no engine mutation. */

  /* ===== V1.19.2 CONFLUENCE / CONFLICT LAYER =====
     Presentation-only interaction labels on Master Opportunity cards.
     CONFLUENCE requires Goal READY/STRONG + HC STRONG with market agreement.
     CONFLICT only surfaces explicit existing divergence (primarily HC vs market). */

  /* ===== V1.21.0 ADAPTIVE LIVE STATE V2 =====
     Production decision surface may use a certified restrictive shadow policy as a guard.
     H1 / FT / HC engine states remain unchanged; fallback is always stable core. */

  /* ===== V1.18.9 GOAL RADAR OVERLAY — UI/CALIBRATION ONLY =====
     H1/FT legacy cards preserved; no scoring/threshold changes.
     ===== */

  /* ===== V1.18.8 STALE LIVE SOURCE GUARD + PARALLEL WORKSPACES =====
     H1 / FT / HANDICAP scan directly from ULTRA live heartbeat into independent
     candidate sources. Starting / refreshing one workspace never clears or stops
     the other two. Terminal fixtures stop only their own workspace once all items
     are ended; histories and validation remain intact. Background registry removes
     terminal fixture IDs to prevent unnecessary sync/storage writes. */

  /* ===== V1.18.6 FINAL TICKET / ENTRY LOCK / SETTLEMENT V2 ===== */
  /* Legacy Bet Tracker storage keys are intentionally preserved for non-regression. */
  /* ===== V1.7 BET TRACKER / PERFORMANCE ===== */
  const BET_STORAGE_KEY='fe_bets_v16';
  const BET_SETTINGS_KEY='fe_bet_settings_v16';
  const betState={bets:[],draftFixture:null,refreshing:false,tab:'active',timer:null,marketCandidates:[],marketLoading:false,editingId:null,draftSource:'MANUAL',modelContext:null};
  const VALIDATION_STORAGE_KEY='fe_validation_v116';
  const VALIDATION_MAX=8000;
  const VALIDATION_LOCAL_RECENT=250;
  const VALIDATION_ARCHIVE_DB='FOOTBALL_EDGE_VALIDATION_ARCHIVE_V1';
  const VALIDATION_ARCHIVE_STORE='rows';
  const validationState={rows:[],archiveHydrated:false,archiveBusy:false};
  const EVIDENCE_BASELINES={FT:{label:'FT Score',qualified:73,high:80,min:73,max:85},H1:{label:'H1 Score',qualified:72,high:79,min:72,max:84},HC:{label:'Handicap LIVE GAP',qualified:22,high:30,min:22,max:40}};

  function loadBets(){try{const x=JSON.parse(localStorage.getItem(BET_STORAGE_KEY)||'[]');betState.bets=Array.isArray(x)?x:[]}catch{betState.bets=[]}}
  function saveBets(){try{localStorage.setItem(BET_STORAGE_KEY,JSON.stringify(betState.bets))}catch(e){showToast('err','Không lưu được nhật ký kèo',e.message)}}
  function loadBetSettings(){try{return JSON.parse(localStorage.getItem(BET_SETTINGS_KEY)||'{}')}catch{return {}}}
  function saveBetSettings(x){try{localStorage.setItem(BET_SETTINGS_KEY,JSON.stringify(x))}catch{}}
  function betById(id){return betState.bets.find(b=>b.id===id)}
  function vnd(n){const x=Number(n)||0;return new Intl.NumberFormat('vi-VN',{maximumFractionDigits:0}).format(x)+'đ'}
  function pct(n){return `${Number(n||0).toFixed(1)}%`}
  function plClass(n){return Number(n)>0?'pl-pos':Number(n)<0?'pl-neg':'pl-zero'}
  function betMarketName(t){return ({AH_FT:'Asian Handicap FT',OU_FT:'Tổng bàn FT',ML_FT:'Match Winner FT',AH_H1:'Asian Handicap H1',OU_H1:'Tổng bàn H1',AH_H2:'Asian Handicap H2',OU_H2:'Tổng bàn H2',TEAM_TOTAL:'Team Total FT',CORNERS:'Total Corners FT',OTHER:'Khác'})[t]||t}
  function betSelectionName(s,b){
    const home=b?.home||'Home',away=b?.away||'Away';
    return ({HOME:home,AWAY:away,DRAW:'Hòa',OVER:'TÀI',UNDER:'XỈU',HOME_OVER:`${home} TÀI`,HOME_UNDER:`${home} XỈU`,AWAY_OVER:`${away} TÀI`,AWAY_UNDER:`${away} XỈU`,OTHER:'Khác'})[s]||s||'-'
  }
  function marketNeedsLine(t){return !['ML_FT','OTHER'].includes(t)}
  /* ===== V1.18.6 FINAL TICKET / ENTRY LOCK V2 =====
     ADDITIVE ONLY: does not alter H1 / FT / Handicap scoring engines.
     Existing fe_cfg_v11 / Background Worker configuration is untouched. */
  function betBasisName(v){return ({FULL_MATCH:'FULL MATCH',FROM_ENTRY:'FROM ENTRY',H1_SEGMENT:'H1 SEGMENT',H2_SEGMENT:'H2 SEGMENT',MANUAL:'MANUAL'})[v]||v||'LEGACY'}
  function defaultBasisForMarket(t){if(['AH_H1','OU_H1'].includes(t))return 'H1_SEGMENT';if(['AH_H2','OU_H2'].includes(t))return 'H2_SEGMENT';if(t==='OTHER')return 'MANUAL';return 'FULL_MATCH'}
  function ticketBasis(b){return b?.settlement_basis||defaultBasisForMarket(b?.market_type)}
  function smaTicketDraft(){
    const r=state.singleAnalyzer?.last,d=r?.decision,top=d?.top;if(!r||d?.verdict!=='MODEL_CHOICE'||!top)return null;
    let market_type=null,engine_tag='AUTO',basis='FULL_MATCH';
    if(top.id==='PRE_AH'){market_type='AH_FT';engine_tag='PRE'}
    else if(top.id==='PRE_TOTAL'){market_type='OU_FT';engine_tag='PRE'}
    else if(top.id==='PRE_ML'){market_type='ML_FT';engine_tag='PRE'}
    else if(top.id==='LIVE_H1_TOTAL'){market_type='OU_H1';engine_tag='H1';basis='H1_SEGMENT'}
    else if(top.id==='LIVE_FT_TOTAL'){market_type='OU_FT';engine_tag='FT';basis='FULL_MATCH'}
    else if(top.id==='LIVE_AH'){market_type='AH_FT';engine_tag='HC';basis='FROM_ENTRY'}
    if(!market_type)return null;
    return {market_type,selection:top.selection,line:top.line,price:top.odd,odds_format:Number(top.odd)>1?'DEC':'HK',engine_tag,basis,
      source:'SMA_FINAL_MODEL',model_context:{captured_at:r.captured_at||Date.now(),mode:r.bundle?.meta?.mode||null,candidate_id:top.id,source:top.source||null,display:top.display||null,state:top.state||null,model_rank:top.score??null,dq:r.bundle?.coverage?.score??null}};
  }
  function setBetDraftSource(src='MANUAL',ctx=null){betState.draftSource=src;betState.modelContext=ctx||null;if($('betDraftSource'))$('betDraftSource').value=src}
  function syncBetSettlementBasis(force=false){
    const market=$('betMarketType')?.value,sel=$('betSettlementBasis');if(!sel)return;
    const fixed=['AH_H1','OU_H1'].includes(market)?'H1_SEGMENT':['AH_H2','OU_H2'].includes(market)?'H2_SEGMENT':market==='OTHER'?'MANUAL':null;
    if(fixed){sel.value=fixed;sel.disabled=true}else{sel.disabled=false;if(force||!sel.value||['H1_SEGMENT','H2_SEGMENT','MANUAL'].includes(sel.value))sel.value='FULL_MATCH'}
    const h=$('betSettlementBasisHint');if(h){
      if(fixed==='H1_SEGMENT')h.textContent='Market H1 được settle theo score hiệp 1.';
      else if(fixed==='H2_SEGMENT')h.textContent='Market H2 được settle theo riêng hiệp 2.';
      else if(fixed==='MANUAL')h.textContent='Market OTHER: app không tự settle, cần xác nhận thủ công.';
      else h.textContent=sel.value==='FROM_ENTRY'?'FROM ENTRY: app trừ tỷ số lúc vào khỏi tỷ số cuối để tính phần diễn biến sau Entry Lock.':'FULL MATCH: app dùng tỷ số cuối trận / tổng bàn toàn trận để settle.';
    }
    updateBetLockPreview();
  }
  function updateBetLockPreview(){
    const el=$('betEntryLockPreview');if(!el)return;const f=betState.draftFixture,market=$('betMarketType')?.value||'',line=$('betLine')?.value,price=$('betPrice')?.value,basis=$('betSettlementBasis')?.value||defaultBasisForMarket(market),src=betState.draftSource||'MANUAL';
    const min=f?.minute!=null?`${f.minute}'`:'PRE',score=f?.score?.home!=null?`${f.score.home}-${f.score.away}`:'-';
    const complete=!!f?.fixture_id&&(!marketNeedsLine(market)||line!=='')&&price!=='';
    el.classList.toggle('good',complete);el.classList.toggle('warn',!complete);
    el.innerHTML=`<b>ENTRY LOCK V2 • ${esc(src)}</b><br>Fixture #${esc(f?.fixture_id??'-')} • ${esc(min)} • score ${esc(score)} • ${esc(betBasisName(basis))}<br>${market?esc(betMarketName(market)):''}${line!==''&&line!=null?` • line ${esc(line)}`:''}${price!==''&&price!=null?` • giá ${esc(price)} ${esc($('betOddsFormat')?.value||'')}`:''}`;
  }
  function resolvedEngineForTicket(market,engineTag,source,modelCtx){
    const explicit=String(engineTag||'').toUpperCase();if(['PRE','FT','H1','HC'].includes(explicit))return explicit;
    const cid=String(modelCtx?.candidate_id||'').toUpperCase();if(cid.startsWith('PRE_'))return 'PRE';if(cid==='LIVE_AH')return 'HC';if(cid==='LIVE_H1_TOTAL')return 'H1';if(cid==='LIVE_FT_TOTAL')return 'FT';
    if(['AH_H1','OU_H1'].includes(market))return 'H1';
    if(market==='AH_FT'){if(String(source||'').includes('PRE')||state.mode==='PRE')return 'PRE';return 'HC'}
    if(state.mode==='PRE'||String(source||'').includes('PRE'))return 'PRE';return 'FT';
  }
  function betDuplicateCandidate(fid,market,selection,line){
    const now=Date.now();return betState.bets.find(b=>Number(b.fixture_id)===Number(fid)&&b.market_type===market&&b.selection===selection&&String(b.line??'')===String(line??'')&&now-new Date(b.created_at||0).getTime()<15*60000)
  }
  function betEntryLockFrom(f,fields,existing=null){
    const now=new Date().toISOString();
    if(existing)return {...existing,market_type:fields.market_type,selection:fields.selection,line:fields.line,price:fields.price,odds_format:fields.odds_format,stake:fields.stake,settlement_basis:fields.settlement_basis,last_edited_at:now};
    return {version:'ENTRY_LOCK_V2',locked_at:now,fixture_id:f.fixture_id,status:f.status,minute:f.minute,score:{home:f.score?.home??null,away:f.score?.away??null},market_type:fields.market_type,selection:fields.selection,line:fields.line,price:fields.price,odds_format:fields.odds_format,stake:fields.stake,settlement_basis:fields.settlement_basis};
  }
  function updateBetSelectionOptions(){
    const t=$('betMarketType')?.value,sel=$('betSelection');if(!sel)return;
    let opts=[];
    if(['AH_FT','AH_H1','AH_H2'].includes(t))opts=[['HOME','Đội nhà'],['AWAY','Đội khách']];
    else if(['OU_FT','OU_H1','OU_H2','CORNERS'].includes(t))opts=[['OVER','TÀI'],['UNDER','XỈU']];
    else if(t==='ML_FT')opts=[['HOME','Đội nhà'],['DRAW','Hòa'],['AWAY','Đội khách']];
    else if(t==='TEAM_TOTAL')opts=[['HOME_OVER','Nhà TÀI'],['HOME_UNDER','Nhà XỈU'],['AWAY_OVER','Khách TÀI'],['AWAY_UNDER','Khách XỈU']];
    else opts=[['OTHER','Khác / thủ công']];
    sel.innerHTML=opts.map(([v,l])=>`<option value="${v}">${l}</option>`).join('');
    const line=$('betLine');if(line){line.disabled=!marketNeedsLine(t);if(line.disabled)line.value=''}
    syncBetSettlementBasis();updateBetLockPreview();
  }
  function extractTagFromPacket(){const m=String(state.lastPacket||'').match(/^TAG:\s*(.+)$/m);return m?m[1].trim():''}
  function compactTrackerFixture(f){if(!f)return null;return {fixture_id:f.fixture?.id??null,league:f.league?.name||'',country:f.league?.country||'',home:f.teams?.home?.name||'Home',away:f.teams?.away?.name||'Away',home_id:f.teams?.home?.id??null,away_id:f.teams?.away?.id??null,kickoff_vn:f.fixture?.timestamp?fmtDateTime(f.fixture.timestamp):'',status:f.fixture?.status?.short||'',minute:f.fixture?.status?.elapsed??null,score:{home:f.goals?.home??null,away:f.goals?.away??null},halftime:{home:f.score?.halftime?.home??null,away:f.score?.halftime?.away??null},fulltime:{home:f.score?.fulltime?.home??null,away:f.score?.fulltime?.away??null}}}
  function trackerFixtureText(f){if(!f)return '<b>Chưa chọn fixture.</b>';return `<b>${esc(f.home)} vs ${esc(f.away)}</b>\n${esc(f.league||'')} • Fixture #${esc(f.fixture_id)} • ${esc(f.status||'')} ${f.minute!=null?esc(f.minute)+"'":''} • ${esc(f.score?.home??'-')}-${esc(f.score?.away??'-')}`}


  function betTrackerTypeFromCategory(category){
    return ({
      asian_handicap:'AH_FT',
      h1_handicap:'AH_H1',
      h2_handicap:'AH_H2',
      over_under:'OU_FT',
      h1_total:'OU_H1',
      h2_total:'OU_H2',
      match_winner:'ML_FT',
      team_total:'TEAM_TOTAL',
      corners:'CORNERS'
    })[category]||null;
  }

  function betTrackerSelectionFromValue(v,category,fixture){
    const raw=normalizedKey(v?.value||'');
    const side=v?.selection_outcome||v?.selection_side||null;
    if(['asian_handicap','h1_handicap','h2_handicap','match_winner'].includes(category)){
      if(side==='home')return 'HOME';
      if(side==='away')return 'AWAY';
      if(side==='draw')return 'DRAW';
    }
    if(['over_under','h1_total','h2_total','corners'].includes(category)){
      if(/\bover\b|\btai\b/.test(raw))return 'OVER';
      if(/\bunder\b|\bxiu\b/.test(raw))return 'UNDER';
    }
    if(category==='team_total'){
      const hn=normalizedKey(fixture?.home),an=normalizedKey(fixture?.away);
      const over=/\bover\b|\btai\b/.test(raw),under=/\bunder\b|\bxiu\b/.test(raw);
      const home=(hn&&(raw.includes(hn)))||/\bhome\b|\bteam 1\b/.test(raw);
      const away=(an&&(raw.includes(an)))||/\baway\b|\bteam 2\b/.test(raw);
      if(home&&over)return 'HOME_OVER';
      if(home&&under)return 'HOME_UNDER';
      if(away&&over)return 'AWAY_OVER';
      if(away&&under)return 'AWAY_UNDER';
    }
    return null;
  }

  function betTrackerLineFromValue(v,category){
    if(category==='match_winner')return null;
    const h=numericHandicap(v?.handicap);
    if(h!==null)return h;
    const raw=String(v?.value||'');
    const nums=[...raw.matchAll(/([+-]?\d+(?:[.,]\d+)?)/g)].map(m=>Number(m[1].replace(',','.'))).filter(Number.isFinite);
    return nums.length?nums[nums.length-1]:null;
  }

  function betTrackerCandidateLabel(c,fixture){
    const src=c.source==='live'?'LIVE':'PRE';
    const sel=betSelectionName(c.selection,{home:fixture?.home,away:fixture?.away});
    const line=c.line===null||c.line===undefined||c.market_type==='ML_FT'?'':` ${Number(c.line)>0?'+':''}${c.line}`;
    const price=Number.isFinite(Number(c.price))?` @${Number(c.price).toFixed(2)}`:'';
    return `${src} • ${betMarketName(c.market_type)} • ${sel}${line}${price}`;
  }

  function betTrackerCandidatesFromMarkets(markets,source,fixture){
    const out=[];
    for(const m of (markets||[])){
      if(m?.integrity?.valid===false)continue;
      if(m?.feed_status?.blocked||m?.feed_status?.stopped||m?.feed_status?.finished)continue;

      const market_type=betTrackerTypeFromCategory(m.category);
      if(!market_type)continue;

      for(const v of (m.values||[])){
        if(v?.suspended)continue;
        const selection=betTrackerSelectionFromValue(v,m.category,fixture);
        if(!selection)continue;

        const line=betTrackerLineFromValue(v,m.category);
        if(marketNeedsLine(market_type)&&line===null)continue;

        const price=Number(v?.odd);
        if(!Number.isFinite(price)||price<=1)continue;

        out.push({
          id:`${source}|${m.category}|${selection}|${line??''}|${price}|${m.bet_id??''}`,
          source,
          category:m.category,
          market_type,
          selection,
          line,
          price,
          bet_id:m.bet_id??null,
          market_name:m.bet||m.market||m.category,
          main:v?.main===true,
          update:m.update??null
        });
      }
    }

    // main=true first, then Football Edge market priority, then stable display order.
    const marketOrder={AH_FT:0,OU_FT:1,ML_FT:2,AH_H1:3,OU_H1:4,AH_H2:5,OU_H2:6,TEAM_TOTAL:7,CORNERS:8};
    return out.sort((a,b)=>
      Number(b.main)-Number(a.main) ||
      (marketOrder[a.market_type]??99)-(marketOrder[b.market_type]??99) ||
      String(a.selection).localeCompare(String(b.selection))
    );
  }

  function uniqueBetTrackerCandidates(rows){
    const seen=new Set(),out=[];
    for(const c of rows){
      const k=[c.source,c.market_type,c.selection,c.line,c.price].join('|');
      if(seen.has(k))continue;
      seen.add(k);out.push(c);
    }
    return out.slice(0,60);
  }

  function renderBetApiCandidates(message=''){
    const sel=$('betApiPick'),hint=$('betApiPickHint');
    if(!sel)return;

    const f=betState.draftFixture;
    const rows=betState.marketCandidates||[];
    const options=['<option value="">— NHẬP THỦ CÔNG / KHÔNG CHỌN API —</option>'];
    rows.forEach((c,i)=>{
      options.push(`<option value="${i}">${esc(betTrackerCandidateLabel(c,f))}${c.main?' • MAIN':''}</option>`);
    });
    sel.innerHTML=options.join('');

    if(hint){
      hint.textContent=message || (
        rows.length
          ? `Có ${rows.length} lựa chọn hợp lệ. LIVE được ưu tiên trước PRE. Chọn một dòng để tự điền; giá API chỉ là tham chiếu.`
          : 'API chưa có line hợp lệ cho trận này. Anh vẫn có thể nhập Market / Line / Giá thủ công.'
      );
    }
  }

  function applyBetApiCandidate(index){
    const c=betState.marketCandidates?.[Number(index)];
    if(!c)return;

    const market=$('betMarketType');
    if(market){
      market.value=c.market_type;
      updateBetSelectionOptions();
    }
    if($('betSelection'))$('betSelection').value=c.selection;
    if($('betLine')){
      $('betLine').value=c.line===null||c.line===undefined?'':String(c.line);
    }
    if($('betPrice'))$('betPrice').value=Number(c.price).toFixed(2);
    if($('betOddsFormat'))$('betOddsFormat').value='DEC';
    if(betState.draftSource==='MANUAL')setBetDraftSource(`API_${String(c.source||'market').toUpperCase()}`,null);
    if($('betSettlementBasis')&&c.source==='live'&&c.market_type==='AH_FT')$('betSettlementBasis').value='FROM_ENTRY';
    else if($('betSettlementBasis')&&c.source==='pre')$('betSettlementBasis').value=defaultBasisForMarket(c.market_type);
    syncBetSettlementBasis(false);updateBetLockPreview();

    const hint=$('betApiPickHint');
    if(hint){
      hint.textContent=`Đã lấy ${c.source.toUpperCase()} • ${c.market_name}. Hãy sửa GIÁ theo screenshot nhà cái trước khi XÁC NHẬN.`;
    }
  }

  function marketBundleMatchesFixture(bundle,fid){
    return Number(bundle?.meta?.fixture_id)===Number(fid);
  }

  async function fetchTrackerMarketsForFixture(fid,fixture){
    const currentRaw=[state.selected,...(state.fixtures||[])].find(x=>Number(x?.fixture?.id)===Number(fid));
    const short=String(currentRaw?.fixture?.status?.short||fixture?.status||'').toUpperCase();
    const liveNow=['1H','HT','2H','ET','BT','P','LIVE','INT'].includes(short);

    const [preBetRef,liveBetRef,preRows,liveRows]=await Promise.all([
      getBetReference('prematch').catch(()=>({byId:{},count:0,source:'prematch'})),
      liveNow?getBetReference('live').catch(()=>({byId:{},count:0,source:'live'})):Promise.resolve({byId:{},count:0,source:'live'}),
      football('/odds',{fixture:fid},true).catch(()=>[]),
      liveNow?football('/odds/live',{fixture:fid},true).catch(()=>[]):Promise.resolve([])
    ]);

    const ctx={
      homeName:fixture?.home||currentRaw?.teams?.home?.name||'',
      awayName:fixture?.away||currentRaw?.teams?.away?.name||'',
      betRefs:{prematch:preBetRef,live:liveBetRef}
    };

    return {
      prematch:normalizePrematchMarkets(preRows,ctx),
      live:normalizeLiveMarkets(liveRows,ctx)
    };
  }

  async function loadBetApiCandidates(force=false){
    const fid=Number($('betFixtureId')?.value||betState.draftFixture?.fixture_id);
    if(!fid){
      betState.marketCandidates=[];
      renderBetApiCandidates('Chưa có Fixture ID để lấy market.');
      return;
    }
    if(betState.marketLoading)return;

    betState.marketLoading=true;
    const btn=$('refreshBetMarketsBtn');
    if(btn){btn.disabled=true;btn.textContent='ĐANG LẤY...'}
    renderBetApiCandidates('Đang lấy main line hợp lệ từ API...');

    try{
      let fixture=betState.draftFixture;
      if(!fixture||Number(fixture.fixture_id)!==fid){
        fixture=await resolveBetFixture(fid);
        betState.draftFixture=fixture;
        $('betFixturePreview').innerHTML=trackerFixtureText(fixture);
      }

      let pre=[],live=[];
      if(!force && marketBundleMatchesFixture(state.lastBundle,fid)){
        pre=state.lastBundle?.normalized?.market?.prematch||[];
        live=state.lastBundle?.normalized?.market?.live||[];
      }

      if(force || (!pre.length&&!live.length)){
        const fresh=await fetchTrackerMarketsForFixture(fid,fixture);
        pre=fresh.prematch||[];
        live=fresh.live||[];
      }

      const liveC=betTrackerCandidatesFromMarkets(live,'live',fixture);
      const preC=betTrackerCandidatesFromMarkets(pre,'prematch',fixture);
      betState.marketCandidates=uniqueBetTrackerCandidates([...liveC,...preC]);

      renderBetApiCandidates();
      if(betState.marketCandidates.length){
        // On iPhone, do not silently place a bet; only preselect first row visually.
        // User still taps the row to confirm which market to record.
        const pick=$('betApiPick');
        if(pick)pick.value='';
      }
    }catch(e){
      betState.marketCandidates=[];
      renderBetApiCandidates('Không lấy được danh sách kèo API: '+e.message+' — vẫn có thể nhập thủ công.');
    }finally{
      betState.marketLoading=false;
      if(btn){btn.disabled=false;btn.textContent='↻ LẤY KÈO MỚI'}
    }
  }

  async function resolveBetFixture(id){
    const fid=Number(id);if(!fid)throw new Error('Fixture ID không hợp lệ.');
    const local=[state.selected,...(state.fixtures||[])].find(f=>Number(f?.fixture?.id)===fid);
    const rows=await football('/fixtures',{id:fid,timezone:TZ},true);
    return compactTrackerFixture((rows&&rows[0])||local);
  }
  function openBetForm(opts={}){
    const form=$('betEntryForm');if(!form)return;
    const editId=typeof opts==='string'?opts:opts?.editId,fromFinal=!!opts?.fromFinal;
    const existing=editId?betById(editId):null;
    betState.editingId=existing?.id||null;
    form.classList.remove('hidden');

    let f=null,draft=null;
    if(existing){
      f=existing.latest||{fixture_id:existing.fixture_id,league:existing.league,country:existing.country,home:existing.home,away:existing.away,home_id:existing.home_id,away_id:existing.away_id,kickoff_vn:existing.kickoff_vn,status:existing.entry_lock?.status||'',minute:existing.entry_minute,score:existing.entry_score,halftime:null,fulltime:existing.settlement?.final_score||null};
      setBetDraftSource(existing.draft_source||'EDIT_EXISTING',existing.model_context||null);
    }else{
      f=state.selected?compactTrackerFixture(state.selected):betState.draftFixture;
      draft=fromFinal?smaTicketDraft():null;
      setBetDraftSource(draft?.source||'MANUAL',draft?.model_context||null);
      if(fromFinal&&!draft)showToast('busy','Chưa có MODEL CHOICE để ghi nhận','Analyzer đang PASS/WATCH hoặc chưa phân tích. Form vẫn mở để nhập thủ công.');
    }
    betState.draftFixture=f||null;
    $('betFixtureId').value=f?.fixture_id||existing?.fixture_id||'';
    $('betFixtureId').disabled=!!existing;
    $('betFixturePreview').innerHTML=trackerFixtureText(f);
    $('betDeepTag').value=existing?.deep_tag??extractTagFromPacket();
    $('betEngineTag').value=existing?.engine_tag||draft?.engine_tag||'AUTO';
    $('betConfidence').value=existing?.confidence??'';
    $('betNote').value=existing?.note||'';

    $('betMarketType').value=existing?.market_type||draft?.market_type||'AH_FT';
    updateBetSelectionOptions();
    $('betSelection').value=existing?.selection||draft?.selection||$('betSelection').value;
    $('betLine').value=existing?.line??(draft?.line??'');
    $('betPrice').value=existing?.price??(Number.isFinite(Number(draft?.price))?Number(draft.price).toFixed(2):'');
    $('betOddsFormat').value=existing?.odds_format||draft?.odds_format||'HK';
    $('betStake').value=existing?.stake??'';
    $('betSettlementBasis').disabled=false;
    $('betSettlementBasis').value=existing?.settlement_basis||draft?.basis||defaultBasisForMarket($('betMarketType').value);
    syncBetSettlementBasis(false);
    if(draft?.basis&&!existing){$('betSettlementBasis').value=draft.basis;syncBetSettlementBasis(false)}
    if($('saveBetBtn'))$('saveBetBtn').textContent=existing?'✓ LƯU CHỈNH SỬA':'🔒 LOCK ENTRY & XÁC NHẬN';

    betState.marketCandidates=[];renderBetApiCandidates(existing?'Đang chỉnh sửa ticket đã khóa. Entry minute/score gốc được giữ nguyên; mọi thay đổi được lưu audit.':'');
    updateBetLockPreview();form.scrollIntoView({behavior:'smooth',block:'center'});
    if(f?.fixture_id&&!existing)setTimeout(()=>loadBetApiCandidates(false),80);
  }
  function closeBetForm(){betState.editingId=null;betState.modelContext=null;betState.draftSource='MANUAL';if($('betFixtureId'))$('betFixtureId').disabled=false;$('betEntryForm')?.classList.add('hidden');if($('saveBetBtn'))$('saveBetBtn').textContent='🔒 LOCK ENTRY & XÁC NHẬN'}


  function profitOdds(price,fmt){const p=Number(price);return fmt==='DEC'?Math.max(0,p-1):p}
  function outcomeProfit(result,stake,price,fmt){
    const s=Number(stake)||0,o=profitOdds(price,fmt);
    if(result==='WIN')return s*o;if(result==='HALF_WIN')return s*0.5*o;if(result==='PUSH')return 0;if(result==='HALF_LOSE')return -s*0.5;if(result==='LOSE')return -s;return null
  }
  function splitQuarter(line){
    const q=Math.round(Number(line)*4)/4;if(!Number.isFinite(q))return [];
    const twice=q*2;if(Math.abs(twice-Math.round(twice))<1e-9)return [q];
    return [Math.floor(q*2)/2,Math.ceil(q*2)/2];
  }
  function legOutcome(v,eps=1e-9){return v>eps?'WIN':v<-eps?'LOSE':'PUSH'}
  function combineLegOutcomes(legs){
    if(!legs.length)return null;if(legs.every(x=>x==='WIN'))return 'WIN';if(legs.every(x=>x==='LOSE'))return 'LOSE';if(legs.every(x=>x==='PUSH'))return 'PUSH';
    if(legs.includes('WIN')&&legs.includes('PUSH')&&!legs.includes('LOSE'))return 'HALF_WIN';
    if(legs.includes('LOSE')&&legs.includes('PUSH')&&!legs.includes('WIN'))return 'HALF_LOSE';
    return 'MIXED'
  }
  function scoreForBet(b,f){
    const latest=f||b.latest;if(!latest)return null;
    if(['AH_H1','OU_H1'].includes(b.market_type))return latest.halftime;
    if(['AH_H2','OU_H2'].includes(b.market_type)){
      const ft=latest.fulltime,ht=latest.halftime;if(ft?.home==null||ft?.away==null||ht?.home==null||ht?.away==null)return null;
      return {home:Number(ft.home)-Number(ht.home),away:Number(ft.away)-Number(ht.away)};
    }
    const full=latest.fulltime?.home!=null?latest.fulltime:latest.score;
    if(ticketBasis(b)==='FROM_ENTRY'&&full?.home!=null&&full?.away!=null){
      const e=b.entry_lock?.score||b.entry_score;if(e?.home==null||e?.away==null)return null;
      return {home:Number(full.home)-Number(e.home),away:Number(full.away)-Number(e.away)};
    }
    return full;
  }
  function betReadyForSuggestion(b,f){
    const st=f?.status||b.latest?.status||'';
    if(['AH_H1','OU_H1'].includes(b.market_type))return f?.halftime?.home!=null&&['HT','2H','ET','BT','P','FT','AET','PEN'].includes(st);
    if(['AH_H2','OU_H2'].includes(b.market_type))return f?.fulltime?.home!=null&&['FT','AET','PEN'].includes(st);
    if(['AH_FT','OU_FT','ML_FT','TEAM_TOTAL'].includes(b.market_type))return f?.fulltime?.home!=null&&['FT','AET','PEN'].includes(st);
    if(b.market_type==='CORNERS')return st==='FT';
    return false;
  }
  function suggestBetResult(b,f,extra={}){
    if(!betReadyForSuggestion(b,f))return {result:null,note:'Chưa đủ điều kiện settle.'};
    if(b.market_type==='OTHER')return {result:null,note:'Market khác: cần xác nhận thủ công.'};
    const sc=scoreForBet(b,f);if(!sc||sc.home==null||sc.away==null)return {result:null,note:'Thiếu score segment để settle.'};
    const h=Number(sc.home),a=Number(sc.away),line=Number(b.line);
    if(!Number.isFinite(h)||!Number.isFinite(a))return {result:null,note:'Score không hợp lệ.'};
    if(['AH_FT','AH_H1','AH_H2'].includes(b.market_type)){
      const margin=b.selection==='HOME'?h-a:a-h,legs=splitQuarter(line).map(l=>legOutcome(margin+l));
      return {result:combineLegOutcomes(legs),note:`AH ${betSelectionName(b.selection,b)} ${line>=0?'+':''}${line} • ${betBasisName(ticketBasis(b))} ${h}-${a} • legs ${legs.join('/')}`};
    }
    if(['OU_FT','OU_H1','OU_H2'].includes(b.market_type)){
      const total=h+a,legs=splitQuarter(line).map(l=>legOutcome(b.selection==='OVER'?total-l:l-total));
      return {result:combineLegOutcomes(legs),note:`${b.selection==='OVER'?'TÀI':'XỈU'} ${line} • ${betBasisName(ticketBasis(b))} total ${total} • legs ${legs.join('/')}`};
    }
    if(b.market_type==='ML_FT'){
      const actual=h>a?'HOME':h<a?'AWAY':'DRAW';return {result:actual===b.selection?'WIN':'LOSE',note:`1X2 • FT ${h}-${a}`};
    }
    if(b.market_type==='TEAM_TOTAL'){
      const homeSel=String(b.selection).startsWith('HOME'),over=String(b.selection).endsWith('OVER'),g=homeSel?h:a;
      const legs=splitQuarter(line).map(l=>legOutcome(over?g-l:l-g));return {result:combineLegOutcomes(legs),note:`Team Total • goals ${g} • legs ${legs.join('/')}`};
    }
    if(b.market_type==='CORNERS'){
      const total=Number(extra.corner_total);if(!Number.isFinite(total))return {result:null,note:'Thiếu thống kê corners cuối trận; xác nhận thủ công.'};
      const legs=splitQuarter(line).map(l=>legOutcome(b.selection==='OVER'?total-l:l-total));return {result:combineLegOutcomes(legs),note:`Corners total ${total} • legs ${legs.join('/')}`};
    }
    return {result:null,note:'Chưa hỗ trợ settle tự động market này.'};
  }
  function outcomeLabel(r){return ({WIN:'WIN',HALF_WIN:'HALF WIN',PUSH:'PUSH',HALF_LOSE:'HALF LOSE',LOSE:'LOSE',MIXED:'MIXED'})[r]||r||'CHƯA XÁC ĐỊNH'}

  async function refreshOneBet(id,quiet=false){
    const b=betById(id);if(!b||b.status!=='OPEN')return;
    const rows=await football('/fixtures',{id:b.fixture_id,timezone:TZ},true);const f=compactTrackerFixture(rows?.[0]);if(!f){if(!quiet)showToast('err','Không cập nhật được fixture',`#${b.fixture_id}`);return}
    b.latest={...f,updated_at:new Date().toISOString()};
    let extra={};
    if(b.market_type==='CORNERS'&&betReadyForSuggestion(b,f)){
      const stats=await football('/fixtures/statistics',{fixture:b.fixture_id},true);const sm=statMap(stats||[]);const hv=getAnyStat(sm?.[b.home_id],['Corner Kicks','Corners']),av=getAnyStat(sm?.[b.away_id],['Corner Kicks','Corners']);
      if(hv!=null&&av!=null)extra.corner_total=Number(hv)+Number(av);
    }
    const sug=suggestBetResult(b,f,extra);b.suggestion={...sug,at:new Date().toISOString(),final_score:f.fulltime||f.score,extra};saveBets();renderBetTracker();
    if(!quiet)showToast('ok','Đã cập nhật kèo',`${b.home} ${f.score?.home??'-'}-${f.score?.away??'-'} ${b.away} • ${f.status}${f.minute!=null?' '+f.minute+"'":''}`)
  }
  async function refreshOpenBets(quiet=false){
    if(betState.refreshing)return;if(!els.fkey.value.trim()){if(!quiet)showToast('err','Chưa có Football API Key','Vào phần Kết nối và lưu key trước.');return}
    const open=betState.bets.filter(b=>b.status==='OPEN');if(!open.length){if(!quiet)showToast('ok','Không có kèo đang chạy','Chưa cần gọi API.');return}
    betState.refreshing=true;const btn=$('refreshBetsBtn');if(btn)btn.disabled=true;
    try{for(const b of open)await refreshOneBet(b.id,true);if(!quiet)showToast('ok','Đã cập nhật LIVE',`${open.length} kèo đang theo dõi`)}finally{betState.refreshing=false;if(btn)btn.disabled=false;renderBetTracker()}
  }
  function confirmBetSettlement(id,result){
    const b=betById(id);if(!b)return;if(!result||result==='MIXED'){showToast('err','Chưa thể xác nhận','Hãy chọn WIN / HALF WIN / PUSH / HALF LOSE / LOSE.');return}
    const profit=outcomeProfit(result,b.stake,b.price,b.odds_format);if(profit==null)return;
    const ok=confirm(`Xác nhận ${outcomeLabel(result)}?\nP/L: ${vnd(profit)}\nSau khi xác nhận sẽ được tính vào hiệu quả.`);if(!ok)return;
    const at=new Date().toISOString();b.status='SETTLED';b.settlement={result,profit,settled_at:at,suggestion:b.suggestion||null,final_score:b.latest?.fulltime||b.latest?.score||null,settlement_basis:ticketBasis(b)};b.audit_trail=[...(b.audit_trail||[]),{at,type:'SETTLE',result,profit}].slice(-30);saveBets();renderBetTracker();showToast('ok',`Đã xác nhận ${outcomeLabel(result)}`,`${profit>=0?'+':''}${vnd(profit)}`)
  }
  function reopenBet(id){const b=betById(id);if(!b)return;if(!confirm('Hoàn tác kết quả và đưa kèo về ĐANG CHẠY?'))return;b.status='OPEN';delete b.settlement;saveBets();renderBetTracker()}
  function deleteBet(id){const b=betById(id);if(!b)return;if(!confirm(`Xóa kèo ${b.home} vs ${b.away}?`))return;betState.bets=betState.bets.filter(x=>x.id!==id);validationState.rows=validationState.rows.filter(x=>x.id!==`BET-${id}`);validationWrite();saveBets();renderBetTracker()}

  function renderBetMiniKpis(){
    const el=$('betMiniKpis');if(!el)return;const open=betState.bets.filter(b=>b.status==='OPEN').length,settled=betState.bets.filter(b=>b.status==='SETTLED'),pl=settled.reduce((s,b)=>s+Number(b.settlement?.profit||0),0),turn=settled.reduce((s,b)=>s+Number(b.stake||0),0),roi=turn?pl/turn*100:0;
    el.innerHTML=`<div class="bet-kpi"><span>ĐANG CHẠY</span><b>${open}</b></div><div class="bet-kpi ${pl>0?'good':pl<0?'bad':''}"><span>P/L ĐÃ CHỐT • ROI ${pct(roi)}</span><b class="${plClass(pl)}">${pl>0?'+':''}${vnd(pl)}</b></div>`
  }
  function ticketMarketText(b){const line=marketNeedsLine(b.market_type)&&b.line!==''&&b.line!=null?` ${Number(b.line)>0?'+':''}${b.line}`:'';return `${betMarketName(b.market_type)} • ${betSelectionName(b.selection,b)}${line} @${b.price} ${b.odds_format} • ${betBasisName(ticketBasis(b))}`}
  function renderOpenTicket(b){
    const l=b.latest||{},score=l.score||b.entry_score||{},st=l.status||'PENDING',live=['1H','HT','2H','ET','BT','P','INT','LIVE'].includes(st),finished=['FT','AET','PEN'].includes(st),sug=b.suggestion||{},def=['WIN','HALF_WIN','PUSH','HALF_LOSE','LOSE'].includes(sug.result)?sug.result:'';
    return `<div class="bet-ticket ${live?'live':''} ${finished?'finished':''}" data-bet="${esc(b.id)}">
      <div class="bet-ticket-top"><div class="bet-ticket-title"><b>${esc(b.home)} vs ${esc(b.away)}</b><span>${esc(b.league||'')} • #${esc(b.fixture_id)} • vào ${esc(b.entry_minute??'-')}' ${esc(b.entry_score?.home??'-')}-${esc(b.entry_score?.away??'-')}</span></div><span class="bet-state ${live?'live':finished?'ft':''}">${esc(st)}${l.minute!=null?' '+esc(l.minute)+"'":''}</span></div>
      <div class="bet-line"><strong>${esc(ticketMarketText(b))}</strong><span>Vốn ${esc(vnd(b.stake))}${b.confidence!=null&&b.confidence!==''?` • C${esc(b.confidence)}`:''}</span></div>
      <div class="bet-live-score"><div class="team">${esc(b.home)}</div><div class="score">${esc(score.home??'-')} - ${esc(score.away??'-')}</div><div class="team">${esc(b.away)}</div></div>
      <div class="bet-live-meta">${l.updated_at?'Cập nhật '+esc(new Date(l.updated_at).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'})):'Chưa cập nhật LIVE'}${b.deep_tag?' • '+esc(b.deep_tag):''}</div>
      <div class="bet-ticket-lock"><b>🔒 ENTRY</b> ${esc(b.entry_minute??'-')}' • ${esc(b.entry_score?.home??'-')}-${esc(b.entry_score?.away??'-')} • ${esc(betBasisName(ticketBasis(b)))} • ${esc(b.resolved_engine||validationEngineFromBet(b))}${b.draft_source?` • ${esc(b.draft_source)}`:''}${b.entry_lock?.locked_at?` • ${esc(new Date(b.entry_lock.locked_at).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit',second:'2-digit'}))}`:''}</div>
      <div class="bet-ticket-actions"><button type="button" data-action="refresh" data-id="${esc(b.id)}">↻ CẬP NHẬT</button><button type="button" data-action="edit" data-id="${esc(b.id)}">✎ CHỈNH</button><button type="button" data-action="delete" data-id="${esc(b.id)}">XÓA</button></div>
      <div class="bet-settle">${sug.note?`<div class="bet-suggest">${sug.result?`Đề xuất: <b>${esc(outcomeLabel(sug.result))}</b> • `:''}${esc(sug.note)}</div>`:''}<div class="bet-settle-row"><select data-result="${esc(b.id)}"><option value="">Chọn kết quả...</option>${['WIN','HALF_WIN','PUSH','HALF_LOSE','LOSE'].map(r=>`<option value="${r}" ${r===def?'selected':''}>${outcomeLabel(r)}</option>`).join('')}</select><button class="primary" type="button" data-action="settle" data-id="${esc(b.id)}">XÁC NHẬN</button></div></div>
    </div>`
  }
  function renderSettledTicket(b){const p=Number(b.settlement?.profit||0),r=b.settlement?.result||'-',fs=b.settlement?.final_score;return `<div class="bet-ticket"><div class="bet-ticket-top"><div class="bet-ticket-title"><b>${esc(b.home)} vs ${esc(b.away)}</b><span>${esc(b.league||'')} • ${esc(new Date(b.settlement?.settled_at||b.created_at).toLocaleString('vi-VN'))}</span></div><span class="bet-state ft">${esc(outcomeLabel(r))}</span></div><div class="bet-line"><strong>${esc(ticketMarketText(b))}</strong><span>Vốn ${esc(vnd(b.stake))}</span></div><div class="bet-live-score"><div class="team">${esc(b.home)}</div><div class="score">${esc(fs?.home??'-')} - ${esc(fs?.away??'-')}</div><div class="team">${esc(b.away)}</div></div><div class="bet-line"><strong class="${plClass(p)}">P/L ${p>0?'+':''}${esc(vnd(p))}</strong><span>${b.confidence!=null&&b.confidence!==''?'Confidence '+esc(b.confidence):''}</span></div><div class="bet-ticket-actions"><button type="button" data-action="reopen" data-id="${esc(b.id)}">↶ HOÀN TÁC</button><button type="button" data-action="edit" data-id="${esc(b.id)}">✎ CHỈNH</button><button type="button" data-action="delete" data-id="${esc(b.id)}">XÓA</button></div></div>`}

  function dashboardData(){
    const settled=betState.bets.filter(b=>b.status==='SETTLED'),now=Date.now(),day=86400000;const turn=settled.reduce((s,b)=>s+Number(b.stake||0),0),pl=settled.reduce((s,b)=>s+Number(b.settlement?.profit||0),0),roi=turn?pl/turn*100:0;
    const today=settled.filter(b=>now-new Date(b.settlement?.settled_at||0).getTime()<day).reduce((s,b)=>s+Number(b.settlement?.profit||0),0),week=settled.filter(b=>now-new Date(b.settlement?.settled_at||0).getTime()<7*day).reduce((s,b)=>s+Number(b.settlement?.profit||0),0);
    const count={WIN:0,HALF_WIN:0,PUSH:0,HALF_LOSE:0,LOSE:0};settled.forEach(b=>{if(count[b.settlement?.result]!=null)count[b.settlement.result]++});
    const decisive=count.WIN+count.HALF_WIN+count.HALF_LOSE+count.LOSE,weightedWins=count.WIN+.5*count.HALF_WIN,winRate=decisive?weightedWins/decisive*100:0;
    const by={};settled.forEach(b=>{const k=betMarketName(b.market_type);if(!by[k])by[k]={n:0,stake:0,pl:0};by[k].n++;by[k].stake+=Number(b.stake||0);by[k].pl+=Number(b.settlement?.profit||0)});
    return {settled,turn,pl,roi,today,week,count,winRate,by}
  }
  function renderDashboard(){const el=$('betDashboard');if(!el)return;const d=dashboardData();const rows=Object.entries(d.by).sort((a,b)=>b[1].n-a[1].n);el.innerHTML=`<div class="bet-kpis"><div class="bet-kpi ${d.pl>0?'good':d.pl<0?'bad':''}"><span>TỔNG P/L</span><b class="${plClass(d.pl)}">${d.pl>0?'+':''}${vnd(d.pl)}</b></div><div class="bet-kpi"><span>ROI / YIELD</span><b>${pct(d.roi)}</b></div><div class="bet-kpi"><span>24 GIỜ</span><b class="${plClass(d.today)}">${d.today>0?'+':''}${vnd(d.today)}</b></div><div class="bet-kpi"><span>7 NGÀY</span><b class="${plClass(d.week)}">${d.week>0?'+':''}${vnd(d.week)}</b></div><div class="bet-kpi"><span>KÈO ĐÃ CHỐT</span><b>${d.settled.length}</b></div><div class="bet-kpi"><span>WIN RATE CÓ TRỌNG SỐ</span><b>${pct(d.winRate)}</b></div></div><div class="status" style="margin-top:9px">Turnover: <b>${vnd(d.turn)}</b> • W ${d.count.WIN} • HW ${d.count.HALF_WIN} • P ${d.count.PUSH} • HL ${d.count.HALF_LOSE} • L ${d.count.LOSE}</div><div class="bet-breakdown"><div class="bet-break-row head"><span>MARKET</span><span>N</span><span>P/L</span><span>ROI</span></div>${rows.length?rows.map(([k,x])=>`<div class="bet-break-row"><span>${esc(k)}</span><span>${x.n}</span><span class="${plClass(x.pl)}">${x.pl>0?'+':''}${esc(vnd(x.pl))}</span><span>${pct(x.stake?x.pl/x.stake*100:0)}</span></div>`).join(''):`<div class="bet-empty">Chưa có dữ liệu đã settle để đánh giá hiệu quả.</div>`}</div>`}

  function validationRead(){
    try{
      const x=JSON.parse(localStorage.getItem(VALIDATION_STORAGE_KEY)||'[]');
      return Array.isArray(x)?x.slice(-VALIDATION_MAX):[]
    }catch{return []}
  }

  let validationArchiveDbp=null;
  function validationArchiveOpen(){
    if(!('indexedDB' in window))return Promise.resolve(null);
    if(validationArchiveDbp)return validationArchiveDbp;
    validationArchiveDbp=new Promise(resolve=>{
      try{
        const r=indexedDB.open(VALIDATION_ARCHIVE_DB,1);
        r.onupgradeneeded=()=>{
          const db=r.result;
          if(!db.objectStoreNames.contains(VALIDATION_ARCHIVE_STORE)){
            const st=db.createObjectStore(VALIDATION_ARCHIVE_STORE,{keyPath:'id'});
            st.createIndex('captured_at','captured_at',{unique:false});
            st.createIndex('engine','engine',{unique:false});
            st.createIndex('source','source',{unique:false})
          }
        };
        r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null)
      }catch{resolve(null)}
    });
    return validationArchiveDbp
  }
  async function validationArchiveWrite(rows){
    if(validationState.archiveBusy)return false;
    validationState.archiveBusy=true;
    try{
      const db=await validationArchiveOpen();if(!db)return false;
      const all=(rows||[]).filter(x=>x&&x.id).slice(-VALIDATION_MAX),chunk=350;
      for(let i=0;i<all.length;i+=chunk){
        const part=all.slice(i,i+chunk);
        await new Promise(resolve=>{
          const tx=db.transaction(VALIDATION_ARCHIVE_STORE,'readwrite'),st=tx.objectStore(VALIDATION_ARCHIVE_STORE);
          for(const row of part)st.put(row);
          tx.oncomplete=()=>resolve();tx.onerror=()=>resolve()
        })
      }
      return true
    }catch(e){
      log('Validation archive error',{error:e.message});
      return false
    }finally{validationState.archiveBusy=false}
  }
  async function validationArchiveRead(limit=VALIDATION_MAX){
    try{
      const db=await validationArchiveOpen();if(!db)return [];
      return await new Promise(resolve=>{
        const tx=db.transaction(VALIDATION_ARCHIVE_STORE,'readonly'),idx=tx.objectStore(VALIDATION_ARCHIVE_STORE).index('captured_at'),
              out=[],req=idx.openCursor(null,'prev');
        req.onsuccess=e=>{const c=e.target.result;if(c&&out.length<limit){out.push(c.value);c.continue()}else resolve(out.reverse())};
        req.onerror=()=>resolve([])
      })
    }catch{return []}
  }
  async function validationArchiveHydrate(){
    if(validationState.archiveHydrated)return validationState.rows;
    const archived=await validationArchiveRead(VALIDATION_MAX),map=new Map();
    for(const r of [...archived,...(validationState.rows||[])])if(r?.id)map.set(String(r.id),r);
    validationState.rows=[...map.values()].sort((a,b)=>Number(a.captured_at||0)-Number(b.captured_at||0)).slice(-VALIDATION_MAX);
    validationState.archiveHydrated=true;
    await validationArchiveWrite(validationState.rows);
    validationWrite({archive:false});
    renderValidation?.();
    return validationState.rows
  }
  function validationWrite(opts={}){
    const rows=(validationState.rows||[]).slice(-VALIDATION_MAX);
    if(opts.archive!==false){validationArchiveWrite(rows).then(ok=>{
      if(ok)validationWrite({archive:false});
    });if(typeof feDbQueueValidationBatch==='function')feDbQueueValidationBatch(rows.slice(-120),{schedule:true}).catch(()=>{})}
    if(opts.archive===false){
      const recent=rows.slice(-VALIDATION_LOCAL_RECENT);
      try{
        // remove the old potentially huge payload first, but only after IndexedDB archive succeeded
        localStorage.removeItem(VALIDATION_STORAGE_KEY);
        localStorage.setItem(VALIDATION_STORAGE_KEY,JSON.stringify(recent));
      }catch(e){
        log('Validation recent-cache skipped',{error:e.message});
      }
    }
  }

  async function storageEstimate(){
    try{
      if(navigator.storage?.estimate){
        const x=await navigator.storage.estimate(),usage=Number(x.usage||0),quota=Number(x.quota||0);
        return {usage,quota,pct:quota?usage/quota*100:null}
      }
    }catch{}
    // localStorage fallback estimate only
    let chars=0;
    try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i)||'';chars+=k.length+(localStorage.getItem(k)||'').length}}catch{}
    return {usage:chars*2,quota:null,pct:null}
  }
  function storageFmt(bytes){
    const b=Number(bytes||0);
    if(b>=1024*1024)return `${(b/1024/1024).toFixed(1)} MB`;
    if(b>=1024)return `${(b/1024).toFixed(0)} KB`;
    return `${Math.round(b)} B`
  }
  async function storageHealthRefresh(){
    const x=await storageEstimate(),pct=x.pct==null?null:Math.min(100,x.pct);
    if(els.storageHealthValue)els.storageHealthValue.textContent=pct==null?storageFmt(x.usage):`${pct.toFixed(1)}%`;
    if(els.storageHealthBar)els.storageHealthBar.style.width=(pct==null?Math.min(100,x.usage/(8*1024*1024)*100):pct)+'%';
    if(els.storageHealthNote){
      els.storageHealthNote.textContent=x.quota?
        `Đang dùng ${storageFmt(x.usage)} / ${storageFmt(x.quota)}. Validation đầy đủ lưu bằng IndexedDB; localStorage chỉ giữ ${VALIDATION_LOCAL_RECENT} mẫu gần nhất.`:
        `Local cache khoảng ${storageFmt(x.usage)}. Validation đầy đủ lưu bằng IndexedDB; localStorage chỉ giữ ${VALIDATION_LOCAL_RECENT} mẫu gần nhất.`
    }
    return x
  }
  function storageRemovePrefix(prefix){
    const drop=[];
    try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith(prefix))drop.push(k)}}catch{}
    for(const k of drop){try{localStorage.removeItem(k)}catch{}}
    return drop.length
  }
  async function storageCleanupTransient({toast=true}={}){
    let removed=0;
    // Safe-to-rebuild transient caches only. Do NOT delete QSIG, decision journal,
    // validation archive, settings or bet history.
    const idx=cacheIndexRead();
    for(const x of idx){try{localStorage.removeItem(x.k);removed++}catch{}}
    try{localStorage.removeItem(API_CACHE_INDEX)}catch{}
    removed+=storageRemovePrefix(API_CACHE_NS);
    // prune old market snapshots aggressively; next LIVE cycle rebuilds them
    const liveIdx=liveHistoryIndexRead?.()||[];
    for(const x of liveIdx){
      const id=x?.fixture_id??x?.id;
      if(id!=null){try{localStorage.removeItem(liveHistoryKey(id));removed++}catch{}}
    }
    try{localStorage.removeItem(LIVE_ODDS_HISTORY_INDEX)}catch{}
    // shrink validation local mirror AFTER archive
    const archived=await validationArchiveWrite(validationState.rows||[]);
    if(archived)validationWrite({archive:false});
    await storageHealthRefresh();
    if(toast)showToast('ok','ĐÃ DỌN CACHE',`Đã bỏ ${removed} cache tạm. Dữ liệu Validation được giữ trong IndexedDB.`);
    return {removed,archived}
  }

  function validationEngineFromBet(b){
    const resolved=String(b.resolved_engine||'').toUpperCase();if(['PRE','FT','H1','HC'].includes(resolved))return resolved;
    const explicit=String(b.engine_tag||'').toUpperCase();if(['PRE','FT','H1','HC'].includes(explicit))return explicit;
    const tag=String(b.deep_tag||'').toUpperCase();if(tag.includes('FE-PRE'))return 'PRE';if(tag.includes('FE-H1'))return 'H1';if(tag.includes('FE-FT'))return 'FT';if(tag.includes('HANDICAP')||tag.includes('FE-HC'))return 'HC';
    return ['AH_H1','OU_H1'].includes(b.market_type)?'H1':'FT'
  }
  function validationSyncSources(){
    const derivedSources=new Set(['QSIG_OFFICIAL','LEGACY_FT_WATCH','LEGACY_H1_WATCH','LEGACY_HANDICAP_WATCH','BET_TRACKER']);
    const base=(validationState.rows||[]).filter(x=>x&&x.id&&!derivedSources.has(String(x.source||''))&&
      !['FT_WATCH','H1_WATCH','HANDICAP_WATCH'].includes(String(x.source||'')));
    const map=new Map(base.map(x=>[String(x.id),x])),put=x=>{const old=map.get(String(x.id))||{};map.set(String(x.id),{...old,...x})};

    for(const r of qsigRead('FT')){
      const done=typeof r.goal_10m==='boolean';
      put({id:`QSIG-FT-${r.id}`,schema:'V1.16.2',sample_type:'AUTO',engine:'FT',source:'QSIG_OFFICIAL',fixture_id:r.fixture_id,
        league:r.league,home:r.home,away:r.away,captured_at:Number(r.t0||0),minute:r.minute,entry_score:{home:r.start_home,away:r.start_away},
        signal_state:r.level,signal_score:r.score,core:r.core,app_dq_100:r.app_dq_100??null,live_quality_5:r.live_quality_5??r.dq??null,
        coverage:r.coverage??null,integrity:r.integrity??null,freshness_age_sec:r.freshness_age_sec??r.fresh??null,data_tier:r.data_tier??null,
        cache_source:r.cache_source??null,evidence_age:r.evidence_age??null,trend:r.trend??null,target:'GOAL_10M',market_type:'OU_FT',selection:'OVER',
        line:r.over_line??null,odds:r.over_odd??null,resolution:done?'RESOLVED':r.release_reason&&r.release_reason!=='PRESSURE_DECAY_120S'?'VOID':'OPEN',
        outcome:done?(r.goal_10m?'HIT':'MISS'):null,hit:done?r.goal_10m:null,release_reason:r.release_reason??null,resolved_at:r.resolved_at??null,
        benchmark_version:r.benchmark_version||'V1.15_FIXED',t0_snapshot:r.t0_snapshot??null})
    }
    for(const r of qsigRead('H1')){
      const done=typeof r.goal_5m==='boolean';
      put({id:`QSIG-H1-${r.id}`,schema:'V1.16.2',sample_type:'AUTO',engine:'H1',source:'QSIG_OFFICIAL',fixture_id:r.fixture_id,
        league:r.league,home:r.home,away:r.away,captured_at:Number(r.t0||0),minute:r.minute,entry_score:{home:r.start_home,away:r.start_away},
        signal_state:r.level,signal_score:r.score,core:r.core,app_dq_100:r.app_dq_100??null,live_quality_5:r.live_quality_5??r.dq??null,
        coverage:r.coverage??null,integrity:r.integrity??null,freshness_age_sec:r.freshness_age_sec??r.fresh??null,data_tier:r.data_tier??null,
        cache_source:r.cache_source??null,evidence_age:r.evidence_age??null,trend:r.trend??null,target:'GOAL_5M',market_type:'OU_H1',selection:'OVER',
        line:r.h1_over_line??null,odds:r.h1_over_odd??null,resolution:done?'RESOLVED':r.release_reason&&r.release_reason!=='PRESSURE_DECAY_120S'?'VOID':'OPEN',
        outcome:done?(r.goal_5m?'HIT':'MISS'):null,hit:done?r.goal_5m:null,release_reason:r.release_reason??null,resolved_at:r.resolved_at??null,
        benchmark_version:r.benchmark_version||'V1.15_FIXED',t0_snapshot:r.t0_snapshot??null})
    }
    for(const r of qsigRead('HC')){
      const state15=r.state_15m??null,newOutcome=state15!=null,legacyBoolean=typeof r.direction_15m==='boolean'&&state15==null,
            legacyHC=!r.benchmark_version&&legacyBoolean,
            sampleType=legacyHC?'LEGACY':'AUTO',source=legacyHC?'LEGACY_HANDICAP_WATCH':'QSIG_OFFICIAL',
            voided=!newOutcome&&!!r.void_reason,
            outcome=newOutcome?state15:legacyBoolean?(r.direction_15m?'LEGACY_SAME_DIRECTION':'LEGACY_NOT_SAME_DIRECTION'):null,
            hit=newOutcome?state15==='MAINTAINED':null;
      put({id:`QSIG-HC-${r.id}`,schema:'V1.16.2',sample_type:sampleType,engine:'HC',source,fixture_id:r.fixture_id,
        league:r.league,home:r.home,away:r.away,captured_at:Number(r.t0||0),minute:r.minute,entry_score:{home:r.start_home,away:r.start_away},
        signal_state:r.level,signal_score:Math.abs(Number(r.live_gap??r.t0_snapshot?.live_gap??0)),live_gap:r.live_gap??r.t0_snapshot?.live_gap??null,
        total_gap:r.total_gap??r.t0_snapshot?.total_gap??null,core:r.core,football_core:r.football_core,app_dq_100:r.app_dq_100??null,
        live_quality_5:r.live_quality_5??r.dq??null,coverage:r.coverage??null,integrity:r.integrity??null,
        freshness_age_sec:r.freshness_age_sec??r.fresh??null,data_tier:r.data_tier??null,cache_source:r.cache_source??null,evidence_age:r.evidence_age??null,
        trend:r.trend??null,target:'STATE_15M',market_type:'AH_FT',selection:r.direction,line:r.line,odds:r.direction==='HOME'?r.home_odd:r.away_odd,
        market_state:r.market_level,resolution:newOutcome?'RESOLVED':voided?'VOID':'OPEN',outcome,hit,void_reason:r.void_reason??null,
        goal_for_direction:r.goal_for_direction??null,goal_delta:r.goal_delta??null,resolved_at:r.resolved_at??null,
        benchmark_version:r.benchmark_version||'LEGACY_V1.15',t0_snapshot:r.t0_snapshot??null})
    }

    // Legacy snapshot calibration is preserved for debugging/reference only; never counted as official AUTO evidence.
    for(const r of watchState.calibration||[])put({id:`LEGACY-FT-${r.id}`,schema:'V1.16.2',sample_type:'LEGACY',engine:'FT',source:'LEGACY_FT_WATCH',fixture_id:r.fixture_id,league:r.league,home:r.home,away:r.away,captured_at:Number(r.captured_at||0),minute:r.minute,signal_state:r.tier,signal_score:r.score,core:r.core,live_quality_5:null,app_dq_100:r.dq??null,target:'LEGACY_GOAL_10M',resolution:typeof r.goal_10m==='boolean'?'RESOLVED':'OPEN',outcome:typeof r.goal_10m==='boolean'?(r.goal_10m?'HIT':'MISS'):null,hit:typeof r.goal_10m==='boolean'?r.goal_10m:null});
    for(const r of h1WatchState.calibration||[])put({id:`LEGACY-H1-${r.id}`,schema:'V1.16.2',sample_type:'LEGACY',engine:'H1',source:'LEGACY_H1_WATCH',fixture_id:r.fixture_id,league:r.league,home:r.home,away:r.away,captured_at:Number(r.captured_at||0),minute:r.minute,signal_state:r.tier,signal_score:r.score,core:r.core,live_quality_5:null,app_dq_100:r.dq??null,target:'LEGACY_GOAL_5M',resolution:typeof r.goal_5m==='boolean'?'RESOLVED':'OPEN',outcome:typeof r.goal_5m==='boolean'?(r.goal_5m?'HIT':'MISS'):null,hit:typeof r.goal_5m==='boolean'?r.goal_5m:null});
    for(const r of handicapWatchState.calibration||[]){const done=r.resolved===true,neutral=done&&r.neutral===true;put({id:`LEGACY-HC-${r.fixture_id}-${r.start_at}`,schema:'V1.16.2',sample_type:'LEGACY',engine:'HC',source:'LEGACY_HANDICAP_WATCH',fixture_id:r.fixture_id,league:r.league,home:r.home,away:r.away,captured_at:Number(r.start_at||0),minute:r.minute,signal_state:r.recommendation,signal_score:Math.abs(Number(r.live_gap??r.gap??0)),live_gap:r.live_gap??null,total_gap:r.gap??null,core:r.core,target:'LEGACY_SCORE_15M',selection:r.direction,resolution:r.resolved===false&&r.void_reason?'VOID':done?'RESOLVED':'OPEN',outcome:done?(neutral?'NEUTRAL':r.confirmed?'HIT':'MISS'):null,hit:done&&!neutral?!!r.confirmed:null,void_reason:r.void_reason||null,resolved_at:r.resolved_at||null})}

    for(const b of betState.bets||[]){const settled=b.status==='SETTLED',profit=settled?Number(b.settlement?.profit||0):null;put({id:`BET-${b.id}`,schema:'V1.16.2',sample_type:'BET',engine:validationEngineFromBet(b),source:'BET_TRACKER',fixture_id:b.fixture_id,league:b.league,home:b.home,away:b.away,captured_at:new Date(b.created_at||0).getTime(),kickoff_vn:b.kickoff_vn,minute:b.entry_minute,entry_score:b.entry_score,signal_state:'FINAL_PICK',signal_score:b.confidence,confidence:b.confidence,app_dq_100:b.validation_context?.dq??null,coverage:b.validation_context?.coverage??null,integrity:b.validation_context?.integrity??null,freshness:b.validation_context?.freshness??null,deep_tag:b.deep_tag||'',target:'BET_RESULT',market_type:b.market_type,selection:b.selection,line:b.line,odds:b.price,odds_format:b.odds_format,settlement_basis:ticketBasis(b),draft_source:b.draft_source||null,entry_lock:b.entry_lock||null,stake:Number(b.stake||0),resolution:settled?'RESOLVED':'OPEN',outcome:settled?b.settlement?.result:null,profit,profit_unit:settled&&Number(b.stake)>0?profit/Number(b.stake):null,final_score:settled?b.settlement?.final_score:null,resolved_at:settled?new Date(b.settlement?.settled_at||0).getTime():null,note:b.note||''})}
    validationState.rows=[...map.values()].sort((a,b)=>Number(a.captured_at||0)-Number(b.captured_at||0)).slice(-VALIDATION_MAX);validationWrite();return validationState.rows
  }
  function validationFiltered(){const engine=$('validationEngineFilter')?.value||'ALL',source=$('validationSourceFilter')?.value||'ALL';return validationSyncSources().filter(r=>(engine==='ALL'||r.engine===engine)&&(source==='ALL'||r.sample_type===source))}
  function validationMetrics(rows){
    const auto=rows.filter(r=>r.sample_type==='AUTO'&&r.resolution==='RESOLVED'&&typeof r.hit==='boolean'),hits=auto.filter(r=>r.hit).length,bets=rows.filter(r=>r.sample_type==='BET'&&r.resolution==='RESOLVED'),turn=bets.reduce((s,r)=>s+Number(r.stake||0),0),pl=bets.reduce((s,r)=>s+Number(r.profit||0),0);
    const ordered=[...bets].sort((a,b)=>Number(a.resolved_at||0)-Number(b.resolved_at||0));let equity=0,peak=0,maxDrawdown=0;for(const r of ordered){equity+=Number(r.profit||0);peak=Math.max(peak,equity);maxDrawdown=Math.max(maxDrawdown,peak-equity)}
    const decisive=bets.filter(r=>['WIN','HALF_WIN','HALF_LOSE','LOSE'].includes(r.outcome)),weighted=decisive.reduce((s,r)=>s+(r.outcome==='WIN'?1:r.outcome==='HALF_WIN'?0.5:0),0),resolved=rows.filter(r=>r.resolution==='RESOLVED').length;
    return {auto,hits,hitRate:auto.length?hits/auto.length*100:null,bets,turn,pl,roi:turn?pl/turn*100:null,betWinRate:decisive.length?weighted/decisive.length*100:null,maxDrawdown,resolved}
  }
  function evidenceWilson(hits,n,z=1.96){if(!n)return {low:null,high:null};const p=hits/n,z2=z*z,den=1+z2/n,center=(p+z2/(2*n))/den,margin=z*Math.sqrt((p*(1-p)+z2/(4*n))/n)/den;return {low:Math.max(0,center-margin)*100,high:Math.min(1,center+margin)*100}}
  function evidenceRateStats(rows){const valid=(rows||[]).filter(r=>typeof r.hit==='boolean'),hits=valid.filter(r=>r.hit).length,ci=evidenceWilson(hits,valid.length);return {n:valid.length,hits,rate:valid.length?hits/valid.length*100:null,low:ci.low,high:ci.high}}
  function evidenceIndependentSamples(engine,rows){const map=new Map(),sorted=[...(rows||[])].sort((a,b)=>Number(a.captured_at||0)-Number(b.captured_at||0));for(const r of sorted){const phase=r.entry_score_total!=null?`G${r.entry_score_total}`:r.entry_score?.home!=null?`S${r.entry_score.home}-${r.entry_score.away}`:`W${Math.floor(Number(r.minute||0)/15)}`,key=`${engine}:${r.fixture_id??r.id}:${phase}`;if(!map.has(key))map.set(key,r)}return [...map.values()]}
  function evidenceSegmentStats(engine,rows){
    const minuteDefs=engine==='H1'?[[20,29,'M20–29'],[30,36,'M30–36'],[37,42,'M37–42']]:engine==='FT'?[[46,54,'M46–54'],[55,69,'M55–69'],[70,80,'M70–80']]:[[30,44,'M30–44'],[45,64,'M45–64'],[65,80,'M65–80']];
    const build=(defs,key)=>defs.map(([lo,hi,label])=>{const rr=rows.filter(r=>r[key]!=null&&Number(r[key])>=lo&&Number(r[key])<=hi),s=evidenceRateStats(rr);return {...s,label}}).filter(x=>x.n);
    const appDQ=build([[0,59,'App DQ <60'],[60,74,'App DQ 60–74'],[75,100,'App DQ 75+']],'app_dq_100');
    const liveQ=build([[0,3.99,'Live Q <4.0'],[4,4.49,'Live Q 4.0–4.49'],[4.5,5,'Live Q 4.5–5.0']],'live_quality_5');
    const extra=[];
    if(engine==='HC'){
      for(const [label,fn] of [['CORE 3/4',r=>Number(r.core)===3],['CORE 4/4',r=>Number(r.core)>=4],['SOFT AGREEMENT',r=>r.market_state==='SOFT_AGREEMENT'],['HARD AGREEMENT',r=>r.market_state==='HARD_AGREEMENT']]){
        const rr=rows.filter(fn),s=evidenceRateStats(rr);if(s.n)extra.push({...s,label})
      }
    }
    return {appDQ,liveQ,minute:build(minuteDefs,'minute'),extra}
  }
  function evidenceReviewEngine(engine,allRows){
    const cfg=EVIDENCE_BASELINES[engine],samples=(allRows||[]).filter(r=>r.engine===engine&&r.sample_type==='AUTO'&&r.source==='QSIG_OFFICIAL'&&r.resolution==='RESOLVED'&&typeof r.hit==='boolean'&&r.signal_score!=null).sort((a,b)=>Number(a.captured_at||0)-Number(b.captured_at||0)),rawSamples=samples,
          cut=Math.max(1,Math.floor(samples.length*.7)),train=samples.slice(0,cut),holdout=samples.slice(cut),
          at=(rows,t)=>evidenceRateStats(rows.filter(r=>Number(r.signal_score)>=t)),baseAll=at(samples,cfg.qualified),baseTrain=at(train,cfg.qualified),baseHoldout=at(holdout,cfg.qualified),minTrain=Math.max(10,Math.floor(baseTrain.n*.35));
    let candidate={threshold:cfg.qualified,stats:baseTrain,score:baseTrain.low??-1};
    for(let threshold=cfg.qualified;threshold<=cfg.max;threshold++){
      const stats=at(train,threshold);if(stats.n<minTrain)continue;const score=(stats.low??-1)+Math.min(stats.n,500)/100000;
      if(score>candidate.score+.0001||(Math.abs(score-candidate.score)<=.0001&&threshold<candidate.threshold))candidate={threshold,stats,score}
    }
    const candHoldout=at(holdout,candidate.threshold),delta=candHoldout.rate!=null&&baseHoldout.rate!=null?candHoldout.rate-baseHoldout.rate:null,
          retention=baseHoldout.n?candHoldout.n/baseHoldout.n:0;let decision='COLLECT',reason=`Cần thêm ${Math.max(0,100-samples.length)} QSIG resolved để bắt đầu đánh giá giả thuyết.`;
    if(samples.length>=100&&samples.length<300){decision='HYPOTHESIS';reason=`QSIG n=${samples.length}; có thể quan sát threshold ${candidate.threshold}, nhưng chưa đạt cổng 300 cho holdout.`}
    else if(samples.length>=300){
      const supported=candidate.threshold!==cfg.qualified&&candHoldout.n>=30&&baseHoldout.n>=30&&retention>=.35&&delta!=null&&delta>=3&&(candHoldout.low??0)>=(baseHoldout.low??0);
      if(supported){decision='REVIEW';reason=`Holdout tăng ${delta.toFixed(1)} điểm %, giữ ${(retention*100).toFixed(0)}% mẫu QSIG baseline. Chỉ đề xuất review release; không tự áp dụng.`}
      else{decision='KEEP';reason=candidate.threshold===cfg.qualified?'Train vẫn chọn đúng benchmark cố định.':'Holdout chưa đồng thời đạt Δ≥3 điểm %, n≥30, retention≥35% và Wilson lower-bound không giảm.'}
    }
    return {engine,cfg,raw_n:rawSamples.length,samples_n:samples.length,baseAll,baseTrain,baseHoldout,candidate_threshold:candidate.threshold,candidateTrain:candidate.stats,candidateHoldout:candHoldout,delta,retention,decision,reason,segments:evidenceSegmentStats(engine,samples)}
  }
  function evidenceDecisionText(x){return ({COLLECT:'THU THÊM MẪU',HYPOTHESIS:'GIẢ THUYẾT',KEEP:'GIỮ BENCHMARK',REVIEW:'XEM XÉT ỨNG VIÊN'})[x]||x}
  function evidenceRateLine(s){return !s?.n?'n=0':`n=${s.n} • ${validationFmt(s.rate)} • CI95 ${validationFmt(s.low)}–${validationFmt(s.high)}`}
  function renderEvidenceReview(rows){
    const el=$('evidenceReview');if(!el)return;const reviews=['FT','H1','HC'].map(e=>evidenceReviewEngine(e,rows)),pre=validationMetrics(rows.filter(r=>r.engine==='PRE')),
          cards=reviews.map(r=>{const cls=({COLLECT:'collect',HYPOTHESIS:'hypothesis',KEEP:'keep',REVIEW:'review'})[r.decision],
            segments=[...r.segments.appDQ,...r.segments.liveQ,...r.segments.minute,...r.segments.extra].map(x=>`${x.label}: n=${x.n}/${validationFmt(x.rate)}`).join(' • ')||'Chưa đủ dữ liệu segment';
            return `<div class="evidence-card"><div class="evidence-head"><div><b>${esc(r.cfg.label)} • benchmark ≥${r.cfg.qualified}</b><div class="tiny">Official QSIG waves n=${r.samples_n} • train 70% / holdout 30% • không dedup lại snapshot</div></div><span class="evidence-decision ${cls}">${evidenceDecisionText(r.decision)}</span></div><div class="evidence-compare"><div class="evidence-box"><span>BASELINE HOLDOUT ≥${r.cfg.qualified}</span><b>${evidenceRateLine(r.baseHoldout)}</b></div><div class="evidence-box"><span>CANDIDATE HOLDOUT ≥${r.candidate_threshold}</span><b>${evidenceRateLine(r.candidateHoldout)}</b></div></div><div class="evidence-reason"><b>Kết luận:</b> ${esc(r.reason)}<br><b>Segments:</b> ${esc(segments)}</div></div>`}).join('');
    const preCard=`<div class="evidence-card"><div class="evidence-head"><div><b>PRE-MATCH • theo dõi FINAL đã ghi nhận</b><div class="tiny">PRE chưa có QSIG chuẩn hóa; confidence không phải xác suất.</div></div><span class="evidence-decision ${pre.bets.length>=100?'keep':'collect'}">${pre.bets.length>=100?'ĐỦ ĐÁNH GIÁ':'THU THÊM MẪU'}</span></div><div class="evidence-compare"><div class="evidence-box"><span>KÈO ĐÃ SETTLE</span><b>${pre.bets.length}</b></div><div class="evidence-box"><span>WEIGHTED WIN / ROI</span><b>${validationFmt(pre.betWinRate)} • ${validationFmt(pre.roi)}</b></div></div><div class="evidence-reason">PRE chỉ là prior/reference; không được dùng để phủ định fresh qualified LIVE state.</div></div>`;
    el.innerHTML=`<div class="validation-section-title" style="margin-top:11px;border-radius:10px">V1.16.2 FOUNDATION EVIDENCE • QSIG LÀ NGUỒN CHÍNH THỨC</div>${preCard}${cards}`
  }
  function evidenceReportMarkdown(){
    const rows=validationSyncSources(),reviews=['FT','H1','HC'].map(e=>evidenceReviewEngine(e,rows)),lines=[`# Football Edge Evidence Review V1.16.2`,``,`Generated: ${new Date().toISOString()}`,`Total validation rows: ${rows.length}`,``,`## Foundation rules`,``,`- Official automatic evidence comes from QSIG T0 waves only.`,`- One pressure wave = one T0 sample; Validation never re-deduplicates by fixture/score phase.`,`- Active engine thresholds are fixed; historical candidates are SHADOW review only.`,`- Score/GAP is signal strength, not probability.`,`- Handicap benchmark uses absolute LIVE GAP, not total PRE+LIVE GAP.`,`- Handicap 15m outcome is MAINTAINED / DECAYED / REVERSED; no-score change is not automatically a HIT.`,`- Automatic signal evidence and recorded-bet ROI remain separate.`,`- PRESENT FIRST: history measures reliability and never overrides a fresh qualified LIVE state.`,` `];
    for(const r of reviews){lines.push(`## ${r.cfg.label}`,``,`- Decision: **${evidenceDecisionText(r.decision)}**`,`- Official QSIG resolved waves: ${r.samples_n}`,`- Current qualified benchmark: >= ${r.cfg.qualified}; high benchmark: >= ${r.cfg.high}`,`- Baseline holdout: ${evidenceRateLine(r.baseHoldout)}`,`- Candidate holdout: >= ${r.candidate_threshold}; ${evidenceRateLine(r.candidateHoldout)}`,`- Reason: ${r.reason}`,` `)}
    lines.push(`## Recorded-bet performance by engine`,``,`| Engine | Settled | Weighted win | ROI | P/L | Max drawdown |`,`|---|---:|---:|---:|---:|---:|`);for(const engine of ['PRE','FT','H1','HC']){const m=validationMetrics(rows.filter(r=>r.engine===engine));lines.push(`| ${engine} | ${m.bets.length} | ${validationFmt(m.betWinRate)} | ${validationFmt(m.roi)} | ${m.pl} | ${m.maxDrawdown} |`)}return lines.join('\n')
  }
  function evidenceExportReport(){const report=evidenceReportMarkdown();validationDownload(`football-edge-evidence-review-${Date.now()}.md`,'text/markdown;charset=utf-8',report);showToast('ok','Đã xuất Evidence Review','Báo cáo chỉ đề xuất xem xét, không thay đổi engine.')}
  function validationSufficiency(n){return n>=300?['ĐỦ MẠNH','ok']:n>=100?['CÓ THỂ ĐÁNH GIÁ','ok']:n>=30?['CHỈ THAM KHẢO','warn']:['CHƯA ĐỦ MẪU','err']}
  function validationFmt(value,suffix='%'){return value==null?'N/A':`${Number(value).toFixed(1)}${suffix}`}
  /* ===== V1.20.0 VALIDATION MATRIX — ANALYTICS ONLY =====
     Context matrix reads existing Validation/QSIG rows. It never changes active
     thresholds, score, state, QSIG collection, Goal Radar, ranking or background policy. */
  function vmSampleClass(n){return n>=100?'nok':n>=30?'nok':n>=10?'nlow':'nlow'}
  function vmSampleLabel(n){return n>=100?'TỐT':n>=30?'ĐỦ XEM':n>=10?'THẤP':'RẤT THẤP'}
  function vmRateClass(rate,n){if(!n||rate==null)return 'muted';if(n<10)return 'muted';return rate>=70?'good':rate>=55?'warn':'bad'}
  function vmCiText(rows){const valid=(rows||[]).filter(r=>typeof r.hit==='boolean'),hits=valid.filter(r=>r.hit).length,ci=evidenceWilson(hits,valid.length);return valid.length?`${validationFmt(ci.low)}–${validationFmt(ci.high)}`:'—'}
  function vmCell(label,rows){
    const rr=(rows||[]).filter(r=>r.resolution==='RESOLVED'&&typeof r.hit==='boolean'),m=validationMetrics(rr),n=m.auto.length,rate=m.hitRate;
    return {label,n,rate,ci:vmCiText(rr),quality:vmSampleLabel(n),cls:vmRateClass(rate,n)}
  }
  function vmMinuteDefs(engine){return engine==='H1'?[[20,29,'20–29\''],[30,36,'30–36\''],[37,42,'37–42\'']]:engine==='FT'?[[46,54,'46–54\''],[55,69,'55–69\''],[70,80,'70–80\'']]:[[30,44,'30–44\''],[45,64,'45–64\''],[65,80,'65–80\'']]}
  function vmScoreDefs(engine){return engine==='HC'?[[22,29,'GAP 22–29'],[30,39,'GAP 30–39'],[40,999,'GAP 40+']]:engine==='H1'?[[72,78,'READY 72–78'],[79,84,'STRONG 79–84'],[85,999,'85+']]:[[73,79,'READY 73–79'],[80,84,'STRONG 80–84'],[85,999,'85+']]}
  function vmDqValue(r){if(r.live_quality_5!=null)return Number(r.live_quality_5);if(r.app_dq_100!=null)return Number(r.app_dq_100)/20;return null}
  function vmDimensions(engine,rows){
    const resolved=rows.filter(r=>r.engine===engine&&r.sample_type==='AUTO'&&r.source==='QSIG_OFFICIAL'&&r.resolution==='RESOLVED'&&typeof r.hit==='boolean');
    const dims=[];
    dims.push({title:'PHÚT TÍN HIỆU',cells:vmMinuteDefs(engine).map(([lo,hi,label])=>vmCell(label,resolved.filter(r=>r.minute!=null&&Number(r.minute)>=lo&&Number(r.minute)<=hi)))});
    dims.push({title:engine==='HC'?'LIVE GAP':'SCORE BAND',cells:vmScoreDefs(engine).map(([lo,hi,label])=>vmCell(label,resolved.filter(r=>r.signal_score!=null&&Number(r.signal_score)>=lo&&Number(r.signal_score)<=hi)))});
    const stateDefs=engine==='HC'?[['QUALIFIED',r=>/QUALIFIED|READY/i.test(String(r.signal_state||''))],['HIGH',r=>/HIGH|STRONG/i.test(String(r.signal_state||''))]]:[['READY',r=>String(r.signal_state||'').toUpperCase()==='READY'],['STRONG',r=>String(r.signal_state||'').toUpperCase()==='STRONG']];
    dims.push({title:'SIGNAL STATE',cells:stateDefs.map(([label,fn])=>vmCell(label,resolved.filter(fn)))});
    dims.push({title:'DATA QUALITY',cells:[vmCell('DQ <4.0',resolved.filter(r=>{const q=vmDqValue(r);return q!=null&&q<4})),vmCell('DQ 4.0–4.49',resolved.filter(r=>{const q=vmDqValue(r);return q!=null&&q>=4&&q<4.5})),vmCell('DQ 4.5–5.0',resolved.filter(r=>{const q=vmDqValue(r);return q!=null&&q>=4.5}))]});
    dims.push({title:'EVIDENCE AGE',cells:[vmCell('≤60s',resolved.filter(r=>r.evidence_age!=null&&Number(r.evidence_age)<=60)),vmCell('61–120s',resolved.filter(r=>r.evidence_age!=null&&Number(r.evidence_age)>60&&Number(r.evidence_age)<=120)),vmCell('>120s',resolved.filter(r=>r.evidence_age!=null&&Number(r.evidence_age)>120))]});
    const markets=[['HARD AGREE',r=>String(r.market_state||'')==='HARD_AGREEMENT'],['SOFT AGREE',r=>String(r.market_state||'')==='SOFT_AGREEMENT'],['DIVERGENCE',r=>/DIVERGENCE/.test(String(r.market_state||''))],['NO MARKET',r=>!r.market_state||String(r.market_state)==='N/A']];
    dims.push({title:'MARKET CONTEXT',cells:markets.map(([label,fn])=>vmCell(label,resolved.filter(fn)))});
    return {resolved,dims}
  }
  function vmRowsHTML(cells){
    const useful=(cells||[]).filter(c=>c.n>0);if(!useful.length)return '<div class="validation-matrix-empty">Chưa có QSIG resolved cho nhóm này.</div>';
    return `<div class="validation-matrix-row head"><span>NHÓM</span><span>N</span><span>HIT</span><span>CI95</span><span>MẪU</span></div>${useful.map(c=>`<div class="validation-matrix-row ${c.cls}"><span><b>${esc(c.label)}</b></span><span class="${vmSampleClass(c.n)}">${c.n}</span><span class="rate">${validationFmt(c.rate)}</span><span>${esc(c.ci)}</span><span>${esc(c.quality)}</span></div>`).join('')}`
  }
  function renderValidationMatrix(rows){
    const el=$('validationMatrix');if(!el)return;const filter=$('validationEngineFilter')?.value||'ALL',engines=filter==='ALL'?['H1','FT','HC']:(['H1','FT','HC'].includes(filter)?[filter]:[]);
    if(!engines.length){el.innerHTML='<div class="validation-matrix-shell"><div class="validation-matrix-empty">Validation Matrix tự động áp dụng cho H1 / FT / Handicap QSIG. PRE dùng kết quả kèo đã settle ở Evidence Review.</div></div>';return}
    const cards=engines.map(engine=>{const x=vmDimensions(engine,rows),cfg=EVIDENCE_BASELINES[engine],dims=x.dims.map(d=>`<div class="validation-matrix-dim"><div class="validation-matrix-dim-title">${esc(d.title)}</div>${vmRowsHTML(d.cells)}</div>`).join('');return `<div class="validation-matrix-engine"><div class="validation-matrix-engine-title"><b>${engine==='HC'?'⚖️ HANDICAP':engine==='H1'?'🔥 RUNG H1':'🔥 RUNG FT'}</b><span>QSIG resolved n=${x.resolved.length} • benchmark ≥${cfg?.qualified??'-'}</span></div>${dims}</div>`}).join('');
    el.innerHTML=`<div class="validation-matrix-shell"><div class="validation-matrix-head"><div><b>V1.20.0 • VALIDATION MATRIX</b><span>Đọc hiệu quả thực tế theo context. Màu xanh chỉ là cell có hit-rate tốt với mẫu đủ xem; không tự thay threshold hoặc kết luận tương lai.</span></div><div class="validation-matrix-badge">SHADOW ANALYTICS</div></div>${cards}<div class="validation-matrix-note"><b>Calibration reliability:</b> mỗi cell hiển thị N + CI95. N&lt;10 chỉ xem thô; N≥30 bắt đầu có thể so sánh; N≥100 mới được xem là nền tương đối tốt. Các cell khác population không được coi là trực tiếp tương đương nếu sample/context khác nhau.</div></div>`
  }
  /* ===== V1.20.1 FAILURE ANALYSIS — OBSERVATIONAL / SHADOW ONLY =====
     Reads resolved official QSIG and shows where misses cluster. A hotspot is an
     association in the stored sample, NOT a causal diagnosis and never changes engine rules. */
  function faOfficialResolved(engine,rows){return (rows||[]).filter(r=>r.engine===engine&&r.sample_type==='AUTO'&&r.source==='QSIG_OFFICIAL'&&r.resolution==='RESOLVED'&&typeof r.hit==='boolean')}
  function faRate(rows){const rr=rows||[],n=rr.length,misses=rr.filter(r=>r.hit===false).length;return {n,misses,missRate:n?misses/n*100:null}}
  function faBucket(dim,label,rows,base){const x=faRate(rows),sampleShare=base.n?x.n/base.n*100:null,missShare=base.misses?x.misses/base.misses*100:null,lift=base.missRate&&x.missRate!=null?x.missRate/base.missRate:null;let level='normal';if(x.n>=30&&lift!=null&&lift>=1.25)level='hot';else if(x.n>=10&&lift!=null&&lift>=1.08)level='watch';return {dim,label,...x,sampleShare,missShare,lift,level}}
  function faDimensionBuckets(engine,resolved){
    const base=faRate(resolved),out=[];
    for(const [lo,hi,label] of vmMinuteDefs(engine))out.push(faBucket('PHÚT',label,resolved.filter(r=>r.minute!=null&&Number(r.minute)>=lo&&Number(r.minute)<=hi),base));
    for(const [lo,hi,label] of vmScoreDefs(engine))out.push(faBucket(engine==='HC'?'LIVE GAP':'SCORE',label,resolved.filter(r=>r.signal_score!=null&&Number(r.signal_score)>=lo&&Number(r.signal_score)<=hi),base));
    const states=engine==='HC'?[['QUALIFIED',r=>/QUALIFIED|READY/i.test(String(r.signal_state||''))],['HIGH',r=>/HIGH|STRONG/i.test(String(r.signal_state||''))]]:[['READY',r=>String(r.signal_state||'').toUpperCase()==='READY'],['STRONG',r=>String(r.signal_state||'').toUpperCase()==='STRONG']];
    for(const [label,fn] of states)out.push(faBucket('STATE',label,resolved.filter(fn),base));
    const dqs=[['DQ <4.0',r=>{const q=vmDqValue(r);return q!=null&&q<4}],['DQ 4.0–4.49',r=>{const q=vmDqValue(r);return q!=null&&q>=4&&q<4.5}],['DQ 4.5–5.0',r=>{const q=vmDqValue(r);return q!=null&&q>=4.5}]];
    for(const [label,fn] of dqs)out.push(faBucket('DQ',label,resolved.filter(fn),base));
    const evidence=[['≤60s',r=>r.evidence_age!=null&&Number(r.evidence_age)<=60],['61–120s',r=>r.evidence_age!=null&&Number(r.evidence_age)>60&&Number(r.evidence_age)<=120],['>120s',r=>r.evidence_age!=null&&Number(r.evidence_age)>120]];
    for(const [label,fn] of evidence)out.push(faBucket('EVIDENCE',label,resolved.filter(fn),base));
    const markets=[['HARD AGREE',r=>String(r.market_state||'')==='HARD_AGREEMENT'],['SOFT AGREE',r=>String(r.market_state||'')==='SOFT_AGREEMENT'],['DIVERGENCE',r=>/DIVERGENCE/.test(String(r.market_state||''))],['NO MARKET',r=>!r.market_state||String(r.market_state)==='N/A']];
    for(const [label,fn] of markets)out.push(faBucket('MARKET',label,resolved.filter(fn),base));
    const trends=[['ACCELERATING',r=>/ACCELERAT/i.test(String(r.trend||''))],['SUSTAINED',r=>/SUSTAIN/i.test(String(r.trend||''))],['OTHER/NA',r=>!r.trend||(!/ACCELERAT/i.test(String(r.trend))&&!/SUSTAIN/i.test(String(r.trend)))]];
    for(const [label,fn] of trends)out.push(faBucket('TREND',label,resolved.filter(fn),base));
    return {base,buckets:out.filter(x=>x.n>0)}
  }
  function faPct(x){return x==null?'—':`${Number(x).toFixed(1)}%`}
  function faLift(x){return x==null?'—':`${Number(x).toFixed(2)}×`}
  function faHotspotRows(engine,resolved){
    const x=faDimensionBuckets(engine,resolved),eligible=x.buckets.filter(b=>b.n>=10).sort((a,b)=>(Number(b.lift||0)-Number(a.lift||0))||(b.misses-a.misses)||(b.n-a.n));
    return {base:x.base,hotspots:eligible.slice(0,8),all:x.buckets}
  }
  function faRowsHTML(rows){if(!rows.length)return '<div class="failure-empty">Chưa có nhóm nào đạt tối thiểu n=10 để đọc Failure Analysis.</div>';return `<div class="failure-hotspot head"><span>CONTEXT</span><span>N</span><span>MISS</span><span>LIFT</span><span>NHÃN</span></div>${rows.map(x=>`<div class="failure-hotspot ${x.level}"><span><b>${esc(x.dim)} • ${esc(x.label)}</b></span><span>${x.n}</span><span class="miss">${faPct(x.missRate)}</span><span class="lift">${faLift(x.lift)}</span><span><i class="failure-tag ${x.level}">${x.level==='hot'?'HOTSPOT':x.level==='watch'?'WATCH':'NORMAL'}</i></span></div>`).join('')}`}
  function renderFailureAnalysis(rows){
    const el=$('validationFailureAnalysis');if(!el)return;const filter=$('validationEngineFilter')?.value||'ALL',engines=filter==='ALL'?['H1','FT','HC']:(['H1','FT','HC'].includes(filter)?[filter]:[]);
    if(!engines.length){el.innerHTML='<div class="failure-analysis-shell"><div class="failure-empty">Failure Analysis áp dụng cho QSIG H1 / FT / Handicap. PRE tiếp tục đọc bằng kết quả kèo đã settle.</div></div>';return}
    const cards=engines.map(engine=>{const resolved=faOfficialResolved(engine,rows),x=faHotspotRows(engine,resolved),base=x.base,top=x.hotspots[0]||null,topText=top?`${top.dim} • ${top.label}`:'Chưa đủ mẫu';return `<div class="failure-engine"><div class="failure-engine-head"><b>${engine==='HC'?'⚖️ HANDICAP':engine==='H1'?'🔥 RUNG H1':'🔥 RUNG FT'}</b><span>Official QSIG resolved n=${base.n}</span></div><div class="failure-kpis"><div class="failure-kpi"><span>TỔNG MẪU</span><b>${base.n}</b></div><div class="failure-kpi"><span>TỔNG MISS</span><b>${base.misses}</b></div><div class="failure-kpi"><span>MISS BASELINE</span><b>${faPct(base.missRate)}</b></div><div class="failure-kpi"><span>CONTEXT CAO NHẤT</span><b style="font-size:10px">${esc(topText)}</b></div></div><div class="failure-hotspots">${faRowsHTML(x.hotspots)}</div></div>`}).join('');
    el.innerHTML=`<div class="failure-analysis-shell"><div class="failure-analysis-head"><div><b>V1.20.1 • FAILURE ANALYSIS</b><span>Xếp các context có tỷ lệ MISS cao hơn baseline của chính engine. Chỉ dùng QSIG official đã resolve.</span></div><div class="failure-analysis-badge">NO AUTO-TUNING</div></div>${cards}<div class="failure-note"><b>Cách đọc:</b> LIFT = miss-rate của context / miss-rate toàn engine. Ví dụ 1.30× nghĩa là nhóm đó có miss-rate cao hơn baseline khoảng 30% trong mẫu đang có. HOTSPOT chỉ bật khi n≥30 và lift≥1.25; WATCH khi n≥10 và lift≥1.08. Đây là tương quan quan sát, không chứng minh nguyên nhân và không tự thay threshold.</div></div>`
  }
  /* ===== V1.20.2 SHADOW OPTIMIZATION — NEVER WRITES ACTIVE RULES =====
     Chronological 70/30 train/holdout comparison using official resolved QSIG only.
     Candidate policies are predefined and selected on TRAIN only. HOLDOUT is read once
     for comparison. No active threshold, score, ranking, QSIG, Goal Radar or market rule
     is changed by this module. */
  function soOfficial(engine,rows){return (rows||[]).filter(r=>r.engine===engine&&r.sample_type==='AUTO'&&r.source==='QSIG_OFFICIAL'&&r.resolution==='RESOLVED'&&typeof r.hit==='boolean'&&r.signal_score!=null).sort((a,b)=>Number(a.captured_at||0)-Number(b.captured_at||0))}
  function soStats(rows){const rr=rows||[],n=rr.length,hits=rr.filter(r=>r.hit===true).length,rate=n?hits/n*100:null,ci=evidenceWilson(hits,n);return {n,hits,rate,low:ci.low,high:ci.high}}
  function soPassDQ(r){const q=vmDqValue(r);return q==null||q>=4.5}
  function soPassEvidence(r){return r.evidence_age==null||Number(r.evidence_age)<=90}
  function soPassMarket(r){const m=String(r.market_state||'');return !/DIVERGENCE/.test(m)}
  function soApply(rows,cfg){return (rows||[]).filter(r=>Number(r.signal_score)>=Number(cfg.threshold)&&(!cfg.dq||soPassDQ(r))&&(!cfg.evidence||soPassEvidence(r))&&(!cfg.market||soPassMarket(r)))}
  function soPolicyText(p){const bits=[`Score/GAP ≥${p.threshold}`];if(p.dq)bits.push('DQ ≥4.5 (nếu có)');if(p.evidence)bits.push('Evidence ≤90s (nếu có)');if(p.market)bits.push('không Divergence');return bits.join(' • ')}
  function soCandidates(engine){const b=EVIDENCE_BASELINES[engine],out=[{id:'BASE',label:'CURRENT CORE',threshold:b.qualified,dq:false,evidence:false,market:false}];for(let d=1;d<=4;d++)if(b.qualified+d<=b.max)out.push({id:`T${d}`,label:`THRESHOLD +${d}`,threshold:b.qualified+d,dq:false,evidence:false,market:false});out.push({id:'Q',label:'QUALITY GATE',threshold:b.qualified,dq:true,evidence:true,market:false});out.push({id:'M',label:'MARKET GUARD',threshold:b.qualified,dq:false,evidence:false,market:true});out.push({id:'QM',label:'QUALITY + MARKET',threshold:b.qualified,dq:true,evidence:true,market:true});for(let d=1;d<=3;d++)if(b.qualified+d<=b.max)out.push({id:`T${d}QM`,label:`+${d} + QUALITY + MARKET`,threshold:b.qualified+d,dq:true,evidence:true,market:true});return out}
  function soChooseTrain(engine,train){
    const basePolicy=soCandidates(engine)[0],baseRows=soApply(train,basePolicy),base=soStats(baseRows),cands=soCandidates(engine),minN=Math.max(20,Math.floor(base.n*.35));let best={policy:basePolicy,stats:base,retention:1,score:(base.low??-1)};
    for(const p of cands.slice(1)){const rr=soApply(train,p),s=soStats(rr),ret=base.n?s.n/base.n:0;if(s.n<minN||ret<.35)continue;const score=(s.low??-1)+Math.min(s.n,500)/100000;if(score>best.score+.0001){best={policy:p,stats:s,retention:ret,score}}}
    return {basePolicy,base,best}
  }
  function soReviewEngine(engine,rows){
    const samples=soOfficial(engine,rows),cut=Math.max(1,Math.floor(samples.length*.7)),train=samples.slice(0,cut),hold=samples.slice(cut),picked=soChooseTrain(engine,train),baseHold=soStats(soApply(hold,picked.basePolicy)),candHold=soStats(soApply(hold,picked.best.policy)),retention=baseHold.n?candHold.n/baseHold.n:0,delta=candHold.rate!=null&&baseHold.rate!=null?candHold.rate-baseHold.rate:null;
    let verdict='COLLECT',reason=`Cần thêm ${Math.max(0,100-samples.length)} QSIG resolved trước khi đọc shadow candidate.`;
    if(samples.length>=100&&samples.length<300){verdict='HYPOTHESIS';reason=`QSIG n=${samples.length}; candidate được chọn trên TRAIN nhưng chưa đạt cổng n=300 để đánh giá holdout mạnh.`}
    else if(samples.length>=300){const changed=picked.best.policy.id!=='BASE',supported=changed&&candHold.n>=30&&baseHold.n>=30&&retention>=.35&&delta!=null&&delta>=3&&(candHold.low??0)>=(baseHold.low??0);if(supported){verdict='REVIEW';reason=`Shadow holdout +${delta.toFixed(1)} điểm %, giữ ${(retention*100).toFixed(0)}% mẫu; Wilson lower-bound không giảm. Chỉ đủ điều kiện REVIEW, chưa áp dụng.`}else{verdict='KEEP';reason=!changed?'TRAIN vẫn chọn CURRENT CORE.':'Candidate chưa đồng thời đạt Δ≥3 điểm %, holdout n≥30, retention≥35% và Wilson lower-bound không giảm.'}}
    return {engine,samples_n:samples.length,train_n:train.length,hold_n:hold.length,baseline:picked.basePolicy,candidate:picked.best.policy,baseTrain:picked.base,bestTrain:picked.best.stats,baseHold,candHold,retention,delta,verdict,reason}
  }
  /* ===== V1.21.0 ADAPTIVE LIVE STATE V2 — GUARDED PRODUCTION OVERLAY =====
     Stable H1/FT/HC engines remain untouched. Adaptive V2 is allowed to affect ONLY
     Master Opportunity TOP eligibility / Smart Follow selection. It can never promote
     a signal above the core state. It may guard a READY/STRONG card only when a
     predefined SHADOW policy passes strict out-of-sample certification. If certification
     is absent, the exact V1.20.2 core behaviour is used as fallback. */
  function alvEnabled(){try{return localStorage.getItem(FE_ADAPTIVE_KEY)!=='0'}catch{return true}}
  function alvSetEnabled(on){try{localStorage.setItem(FE_ADAPTIVE_KEY,on?'1':'0')}catch{};FE_ADAPTIVE_CACHE.at=0;try{renderMasterOpportunityBoard()}catch(_){};try{renderValidation()}catch(_){}}
  function alvHoldoutSlices(engine,rows,policy){
    const samples=soOfficial(engine,rows),cut=Math.max(1,Math.floor(samples.length*.7)),hold=samples.slice(cut),mid=Math.floor(hold.length/2),base=soCandidates(engine)[0];
    const mk=rr=>{const b=soStats(soApply(rr,base)),c=soStats(soApply(rr,policy));return {base:b,cand:c,delta:c.rate!=null&&b.rate!=null?c.rate-b.rate:null,retention:b.n?c.n/b.n:0}};
    return {first:mk(hold.slice(0,mid)),second:mk(hold.slice(mid))};
  }
  function alvPolicyReview(engine,rows){
    const x=soReviewEngine(engine,rows),p=x.candidate,slices=alvHoldoutSlices(engine,rows,p),changed=p?.id&&p.id!=='BASE';
    const stableHalf=z=>z.base.n>=12&&z.cand.n>=12&&z.retention>=.30&&z.delta!=null&&z.delta>=-1;
    const certified=changed&&x.verdict==='REVIEW'&&x.samples_n>=300&&x.baseHold.n>=30&&x.candHold.n>=30&&x.retention>=.35&&x.delta!=null&&x.delta>=3&&(x.candHold.low??0)>=(x.baseHold.low??0)&&stableHalf(slices.first)&&stableHalf(slices.second);
    const reason=certified?`Holdout +${x.delta.toFixed(1)} pp • retention ${(x.retention*100).toFixed(0)}% • 2 nửa holdout không suy giảm >1 pp.`:x.verdict!=='REVIEW'?`Shadow hiện là ${soVerdictText(x.verdict)}.`:!changed?'Candidate vẫn là CURRENT CORE.':'Chưa vượt cổng Adaptive: n≥300, holdout n≥30, Δ≥3 pp, retention≥35%, Wilson không giảm và ổn định theo thời gian.';
    return {...x,certified,reason,slices};
  }
  function alvReviews(force=false){
    let rows=[];try{rows=validationSyncSources()}catch(_){rows=[]}
    const sig=`${rows.length}:${rows.length?Number(rows[rows.length-1]?.captured_at||0):0}`;
    if(!force&&FE_ADAPTIVE_CACHE.at&&Date.now()-FE_ADAPTIVE_CACHE.at<FE_ADAPTIVE_CACHE.ttl&&FE_ADAPTIVE_CACHE.rowsSig===sig)return FE_ADAPTIVE_CACHE.reviews;
    const reviews={};for(const e of ['H1','FT','HC'])reviews[e]=alvPolicyReview(e,rows);
    FE_ADAPTIVE_CACHE.at=Date.now();FE_ADAPTIVE_CACHE.rowsSig=sig;FE_ADAPTIVE_CACHE.reviews=reviews;return reviews;
  }
  function alvLiveMetrics(engine,it){
    const e=it?.eval||{},s=it?.latest||{};
    if(engine==='HC')return {value:Math.abs(Number(e.states?.liveGap||0)),dq:Number(e.dq),evidence:Number(e.evidenceAge?.direction),market:String(e.marketFit?.level||''),coreState:String(e.state||'')};
    const qa=engine==='H1'?qsigAssessH1(it,s):qsigAssessFT(it,s);
    return {value:Number(e.score),dq:Number(e.quality),evidence:Number(qa?.evidenceAge),market:feMasterMarketRank(it,engine).label,coreState:String(it?.state||'')};
  }
  function alvLiveDecision(engine,it){
    if(!it)return {mode:'NO_ITEM',allowTop:true,certified:false,label:'NO ITEM'};
    if(!alvEnabled())return {mode:'DISABLED',allowTop:true,certified:false,label:'ADAPTIVE OFF'};
    let r=null;try{r=alvReviews()[engine]}catch(_){}
    if(!r?.certified)return {mode:'FALLBACK',allowTop:true,certified:false,label:'CORE FALLBACK',review:r||null};
    const p=r.candidate,m=alvLiveMetrics(engine,it),fails=[];
    if(!Number.isFinite(m.value)||m.value<Number(p.threshold))fails.push(`${engine==='HC'?'GAP':'Score'} < ${p.threshold}`);
    if(p.dq&&(!Number.isFinite(m.dq)||m.dq<4.5))fails.push('DQ <4.5');
    if(p.evidence&&(!Number.isFinite(m.evidence)||m.evidence>90))fails.push('Evidence >90s');
    if(p.market&&engine==='HC'&&/DIVERGENCE/.test(String(m.market||'')))fails.push('Market Divergence');
    const coreReady=engine==='HC'?/_STRONG$/.test(m.coreState):['READY','STRONG'].includes(m.coreState);
    const pass=fails.length===0;
    return {mode:pass?'CONFIRMED':'GUARD',allowTop:!coreReady||pass,certified:true,label:pass?'ADAPTIVE CONFIRMED':'ADAPTIVE GUARD',policy:p,review:r,metrics:m,fails};
  }
  function alvChip(d){if(!d)return '';const cls=d.mode==='CONFIRMED'?'confirmed':d.mode==='GUARD'?'guard':'fallback';const t=d.mode==='CONFIRMED'?'✓ ADAPTIVE':d.mode==='GUARD'?'⚠ ADAPTIVE GUARD':d.mode==='DISABLED'?'ADAPTIVE OFF':'CORE FALLBACK';return `<span class="adaptive-master-chip ${cls}">${esc(t)}</span>`}
  function renderAdaptiveLiveState(rows){
    const el=$('validationAdaptiveLive');if(!el)return;let sourceRows=[];try{sourceRows=validationSyncSources()}catch(_){sourceRows=Array.isArray(rows)?rows:[]}const reviews={};for(const e of ['H1','FT','HC'])reviews[e]=alvPolicyReview(e,sourceRows);FE_ADAPTIVE_CACHE.at=Date.now();FE_ADAPTIVE_CACHE.rowsSig=`${sourceRows.length}:${sourceRows.length?Number(sourceRows[sourceRows.length-1]?.captured_at||0):0}`;FE_ADAPTIVE_CACHE.reviews=reviews;
    const cards=['H1','FT','HC'].map(engine=>{const r=reviews[engine],active=alvEnabled()&&r.certified,cls=active?'active':'fallback',policy=r.candidate?soPolicyText(r.candidate):'CURRENT CORE',delta=r.delta==null?'—':`${r.delta>=0?'+':''}${r.delta.toFixed(1)} pp`;return `<div class="adaptive-live-engine"><div class="adaptive-live-engine-head"><b>${engine==='HC'?'⚖️ HANDICAP':engine==='H1'?'🔥 RUNG H1':'🔥 RUNG FT'}</b><span class="adaptive-live-pill ${cls}">${active?'ACTIVE GUARD':'CORE FALLBACK'}</span></div><div class="adaptive-live-grid"><div class="adaptive-live-box"><span>POLICY</span><b>${esc(policy)}</b></div><div class="adaptive-live-box"><span>QSIG</span><b>n=${r.samples_n}</b></div><div class="adaptive-live-box"><span>HOLDOUT Δ</span><b>${esc(delta)}</b></div><div class="adaptive-live-box"><span>RETENTION</span><b>${r.baseHold.n?Math.round(r.retention*100)+'%':'—'}</b></div></div><div class="adaptive-live-note">${esc(r.reason)}</div></div>`}).join('');
    el.innerHTML=`<div class="adaptive-live-shell"><div class="adaptive-live-head"><div><b>V1.21.0 • ADAPTIVE LIVE STATE V2</b><span>Guarded production overlay. Không sửa score/state của H1/FT/HC; chỉ có thể chặn một READY/STRONG khỏi TOP nếu policy SHADOW đã được chứng nhận out-of-sample.</span></div><div class="adaptive-live-badge">NO PROMOTION</div></div><div class="adaptive-live-controls"><label><input id="adaptiveLiveEnabled" type="checkbox" ${alvEnabled()?'checked':''}/> ADAPTIVE GUARD</label><small>OFF = hành vi Master Ranking V1.20.2 nguyên bản.</small></div><div class="adaptive-live-engines">${cards}</div><div class="adaptive-live-note"><b>Fail-safe:</b> chưa đủ bằng chứng → CORE FALLBACK. Adaptive không tăng cấp tín hiệu, không thay QSIG, không đổi Goal Radar và không ghi threshold mới vào core. Smart Follow chỉ kế thừa TOP sau guard.</div></div>`;
    $('adaptiveLiveEnabled')?.addEventListener('change',e=>alvSetEnabled(!!e.target.checked));
  }

  function soFmtRate(s){return !s?.n?'n=0':`n=${s.n} • ${validationFmt(s.rate)} • CI95 ${validationFmt(s.low)}–${validationFmt(s.high)}`}
  function soVerdictText(v){return ({COLLECT:'THU THÊM MẪU',HYPOTHESIS:'SHADOW HYPOTHESIS',KEEP:'GIỮ CORE',REVIEW:'ĐỦ ĐIỀU KIỆN REVIEW'})[v]||v}
  function renderShadowOptimization(rows){
    const el=$('validationShadowOptimization');if(!el)return;const filter=$('validationEngineFilter')?.value||'ALL',engines=filter==='ALL'?['H1','FT','HC']:(['H1','FT','HC'].includes(filter)?[filter]:[]);if(!engines.length){el.innerHTML='<div class="shadow-opt-shell"><div class="shadow-opt-empty">Shadow Optimization áp dụng cho QSIG H1 / FT / Handicap. PRE vẫn giữ workflow riêng.</div></div>';return}
    const cards=engines.map(engine=>{const x=soReviewEngine(engine,rows),cls=({COLLECT:'collect',HYPOTHESIS:'hypothesis',KEEP:'keep',REVIEW:'review'})[x.verdict]||'collect',delta=x.delta==null?'—':`${x.delta>=0?'+':''}${x.delta.toFixed(1)} pp`,ret=x.baseHold.n?`${(x.retention*100).toFixed(0)}%`:'—',deltaCls=x.delta==null?'muted':x.delta>=3?'good':x.delta<0?'bad':'muted';return `<div class="shadow-opt-engine"><div class="shadow-opt-engine-head"><b>${engine==='HC'?'⚖️ HANDICAP':engine==='H1'?'🔥 RUNG H1':'🔥 RUNG FT'}</b><span>Official QSIG n=${x.samples_n} • train ${x.train_n} / holdout ${x.hold_n}</span></div><div class="shadow-opt-grid"><div class="shadow-opt-box"><span>OLD CORE • PRODUCTION</span><b>${esc(soPolicyText(x.baseline))}</b><small>Không đổi. Đây vẫn là rule đang vận hành app.</small></div><div class="shadow-opt-box"><span>SHADOW CANDIDATE • TRAIN CHỌN</span><b>${esc(x.candidate.label)} — ${esc(soPolicyText(x.candidate))}</b><small>Chỉ tính song song; không có quyền phát tín hiệu production.</small></div></div><div class="shadow-opt-compare head"><span>HOLDOUT</span><span>N</span><span>HIT</span><span>CI95 LOW</span><span>RETENTION</span></div><div class="shadow-opt-compare"><span><b>OLD CORE</b></span><span>${x.baseHold.n}</span><span>${validationFmt(x.baseHold.rate)}</span><span>${validationFmt(x.baseHold.low)}</span><span>100%</span></div><div class="shadow-opt-compare"><span><b>SHADOW</b></span><span>${x.candHold.n}</span><span class="${deltaCls}">${validationFmt(x.candHold.rate)}</span><span>${validationFmt(x.candHold.low)}</span><span>${ret}</span></div><div class="shadow-opt-verdict"><span class="shadow-opt-pill ${cls}">${soVerdictText(x.verdict)}</span><div><b>Δ holdout: ${delta}</b><br>${esc(x.reason)}</div></div></div>`}).join('');
    el.innerHTML=`<div class="shadow-opt-shell"><div class="shadow-opt-head"><div><b>V1.20.2 • SHADOW OPTIMIZATION</b><span>OLD CORE vs candidate được chọn trên TRAIN 70%; HOLDOUT 30% chỉ dùng để kiểm chứng. Không có auto-tuning.</span></div><div class="shadow-opt-badge">PRODUCTION LOCKED</div></div>${cards}<div class="shadow-opt-note"><b>Nguyên tắc:</b> candidate chỉ được chọn từ tập policy định nghĩa trước (threshold chặt hơn, quality gate, market guard). HOLDOUT không được dùng để chọn candidate. Nhãn REVIEW chỉ có nghĩa “đáng xem xét ở release sau”, không có nghĩa tự thay core. Ranking Master Board và Goal Radar production vẫn giữ nguyên trong V1.20.2.</div></div>`
  }
  function renderValidation(){
    const el=$('validationDashboard');if(!el)return;const rows=validationFiltered(),m=validationMetrics(rows),suf=validationSufficiency(m.resolved),by={};
    for(const engine of ['PRE','FT','H1','HC']){const rr=rows.filter(r=>r.engine===engine);if(!rr.length)continue;by[engine]=validationMetrics(rr)}
    const breakdown=Object.entries(by).map(([engine,x])=>`<div class="validation-grid-row"><span><b>${engine}</b></span><span>${x.auto.length?`${x.hits}/${x.auto.length} • ${validationFmt(x.hitRate)}`:'—'}</span><span>${x.bets.length?`${x.bets.length} • ${validationFmt(x.betWinRate)}`:'—'}</span><span>${x.bets.length?validationFmt(x.roi):'—'}</span></div>`).join('');
    const bandRows=[];for(const engine of ['PRE','FT','H1','HC']){const defs=engine==='HC'?[[0,21,'LIVE GAP 0–21'],[22,29,'LIVE GAP 22–29'],[30,Infinity,'LIVE GAP 30+']]:[[0,59,'0–59'],[60,69,'60–69'],[70,79,'70–79'],[80,Infinity,'80+']];for(const [lo,hi,label] of defs){const rr=rows.filter(r=>r.engine===engine&&r.resolution==='RESOLVED'&&r.signal_score!=null&&Number(r.signal_score)>=lo&&Number(r.signal_score)<=hi);if(!rr.length)continue;const x=validationMetrics(rr);bandRows.push(`<div class="validation-grid-row"><span><b>${engine}</b> ${label}</span><span>${rr.length}</span><span>${x.auto.length?validationFmt(x.hitRate):'—'}</span><span>${x.bets.length?validationFmt(x.betWinRate):'—'}</span></div>`)}}
    const recent=[...rows].sort((a,b)=>Number(b.captured_at||0)-Number(a.captured_at||0)).slice(0,30).map(r=>{const resolved=r.resolution==='RESOLVED',good=r.sample_type==='AUTO'?r.hit:Number(r.profit||0)>0,label=!resolved?r.resolution:r.sample_type==='AUTO'?r.outcome:r.outcome||'—';return `<div class="validation-record"><div class="validation-record-top"><b>${esc(r.engine)} • ${esc(r.home||'?')} vs ${esc(r.away||'?')}</b><span class="validation-pill ${resolved?(good?'hit':'miss'):''}">${esc(label||'OPEN')}</span></div><div>${esc(r.sample_type)} • FX ${esc(r.fixture_id??'-')} • ${esc(r.market_type||r.target||'-')} ${r.selection?`• ${esc(r.selection)}`:''}${r.line!=null?` ${Number(r.line)>0?'+':''}${esc(r.line)}`:''}</div><div class="tiny">${r.minute!=null?`M${esc(r.minute)} • `:''}${r.signal_score!=null?`Score/GAP ${esc(r.signal_score)} • `:''}${esc(r.signal_state||'')} • ${r.captured_at?esc(new Date(Number(r.captured_at)).toLocaleString('vi-VN')):''}</div></div>`}).join('');
    el.innerHTML=`<div class="validation-kpis"><div class="validation-kpi"><span>TỔNG MẪU</span><b>${rows.length}</b></div><div class="validation-kpi"><span>ĐÃ CÓ KẾT QUẢ</span><b>${m.resolved}</b></div><div class="validation-kpi"><span>QSIG HIT RATE</span><b>${validationFmt(m.hitRate)}</b></div><div class="validation-kpi"><span>ROI KÈO THẬT</span><b class="${plClass(m.pl)}">${validationFmt(m.roi)}</b></div><div class="validation-kpi"><span>MAX DRAWDOWN</span><b>${vnd(m.maxDrawdown)}</b></div></div><div class="status ${suf[1]}"><b>${suf[0]}</b> • resolved n=${m.resolved} • Bet weighted win ${validationFmt(m.betWinRate)} • P/L ${m.pl>0?'+':''}${vnd(m.pl)}</div><div class="validation-section"><div class="validation-section-title">THEO ENGINE — QSIG HIT / KÈO WIN / ROI</div><div class="validation-grid-row head"><span>ENGINE</span><span>AUTO</span><span>KÈO</span><span>ROI</span></div>${breakdown||'<div class="bet-empty">Chưa có dữ liệu.</div>'}</div><div class="validation-section"><div class="validation-section-title">ĐỘ MẠNH TÍN HIỆU — SCORE / LIVE GAP KHÔNG PHẢI XÁC SUẤT</div><div class="validation-grid-row head"><span>ENGINE / BAND</span><span>N</span><span>QSIG HIT</span><span>KÈO WIN</span></div>${bandRows.join('')||'<div class="bet-empty">Cần mẫu đã có kết quả và có Score/GAP.</div>'}</div><div class="validation-section"><div class="validation-section-title">30 MẪU GẦN NHẤT</div>${recent||'<div class="bet-empty">Chưa có mẫu. Hãy ghi nhận kèo hoặc chạy LIVE WATCH.</div>'}</div>`;
    status($('validationStatus'),`Kho V1.16.2: ${validationState.rows.length} mẫu • bộ lọc hiện tại ${rows.length} • ${suf[0]}`,suf[1]);renderValidationMatrix(rows);renderFailureAnalysis(rows);renderShadowOptimization(rows);renderAdaptiveLiveState(rows);renderEntryValidation();renderEntryCalibration();renderEvidenceReview(rows)
  }
  function validationDownload(name,type,data){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([data],{type}));a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500)}
  function validationExportJSON(){
    validationSyncSources();const payload={schema:'FOOTBALL_EDGE_VALIDATION_V1.16.2',app_version:APP_VERSION,exported_at:new Date().toISOString(),
      rows:validationState.rows,qsig:{FT:qsigRead('FT'),H1:qsigRead('H1'),HC:qsigRead('HC')}};
    validationDownload(`football-edge-validation-${Date.now()}.json`,'application/json',JSON.stringify(payload,null,2));showToast('ok','Đã xuất Validation + QSIG JSON',`${validationState.rows.length} dòng • QSIG ${payload.qsig.FT.length+payload.qsig.H1.length+payload.qsig.HC.length}`)
  }
  function validationExportCSV(){
    const rows=validationFiltered(),cols=['id','engine','sample_type','source','fixture_id','league','home','away','captured_at','minute','signal_state','signal_score','live_gap','total_gap','core','football_core','app_dq_100','live_quality_5','coverage','integrity','freshness_age_sec','data_tier','evidence_age','trend','market_state','target','market_type','selection','line','odds','stake','resolution','outcome','hit','profit','profit_unit'];
    const q=v=>`"${String(v??'').replaceAll('"','""')}"`;validationDownload(`football-edge-validation-${Date.now()}.csv`,'text/csv;charset=utf-8','\ufeff'+[cols.join(','),...rows.map(r=>cols.map(c=>q(r[c])).join(','))].join('\n'));showToast('ok','Đã xuất Validation CSV',`${rows.length} mẫu theo bộ lọc`)
  }
  async function validationImport(file){
  try{
    const x=JSON.parse(await file.text()),rows=Array.isArray(x)?x:x?.rows;if(!Array.isArray(rows))throw new Error('File không có mảng rows hợp lệ.');
    const map=new Map(validationState.rows.map(r=>[String(r.id),r]));let added=0;for(const raw of rows){if(!raw||typeof raw!=='object')continue;const id=String(raw.id||`IMPORT-${Date.now()}-${added}`);map.set(id,{...raw,id,source:raw.source||'IMPORT'});added++}
    validationState.rows=[...map.values()].sort((a,b)=>Number(a.captured_at||0)-Number(b.captured_at||0)).slice(-VALIDATION_MAX);validationWrite();
    if(x?.qsig&&typeof x.qsig==='object')for(const engine of ['FT','H1','HC'])if(Array.isArray(x.qsig[engine]))qsigWrite(engine,x.qsig[engine]);
    renderValidation();showToast('ok','Đã nhập Validation + QSIG',`${added} dòng validation được đọc`)
  }catch(e){showToast('err','Không nhập được Validation',e.message)}finally{if($('validationImportFile'))$('validationImportFile').value=''}
}
  function renderBetTracker(){
    renderBetMiniKpis();const open=betState.bets.filter(b=>b.status==='OPEN'),settled=betState.bets.filter(b=>b.status==='SETTLED').sort((a,b)=>new Date(b.settlement?.settled_at||0)-new Date(a.settlement?.settled_at||0));
    const active=$('activeBetList'),hist=$('settledBetList');if(active)active.innerHTML=open.length?open.map(renderOpenTicket).join(''):'<div class="bet-empty">Chưa có kèo đang chạy. Sau khi GPT + screenshot chốt VÀO, bấm <b>GHI NHẬN KÈO</b>.</div>';if(hist)hist.innerHTML=settled.length?settled.map(renderSettledTicket).join(''):'<div class="bet-empty">Chưa có kèo đã xác nhận kết quả.</div>';
    status($('betTrackStatus'),open.length?`${open.length} kèo đang theo dõi • AUTO ${$('betAutoRefresh')?.checked?'90s':'TẮT'} • API chỉ refresh fixture của kèo đang mở.`:'Chưa có kèo đang theo dõi.','ok');renderDashboard();if(betState.tab==='validation')renderValidation();bindBetTicketActions()
  }
  function bindBetTicketActions(){document.querySelectorAll('[data-action][data-id]').forEach(btn=>btn.onclick=async()=>{const id=btn.dataset.id,a=btn.dataset.action;if(a==='refresh')await refreshOneBet(id);else if(a==='delete')deleteBet(id);else if(a==='edit')openBetForm({editId:id});else if(a==='reopen')reopenBet(id);else if(a==='settle'){const sel=document.querySelector(`select[data-result="${CSS.escape(id)}"]`);confirmBetSettlement(id,sel?.value)}})}
  function setBetTab(tab){betState.tab=tab;document.querySelectorAll('#betTabs button').forEach(b=>b.classList.toggle('active',b.dataset.btab===tab));['active','history','dashboard','validation'].forEach(x=>$(`betPane${x[0].toUpperCase()+x.slice(1)}`)?.classList.toggle('hidden',x!==tab));if(tab==='dashboard')renderDashboard();if(tab==='validation')renderValidation()}
  function scheduleBetAutoRefresh(){clearInterval(betState.timer);betState.timer=setInterval(()=>{if(document.visibilityState==='visible'&&$('betAutoRefresh')?.checked&&betState.bets.some(b=>b.status==='OPEN'))refreshOpenBets(true)},90000)}

  $('betMarketType')?.addEventListener('change',()=>{updateBetSelectionOptions();syncBetSettlementBasis(true)});
  $('betSettlementBasis')?.addEventListener('change',()=>{syncBetSettlementBasis(false);updateBetLockPreview()});
  ['betLine','betPrice','betStake','betOddsFormat','betEngineTag'].forEach(id=>$(id)?.addEventListener('input',()=>{if(id==='betPrice'){const p=Number($('betPrice')?.value);if(p>0&&p<=1&&$('betOddsFormat'))$('betOddsFormat').value='HK'}updateBetLockPreview()}));
  $('betApiPick')?.addEventListener('change',e=>{
    if(e.target.value!=='')applyBetApiCandidate(e.target.value);
  });
  $('refreshBetMarketsBtn')?.addEventListener('click',()=>loadBetApiCandidates(true));
  $('betFixtureId')?.addEventListener('change',async e=>{
    const fid=Number(e.target.value);
    betState.marketCandidates=[];
    renderBetApiCandidates();
    if(!fid)return;
    try{
      const f=await resolveBetFixture(fid);
      betState.draftFixture=f;
      $('betFixturePreview').innerHTML=trackerFixtureText(f);
      await loadBetApiCandidates(true);
    }catch(err){
      renderBetApiCandidates('Fixture không hợp lệ hoặc API chưa trả dữ liệu: '+err.message);
    }
  });
  $('newBetBtn')?.addEventListener('click',()=>openBetForm({}));
  $('quickRecordBetBtn')?.addEventListener('click',()=>{setBetTab('active');$('betTrackerCard')?.scrollIntoView({behavior:'smooth',block:'start'});setTimeout(()=>openBetForm({fromFinal:true}),250)});
  $('cancelBetBtn')?.addEventListener('click',closeBetForm);
  $('refreshBetsBtn')?.addEventListener('click',()=>refreshOpenBets(false));
  $('betAutoRefresh')?.addEventListener('change',e=>{saveBetSettings({auto:!!e.target.checked});renderBetTracker()});
  $('validationEngineFilter')?.addEventListener('change',renderValidation);
  $('validationSourceFilter')?.addEventListener('change',renderValidation);
  $('validationExportJsonBtn')?.addEventListener('click',validationExportJSON);
  $('validationExportCsvBtn')?.addEventListener('click',validationExportCSV);
  $('evidenceExportBtn')?.addEventListener('click',evidenceExportReport);
  $('validationImportFile')?.addEventListener('change',e=>{const f=e.target.files?.[0];if(f)validationImport(f)});
  document.querySelectorAll('#betTabs button').forEach(b=>b.addEventListener('click',()=>setBetTab(b.dataset.btab)));
  $('saveBetBtn')?.addEventListener('click',async()=>{
    try{
      const fid=Number($('betFixtureId').value);if(!fid)throw new Error('Chưa có Fixture ID.');
      const editing=betState.editingId?betById(betState.editingId):null;
      const f=editing?(editing.latest||await resolveBetFixture(fid)):await resolveBetFixture(fid);if(!f)throw new Error('Không lấy được thông tin fixture.');
      const market=$('betMarketType').value,selection=$('betSelection').value,lineRaw=$('betLine').value.trim(),line=marketNeedsLine(market)?Number(lineRaw):null,price=Number($('betPrice').value),fmt=$('betOddsFormat').value,stake=Number($('betStake').value),conf=$('betConfidence').value,basis=$('betSettlementBasis').value||defaultBasisForMarket(market);
      if(marketNeedsLine(market)&&(lineRaw===''||!Number.isFinite(line)))throw new Error('Chưa nhập line.');if(!Number.isFinite(price)||price<=0)throw new Error('Giá không hợp lệ.');if(fmt==='DEC'&&price<=1)throw new Error('Giá Decimal phải > 1.00. Nếu giá kiểu 0.88 hãy chọn Hong Kong.');if(!Number.isFinite(stake)||stake<=0)throw new Error('Tiền cược phải > 0.');
      if(['AH_H1','OU_H1'].includes(market)&&basis!=='H1_SEGMENT')throw new Error('Kèo H1 phải dùng H1 SEGMENT.');
      if(['AH_H2','OU_H2'].includes(market)&&basis!=='H2_SEGMENT')throw new Error('Kèo H2 phải dùng H2 SEGMENT.');
      const lb=Number(state.lastBundle?.meta?.fixture_id)===fid?state.lastBundle:null,validationContext=lb?{dq:lb.coverage?.score??null,coverage:lb.coverage?.coverage_score??null,integrity:lb.coverage?.integrity_score??null,freshness:lb.coverage?.freshness_score??null,cache_status:lb.normalized?.cache_status??null}:editing?.validation_context||null;
      const engineTag=$('betEngineTag').value,deepTag=$('betDeepTag').value.trim(),source=betState.draftSource||editing?.draft_source||'MANUAL',resolvedEngine=resolvedEngineForTicket(market,engineTag,source,betState.modelContext||editing?.model_context);
      const fields={market_type:market,selection,line,price,odds_format:fmt,stake,settlement_basis:basis};

      if(editing){
        const before={market_type:editing.market_type,selection:editing.selection,line:editing.line,price:editing.price,odds_format:editing.odds_format,stake:editing.stake,settlement_basis:ticketBasis(editing),engine_tag:editing.engine_tag,note:editing.note};
        Object.assign(editing,{market_type:market,selection,line,price,odds_format:fmt,stake,confidence:conf===''?null:Number(conf),engine_tag:engineTag,resolved_engine:resolvedEngine,settlement_basis:basis,deep_tag:deepTag,note:$('betNote').value.trim(),draft_source:source,validation_context:validationContext,entry_lock:betEntryLockFrom(f,fields,editing.entry_lock),ticket_version:'ENTRY_LOCK_V2'});
        editing.audit_trail=[...(editing.audit_trail||[]),{at:new Date().toISOString(),type:'EDIT_TICKET',before,after:{...fields,engine_tag:engineTag,resolved_engine:resolvedEngine}}].slice(-30);
        if(editing.status==='SETTLED'&&editing.settlement?.result){
          const affectsResult=before.market_type!==market||before.selection!==selection||String(before.line??'')!==String(line??'')||before.settlement_basis!==basis;
          if(affectsResult){editing.audit_trail.push({at:new Date().toISOString(),type:'REOPEN_AFTER_RESULT_AFFECTING_EDIT',previous_settlement:editing.settlement});editing.status='OPEN';delete editing.settlement;editing.suggestion=null}
          else{editing.settlement.profit=outcomeProfit(editing.settlement.result,stake,price,fmt);editing.settlement.corrected_at=new Date().toISOString();editing.settlement.settlement_basis=basis}
        }
        saveBets();closeBetForm();validationSyncSources();renderBetTracker();showToast('ok','Đã chỉnh ticket',editing.status==='OPEN'?'Entry gốc được giữ. Nếu line/basis đổi, app đã mở lại để settle lại cho đúng.':'Entry minute/score gốc được giữ; P/L đã cập nhật theo giá/vốn mới.');return;
      }

      const dup=betDuplicateCandidate(fid,market,selection,line);if(dup&&!confirm(`Đã có một kèo tương tự được ghi gần đây:\n${ticketMarketText(dup)}\n\nVẫn tạo thêm một ticket?`))return;
      const lock=betEntryLockFrom(f,fields,null);
      const b={id:`BET-${Date.now()}-${Math.random().toString(36).slice(2,6)}`,ticket_version:'ENTRY_LOCK_V2',fixture_id:fid,league:f.league,country:f.country,home:f.home,away:f.away,home_id:f.home_id,away_id:f.away_id,kickoff_vn:f.kickoff_vn,market_type:market,selection,line,price,odds_format:fmt,stake,confidence:conf===''?null:Number(conf),engine_tag:engineTag,resolved_engine:resolvedEngine,settlement_basis:basis,draft_source:source,model_context:betState.modelContext||null,deep_tag:deepTag,validation_context:validationContext,note:$('betNote').value.trim(),created_at:lock.locked_at,entry_minute:lock.minute,entry_score:lock.score,entry_lock:lock,audit_trail:[{at:lock.locked_at,type:'LOCK_ENTRY',source,engine:resolvedEngine}],status:'OPEN',latest:{...f,updated_at:new Date().toISOString()}};
      betState.bets.unshift(b);saveBets();closeBetForm();validationSyncSources();renderBetTracker();showToast('ok','ENTRY LOCKED',`${ticketMarketText(b)} • ${vnd(stake)} • ${b.entry_minute??'-'}' ${b.entry_score?.home??'-'}-${b.entry_score?.away??'-'}`)
    }catch(e){showToast('err','Chưa ghi nhận được kèo',e.message)}
  });

  loadBets();validationState.rows=validationRead();const bs=loadBetSettings();if($('betAutoRefresh'))$('betAutoRefresh').checked=bs.auto!==false;updateBetSelectionOptions();validationSyncSources();renderBetTracker();scheduleBetAutoRefresh();
  setTimeout(()=>validationArchiveHydrate().then(()=>{validationSyncSources();renderBetTracker();storageHealthRefresh()}),150);
  $('storageCleanupBtn')?.addEventListener('click',()=>storageCleanupTransient({toast:true}));
  setTimeout(storageHealthRefresh,500);


  // V1.4 — iPhone web-app helper + safe service-worker registration.
  const installBtn=$('installHelpBtn'),installSheet=$('installSheet'),installClose=$('installCloseBtn'),installNote=$('installNote');
  const standalone=window.matchMedia?.('(display-mode: standalone)')?.matches || window.navigator.standalone===true;
  if(installBtn){
    if(standalone) installBtn.style.display='none';
    installBtn.addEventListener('click',()=>{
      if(location.protocol==='file:'){
        installNote.innerHTML='<b>Bản HTML đang chạy trực tiếp từ Files.</b> Để cài thành biểu tượng app độc lập trên iPhone, cần mở bản PWA bằng một địa chỉ <b>https://</b>. Bản V1.16.2 có Foundation Merge + QSIG Evidence; cập nhật Worker là dùng được ngay.';
      }else{
        installNote.innerHTML='Trong Safari: <b>Chia sẻ → Thêm vào Màn hình chính</b>. Football Edge sẽ mở như một web app độc lập và không cần App Store.';
      }
      installSheet?.classList.add('show');
    });
  }
  installClose?.addEventListener('click',()=>installSheet?.classList.remove('show'));
  installSheet?.addEventListener('click',e=>{if(e.target===installSheet)installSheet.classList.remove('show')});
  if('serviceWorker' in navigator && /^https?:$/.test(location.protocol)){
    window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
  }

  // ================================================================
  // FE PUSH P0.2 — DEVICE + EXISTING NOTIFY WORKER BRIDGE
  // Additive only. Dedicated service-worker scope; ./sw.js remains intact.
  // Server contract: /api/notify/* on the existing Background Worker.
  // ================================================================
  const FE_PUSH_P02={sw:'./push-sw.js',scope:'./push/',reg:null,sub:null,deviceId:null,
    deviceKey:'FE_NOTIFY_DEVICE_ID_V1',prefsKey:'FE_NOTIFY_PREFS_V1'};
  const fePushBadge=$('fePushBadge'),fePushStatus=$('fePushStatus'),fePushEnableBtn=$('fePushEnableBtn'),
        fePushSaveBtn=$('fePushSaveBtn'),fePushLocalTestBtn=$('fePushLocalTestBtn'),fePushServerTestBtn=$('fePushServerTestBtn'),
        fePushGoalEnabled=$('fePushGoalEnabled'),fePushGapEnabled=$('fePushGapEnabled'),
        fePushGoalThreshold=$('fePushGoalThreshold'),fePushGapThreshold=$('fePushGapThreshold');
  function fePushSet(msg,kind=''){
    if(fePushStatus)status(fePushStatus,msg,kind==='ok'?'ok':kind==='err'?'err':kind==='busy'?'busy':'');
    if(fePushBadge){fePushBadge.className=kind||'';fePushBadge.textContent=kind==='ok'?'ĐÃ BẬT':kind==='err'?'LỖI':kind==='warn'?'CẦN KIỂM TRA':'CHƯA BẬT'}
  }
  function fePushStandalone(){return window.matchMedia?.('(display-mode: standalone)')?.matches||window.navigator.standalone===true}
  function fePushSecure(){return window.isSecureContext&&/^https:$/.test(location.protocol)}
  function fePushSupported(){return 'serviceWorker' in navigator&&'PushManager' in window&&'Notification' in window}
  function fePushClamp(v,d=70){const n=Number(v);return Number.isFinite(n)?Math.max(1,Math.min(100,Math.round(n))):d}
  function fePushPrefs(){
    return {enabled:true,goal:!!fePushGoalEnabled?.checked,gap:!!fePushGapEnabled?.checked,
      goalThreshold:fePushClamp(fePushGoalThreshold?.value,70),gapThreshold:fePushClamp(fePushGapThreshold?.value,70)}
  }
  function fePushPrefsLoad(){
    try{const p=JSON.parse(localStorage.getItem(FE_PUSH_P02.prefsKey)||'{}');
      if(typeof p.goal==='boolean'&&fePushGoalEnabled)fePushGoalEnabled.checked=p.goal;
      if(typeof p.gap==='boolean'&&fePushGapEnabled)fePushGapEnabled.checked=p.gap;
      if(Number.isFinite(Number(p.goalThreshold))&&fePushGoalThreshold)fePushGoalThreshold.value=fePushClamp(p.goalThreshold,70);
      if(Number.isFinite(Number(p.gapThreshold))&&fePushGapThreshold)fePushGapThreshold.value=fePushClamp(p.gapThreshold,70)
    }catch{}
    try{FE_PUSH_P02.deviceId=localStorage.getItem(FE_PUSH_P02.deviceKey)||null}catch{}
  }
  function fePushPrefsSaveLocal(){try{localStorage.setItem(FE_PUSH_P02.prefsKey,JSON.stringify(fePushPrefs()))}catch{}}
  function fePushDeviceSave(id){FE_PUSH_P02.deviceId=String(id||'')||null;try{if(FE_PUSH_P02.deviceId)localStorage.setItem(FE_PUSH_P02.deviceKey,FE_PUSH_P02.deviceId)}catch{}}
  function fePushKeyBytes(v){
    const s=String(v||'').trim(),pad='='.repeat((4-s.length%4)%4),raw=atob((s+pad).replace(/-/g,'+').replace(/_/g,'/')),out=new Uint8Array(raw.length);
    for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out
  }
  function fePushSameKey(a,b){
    if(!a||!b)return false;const x=new Uint8Array(a),y=b instanceof Uint8Array?b:new Uint8Array(b);if(x.length!==y.length)return false;
    for(let i=0;i<x.length;i++)if(x[i]!==y[i])return false;return true
  }
  async function fePushWaitActive(reg){
    if(reg.active)return reg;const sw=reg.installing||reg.waiting;if(!sw)return reg;
    await new Promise(resolve=>{let done=false;const finish=()=>{if(done)return;done=true;resolve()};sw.addEventListener('statechange',()=>{if(sw.state==='activated')finish()});setTimeout(finish,4500)});return reg
  }
  async function fePushRegistration(){
    if(FE_PUSH_P02.reg)return FE_PUSH_P02.reg;
    const reg=await navigator.serviceWorker.register(FE_PUSH_P02.sw,{scope:FE_PUSH_P02.scope});
    FE_PUSH_P02.reg=await fePushWaitActive(reg);return FE_PUSH_P02.reg
  }
  async function fePushWorkerKey(){
    if(!bgEnabled())throw new Error('Bật Background Watch và nhập Worker URL trước.');
    const r=await bgRequest('/api/notify/key',{timeout:12000});
    const key=String(r?.publicKey||'').trim();if(!r?.ok||!key)throw new Error(r?.error||'Worker chưa trả VAPID public key.');return key
  }
  function fePushCalibration(){
    const clean=r=>({score:Number(r?.score)||0,minute:Number(r?.minute)||0,level:r?.level??null,tier:r?.tier??null,goal_ft:typeof r?.goal_ft==='boolean'?r.goal_ft:null});
    let official=[],legacy=[];
    try{if(typeof qsigRead==='function')official=(qsigRead('FT')||[]).slice(-5000).map(clean)}catch{}
    try{legacy=(watchState?.calibration||[]).slice(-5000).map(clean)}catch{}
    return {FT:official,legacyFT:legacy}
  }
  async function fePushSubscribeServer(reg){
    const key=await fePushWorkerKey(),serverKey=fePushKeyBytes(key);let sub=await reg.pushManager.getSubscription();
    if(sub&&sub.options?.applicationServerKey&&!fePushSameKey(sub.options.applicationServerKey,serverKey)){await sub.unsubscribe().catch(()=>{});sub=null}
    if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:serverKey});
    const body={subscription:sub.toJSON(),prefs:fePushPrefs(),calibration:fePushCalibration()};
    const r=await bgRequest('/api/notify/subscribe',{method:'POST',body,timeout:20000});
    if(r?.ok!==true||!r?.id)throw new Error(r?.error||r?.message||'Worker từ chối Push Subscription.');
    FE_PUSH_P02.sub=sub;fePushDeviceSave(r.id);fePushPrefsSaveLocal();return {sub,server:r}
  }
  async function fePushEnable(){
    try{
      if(!fePushSecure())throw new Error('Thông báo nền cần mở Football Edge bằng HTTPS.');
      if(!fePushSupported())throw new Error('Thiết bị/trình duyệt này chưa hỗ trợ Web Push. Trên iPhone hãy mở Football Edge từ icon Màn hình chính.');
      if(/iphone|ipad|ipod/i.test(navigator.userAgent)&&!fePushStandalone())throw new Error('Trên iPhone: Safari → Chia sẻ → Thêm vào Màn hình chính, rồi mở Football Edge từ icon đó.');
      fePushSet('Đang xin quyền thông báo…','busy');let perm=Notification.permission;if(perm!=='granted')perm=await Notification.requestPermission();
      if(perm!=='granted')throw new Error(perm==='denied'?'Quyền thông báo đang bị từ chối trên thiết bị.':'Chưa cấp quyền thông báo.');
      const reg=await fePushRegistration();fePushSet('Đang đăng ký thiết bị với Background Worker…','busy');
      await fePushSubscribeServer(reg);fePushSet(`Đã bật Push nền • Goal ≥ ${fePushPrefs().goalThreshold} • GAP ≥ ${fePushPrefs().gapThreshold}.`,'ok')
    }catch(e){fePushSet(e.message||String(e),'err')}
  }
  async function fePushSave(){
    try{
      fePushPrefsSaveLocal();if(!FE_PUSH_P02.deviceId){fePushSet('Đã lưu ngưỡng trên máy. Bấm BẬT THÔNG BÁO để đăng ký với Worker.','warn');return}
      const r=await bgRequest('/api/notify/settings',{method:'POST',body:{id:FE_PUSH_P02.deviceId,prefs:fePushPrefs()},timeout:15000});
      if(r?.ok!==true)throw new Error(r?.error||'Worker không lưu được ngưỡng.');
      fePushSet(`Đã lưu trên Worker • Goal ${fePushPrefs().goal?'ON':'OFF'} ≥ ${fePushPrefs().goalThreshold} • GAP ${fePushPrefs().gap?'ON':'OFF'} ≥ ${fePushPrefs().gapThreshold}.`,'ok')
    }catch(e){fePushSet('Lưu ngưỡng lỗi: '+(e.message||e),'err')}
  }
  async function fePushLocalTest(){
    try{
      if(!fePushSecure())throw new Error('TEST notification cần HTTPS.');if(!fePushSupported())throw new Error('Web Push chưa khả dụng trên thiết bị này.');
      if(Notification.permission!=='granted')throw new Error('Bấm BẬT THÔNG BÁO trước.');
      const reg=await fePushRegistration();await reg.showNotification('⚽ Football Edge • Test trên máy',{body:'Phần hiển thị notification trên thiết bị đã hoạt động.',tag:'fe-push-local-test',data:{url:location.origin+location.pathname+'?fe_push=test#connectCard'},timestamp:Date.now()});
      fePushSet('Đã gửi TEST TRÊN MÁY. Nếu thấy banner thì service worker + quyền thông báo đạt.','ok')
    }catch(e){fePushSet(e.message||String(e),'err')}
  }
  async function fePushServerTest(){
    try{
      if(Notification.permission!=='granted')throw new Error('Bấm BẬT THÔNG BÁO trước.');
      const reg=await fePushRegistration();let sub=await reg.pushManager.getSubscription();if(!sub||!FE_PUSH_P02.deviceId){await fePushSubscribeServer(reg);sub=await reg.pushManager.getSubscription()}
      fePushSet('Worker đang gửi Web Push thực sự…','busy');
      const r=await bgRequest('/api/notify/test',{method:'POST',body:{id:FE_PUSH_P02.deviceId},timeout:20000});
      if(r?.ok!==true)throw new Error(r?.error||r?.message||'Push service từ chối notification test.');
      fePushSet('Worker đã gửi push test. Khóa màn hình để xác nhận banner/Lock Screen.','ok')
    }catch(e){fePushSet('TEST PUSH NỀN lỗi: '+(e.message||e),'err')}
  }
  async function fePushRefresh(){
    fePushPrefsLoad();
    if(!fePushSecure()){fePushSet('Mở bằng HTTPS để dùng thông báo nền.','warn');return}
    if(!fePushSupported()){fePushSet('Web Push chưa khả dụng. Trên iPhone cần cài Football Edge ra Màn hình chính.','warn');return}
    if(Notification.permission!=='granted'){fePushSet(Notification.permission==='denied'?'Quyền thông báo đang bị chặn.':'Chưa cấp quyền thông báo.','');return}
    try{
      const reg=await fePushRegistration(),sub=await reg.pushManager.getSubscription();FE_PUSH_P02.sub=sub;
      if(!sub){fePushSet('Đã cấp quyền nhưng chưa có Push Subscription. Bấm BẬT THÔNG BÁO.','warn');return}
      if(!FE_PUSH_P02.deviceId){fePushSet('Có Push Subscription nhưng chưa liên kết Worker. Bấm BẬT THÔNG BÁO để đồng bộ.','warn');return}
      if(bgEnabled()){
        const r=await bgRequest('/api/notify/status',{timeout:12000}),found=Array.isArray(r?.devices)&&r.devices.some(d=>String(d.id)===String(FE_PUSH_P02.deviceId));
        if(found){fePushSet(`Push nền đã liên kết Worker • Goal ≥ ${fePushPrefs().goalThreshold} • GAP ≥ ${fePushPrefs().gapThreshold}.`,'ok');return}
      }
      fePushSet('Subscription có trên máy nhưng Worker chưa xác nhận thiết bị. Bấm BẬT THÔNG BÁO để đăng ký lại.','warn')
    }catch(e){fePushSet('Kiểm tra Push lỗi: '+(e.message||e),'err')}
  }
  fePushEnableBtn?.addEventListener('click',fePushEnable);
  fePushSaveBtn?.addEventListener('click',fePushSave);
  fePushLocalTestBtn?.addEventListener('click',fePushLocalTest);
  fePushServerTestBtn?.addEventListener('click',fePushServerTest);
  fePushPrefsLoad();
  if(/^https?:$/.test(location.protocol))window.addEventListener('load',()=>setTimeout(()=>fePushRefresh().catch(()=>{}),900));

  // ================================================================
  // FE PUSH P0.3 — BACKGROUND SCAN HEARTBEAT / TELEMETRY UI
  // Read-only. Uses existing /api/notify/status; does not touch engines.
  // ================================================================
  const feScanBadge=$('feScanBadge'),feScanHeartbeat=$('feScanHeartbeat'),feScanLive=$('feScanLive'),
        feScanScanned=$('feScanScanned'),feScanAlerts=$('feScanAlerts'),feScanLine=$('feScanLine'),
        feScanErrors=$('feScanErrors'),feScanRefreshBtn=$('feScanRefreshBtn'),feScanControlBtn=$('feScanControlBtn');
  const FE_SCAN_HEALTH={timer:null,last:null,control:null,pollMs:15000,busy:false};
  function feScanText(el,v){const x=String(v??'—');if(el&&el.textContent!==x)el.textContent=x}
  function feScanBadgeSet(text,kind=''){
    if(!feScanBadge)return;feScanBadge.className=kind||'';feScanText(feScanBadge,text)
  }
  function feScanAgeLabel(ms){
    if(!Number.isFinite(ms)||ms<0)return '—';const sec=Math.floor(ms/1000);if(sec<60)return `${sec}s trước`;
    const min=Math.floor(sec/60);if(min<60)return `${min} phút trước`;return `${Math.floor(min/60)} giờ trước`
  }
  function feScanControlRender(control){
    const raw=control?.scan_control||control||{},paused=raw.enabled===false||raw.paused===true,c={...raw,paused};FE_SCAN_HEALTH.control=c;
    if(feScanControlBtn){
      feScanControlBtn.textContent=paused?'TIẾP TỤC QUÉT':'TẠM DỪNG QUÉT';
      feScanControlBtn.className=paused?'blue':'';
      feScanControlBtn.setAttribute('aria-pressed',paused?'true':'false')
    }
    return paused
  }
  function feScanRender(scan,control){
    FE_SCAN_HEALTH.last=scan||null;
    const paused=feScanControlRender(control);
    if(paused){
      const at=Number(scan?.at||control?.updated_at||0),age=at?Math.max(0,Date.now()-at):NaN;
      feScanBadgeSet('ĐÃ TẠM DỪNG','warn');
      feScanText(feScanHeartbeat,Number.isFinite(age)?feScanAgeLabel(age):'—');
      feScanText(feScanLive,0);feScanText(feScanScanned,0);feScanText(feScanAlerts,0);
      const api=Number.isFinite(Number(scan?.apiToday))?`${scan.apiToday}/${Number.isFinite(Number(scan?.apiLimit))?scan.apiLimit:'—'}`:'—';
      feScanText(feScanLine,`Đã tạm dừng theo yêu cầu • API hôm nay: ${api} • Không quét LIVE và không phát tín hiệu mới cho đến khi TIẾP TỤC QUÉT.`);
      if(feScanErrors){feScanErrors.hidden=true;feScanErrors.textContent=''}return
    }
    if(!scan||!Number.isFinite(Number(scan.at))){
      feScanBadgeSet('CHƯA CÓ DỮ LIỆU','warn');feScanText(feScanHeartbeat,'—');feScanText(feScanLive,'—');feScanText(feScanScanned,'—');feScanText(feScanAlerts,'—');
      feScanText(feScanLine,'Worker đã kết nối nhưng chưa ghi nhận vòng quét Push.');if(feScanErrors){feScanErrors.hidden=true;feScanErrors.textContent=''}return
    }
    const age=Math.max(0,Date.now()-Number(scan.at)),errs=Array.isArray(scan.errors)?scan.errors:[],budgetReached=errs.some(x=>/NOTIFY_DAILY_BUDGET_REACHED|API_TOTAL_DAILY_BUDGET_REACHED/i.test(String(x?.error||x||'')));
    if(budgetReached)feScanBadgeSet('HẾT BUDGET NỀN','warn');else if(age<=90000)feScanBadgeSet('ĐANG QUÉT','ok');else if(age<=180000)feScanBadgeSet('CHẬM','warn');else feScanBadgeSet('GIÁN ĐOẠN','err');
    feScanText(feScanHeartbeat,feScanAgeLabel(age));feScanText(feScanLive,Number.isFinite(Number(scan.live))?scan.live:'—');
    feScanText(feScanScanned,Number.isFinite(Number(scan.scanned))?scan.scanned:'—');feScanText(feScanAlerts,Number.isFinite(Number(scan.alertsAccepted))?scan.alertsAccepted:'—');
    const api=Number.isFinite(Number(scan.apiToday))?`${scan.apiToday}/${Number.isFinite(Number(scan.apiLimit))?scan.apiLimit:'—'}`:'—';
    const rot=Number.isFinite(Number(scan.rotationEstimateSeconds))?`~${scan.rotationEstimateSeconds}s`:'—';
    feScanText(feScanLine,budgetReached?`Background đã chạm ngân sách riêng ${api}. QUÉT LIVE thủ công vẫn dùng API-Football trực tiếp; có thể TẠM DỪNG QUÉT NỀN để giảm tải Worker.`:`Vòng gần nhất: ${new Date(Number(scan.at)).toLocaleTimeString('vi-VN')} • API nền hôm nay: ${api} • Chu kỳ phủ LIVE ước tính: ${rot}`);
    if(feScanErrors){if(errs.length){const e=errs.slice(0,2).map(x=>`${x.fixture?`#${x.fixture} `:''}${x.error||'Lỗi không xác định'}`).join(' • ');feScanErrors.hidden=false;feScanText(feScanErrors,`Lỗi vòng gần nhất (${errs.length}): ${e}`)}else{feScanErrors.hidden=true;feScanErrors.textContent=''}}
  }
  async function feScanRefresh({silent=false}={}){
    try{
      if(!bgEnabled()){if(!silent){feScanBadgeSet('BACKGROUND OFF','warn');feScanText(feScanLine,'Bật Background Watch để đọc heartbeat.')}return}
      if(!silent)feScanBadgeSet('ĐANG ĐỌC','');
      const r=await bgRequest('/api/notify/status',{timeout:12000});
      if(r?.ok!==true)throw new Error(r?.error||'Worker không trả trạng thái Push.');
      feScanRender(r.scan||null,r.scan_control||r.control||{enabled:r.scan?.scanEnabled,paused:r.scan?.paused===true||r.paused===true,state:r.scan_state||null})
    }catch(e){
      if(!silent){feScanBadgeSet('LỖI KẾT NỐI','err');feScanText(feScanLine,'Không đọc được trạng thái quét: '+(e.message||e))}
    }
  }
  async function feScanSetControl(paused){
    if(FE_SCAN_HEALTH.busy)return;
    if(!bgEnabled()){feScanBadgeSet('BACKGROUND OFF','warn');feScanText(feScanLine,'Bật Background Watch trước khi điều khiển vòng quét.');return}
    if(paused&&!confirm('Tạm dừng quét nền? Trong thời gian dừng, Worker sẽ không quét LIVE và không phát tín hiệu mới.'))return;
    FE_SCAN_HEALTH.busy=true;if(feScanControlBtn)feScanControlBtn.disabled=true;
    try{
      feScanBadgeSet(paused?'ĐANG TẠM DỪNG':'ĐANG KHỞI ĐỘNG','');
      const r=await bgRequest('/api/notify/scan-control',{method:'POST',body:{enabled:!paused},timeout:15000});
      if(r?.ok!==true)throw new Error(r?.error||'Worker không cập nhật trạng thái quét.');
      feScanControlRender(r.scan_control||r);
      await feScanRefresh({silent:true});
    }catch(e){
      feScanBadgeSet('LỖI ĐIỀU KHIỂN','err');feScanText(feScanLine,'Không đổi được trạng thái quét: '+(e.message||e))
    }finally{
      FE_SCAN_HEALTH.busy=false;if(feScanControlBtn)feScanControlBtn.disabled=false
    }
  }
  function feScanStart(){
    if(FE_SCAN_HEALTH.timer)clearInterval(FE_SCAN_HEALTH.timer);
    FE_SCAN_HEALTH.timer=setInterval(()=>{if(document.visibilityState==='visible'&&bgEnabled())feScanRefresh({silent:true})},FE_SCAN_HEALTH.pollMs)
  }
  feScanRefreshBtn?.addEventListener('click',()=>feScanRefresh());
  feScanControlBtn?.addEventListener('click',()=>feScanSetControl(!(FE_SCAN_HEALTH.control?.paused===true)));
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')feScanRefresh({silent:true})});
  if(/^https?:$/.test(location.protocol))window.addEventListener('load',()=>{setTimeout(()=>feScanRefresh({silent:true}),1600);feScanStart()});




  // ================================================================
  // FE PUSH P0.9 — SIGNAL VALIDATION DASHBOARD (READ-ONLY)
  // Reads /api/notify/validation/* only. Never changes engines/thresholds.
  // ================================================================
  const FE_VAL_UI={timer:null,pollMs:60000,lastSummary:null,lastRecent:null};
  const feValBadge=$('feValBadge'),feValH1=$('feValH1'),feValH1n=$('feValH1n'),feValFT=$('feValFT'),feValFTn=$('feValFTn'),
        feValHC=$('feValHC'),feValHCn=$('feValHCn'),feValPending=$('feValPending'),feValBreakdown=$('feValBreakdown'),feValRecent=$('feValRecent'),feValRefreshBtn=$('feValRefreshBtn');
  function feValText(el,v){const x=String(v??'—');if(el&&el.textContent!==x)el.textContent=x}
  function feValBadgeSet(t,k=''){if(!feValBadge)return;feValBadge.className=k||'';feValText(feValBadge,t)}
  function feValPct(v){return Number.isFinite(Number(v))?`${Number(v).toFixed(1)}%`:'—'}
  function feValType(s,key){return s?.types?.[key]||{n:0,pending:0,hit:0,miss:0,unknown:0,states:{},accuracy:null,resolved:0}}
  function feValBucketText(s,type){
    const b=s?.buckets?.[type]||{},parts=[];for(const k of ['70-74','75-79','80+']){const x=b[k];if(x?.n)parts.push(`${k}: ${x.hit}/${x.n} (${feValPct(x.accuracy)})`)}return parts.join(' • ')
  }
  function feValRenderSummary(s){
    FE_VAL_UI.lastSummary=s||null;const h1=feValType(s,'PUSH_H1_5M'),ft=feValType(s,'PUSH_FT_10M'),hc=feValType(s,'PUSH_HC_15M');
    const hcStates=hc.states||{},same=Number(hcStates.SAME_ABOVE_THRESHOLD||0)+Number(hcStates.SAME_BELOW_THRESHOLD||0),hcDen=same+Number(hcStates.NEUTRALIZED||0)+Number(hcStates.FLIPPED||0),hcRate=hcDen?same*100/hcDen:null;
    const pending=Number(h1.pending||0)+Number(ft.pending||0)+Number(hc.pending||0),resolved=Number(h1.resolved||0)+Number(ft.resolved||0)+hcDen;
    feValText(feValH1,feValPct(h1.accuracy));feValText(feValH1n,`n=${h1.resolved||0}`);feValText(feValFT,feValPct(ft.accuracy));feValText(feValFTn,`n=${ft.resolved||0}`);
    feValText(feValHC,feValPct(hcRate));feValText(feValHCn,`n=${hcDen}`);feValText(feValPending,pending);
    if(resolved>0)feValBadgeSet('ĐANG TÍCH LŨY','ok');else if(pending>0)feValBadgeSet('ĐANG CHỜ','warn');else feValBadgeSet('CHƯA CÓ MẪU','warn');
    const lines=[];const hb=feValBucketText(s,'PUSH_H1_5M'),fb=feValBucketText(s,'PUSH_FT_10M');if(hb)lines.push(`H1 theo score: ${hb}`);if(fb)lines.push(`FT theo score: ${fb}`);
    if(hcDen)lines.push(`HC 15': giữ hướng ${same}/${hcDen} • lật ${Number(hcStates.FLIPPED||0)} • trung hòa ${Number(hcStates.NEUTRALIZED||0)}`);
    feValText(feValBreakdown,lines.length?lines.join(' | '):'Chưa có tín hiệu Push đủ thời gian để kiểm chứng.');
  }
  function feValStateClass(x){x=String(x||'').toUpperCase();if(x==='HIT')return'hit';if(x==='MISS'||x==='FLIPPED')return x==='MISS'?'miss':'flip';if(x.startsWith('SAME_'))return'same';if(x==='PENDING')return'pending';return''}
  function feValTypeLabel(t){return t==='PUSH_H1_5M'?'H1 5m':t==='PUSH_FT_10M'?'FT 10m':t==='PUSH_HC_15M'?'HC 15m':t}
  function feValRenderRecent(r){
    FE_VAL_UI.lastRecent=r||null;if(!feValRecent)return;const rows=Array.isArray(r?.rows)?r.rows.slice(0,8):[];
    if(!rows.length){feValRecent.innerHTML='';return}
    feValRecent.innerHTML=rows.map(x=>{const p=x.payload||{},v=Number.isFinite(Number(p.signal_value))?Math.round(Number(p.signal_value)):'—',th=Number.isFinite(Number(p.threshold))?Math.round(Number(p.threshold)):'—',m=p.minute??'—';
      const score=(p.score_home!=null&&p.score_away!=null)?`${p.score_home}-${p.score_away}`:'—',when=Number(x.created_at)?new Date(Number(x.created_at)).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'}):'—';
      return `<div class="fe-val-row"><div class="main"><b>${esc(p.match||('#'+x.fixture_id))}</b><small>${esc(feValTypeLabel(x.validation_type))} • ${m}' • ${score} • score ${v} / ngưỡng ${th} • ${when}</small></div><span class="fe-val-state ${feValStateClass(x.result_key)}">${esc(x.result_key||'PENDING')}</span></div>`
    }).join('');
  }
  async function feValRefresh({silent=false}={}){
    try{
      if(!bgEnabled()){if(!silent)feValBadgeSet('BACKGROUND OFF','warn');return}
      if(!silent)feValBadgeSet('ĐANG ĐỌC','');
      const [s,r]=await Promise.all([bgRequest('/api/notify/validation/summary',{timeout:15000}),bgRequest('/api/notify/validation/recent?limit=12',{timeout:15000})]);
      if(s?.ok!==true)throw new Error(s?.error||'Validation summary unavailable');if(r?.ok!==true)throw new Error(r?.error||'Validation recent unavailable');
      feValRenderSummary(s);feValRenderRecent(r);
    }catch(e){if(!silent){feValBadgeSet('CHƯA SẴN SÀNG','err');feValText(feValBreakdown,'Worker chưa có Validation P0.9 hoặc chưa deploy bản mới: '+(e.message||e))}}
  }
  function feValStart(){if(FE_VAL_UI.timer)clearInterval(FE_VAL_UI.timer);FE_VAL_UI.timer=setInterval(()=>{if(document.visibilityState==='visible'&&bgEnabled())feValRefresh({silent:true})},FE_VAL_UI.pollMs)}
  feValRefreshBtn?.addEventListener('click',()=>feValRefresh());
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')feValRefresh({silent:true})});
  if(/^https?:$/.test(location.protocol))window.addEventListener('load',()=>{setTimeout(()=>feValRefresh({silent:true}),2600);feValStart()});

  // ================================================================
  // V1.11.2 SLATE REGIME — WARNING ONLY / SHADOW MODE
  // This module NEVER modifies H1/FT/Corner scores, thresholds or odds.
  // It only reads a mature LIVE sample and displays the slate context.
  // ================================================================
  const SLATE_REGIME_REFRESH_MS=120000;
  const SLATE_REGIME_STATS_TTL=55000;
  const SLATE_REGIME_MAX_FIXTURES=24;
  const slateRegimeState={refreshing:false,timer:null,last:null};

  function slateClamp(v,a=0,b=100){return Math.max(a,Math.min(b,Number(v)||0))}
  function slateMean(a){const x=(a||[]).filter(Number.isFinite);return x.length?x.reduce((s,v)=>s+v,0)/x.length:null}
  function slateMedian(a){const x=(a||[]).filter(Number.isFinite).sort((a,b)=>a-b);if(!x.length)return null;const m=Math.floor(x.length/2);return x.length%2?x[m]:(x[m-1]+x[m])/2}
  function slateRobust(a){const mean=slateMean(a),med=slateMedian(a);if(mean==null)return null;if(med==null)return mean;return med*.6+mean*.4}
  function slateRatioScore(value,baseline){
    if(!Number.isFinite(value)||!Number.isFinite(baseline)||baseline<=0)return null;
    return slateClamp(50+((value/baseline)-1)*50,0,100);
  }
  function slateSumNullable(a,b){if(a==null&&b==null)return null;return Number(a||0)+Number(b||0)}
  function slateSideNum(side,names){const v=getAnyStat(side,names);if(v==null)return null;const n=Number(String(v).replace('%','').trim());return Number.isFinite(n)?n:null}
  function slateEligibleFixtures(){
    return (state.fixtures||[]).filter(f=>{
      const st=f?.fixture?.status?.short||'',m=Number(f?.fixture?.status?.elapsed);
      return isLive(f)&&['1H','HT','2H','LIVE','INT'].includes(st)&&Number.isFinite(m)&&m>=25&&m<=88;
    }).slice(0,SLATE_REGIME_MAX_FIXTURES);
  }
  function slateRowFromStats(f,stats){
    const m=Number(f?.fixture?.status?.elapsed||0);if(!Number.isFinite(m)||m<25)return null;
    const mp=statMap(stats||[]),home=mp?.[f?.teams?.home?.id],away=mp?.[f?.teams?.away?.id];
    const presence=watchStatsPresence(mp,{teams:f.teams});
    if(!presence?.core)return null;
    const shots=slateSumNullable(slateSideNum(home,['Total Shots']),slateSideNum(away,['Total Shots']));
    const sot=slateSumNullable(slateSideNum(home,['Shots on Goal','Shots on Target']),slateSideNum(away,['Shots on Goal','Shots on Target']));
    const inbox=slateSumNullable(slateSideNum(home,['Shots insidebox','Shots inside box']),slateSideNum(away,['Shots insidebox','Shots inside box']));
    const xg=slateSumNullable(slateSideNum(home,['Expected Goals','expected_goals']),slateSideNum(away,['Expected Goals','expected_goals']));
    const goals=Number(f?.goals?.home||0)+Number(f?.goals?.away||0),factor=90/Math.max(1,m);
    return {
      fixture_id:f.fixture?.id,minute:m,goals,
      goals90:goals*factor,
      shots90:shots==null?null:shots*factor,
      sot90:sot==null?null:sot*factor,
      inbox90:inbox==null?null:inbox*factor,
      xg90:xg==null?null:xg*factor,
      scoreless:goals===0,
      coverage:presence.coverage||0
    };
  }
  function slateClassify(rows,candidateCount){
    const valid=(rows||[]).filter(x=>x&&!x.error),coverage=candidateCount?valid.length/candidateCount:0;
    if(candidateCount<4||valid.length<4||coverage<.5){
      return {label:'DATA-THIN',kind:'thin',tempo:null,valid:valid.length,candidates:candidateCount,coverage,reason:'Không đủ mẫu LIVE có core stats để kết luận nhịp toàn khung.'};
    }
    const goals90=slateRobust(valid.map(x=>x.goals90));
    const sot90=slateRobust(valid.map(x=>x.sot90));
    const shots90=slateRobust(valid.map(x=>x.shots90));
    const inbox90=slateRobust(valid.map(x=>x.inbox90));
    const late=valid.filter(x=>x.minute>=35),scorelessRate=late.length?late.filter(x=>x.scoreless).length/late.length:null;
    const comps=[];
    const add=(value,base,w)=>{const s=slateRatioScore(value,base);if(s!=null)comps.push({s,w})};
    // Baselines are intentionally broad and only used for SHADOW warning.
    add(goals90,2.60,.35); add(sot90,8.0,.35); add(shots90,24.0,.15); add(inbox90,15.0,.10);
    if(scorelessRate!=null){const nonZero=1-scorelessRate;add(nonZero,.65,.05)}
    const w=comps.reduce((a,x)=>a+x.w,0),tempo=w?Math.round(comps.reduce((a,x)=>a+x.s*x.w,0)/w):null;
    let label='NORMAL',kind='normal',reason='Nhịp bàn/cơ hội toàn khung ở vùng trung tính.';
    if(tempo!=null&&tempo<38){label='LOW-EVENT';kind='low';reason='Nhịp bàn và chance quality toàn khung đang thấp. Chỉ cảnh báo, không đổi signal/odds.'}
    else if(tempo!=null&&tempo>68){label='GOAL-RICH';kind='rich';reason='Nhịp bàn/cơ hội toàn khung đang cao hơn baseline cảnh báo.'}
    return {label,kind,tempo,valid:valid.length,candidates:candidateCount,coverage,goals90,sot90,shots90,inbox90,scorelessRate,reason};
  }
  function slateFmt(v,d=1){return Number.isFinite(v)?Number(v).toFixed(d):'N/A'}
  function renderSlateRegime(r,busy=false){
    const card=$('slateRegimeCard'),lab=$('slateRegimeLabel'),txt=$('slateRegimeText'),met=$('slateRegimeMetrics');if(!card||!lab||!txt||!met)return;
    card.classList.remove('low','normal','rich','thin','busy');
    if(busy){card.classList.add('busy');lab.textContent='ĐANG ĐÁNH GIÁ...';txt.textContent='Đọc mẫu LIVE đủ phút và core stats • không tác động H1/FT/Góc/odds.';met.innerHTML='';return}
    if(!r){lab.textContent='CHƯA ĐÁNH GIÁ';txt.textContent='Quét LIVE để đánh giá nhịp bàn/cơ hội toàn khung. Không thay score hoặc odds hiện tại.';met.innerHTML='';return}
    card.classList.add(r.kind||'thin');
    lab.textContent=r.tempo==null?r.label:`${r.label} • ${r.tempo}/100`;
    txt.textContent=r.reason||'';
    const chips=[`MẪU ${r.valid}/${r.candidates}`];
    if(r.tempo!=null){
      chips.push(`G/90 ${slateFmt(r.goals90,2)}`);
      chips.push(`SOT/90 ${slateFmt(r.sot90,1)}`);
      if(Number.isFinite(r.shots90))chips.push(`SHOTS/90 ${slateFmt(r.shots90,1)}`);
      if(Number.isFinite(r.scorelessRate))chips.push(`0-0 ${Math.round(r.scorelessRate*100)}%`);
    }
    chips.push('SHADOW • KHÔNG ĐỔI ODDS');
    met.innerHTML=chips.map(x=>`<span class="slate-regime-chip">${esc(x)}</span>`).join('');
  }
  function resetSlateRegime(msg='Chỉ đánh giá khi quét LIVE.'){
    clearTimeout(slateRegimeState.timer);slateRegimeState.timer=null;slateRegimeState.last=null;
    const r={label:'CHƯA ĐÁNH GIÁ',kind:'thin',tempo:null,valid:0,candidates:0,reason:msg};renderSlateRegime(r,false);
  }
  function scheduleSlateRegime(){
    clearTimeout(slateRegimeState.timer);slateRegimeState.timer=null;
    if(state.scan!=='live')return;
    slateRegimeState.timer=setTimeout(()=>{if(document.visibilityState==='visible'&&state.scan==='live')refreshSlateRegime(false);else scheduleSlateRegime()},SLATE_REGIME_REFRESH_MS);
  }
  async function refreshSlateRegime(force=false){
    if(slateRegimeState.refreshing)return;
    if(state.scan!=='live'){resetSlateRegime();return}
    if(!els.fkey.value.trim()){renderSlateRegime({label:'DATA-THIN',kind:'thin',tempo:null,valid:0,candidates:0,reason:'Chưa có API key để đọc stats toàn khung.'});return}
    const fixtures=slateEligibleFixtures();
    if(!fixtures.length){renderSlateRegime({label:'DATA-THIN',kind:'thin',tempo:null,valid:0,candidates:0,reason:'Chưa có đủ trận LIVE từ phút 25–88 để đánh giá.'});scheduleSlateRegime();return}
    slateRegimeState.refreshing=true;renderSlateRegime(null,true);
    try{
      const rows=await mapLimit(fixtures,6,async f=>{
        const stats=force?await football('/fixtures/statistics',{fixture:f.fixture.id},true):await footballCached('/fixtures/statistics',{fixture:f.fixture.id},SLATE_REGIME_STATS_TTL,true);
        return slateRowFromStats(f,stats||[]);
      });
      const result=slateClassify(rows,fixtures.length);result.updated_at=Date.now();slateRegimeState.last=result;renderSlateRegime(result,false);
      log('Slate regime',{label:result.label,tempo:result.tempo,sample:`${result.valid}/${result.candidates}`,goals90:result.goals90,sot90:result.sot90});
    }catch(e){
      renderSlateRegime({label:'DATA-THIN',kind:'thin',tempo:null,valid:0,candidates:fixtures.length,reason:'Không đánh giá được nhịp toàn khung: '+e.message},false);
    }finally{slateRegimeState.refreshing=false;scheduleSlateRegime()}
  }
  $('refreshSlateRegimeBtn')?.addEventListener('click',()=>refreshSlateRegime(true));

  $('backgroundTestBtn')?.addEventListener('click',bgTestConnection);
  $('backgroundSyncBtn')?.addEventListener('click',()=>bgSyncNow({silent:false}));
  els.bgEnabled?.addEventListener('change',()=>{saveConfig(true);if(els.bgEnabled.checked){bgTestConnection().then(()=>bgSyncNow({silent:true}))}else status(els.bgStatus,'Background Watch đã tắt trên app.','')});
  els.bgUrl?.addEventListener('change',()=>saveConfig(true));
  els.bgToken?.addEventListener('change',()=>saveConfig(true));
  document.addEventListener('visibilitychange',bgAutoSyncOnVisible);
  window.addEventListener('focus',bgAutoSyncOnVisible);

  // FE_UI_READ_BRIDGE_START: detached display data only; no engine setters.
  const feUICopy=value=>value==null?null:JSON.parse(JSON.stringify(value));
  const feUIItem=item=>({id:item.id,home:item.home,away:item.away,league:item.league,
    state:item.state??item.eval?.state,reason:item.reason,latest:item.latest,eval:item.eval});
  Object.defineProperty(window,'FEUIReadBridge',{value:Object.freeze({
    read:()=>feUICopy({
      state:{selected:state.selected,fixtures:state.fixtures,fixtureFilter:state.fixtureFilter,scanning:state.scanning},
      watchState:{active:watchState.active,items:watchState.items.map(feUIItem)},
      h1WatchState:{active:h1WatchState.active,items:h1WatchState.items.map(feUIItem)},
      handicapWatchState:{active:handicapWatchState.active,pool:handicapWatchState.pool.map(feUIItem)}
    }),
    estimate:(item,engine)=>['FT','H1'].includes(engine)?feUICopy(grEstimate(feUICopy(item),engine)):null,
    why:(item,engine)=>{const copy=feUICopy(item);return copy&&['FT','H1'].includes(engine)
      ?feUICopy((engine==='FT'?watchWhy:h1WatchWhy)(copy,copy.latest||{},copy.eval||{})):null}
  }),writable:false,configurable:false});
  // FE_UI_READ_BRIDGE_END

  // FE_ADDON_BRIDGE_START: presentation/read actions for P1.x UI layers only.
  // No engine setters, no threshold mutation, no ranking mutation.
  const feAddonPlainGroups=groups=>{
    const out={};
    for(const [k,g] of Object.entries(groups||{})){
      const n=Number(g?.n||0),pl=Number(g?.pl||0),roi=n?pl/n*100:null;
      out[k]={
        n,pl,roi,
        positive_rate:n?Number(g?.pos||0)/n*100:null,
        negative_rate:n?Number(g?.neg||0)/n*100:null,
        push_rate:n?Number(g?.push||0)/n*100:null,
        avg_price:Number(g?.priceN||0)?Number(g.priceSum||0)/Number(g.priceN):null,
        avg_edge:Number(g?.edgeN||0)?Number(g.edgeSum||0)/Number(g.edgeN):null
      };
    }
    return out;
  };
  const feAddonMarketValidation=()=>{
    const x=epcalSnapshot();
    const price=epcalGroup(x.rows,r=>r.price_zone);
    const edge=epcalGroup(x.rows,epcalEdgeBand);
    const behavior=epcalGroup(x.rows,epcalBehaviorBucket);
    const engine=epcalGroup(x.rows,r=>r.engine);
    const policy=epcalGroup(x.rows,r=>r.policy_status);
    return feUICopy({
      schema:'FE_MARKET_ENTRY_VALIDATION_BRIDGE_V1',
      generated_at:Date.now(),
      episodes:x.rows.length,
      unique_fixtures:x.fixtures,
      suitable_n:Number(x.s?.n||0),
      non_suitable_n:Number(x.other?.n||0),
      suitable_roi:x.sr,
      non_suitable_roi:x.orr,
      separation_pp:x.delta,
      h1:x.h1,ft:x.ft,
      gates:x.gates,ready:x.ready,verdict:x.verdict,cls:x.cls,reason:x.reason,
      price:feAddonPlainGroups(price),
      edge:feAddonPlainGroups(edge),
      behavior:feAddonPlainGroups(behavior),
      engine:feAddonPlainGroups(engine),
      policy:feAddonPlainGroups(policy)
    });
  };

  const feAddonCalibrationReview=()=>{
    const rows=validationSyncSources();
    const engines={};
    for(const engine of ['H1','FT','HC']){
      const r=alvPolicyReview(engine,rows),b=EVIDENCE_BASELINES[engine];
      engines[engine]={
        engine,
        current:{qualified:b?.qualified??null,high:b?.high??null,label:b?.label??engine},
        samples_n:r.samples_n,train_n:r.train_n,hold_n:r.hold_n,
        baseline:r.baseline,candidate:r.candidate,
        base_hold:r.baseHold,candidate_hold:r.candHold,
        retention:r.retention,delta_pp:r.delta,
        verdict:r.verdict,certified:!!r.certified,reason:r.reason,
        slices:r.slices
      };
    }
    const entry=feAddonMarketValidation();
    const pushThresholds={
      ft_goal:Number($('fePushGoalThreshold')?.value||70),
      hc_gap:Number($('fePushGapThreshold')?.value||70)
    };
    return feUICopy({
      schema:'FE_CALIBRATION_REVIEW_V1',
      generated_at:Date.now(),
      engines,
      entry_policy:{
        episodes:entry.episodes,
        unique_fixtures:entry.unique_fixtures,
        suitable_n:entry.suitable_n,
        non_suitable_n:entry.non_suitable_n,
        suitable_roi:entry.suitable_roi,
        non_suitable_roi:entry.non_suitable_roi,
        separation_pp:entry.separation_pp,
        ready:entry.ready,
        verdict:entry.verdict,
        reason:entry.reason,
        gates:entry.gates
      },
      notification_thresholds:pushThresholds
    });
  };


  const feAddonReleaseHealth=async()=>{
    const checks=[];
    const add=(id,label,state,detail,required=true)=>checks.push({id,label,state,detail:String(detail??''),required});
    const isIOS=/iphone|ipad|ipod/i.test(navigator.userAgent||'');

    add('https','HTTPS / SECURE CONTEXT',fePushSecure()?'pass':'fail',fePushSecure()?'Secure context OK':'App phải chạy bằng HTTPS.');
    add('api_key','FOOTBALL API KEY',String(els.fkey?.value||'').trim()?'pass':'fail',String(els.fkey?.value||'').trim()?'Đã cấu hình':'Chưa có API key.');
    add('background','BACKGROUND WATCH',bgEnabled()?'pass':'fail',bgEnabled()?'Đã bật và có Worker URL':'Chưa bật hoặc thiếu Worker URL.');
    add('push_support','WEB PUSH SUPPORT',fePushSupported()?'pass':'fail',fePushSupported()?'Service Worker + PushManager + Notification có sẵn':'Trình duyệt/PWA chưa hỗ trợ Web Push.');
    add('standalone','PWA STANDALONE',!isIOS||fePushStandalone()?'pass':'fail',isIOS?(fePushStandalone()?'Đang mở từ icon Màn hình chính':'iPhone cần mở từ icon Màn hình chính.'):'Không bắt buộc trên thiết bị này.',isIOS);

    let sw=null,sub=null;
    if('serviceWorker' in navigator){
      try{
        sw=await navigator.serviceWorker.getRegistration(FE_PUSH_P02.scope);
        add('service_worker', 'SERVICE WORKER', sw?.active?'pass':'fail', sw?.active?`Active • scope ${sw.scope}`:'Chưa có active service worker.');
      }catch(e){add('service_worker','SERVICE WORKER','fail',e.message)}
    }else add('service_worker','SERVICE WORKER','fail','navigator.serviceWorker không có.');

    const perm=('Notification' in window)?Notification.permission:'unsupported';
    add('notification_permission','NOTIFICATION PERMISSION',perm==='granted'?'pass':perm==='denied'?'fail':'warn',`Permission: ${perm}`);
    if(sw?.pushManager){
      try{sub=await sw.pushManager.getSubscription()}catch{}
    }
    add('push_subscription','PUSH SUBSCRIPTION',sub?'pass':'fail',sub?'Thiết bị có Push Subscription':'Chưa có Push Subscription.');

    let notify=null,workerErr=null;
    if(bgEnabled()){
      try{notify=await bgRequest('/api/notify/status',{timeout:15000})}catch(e){workerErr=e}
    }
    add('worker_status','BACKGROUND WORKER',notify?.ok===true?'pass':'fail',notify?.ok===true?'Worker /api/notify/status OK':workerErr?.message||'Worker chưa trả trạng thái.');

    const deviceLinked=!!(notify?.ok===true&&FE_PUSH_P02.deviceId&&Array.isArray(notify.devices)&&notify.devices.some(d=>String(d.id)===String(FE_PUSH_P02.deviceId)));
    add('device_link','PUSH DEVICE LINK',deviceLinked?'pass':'fail',deviceLinked?'Thiết bị đã được Worker xác nhận':'Worker chưa xác nhận device ID.');

    const scan=notify?.scan||notify?.last_scan||notify?.health?.scan||null;
    const scanAt=Number(scan?.at||notify?.scan_at||0),scanPaused=notify?.control?.paused===true||notify?.paused===true;
    if(scanPaused){
      const age=scanAt?Math.max(0,Date.now()-scanAt):null;
      add('scan_freshness','BACKGROUND SCAN FRESHNESS','pass',age==null?'Paused by user':'Paused by user • heartbeat '+Math.round(age/1000)+'s ago');
    }else if(scanAt){
      const age=Math.max(0,Date.now()-scanAt),ok=age<=180000;
      add('scan_freshness','BACKGROUND SCAN FRESHNESS',ok?'pass':'warn',`Last scan ${Math.round(age/1000)}s ago`);
    }else{
      add('scan_freshness','BACKGROUND SCAN FRESHNESS','warn','Chưa đọc được timestamp vòng scan.',false);
    }

    let db=null,dbErr=null;
    if(feDbConfigured()){
      try{db=await bgRequest('/api/db/health',{timeout:15000})}catch(e){dbErr=e}
    }
    add('d1_config','D1 CONFIGURATION',feDbConfigured()?'pass':'fail',feDbConfigured()?'Worker URL + token đã cấu hình':'Thiếu Worker URL hoặc token.');
    add('d1_health','D1 HEALTH',db?.configured&&db?.schema_ready?'pass':'fail',db?.configured&&db?.schema_ready?'D1 configured + schema ready':dbErr?.message||'D1 chưa ready.');

    let outbox=0;
    try{outbox=await feDbOutboxCount()}catch{}
    add('sync_queue','SYNC QUEUE',outbox===0?'pass':'warn',`${outbox} event đang chờ đồng bộ`,false);

    const required=checks.filter(x=>x.required!==false),passed=required.filter(x=>x.state==='pass').length,failed=required.filter(x=>x.state==='fail').length,warn=checks.filter(x=>x.state==='warn').length;
    return feUICopy({
      schema:'FE_RELEASE_HEALTH_V1',
      generated_at:Date.now(),
      app_version:APP_VERSION,
      user_agent:navigator.userAgent,
      ios:isIOS,
      checks,
      totals:{required:required.length,passed,failed,warn},
      ready:failed===0
    });
  };

  if(!window.FEAddonBridge)Object.defineProperty(window,'FEAddonBridge',{value:Object.freeze({
    masterRows:()=>feUICopy(feMasterRankRows(feMasterMergeFixtures()).map(x=>({
      ...x,
      __addon:{
        rankWhy:feMasterRankWhy(x.__rank||feMasterRankMeta(x)),
        entry:epOverall(epPolicies(x)),
        manual:feSmartIsManual(x.id)
      }
    }))),
    toggleManual:id=>feSmartToggleManual(id),
    bgCount:()=>bgRegistryRead().filter(r=>['SMART','H1','FT','HC'].includes(String(r.engine||''))).length,
    unified:()=>feUICopy({
      fresh:Number(FE_UNIFIED_SCAN_STATE?.lastFreshCount||0),
      lastAt:Number(FE_UNIFIED_SCAN_STATE?.lastAt||0),
      running:!!FE_UNIFIED_SCAN_STATE?.running
    }),
    enabled:()=>bgEnabled(),
    request:(path,opts)=>bgRequest(path,opts),
    marketValidation:()=>feAddonMarketValidation(),
    refreshEntryValidation:async()=>{await evRefreshResolutions(false);return feAddonMarketValidation()},
    exportEntryCalibration:()=>epcalExport(),
    calibrationReview:()=>feAddonCalibrationReview(),
    releaseHealth:()=>feAddonReleaseHealth()
  }),writable:false,configurable:false});
  // FE_ADDON_BRIDGE_END


  setDefaultTimes();
  setScanPurpose('single');loadConfig();
  setTimeout(()=>{if(bgEnabled())bgSyncNow({silent:true})},900);
})();

  // V1.11.5 PRO THEMES UI navigation only.
  document.querySelectorAll('.bottom-item,.light-tab').forEach(el=>{
    el.addEventListener('click',()=>{
      if(el.classList.contains('bottom-item')){
        document.querySelectorAll('.bottom-item').forEach(x=>x.classList.remove('active'));
        el.classList.add('active');
      }
      if(el.classList.contains('light-tab')){
        document.querySelectorAll('.light-tab').forEach(x=>x.classList.remove('active'));
        el.classList.add('active');
      }
    });
  });


  // V1.9.1 compact UI: connection summary status.
  const syncConnMini=()=>{
    const mini=document.getElementById('connMiniStatus');
    const full=document.getElementById('connStatus');
    const key=document.getElementById('footballKey');
    if(!mini||!full)return;
    const txt=(full.textContent||'').trim();
    mini.classList.remove('ok','err');
    if(full.classList.contains('ok')){
      mini.textContent='API OK'; mini.classList.add('ok');
    }else if(full.classList.contains('err')){
      mini.textContent='Cần kiểm tra'; mini.classList.add('err');
    }else if(key?.value?.trim()){
      mini.textContent='Đã cấu hình';
    }else{
      mini.textContent='Chưa cấu hình';
    }
  };
  const connObserverTarget=document.getElementById('connStatus');
  if(connObserverTarget){
    new MutationObserver(syncConnMini).observe(connObserverTarget,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
  }
  document.getElementById('footballKey')?.addEventListener('input',syncConnMini);
  setTimeout(syncConnMini,80);


  // V1.11.5 PRO THEMES
  const FE_THEME_KEY='FE_THEME_V115';
  const FE_DENSITY_KEY='FE_DENSITY_V115';

  function applyTheme(theme,save=true){
    const valid=['light','dark','glass'];
    const next=valid.includes(theme)?theme:'light';
    document.body.dataset.theme=next;
    document.querySelectorAll('.theme-option').forEach(b=>{
      b.classList.toggle('active',b.dataset.theme===next);
    });
    if(save){
      try{localStorage.setItem(FE_THEME_KEY,next)}catch{}
    }
    const meta=document.querySelector('meta[name="theme-color"]');
    if(meta){
      meta.setAttribute('content',next==='dark'?'#111a26':next==='glass'?'#050a12':'#f7fafc');
    }
  }

  function applyDensity(density,save=true){
    const next=density==='comfortable'?'comfortable':'compact';
    document.body.dataset.density=next;
    document.querySelectorAll('.density-option').forEach(b=>{
      b.classList.toggle('active',b.dataset.density===next);
    });
    if(save){
      try{localStorage.setItem(FE_DENSITY_KEY,next)}catch{}
    }
  }

  document.querySelectorAll('.theme-option').forEach(btn=>{
    btn.addEventListener('click',()=>applyTheme(btn.dataset.theme,true));
  });
  document.querySelectorAll('.density-option').forEach(btn=>{
    btn.addEventListener('click',()=>applyDensity(btn.dataset.density,true));
  });

  let initialTheme='light',initialDensity='compact';
  try{
    initialTheme=localStorage.getItem(FE_THEME_KEY)||'light';
    initialDensity=localStorage.getItem(FE_DENSITY_KEY)||'compact';
  }catch{}
  try{const previewTheme=new URLSearchParams(location.search).get('theme');if(['light','dark','glass'].includes(previewTheme))initialTheme=previewTheme}catch{}
  applyTheme(initialTheme,false);
  applyDensity(initialDensity,false);
