import fs from 'node:fs';
import vm from 'node:vm';

const noop=()=>{};
function buildContext(nowMs){
  const classList={add:noop,remove:noop,toggle:()=>false,contains:()=>false};
  const dummyTarget={style:{setProperty:noop},dataset:{},classList,addEventListener:noop,removeEventListener:noop,setAttribute:noop,getAttribute:()=>null,removeAttribute:noop,appendChild:noop,insertBefore:noop,remove:noop,click:noop,focus:noop,scrollIntoView:noop,querySelector:()=>null,querySelectorAll:()=>[],closest:()=>null,contains:()=>false,matches:()=>false,replaceChildren:noop,cloneNode(){return this},getContext:()=>({}),open:false,value:'',checked:false,textContent:'',innerHTML:'',hidden:false,disabled:false,options:[],files:[],parentElement:null,childNodes:[],children:[],firstChild:null,lastChild:null,nextSibling:null,parentNode:null,nodeType:1,tagName:'DIV'};
  let dummy;dummy=new Proxy(dummyTarget,{get(t,p){if(p in t)return t[p];if(p==='length')return 0;if(p==='firstElementChild'||p==='content')return dummy;return null},set(t,p,v){t[p]=v;return true}});
  const document=new Proxy({readyState:'complete',body:dummy,documentElement:dummy,head:dummy,activeElement:null,getElementById:()=>dummy,querySelector:()=>dummy,querySelectorAll:()=>[],createElement:()=>dummy,addEventListener:noop,removeEventListener:noop},{get(t,p){if(p in t)return t[p];return noop}});
  const storage=new Map(),localStorage={getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)};
  const indexedDB={open(){const req={};queueMicrotask(()=>req.onerror?.());return req}};
  const RealDate=Date;class FakeDate extends RealDate{constructor(...a){super(...(a.length?a:[nowMs]))}static now(){return nowMs}}
  const ctx={console,document,localStorage,sessionStorage:localStorage,indexedDB,location:{search:'',href:'http://offline/',origin:'http://offline/'},navigator:{userAgent:'node-offline',serviceWorker:null},window:null,self:null,globalThis:null,
    addEventListener:noop,removeEventListener:noop,dispatchEvent:()=>true,setTimeout:()=>0,clearTimeout:noop,setInterval:()=>0,clearInterval:noop,requestAnimationFrame:fn=>{try{fn(0)}catch{};return 0},cancelAnimationFrame:noop,
    fetch:async()=>({ok:false,status:599,headers:{get:()=>null},text:async()=>'{"response":[]}',json:async()=>({response:[]})}),AbortController,URL,URLSearchParams,TextEncoder,TextDecoder,crypto:globalThis.crypto,Blob,Response,Request,Headers,FormData:class{},
    Notification:{permission:'denied'},MutationObserver:class{observe(){}disconnect(){}},IntersectionObserver:class{observe(){}disconnect(){}},ResizeObserver:class{observe(){}disconnect(){}},Event:class{},CustomEvent:class{},FileReader:class{},performance:{now:()=>0},structuredClone,Date:FakeDate};
  ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;return ctx;
}
export function loadExactP2052Runtime({nowMs=Date.parse('2026-10-07T10:10:00Z')}={}){
  let code=fs.readFileSync(new URL('./p2052-main-runtime-exact.js',import.meta.url),'utf8');const close=code.lastIndexOf('})();');if(close<0)throw new Error('P2052_RUNTIME_CLOSURE_NOT_FOUND');
  const exportCode=`\nwindow.FE_B4_P2052_EXACT_EXPORT={compactFixtureMeta,autoModeForFixture,statMap,eventsCompact,oddsCompact,watchSnapshotFromBundle,watchEvaluate,watchApplyState,watchNewResetEvent:(typeof watchNewResetEvent==='function'?watchNewResetEvent:null),h1WatchSnapshotFromBundle,h1WatchEvaluate,h1WatchApplyState,h1WatchNewResetEvent:(typeof h1WatchNewResetEvent==='function'?h1WatchNewResetEvent:null),handicapAggregate,hcMarketFromRows,hcMarketHistory,hcEvaluate,feMasterRankMeta};\n`;
  code=code.slice(0,close)+exportCode+code.slice(close);const ctx=buildContext(nowMs);vm.runInNewContext(code,ctx,{timeout:8000,filename:'p2052-main-runtime-exact.js'});const bridge=fs.readFileSync(new URL('../batch04-old-exact-runtime-bridge.js',import.meta.url),'utf8');vm.runInNewContext(bridge,ctx,{timeout:3000,filename:'batch04-old-exact-runtime-bridge.js'});
  if(!ctx.FE_B4_P2052_EXACT_EXPORT||!ctx.FE_B4_OLD_EXACT)throw new Error('P2052_EXACT_EXPORT_OR_BRIDGE_MISSING');return ctx;
}
