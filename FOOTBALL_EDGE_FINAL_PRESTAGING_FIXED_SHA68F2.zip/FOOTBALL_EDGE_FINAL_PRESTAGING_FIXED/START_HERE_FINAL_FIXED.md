# Start here — FINAL PRESTAGING FIXED

Read FINAL_FIXED_RESULT.md, then docs/FINAL_FIXED_RUNBOOK.md. These supersede the historical result reports and manifests retained in the package. SHA256SUMS_FINAL_FIXED.txt is the authoritative manifest for the delivered bytes.

Exact current source is prediction_v2/ plus staging_kit/. No model coefficients or production frontend changed.

Offline verification:
```
node prediction_v2/test-final-blockers-fixed.mjs
node prediction_v2/test-batch05a-final-package.mjs
```
Run all test programs from this package's root (the two historical raw tests require that cwd):
```
for test_file in prediction_v2/test-*.mjs; do node "$test_file" || exit 1; done
```

29 test programs and 82 JS/MJS syntax checks passed in the supplied logs. Full HTTP runner/stop/restart/export probes use synthetic provider responses and SQLite. This is not a remote verification.

STOP at the staging approval checkpoint. Do not run deploy/db-init/provider commands without that approval.
