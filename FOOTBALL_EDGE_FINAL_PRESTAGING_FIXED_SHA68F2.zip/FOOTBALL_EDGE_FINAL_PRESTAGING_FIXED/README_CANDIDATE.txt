FOOTBALL EDGE PREDICTION V2 — B2..B9 CANDIDATE
Date: 2026-10-06
Production deploy: NO
Current TOP replacement: NO

Contains:
- provider-aware API budget candidate
- player/lineup/context feature layer
- shadow probability engine
- actual-market Asian Total/AH edge math
- relative opportunity ranking
- calibration / OLD-vs-NEW validation
- compact shadow/paper evidence
- persistent validation sync using existing D1 validation_results\n          - validation dashboard + OLD-vs-NEW comparison\n          - manual promotion gate (no auto-promotion)\n          - automated tests
- final staging smoke requires exact live hash + hide/validation markers

Frozen production rollback remains on:
freeze/frontend-p2052-production-before-prediction-v2-20261006

Candidate source branch:
work/prediction-v2-audit-20261006
